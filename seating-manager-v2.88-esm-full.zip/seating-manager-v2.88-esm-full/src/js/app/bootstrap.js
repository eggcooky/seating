// [L5] 앱 초기화 및 5개 도메인 이벤트 바인더 오케스트레이터 (BootstrapModule)
import { APP_VERSION } from '../core/constants.js';
import { checkForAppUpdate, getRuntimePkgSha256 } from '../features/updater-ui.js';
import { AppStore } from '../state/store.js';
import { updateSecretPresetIndicator } from '../ui/secret-indicators.js';
import { showToast } from '../ui/toast.js';
import { toggleLeftSidebar } from '../views/toolbar-ui.js';
import { bindClassroomControlEvents } from './binders/classroom-controls-binder.js';
import { bindFileIoEvents } from './binders/file-io-binder.js';
import { bindKeyboardAndSyncEvents } from './binders/keyboard-sync-binder.js';
import { bindModalsAndUpdaterEvents } from './binders/modals-updater-binder.js';
import { bindRevealAndRouletteEvents } from './binders/reveal-roulette-binder.js';
import { initMultiClassOnBoot } from './multiclass-coordinator.js';
import { wireAppCoordinators } from './view-sync-coordinator.js';

export function initApp() {
  // 0단계: 모든 Store 훅 및 View 핸들러를 최우선으로 동기 등록한다.
  wireAppCoordinators();

  const loaded = initMultiClassOnBoot();
  const hadCorruptedStorage = Boolean(AppStore.getState()._corruptedStorageRecovered);
  if (!loaded) {
    AppStore.resetState();
  }

  const dateEl = document.getElementById('paperDateDisplay');
  if (dateEl) {
    const today = new Date();
    dateEl.textContent = `${today.getFullYear()}. ${String(today.getMonth() + 1).padStart(2, '0')}. ${String(today.getDate()).padStart(2, '0')} 기준`;
  }

  // 공용 컨텍스트(모달 닫기 핸들러 및 제목 입력 참조)를 주입해 바인더 간 수평 import 없이 연결한다.
  const binderCtx = {
    titleInput: document.getElementById('classTitleInput'),
    modalClosers: Object.create(null)
  };

  bindFileIoEvents(binderCtx);
  bindClassroomControlEvents(binderCtx);
  bindRevealAndRouletteEvents(binderCtx);
  bindModalsAndUpdaterEvents(binderCtx);
  bindKeyboardAndSyncEvents(binderCtx);

  // 우측 화면 하단 및 설정 창 하단에 현재 버전(버전 vX.XX) 표시
  const footerVerText = document.getElementById('appVersionFooterText');
  if (footerVerText) footerVerText.textContent = '버전 v' + APP_VERSION;
  const rulesVerText = document.getElementById('rulesModalVersionText');
  if (rulesVerText) rulesVerText.textContent = '버전 v' + APP_VERSION;

  // 좁은 화면(폭 768px 미만)으로 처음 열었을 때는 좌측 명렬표 사이드바를 자동으로 접는다.
  if (typeof window !== 'undefined' && window.innerWidth > 0 && window.innerWidth < 768 && !AppStore.getState().sidebarCollapsed) {
    toggleLeftSidebar(true);
  }

  // 초기 화면 렌더링 (가리기·성별색상·명렬표·좌석표·인쇄뷰·조건배지 일괄 동기화)
  updateSecretPresetIndicator();
  AppStore.syncViews({ animate: false });
  if (hadCorruptedStorage) {
    showToast('저장된 데이터가 손상되어 백업 키에 보관하고 기본 상태로 시작했습니다.', 'warn');
  }

  // 부팅 직후 __app_pkg__ 해시를 1회 계산·캐시하고 임시 참조를 정리한다.
  getRuntimePkgSha256();
  // 앱 시작 시 조용히 최신 버전 및 파일 무결성 여부를 확인한다(1시간 간격 제한, 5초 타임아웃, 실패 시 무시).
  checkForAppUpdate(false);
}
