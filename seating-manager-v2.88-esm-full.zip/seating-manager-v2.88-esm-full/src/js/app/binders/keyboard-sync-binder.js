// [L5 Binder] 전역 단축키(Alt+Shift+T · Escape 14모달 우선순위) · 다중 탭 storage 동기화 · 전체화면 복구
import { MULTI_CLASS_META_KEY } from '../../core/constants.js';
import { runAutomatedSelfDiagnostics } from '../../diagnostics/index.js';
import { parseSeatFileText } from '../../domain/codec.js';
import { stopSequentialReveal } from '../../features/reveal-controller.js';
import { initRouletteSession, stopRouletteColumnAuto } from '../../features/roulette-controller.js';
import { closeTamperWarningModal } from '../../features/updater-ui.js';
import { playSoundEffect } from '../../infra/audio.js';
import { getActiveStorageKey } from '../../infra/storage-io.js';
import { clearUndoHistory } from '../../state/history-store.js';
import { AppStore } from '../../state/store.js';
import { markDirty } from '../../ui/dirty-indicator.js';
import { updateSecretPresetIndicator } from '../../ui/secret-indicators.js';
import { showToast } from '../../ui/toast.js';
import { renderClassroom } from '../../views/classroom-view.js';
import { closeStatusHistoryPopover } from '../../views/history-popover.js';
import { renderRoster } from '../../views/roster-view.js';
import { toggleLeftSidebar, updateLargeViewButtonUI } from '../../views/toolbar-ui.js';
import { toggleSecretRoom } from '../mode-coordinator.js';
import { refreshMultiClassMetaFromStorage, syncCurrentSlotTitle } from '../multiclass-coordinator.js';

export function bindKeyboardAndSyncEvents(ctx) {
  const titleInput = ctx && ctx.titleInput ? ctx.titleInput : document.getElementById('classTitleInput');

  // 전역 키보드 단축키:
  // - Alt + Shift + T: 내장 자가 진단 실행
  // - Escape(ESC): 최상위 모달 닫기(14종 우선순위) → 선택 취소 → 1줄 연속 룰렛 정지 → 팝오버 닫기
  window.addEventListener('keydown', (e) => {
    const state = AppStore.getState();
    if (e.altKey && e.shiftKey && (e.key === 'T' || e.key === 't' || e.code === 'KeyT')) {
      e.preventDefault();
      runAutomatedSelfDiagnostics();
      return;
    }
    if (e.key === 'Escape' || e.code === 'Escape') {
      const overflowModal = document.getElementById('frontRowOverflowModal');
      if (overflowModal && !overflowModal.classList.contains('hidden')) {
        overflowModal.classList.add('hidden');
        overflowModal.classList.remove('flex');
        return;
      }
      const tamperModalEl = document.getElementById('tamperWarningModal');
      if (tamperModalEl && !tamperModalEl.classList.contains('hidden')) {
        closeTamperWarningModal();
        return;
      }
      const closeBtnModalPairs = [
        ['alignLockConfirmModal', 'alignCancelModalBtn'],
        ['syncLockConflictModal', 'syncConflictCancelBtn'],
        ['printOptionsModal', 'closePrintOptionsModalBtn'],
        ['appUpdateModal', 'closeAppUpdateModalBtn'],
        ['jsonImportOverwriteConfirmModal', 'jsonImportOverwriteCancelBtn'],
        ['saveFileModal', 'cancelSaveModalBtn'],
        ['excelOverwriteConfirmModal', 'excelOverwriteCancelBtn'],
        ['excelPasteModal', 'closeExcelModalBtn'],
        ['secretNoticeModal', 'secretNoticeCloseBtn'],
        ['pairOptionModal', 'closePairOptionModalBtn'],
        ['rulesModal', 'closeRulesModalBtn'],
        ['selfTestModal', 'closeSelfTestModalBtn']
      ];
      for (const [modalId, closeBtnId] of closeBtnModalPairs) {
        if (modalId === 'selfTestModal' && AppStore.isRunningSelfDiagnostics()) continue;
        const mEl = document.getElementById(modalId);
        if (mEl && !mEl.classList.contains('hidden')) {
          if (ctx && ctx.modalClosers && typeof ctx.modalClosers[modalId] === 'function') {
            ctx.modalClosers[modalId]();
            return;
          }
          const cBtn = document.getElementById(closeBtnId);
          if (cBtn) cBtn.click();
          else { mEl.classList.add('hidden'); mEl.classList.remove('flex'); }
          return;
        }
      }
      if (state.selectedStudentId !== null) {
        state.selectedStudentId = null;
        playSoundEffect('unlock');
        renderRoster();
        renderClassroom(false);
        showToast('학생 자리 선택이 취소되었습니다.', 'info');
        return;
      }
      if (state.rouletteAutoColumnTarget !== null) {
        stopRouletteColumnAuto();
        showToast('1줄(세로) 연속 뽑기가 취소되었습니다.', 'info');
        return;
      }
      closeStatusHistoryPopover();
    }
  });

  window.addEventListener('beforeprint', () => AppStore.flushPendingCommit(true));
  window.addEventListener('beforeunload', () => AppStore.flushPendingCommit(false));

  // 다중 탭 동시 실행 시 다른 탭에서 저장한 최신 학급 상태를 실시간으로 동기화한다.
  window.addEventListener('storage', (e) => {
    const state = AppStore.getState();
    if (!e || !e.newValue) return;
    if (e.key === MULTI_CLASS_META_KEY) {
      if (!AppStore.isRunningSelfDiagnostics()) refreshMultiClassMetaFromStorage();
      return;
    }
    if (e.key !== getActiveStorageKey()) return;
    if (AppStore.isRunningSelfDiagnostics() || state.rouletteSpinning) return;
    try {
      const parsed = parseSeatFileText(e.newValue);
      if (AppStore.applyLoadedData(parsed, state.classTitle, true)) {
        const curState = AppStore.getState();
        AppStore.clearPendingCommitTimer();
        stopSequentialReveal();
        stopRouletteColumnAuto();
        AppStore.resetTransientSession();
        clearUndoHistory();
        curState.rulesModalBackup = null;
        curState.lastSavedAt = parsed.lastSavedAt || curState.lastSavedAt || null;
        if (curState.inSecretRoom && !curState.secretPos) {
          toggleSecretRoom(false, true);
        }
        if (titleInput) titleInput.value = curState.classTitle;
        syncCurrentSlotTitle(curState.classTitle);
        if (curState.rouletteOpen) {
          initRouletteSession(false);
        }
        updateSecretPresetIndicator();
        markDirty(false);
        AppStore.syncViews({ roster: true, classroom: true, animate: false, print: true, rules: true });
        const savedTimeEl = document.getElementById('savedTimeText');
        if (savedTimeEl && curState.lastSavedAt) {
          savedTimeEl.textContent = `자동저장 (${curState.lastSavedAt})`;
        }
        showToast('다른 탭에서 변경된 자리 배치가 자동으로 동기화되었습니다.', 'info');
      }
    } catch (err) {}
  });

  // 브라우저 전체화면 해제 시 크게 보기 상태 복구
  document.addEventListener('fullscreenchange', () => {
    const state = AppStore.getState();
    if (!document.fullscreenElement && state.largeViewEnabled) {
      state.largeViewEnabled = false;
      toggleLeftSidebar(false);
      updateLargeViewButtonUI();
      renderClassroom(false);
    }
  });
}
