import { escapeHtml } from '../core/utils.js';
import { getGridBounds } from './grid.js';
// [L1] 순수 상태 조회(Selector) 모듈 (DOM·전역상태 비의존)

export function getStudentById(state, id) {
  if (!state || !id) return null;
  const target = String(id);
  const list = state.students || [];
  for (let i = 0; i < list.length; i++) {
    if (String(list[i].id) === target) return list[i];
  }
  return null;
}

// 일반 화면 기준 해당 학생의 좌석 고정 여부를 반환한다 (불필요한 배열 재생성 없이 즉시 조회).
export function isNormalSeatLocked(state, studentId) {
  if (!state) return false;
  const target = String(studentId);
  const list = state.lockedIds;
  if (!list) return false;
  for (let i = 0; i < list.length; i++) {
    if (String(list[i]) === target) return true;
  }
  return false;
}

// 비밀의 방 기준 해당 학생의 좌석 고정 여부를 반환한다.
export function isSecretSeatLocked(state, studentId) {
  if (!state) return false;
  const target = String(studentId);
  const list = state.secretLockedIds;
  if (!list) return false;
  for (let i = 0; i < list.length; i++) {
    if (String(list[i]) === target) return true;
  }
  return false;
}

// 현재 활성화된 화면 기준 해당 학생의 좌석 고정 여부를 반환한다.
export function isSeatLocked(state, studentId) {
  if (!state) return false;
  return state.inSecretRoom ? isSecretSeatLocked(state, studentId) : isNormalSeatLocked(state, studentId);
}

export function isSeatHidden(state, studentId) {
  if (!state || state.inSecretRoom) return false;
  const target = String(studentId);
  const list = state.hiddenSeatIds;
  if (!list) return false;
  for (let i = 0; i < list.length; i++) {
    if (String(list[i]) === target) return true;
  }
  return false;
}

// 현재 활성화된 화면(일반 화면 또는 비밀의 방)의 좌석 좌표 맵을 반환한다.
export function getActivePosMap(state) {
  if (state.inSecretRoom) {
    if (!state.secretPos) {
      state.secretPos = JSON.parse(JSON.stringify(state.pos));
    }
    return state.secretPos;
  }
  return state.pos;
}

export function hasValidSecretPreset(state) {
  if (!state || !state.secretPos || typeof state.secretPos !== 'object') return false;
  return state.students.length > 0 && state.students.every(s => Array.isArray(state.secretPos[s.id]));
}

// 일반 화면에서 고정된 학생의 위치가 비밀의 방 위치와 다른 경우 해당 학생 이름 목록을 반환한다.
export function getLockedSeatConflicts(state) {
  if (!hasValidSecretPreset(state)) return [];
  const conflicts = [];
  state.students.forEach(s => {
    if (isNormalSeatLocked(state, s.id)) {
      const pubP = state.pos[s.id];
      const secP = state.secretPos[s.id];
      if (!pubP || !secP || pubP[0] !== secP[0] || pubP[1] !== secP[1]) {
        conflicts.push(s.name);
      }
    }
  });
  return conflicts;
}

// 일반 화면과 비밀의 방의 책상 좌표 집합이 일치하고 고정석 위치 충돌이 없는지 확인한다.
export function doesSecretLayoutMatchCurrent(state) {
  if (!hasValidSecretPreset(state)) return false;
  const normalCoords = state.students
    .map(s => state.pos[s.id])
    .filter(Boolean)
    .map(p => `${p[0]},${p[1]}`)
    .sort();
  const secretCoords = state.students
    .map(s => state.secretPos[s.id])
    .filter(Boolean)
    .map(p => `${p[0]},${p[1]}`)
    .sort();
  if (normalCoords.length !== secretCoords.length) return false;
  for (let i = 0; i < normalCoords.length; i++) {
    if (normalCoords[i] !== secretCoords[i]) return false;
  }
  if (getLockedSeatConflicts(state).length > 0) return false;
  return true;
}

// 현재 좌석 배치를 한글(HWP)·엑셀 붙여넣기용 탭 구분(TSV) 표 텍스트로 직렬화한다.
export function buildSeatingTsvText(state, orientation = 'student') {
  if (!state || !Array.isArray(state.students) || state.students.length === 0) return '';
  const posMap = state.pos || {};
  const { c0, c1, r0, r1 } = getGridBounds(state.students, posMap, false);
  const coordToStudent = new Map();
  state.students.forEach(s => {
    const p = posMap[s.id];
    if (Array.isArray(p) && p.length === 2) {
      coordToStudent.set(`${p[0]},${p[1]}`, s);
    }
  });

  const isTeacherView = orientation === 'teacher';
  const rows = [];
  if (isTeacherView) {
    for (let r = r1; r >= r0; r--) rows.push(r);
  } else {
    for (let r = r0; r <= r1; r++) rows.push(r);
  }
  const cols = [];
  if (isTeacherView) {
    for (let c = c1; c >= c0; c--) cols.push(c);
  } else {
    for (let c = c0; c <= c1; c++) cols.push(c);
  }

  const title = String(state.classTitle || '우리 반 자리 배치표').trim();
  const orientLabel = isTeacherView ? '교탁 게시용 - 교탁 아래' : '학생 게시용 - 교탁 위';
  const lines = [`${title} (${orientLabel})`];
  const podiumRow = Array(cols.length).fill('');
  if (podiumRow.length > 0) podiumRow[Math.floor(podiumRow.length / 2)] = '[교탁]';

  if (!isTeacherView) lines.push(podiumRow.join('\t'));

  rows.forEach(r => {
    const cells = cols.map(c => {
      const stu = coordToStudent.get(`${c},${r}`);
      if (!stu) return '';
      const cleanName = String(stu.name || '').replace(/[\t\r\n]+/g, ' ').trim();
      return `${stu.num} ${cleanName}`.trim();
    });
    lines.push(cells.join('\t'));
  });

  if (isTeacherView) lines.push(podiumRow.join('\t'));
  return lines.join('\n');
}

// 출력 모달의 음영 설정을 반영해 명렬표 행 또는 좌석 셀의 음영 여부를 반환한다.
function shouldShadeCopyCell(state, student, rosterIndexMap, forSeat = true) {
  if (!state || !student || state.printIncludeRoster === false) return false;
  if (forSeat && !state.printShadeSeatEnabled) return false;
  const mode = state.printShadeMode || 'female';
  if (mode === 'none') return false;
  const useGender = !(state.rules && state.rules.useGenderDistinction === false);
  if (mode === 'female' && useGender) return student.gender === '여';
  if (mode === 'male' && useGender) return student.gender === '남';
  if (mode === 'zebra') {
    const idx = rosterIndexMap.get(String(student.id));
    return typeof idx === 'number' && (idx % 2 === 1);
  }
  return false;
}

// 현재 좌석 배치를 인쇄용 카드 스타일(엑셀 외곽 테두리 보존 · 열 간격 · 성별 음영 · 8pt 명렬표)의 HTML <table>로 직렬화한다.
export function buildSeatingHtmlTable(state, orientation = 'student') {
  if (!state || !Array.isArray(state.students) || state.students.length === 0) return '';
  const posMap = state.pos || {};
  const { c0, c1, r0, r1 } = getGridBounds(state.students, posMap, false);
  const coordToStudent = new Map();
  state.students.forEach(s => {
    const p = posMap[s.id];
    if (Array.isArray(p) && p.length === 2) {
      coordToStudent.set(`${p[0]},${p[1]}`, s);
    }
  });
  const rosterIndexMap = new Map(state.students.map((s, idx) => [String(s.id), idx]));

  const isTeacherView = orientation === 'teacher';
  const rows = [];
  if (isTeacherView) { for (let r = r1; r >= r0; r--) rows.push(r); }
  else { for (let r = r0; r <= r1; r++) rows.push(r); }
  const cols = [];
  if (isTeacherView) { for (let c = c1; c >= c0; c--) cols.push(c); }
  else { for (let c = c0; c <= c1; c++) cols.push(c); }

  const totalGridCols = Math.max(1, cols.length * 2 - 1);
  const podiumSpan = cols.length === 1 ? 1 : Math.max(1, Math.min(totalGridCols, Math.round(totalGridCols * 0.45)));
  const leftPad = Math.floor((totalGridCols - podiumSpan) / 2);
  const rightPad = totalGridCols - podiumSpan - leftPad;

  const makeSpacerTr = (heightPx) =>
    `<tr style="height:${heightPx}px;"><td colspan="${totalGridCols}" style="background:transparent;padding:0;">&nbsp;</td></tr>`;

  const makePodiumTr = () => {
    const parts = [];
    if (leftPad > 0) parts.push(`<td colspan="${leftPad}" style="background:transparent;">&nbsp;</td>`);
    parts.push(`<td colspan="${podiumSpan}" style="border:1pt solid #000000;background:#ffffff;color:#0f172a;font-size:12pt;font-weight:bold;text-align:center;padding:8px 12px;letter-spacing:6px;">교&nbsp;&nbsp;탁</td>`);
    if (rightPad > 0) parts.push(`<td colspan="${rightPad}" style="background:transparent;">&nbsp;</td>`);
    return `<tr>${parts.join('')}</tr>`;
  };

  const bodyTrs = rows.map(r => {
    const tds = [];
    cols.forEach((c, ci) => {
      if (ci > 0) {
        tds.push('<td style="background:transparent;width:12px;padding:0;">&nbsp;</td>');
      }
      const stu = coordToStudent.get(`${c},${r}`);
      if (!stu) {
        tds.push('<td style="background:transparent;width:112px;height:62px;padding:0;">&nbsp;</td>');
      } else {
        const bg = shouldShadeCopyCell(state, stu, rosterIndexMap, true) ? '#e5e7eb' : '#ffffff';
        const cleanName = String(stu.name || '').replace(/[\t\r\n]+/g, ' ').trim();
        const numLabel = `${escapeHtml(stu.num)}번`;
        tds.push(
          `<td style="border:1pt solid #000000;background:${bg};width:112px;height:62px;vertical-align:top;padding:5px 8px 8px 8px;">` +
          `<div style="font-size:8.5pt;color:#475569;text-align:left;line-height:1.1;margin-bottom:4px;">${numLabel}</div>` +
          `<div style="font-size:13pt;font-weight:bold;color:#0f172a;text-align:center;line-height:1.25;">${escapeHtml(cleanName)}</div>` +
          `</td>`
        );
      }
    });
    return `<tr>${tds.join('')}</tr>`;
  });

  const allTrs = isTeacherView
    ? [...bodyTrs, makeSpacerTr(26), makePodiumTr()].join('')
    : [makePodiumTr(), makeSpacerTr(26), ...bodyTrs].join('');

  const seatTableHtml = `<table cellspacing="0" cellpadding="0" style="border-collapse:collapse;font-family:'Malgun Gothic','맑은 고딕',sans-serif;"><tbody>${allTrs}</tbody></table>`;
  if (state.printIncludeRoster === false) {
    return seatTableHtml;
  }

  // A안: 좌측 명렬표(8pt, 번호/성별 38px · 성명 76px / 성별 미표시 시 104px) + 우측 자리배치표 가로 2단 나란히 배치
  const useGender = !(state.rules && state.rules.useGenderDistinction === false);
  const headCells = useGender
    ? '<th style="border:1pt solid #000000;background:#f1f5f9;padding:2px 3px;text-align:center;font-weight:bold;width:38px;white-space:nowrap;">번호</th>' +
      '<th style="border:1pt solid #000000;background:#f1f5f9;padding:2px 6px;text-align:center;font-weight:bold;width:76px;white-space:nowrap;">성명</th>' +
      '<th style="border:1pt solid #000000;background:#f1f5f9;padding:2px 3px;text-align:center;font-weight:bold;width:38px;white-space:nowrap;">성별</th>'
    : '<th style="border:1pt solid #000000;background:#f1f5f9;padding:2px 3px;text-align:center;font-weight:bold;width:38px;white-space:nowrap;">번호</th>' +
      '<th style="border:1pt solid #000000;background:#f1f5f9;padding:2px 6px;text-align:center;font-weight:bold;width:104px;white-space:nowrap;">성명</th>';
  const rosterRowsHtml = state.students.map((stu, idx) => {
    const bg = shouldShadeCopyCell(state, stu, rosterIndexMap, false) ? '#e5e7eb' : '#ffffff';
    const num = escapeHtml(stu.num || (idx + 1));
    const name = escapeHtml(String(stu.name || '').replace(/[\t\r\n]+/g, ' ').trim());
    if (useGender) {
      return `<tr><td style="border:1pt solid #000000;background:${bg};padding:2px 3px;text-align:center;width:38px;white-space:nowrap;">${num}</td><td style="border:1pt solid #000000;background:${bg};padding:2px 6px;text-align:center;font-weight:bold;width:76px;white-space:nowrap;">${name}</td><td style="border:1pt solid #000000;background:${bg};padding:2px 3px;text-align:center;width:38px;white-space:nowrap;">${escapeHtml(stu.gender || '')}</td></tr>`;
    }
    return `<tr><td style="border:1pt solid #000000;background:${bg};padding:2px 3px;text-align:center;width:38px;white-space:nowrap;">${num}</td><td style="border:1pt solid #000000;background:${bg};padding:2px 6px;text-align:center;font-weight:bold;width:104px;white-space:nowrap;">${name}</td></tr>`;
  }).join('');
  const rosterTableHtml = `<table cellspacing="0" cellpadding="2" style="border-collapse:collapse;font-family:'Malgun Gothic','맑은 고딕',sans-serif;font-size:8pt;"><thead><tr>${headCells}</tr></thead><tbody>${rosterRowsHtml}</tbody></table>`;

  return (
    `<table cellspacing="0" cellpadding="0" style="border-collapse:collapse;font-family:'Malgun Gothic','맑은 고딕',sans-serif;"><tbody><tr>` +
    `<td style="background:transparent;vertical-align:top;padding:0;">${rosterTableHtml}</td>` +
    `<td style="background:transparent;width:24px;padding:0;">&nbsp;</td>` +
    `<td style="background:transparent;vertical-align:top;padding:0;">${seatTableHtml}</td>` +
    `</tr></tbody></table>`
  );
}
