// [L4] 첫 실행 안내 · 일반/비밀의 방 전용 도움말 모달 및 공용 SVG 컷아웃 스포트라이트 렌더러
import { markHelpGuideSeen, markSecretHelpGuideSeen } from '../infra/storage-io.js';
import { AppStore } from '../state/store.js';
import { toggleLeftSidebar } from './toolbar-ui.js';

const SVG_NS = 'http://www.w3.org/2000/svg';
const SPOTLIGHT_MIN_VIEWPORT_WIDTH = 960;
const HOLE_PAD = 5;
const CALLOUT_GAP = 10;

// 일반 화면 6개 핵심 메뉴 타깃 정의 (②와 ⑥은 같은 행이므로 방향 분리)
const NORMAL_SPOTLIGHT_TARGETS = [
  { num: 1, selector: '#openExcelPasteModalBtn', label: '엑셀 명단 붙여넣기', placement: 'bottom' },
  { num: 2, selector: '#openRulesModalBtn', label: '열·성별·짝·앞줄', placement: 'top' },
  { num: 3, selector: '#randomShuffleBtn', label: '자동 배정 · 룰렛', placement: 'top' },
  { num: 4, selector: '#classroomStage .seat-box-responsive, #classroomStage .seat-box-large', fallback: '#seatingPaperCard', label: '클릭 교환·이동·고정', placement: 'top' },
  { num: 5, selector: '#printA4Btn', label: '인쇄 · 이미지 · 표 복사', placement: 'bottom' },
  { num: 6, selector: '#multiClassToggleWrapper', label: '최대 7학급 전환', placement: 'right' }
];

// 비밀의 방 5개 핵심 타깃 정의 (②와 ⑤는 좌측 배너 같은 행이므로 bottom/right로 방향 분리)
const SECRET_SPOTLIGHT_TARGETS = [
  { num: 1, selector: '#classroomStage .seat-box-responsive, #classroomStage .seat-box-large', fallback: '#seatingPaperCard', label: '사전 배치 클릭 수정', placement: 'top' },
  { num: 2, selector: '#copyCurrentToSecretBtn', label: '일반 자리 복사', placement: 'bottom' },
  { num: 3, selector: '#openPairOptionModalBtn', label: '거리두기 · 붙이기', placement: 'top' },
  { num: 4, selector: '#randomShuffleBtn', label: '일반 복귀 후 Ctrl+클릭', placement: 'top' },
  { num: 5, selector: '#exitSecretRoomBtn', label: '저장 후 일반 복귀', placement: 'right' }
];

const HELP_GUIDE_CONFIGS = {
  normal: {
    modalId: 'helpGuideModal',
    cardId: 'helpGuideModalCard',
    holesId: 'helpSpotlightHoles',
    calloutsId: 'helpSpotlightCallouts',
    subtitleId: 'helpGuideSubtitle',
    stepListId: 'helpGuideStepList',
    stepAttr: 'data-help-step',
    checkWrapId: 'helpDontShowAgainWrap',
    checkId: 'helpDontShowAgainCheckbox',
    startBtnId: 'startHelpGuideBtn',
    autoStartLabel: '시작하기',
    fallbackSubtitle: '설치 없이 브라우저에서 바로 쓰는 오프라인 자리 배치 도구',
    markSeen: markHelpGuideSeen,
    targets: NORMAL_SPOTLIGHT_TARGETS
  },
  secret: {
    modalId: 'secretHelpGuideModal',
    cardId: 'secretHelpGuideModalCard',
    holesId: 'secretHelpSpotlightHoles',
    calloutsId: 'secretHelpSpotlightCallouts',
    subtitleId: 'secretHelpGuideSubtitle',
    stepListId: 'secretHelpGuideStepList',
    stepAttr: 'data-secret-help-step',
    checkWrapId: 'secretHelpDontShowAgainWrap',
    checkId: 'secretHelpDontShowAgainCheckbox',
    startBtnId: 'startSecretHelpGuideBtn',
    autoStartLabel: '비밀의 방 시작하기',
    fallbackSubtitle: '학생 모르게 목표 자리와 비공개 조건을 미리 구성하는 교사 전용 공간입니다',
    markSeen: markSecretHelpGuideSeen,
    targets: SECRET_SPOTLIGHT_TARGETS
  }
};

let _activeMode = null;
let _isAutoFirstRunOpen = false;
let _lastTriggerEl = null;
let _resizeRafId = 0;
let _openRafId = 0;
let _sidebarSettleTimer = null;
let _temporarilyExpandedSidebar = false;
let _listenersAttached = false;
let _focusedStepNum = null;

function isRectVisibleInViewport(rect) {
  if (!rect || rect.width <= 0 || rect.height <= 0) return false;
  return rect.right > 4 && rect.left < window.innerWidth - 4 && rect.bottom > 4 && rect.top < window.innerHeight - 4;
}

function rectsOverlap(a, b, pad = 6) {
  return !(
    a.right + pad <= b.left ||
    a.left - pad >= b.right ||
    a.bottom + pad <= b.top ||
    a.top - pad >= b.bottom
  );
}

function resolveTargetElement(spec, modalRect) {
  const candidates = document.querySelectorAll(spec.selector);
  if (candidates.length === 1) {
    const r = candidates[0].getBoundingClientRect();
    if (isRectVisibleInViewport(r)) return candidates[0];
  } else if (candidates.length > 1) {
    // 책상 등 다수 요소인 경우 모달 카드와 겹치지 않는 첫 가시 요소를 우선 선택
    let firstVisible = null;
    for (const el of candidates) {
      const r = el.getBoundingClientRect();
      if (!isRectVisibleInViewport(r)) continue;
      if (!firstVisible) firstVisible = el;
      if (!modalRect || !rectsOverlap(r, modalRect, 4)) return el;
    }
    if (firstVisible) return firstVisible;
  }
  if (spec.fallback) {
    const fb = document.querySelector(spec.fallback);
    if (fb && isRectVisibleInViewport(fb.getBoundingClientRect())) return fb;
  }
  return null;
}

function computeCalloutPosition(holeRect, width, height, placement) {
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  let left = holeRect.left;
  let top = holeRect.bottom + CALLOUT_GAP;
  let arrow = '↑';

  if (placement === 'top') {
    left = holeRect.left + (holeRect.width - width) / 2;
    top = holeRect.top - height - CALLOUT_GAP;
    arrow = '↓';
  } else if (placement === 'bottom') {
    left = holeRect.left + (holeRect.width - width) / 2;
    top = holeRect.bottom + CALLOUT_GAP;
    arrow = '↑';
  } else if (placement === 'right') {
    left = holeRect.right + CALLOUT_GAP;
    top = holeRect.top + (holeRect.height - height) / 2;
    arrow = '←';
  } else if (placement === 'left') {
    left = holeRect.left - width - CALLOUT_GAP;
    top = holeRect.top + (holeRect.height - height) / 2;
    arrow = '→';
  }

  left = Math.max(8, Math.min(vw - width - 8, left));
  top = Math.max(8, Math.min(vh - height - 8, top));
  return {
    left,
    top,
    right: left + width,
    bottom: top + height,
    arrow
  };
}

function getPlacementTryOrder(primary) {
  if (primary === 'top') return ['top', 'bottom', 'left', 'right'];
  if (primary === 'bottom') return ['bottom', 'top', 'left', 'right'];
  if (primary === 'right') return ['right', 'left', 'top', 'bottom'];
  return ['left', 'right', 'top', 'bottom'];
}

function clearHelpSpotlights(mode = _activeMode || 'normal') {
  const cfg = HELP_GUIDE_CONFIGS[mode];
  if (!cfg) return;
  const holesEl = document.getElementById(cfg.holesId);
  const calloutsEl = document.getElementById(cfg.calloutsId);
  if (holesEl) holesEl.textContent = '';
  if (calloutsEl) calloutsEl.textContent = '';
}

export function setFocusedHelpStep(stepNum, mode = _activeMode || 'normal') {
  const cfg = HELP_GUIDE_CONFIGS[mode];
  if (!cfg) return;
  _focusedStepNum = stepNum === null || stepNum === undefined ? null : Number(stepNum);
  const calloutsEl = document.getElementById(cfg.calloutsId);
  const stepListEl = document.getElementById(cfg.stepListId);

  if (stepListEl) {
    stepListEl.querySelectorAll(`[${cfg.stepAttr}]`).forEach((item) => {
      const n = Number(item.getAttribute(cfg.stepAttr));
      item.classList.toggle('is-active', _focusedStepNum !== null && n === _focusedStepNum);
    });
  }
  if (calloutsEl) {
    calloutsEl.querySelectorAll('[data-spot-step]').forEach((el) => {
      const n = Number(el.getAttribute('data-spot-step'));
      const hasFocus = _focusedStepNum !== null;
      el.classList.toggle('is-focused', hasFocus && n === _focusedStepNum);
      el.classList.toggle('is-dimmed', hasFocus && n !== _focusedStepNum);
    });
  }
}

function renderHelpSpotlights(mode = _activeMode || 'normal') {
  const cfg = HELP_GUIDE_CONFIGS[mode];
  if (!cfg) return;
  const modalEl = document.getElementById(cfg.modalId);
  const cardEl = document.getElementById(cfg.cardId);
  const holesEl = document.getElementById(cfg.holesId);
  const calloutsEl = document.getElementById(cfg.calloutsId);
  const subtitleEl = document.getElementById(cfg.subtitleId);

  if (!modalEl || modalEl.classList.contains('hidden') || !holesEl || !calloutsEl) return;
  clearHelpSpotlights(mode);

  // 좁은 화면(960px 미만)에서는 스포트라이트 컷아웃·말풍선을 생략해 모달 가독성을 보호한다.
  if (window.innerWidth < SPOTLIGHT_MIN_VIEWPORT_WIDTH) {
    if (subtitleEl) subtitleEl.textContent = cfg.fallbackSubtitle;
    return;
  }

  const modalRect = cardEl ? cardEl.getBoundingClientRect() : null;
  const placedCalloutRects = [];
  let renderedCount = 0;

  for (const spec of cfg.targets) {
    const targetEl = resolveTargetElement(spec, modalRect);
    if (!targetEl) continue;
    const rawRect = targetEl.getBoundingClientRect();
    // 모달 카드 아래에 완전히 가려진 요소는 컷아웃 제외
    if (modalRect && rectsOverlap(rawRect, modalRect, -4)) continue;

    const hLeft = Math.max(2, rawRect.left - HOLE_PAD);
    const hTop = Math.max(2, rawRect.top - HOLE_PAD);
    const hRight = Math.min(window.innerWidth - 2, rawRect.right + HOLE_PAD);
    const hBottom = Math.min(window.innerHeight - 2, rawRect.bottom + HOLE_PAD);
    const holeRect = {
      left: hLeft,
      top: hTop,
      right: hRight,
      bottom: hBottom,
      width: Math.max(0, hRight - hLeft),
      height: Math.max(0, hBottom - hTop)
    };

    // 1) SVG 마스크 컷아웃(검정 rect = 투명 구멍)
    const maskRect = document.createElementNS(SVG_NS, 'rect');
    maskRect.setAttribute('x', String(Math.round(holeRect.left)));
    maskRect.setAttribute('y', String(Math.round(holeRect.top)));
    maskRect.setAttribute('width', String(Math.round(holeRect.width)));
    maskRect.setAttribute('height', String(Math.round(holeRect.height)));
    maskRect.setAttribute('rx', '12');
    maskRect.setAttribute('fill', 'black');
    holesEl.appendChild(maskRect);

    // 2) 노란 강조 테두리 링
    const ringEl = document.createElement('div');
    ringEl.className = 'help-spot-ring';
    ringEl.setAttribute('data-spot-step', String(spec.num));
    ringEl.style.left = `${Math.round(holeRect.left)}px`;
    ringEl.style.top = `${Math.round(holeRect.top)}px`;
    ringEl.style.width = `${Math.round(holeRect.width)}px`;
    ringEl.style.height = `${Math.round(holeRect.height)}px`;
    calloutsEl.appendChild(ringEl);
    renderedCount++;

    // 3) 번호 화살표 말풍선 (실제 크기 측정 후 모달·타 말풍선 겹침 회피)
    const calloutEl = document.createElement('div');
    calloutEl.className = 'help-spot-callout';
    calloutEl.setAttribute('data-spot-step', String(spec.num));

    const arrowSpan = document.createElement('span');
    arrowSpan.className = 'help-spot-arrow';
    arrowSpan.textContent = '→';
    const badgeSpan = document.createElement('span');
    badgeSpan.className = 'help-spot-badge';
    badgeSpan.textContent = String(spec.num);
    const labelSpan = document.createElement('span');
    labelSpan.textContent = spec.label;

    calloutEl.appendChild(arrowSpan);
    calloutEl.appendChild(badgeSpan);
    calloutEl.appendChild(labelSpan);
    calloutEl.style.left = '-9999px';
    calloutEl.style.top = '-9999px';
    calloutsEl.appendChild(calloutEl);

    const cw = calloutEl.offsetWidth || 130;
    const ch = calloutEl.offsetHeight || 28;
    const tryOrder = getPlacementTryOrder(spec.placement);
    let chosen = null;

    for (const dir of tryOrder) {
      const candidate = computeCalloutPosition(holeRect, cw, ch, dir);
      const hitsModal = modalRect && rectsOverlap(candidate, modalRect, 6);
      const hitsOther = placedCalloutRects.some((r) => rectsOverlap(candidate, r, 4));
      const hitsHole = rectsOverlap(candidate, holeRect, 4);
      if (!hitsModal && !hitsOther && !hitsHole) {
        chosen = candidate;
        break;
      }
    }

    if (chosen) {
      arrowSpan.textContent = chosen.arrow;
      calloutEl.style.left = `${Math.round(chosen.left)}px`;
      calloutEl.style.top = `${Math.round(chosen.top)}px`;
      placedCalloutRects.push(chosen);
    } else {
      // 모든 방향이 겹치면 말풍선만 숨기고 노란 링은 유지
      calloutEl.remove();
    }
  }

  if (subtitleEl) {
    if (renderedCount > 0) {
      subtitleEl.textContent = '';
      subtitleEl.append(
        document.createTextNode('배경의 노란 번호와 아래 항목을 함께 확인하세요'),
        document.createElement('br'),
        document.createTextNode('(항목에 마우스를 올리면 해당 위치가 강조됩니다)')
      );
    } else {
      subtitleEl.textContent = cfg.fallbackSubtitle;
    }
  }
  if (_focusedStepNum !== null) {
    setFocusedHelpStep(_focusedStepNum, mode);
  }
}

function handleViewportRelayout() {
  if (_resizeRafId) cancelAnimationFrame(_resizeRafId);
  _resizeRafId = requestAnimationFrame(() => {
    _resizeRafId = 0;
    if (_activeMode) renderHelpSpotlights(_activeMode);
  });
}

function attachSpotlightListeners() {
  if (_listenersAttached) return;
  window.addEventListener('resize', handleViewportRelayout);
  _listenersAttached = true;
}

function detachSpotlightListeners() {
  if (_resizeRafId) {
    cancelAnimationFrame(_resizeRafId);
    _resizeRafId = 0;
  }
  if (!_listenersAttached) return;
  window.removeEventListener('resize', handleViewportRelayout);
  _listenersAttached = false;
}

function closeHelpGuideByMode(mode, { persistSeen = true, preserveSidebarExpand = false } = {}) {
  const cfg = HELP_GUIDE_CONFIGS[mode];
  if (!cfg) return false;
  const modalEl = document.getElementById(cfg.modalId);
  if (!modalEl || modalEl.classList.contains('hidden')) return false;

  const checkEl = document.getElementById(cfg.checkId);
  if (persistSeen && _activeMode === mode && _isAutoFirstRunOpen && (!checkEl || checkEl.checked)) {
    cfg.markSeen();
  }

  if (_openRafId) {
    cancelAnimationFrame(_openRafId);
    _openRafId = 0;
  }
  if (_sidebarSettleTimer) {
    clearTimeout(_sidebarSettleTimer);
    _sidebarSettleTimer = null;
  }
  clearHelpSpotlights(mode);
  setFocusedHelpStep(null, mode);
  modalEl.classList.add('hidden');
  modalEl.classList.remove('flex');
  modalEl.classList.remove('help-sidebar-open');

  if (_activeMode === mode) {
    detachSpotlightListeners();
    _activeMode = null;
    _isAutoFirstRunOpen = false;
  }

  if (!preserveSidebarExpand && _temporarilyExpandedSidebar) {
    _temporarilyExpandedSidebar = false;
    if (!AppStore.isRunningSelfDiagnostics()) {
      toggleLeftSidebar(true);
    }
  }

  if (!preserveSidebarExpand) {
    if (_lastTriggerEl && typeof _lastTriggerEl.focus === 'function' && document.contains(_lastTriggerEl)) {
      _lastTriggerEl.focus();
    }
    _lastTriggerEl = null;
  }
  return true;
}

function openHelpGuideByMode(mode, { isAutoFirstRun = false } = {}) {
  const cfg = HELP_GUIDE_CONFIGS[mode];
  if (!cfg) return false;
  if (isAutoFirstRun && AppStore.isRunningSelfDiagnostics()) return false;
  if (mode === 'secret' && !AppStore.getState().inSecretRoom) return false;

  const modalEl = document.getElementById(cfg.modalId);
  if (!modalEl) return false;

  // 다른 모드 도움말이 열려 있으면 먼저 조용히 닫는다(사이드바 임시 펼침 상태는 이어받음).
  const otherMode = mode === 'secret' ? 'normal' : 'secret';
  const wasOtherOpen = closeHelpGuideByMode(otherMode, { persistSeen: false, preserveSidebarExpand: true });

  const alreadyOpen = !modalEl.classList.contains('hidden');
  _activeMode = mode;
  _isAutoFirstRunOpen = Boolean(isAutoFirstRun);
  _focusedStepNum = null;

  if (!alreadyOpen && !wasOtherOpen) {
    _lastTriggerEl = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    if (
      window.innerWidth >= SPOTLIGHT_MIN_VIEWPORT_WIDTH &&
      !AppStore.isRunningSelfDiagnostics() &&
      AppStore.getState().sidebarCollapsed
    ) {
      toggleLeftSidebar(false);
      _temporarilyExpandedSidebar = true;
    } else {
      _temporarilyExpandedSidebar = false;
    }
  }
  modalEl.classList.toggle('help-sidebar-open', !AppStore.getState().sidebarCollapsed);

  const checkWrap = document.getElementById(cfg.checkWrapId);
  const checkEl = document.getElementById(cfg.checkId);
  const startBtn = document.getElementById(cfg.startBtnId);

  if (checkWrap) {
    if (_isAutoFirstRunOpen) {
      checkWrap.classList.remove('hidden');
      checkWrap.classList.add('flex');
    } else {
      checkWrap.classList.add('hidden');
      checkWrap.classList.remove('flex');
    }
  }
  if (checkEl && _isAutoFirstRunOpen) {
    checkEl.checked = true;
  }
  if (startBtn) {
    startBtn.textContent = _isAutoFirstRunOpen ? cfg.autoStartLabel : '닫기';
  }

  modalEl.classList.remove('hidden');
  modalEl.classList.add('flex');
  attachSpotlightListeners();
  if (_openRafId) cancelAnimationFrame(_openRafId);
  if (_sidebarSettleTimer) {
    clearTimeout(_sidebarSettleTimer);
    _sidebarSettleTimer = null;
  }
  _openRafId = requestAnimationFrame(() => {
    _openRafId = 0;
    if (modalEl.classList.contains('hidden') || _activeMode !== mode) return;
    renderHelpSpotlights(mode);
    if (startBtn) startBtn.focus();
  });
  if (_temporarilyExpandedSidebar) {
    _sidebarSettleTimer = setTimeout(() => {
      _sidebarSettleTimer = null;
      if (!modalEl.classList.contains('hidden') && _activeMode === mode) renderHelpSpotlights(mode);
    }, 320);
  }
  return true;
}

export function openHelpGuideModal({ isAutoFirstRun = false } = {}) {
  return openHelpGuideByMode('normal', { isAutoFirstRun });
}

export function closeHelpGuideModal({ persistSeen = true } = {}) {
  return closeHelpGuideByMode('normal', { persistSeen });
}

export function openSecretHelpGuideModal({ isAutoFirstRun = false } = {}) {
  return openHelpGuideByMode('secret', { isAutoFirstRun });
}

export function closeSecretHelpGuideModal({ persistSeen = true } = {}) {
  return closeHelpGuideByMode('secret', { persistSeen });
}

export function closeAnyHelpGuideModal({ persistSeen = false } = {}) {
  const closedSecret = closeHelpGuideByMode('secret', { persistSeen });
  const closedNormal = closeHelpGuideByMode('normal', { persistSeen });
  return closedSecret || closedNormal;
}
