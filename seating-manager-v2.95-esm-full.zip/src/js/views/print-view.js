import { buildSeatingHtmlTable, buildSeatingTsvText } from '../domain/seat-queries.js';
// [L4] A4 가로 인쇄 화면 렌더링, 출력 옵션 모달 및 고해상도 이미지 캡처
import {
  escapeHtml,
  formatStudentNumCompact,
  formatStudentNumLabel,
  hasWideStudentNum,
  sanitizeFileName
} from '../core/utils.js';
import { getGridBounds } from '../domain/grid.js';
import { AppStore } from '../state/store.js';
import { createPodiumAndMessageElement } from '../ui/podium.js';
import { showToast } from '../ui/toast.js';

// 선택된 음영 옵션('zebra' | 'female' | 'male' | 'none')에 따라 명렬표 행 및 우측 좌석 칸의 흑백 음영 적용 여부를 판별한다.
function shouldShadePrintItem(student, zeroBasedOrderIdx, shadeMode, includeRoster, useGender) {
  if (!includeRoster || shadeMode === 'none' || !student) return false;
  if (shadeMode === 'zebra') {
    return (zeroBasedOrderIdx % 2) === 1;
  }
  if (shadeMode === 'female') {
    return Boolean(useGender && student.gender === '여');
  }
  if (shadeMode === 'male') {
    return Boolean(useGender && student.gender === '남');
  }
  return false;
}

function getEffectivePrintOptions(state) {
  const useGender = state.rules && state.rules.useGenderDistinction !== false;
  const orientation = (state.printOrientation === 'teacher' || state.printOrientation === 'student')
    ? state.printOrientation
    : (state.viewOrientation === 'teacher' ? 'teacher' : 'student');
  const includeRoster = state.printIncludeRoster !== false;
  let shadeMode = ['zebra', 'female', 'male', 'none'].includes(state.printShadeMode)
    ? state.printShadeMode
    : 'female';
  if (!useGender && (shadeMode === 'female' || shadeMode === 'male')) {
    shadeMode = 'zebra';
  }
  const shadeSeatEnabled = Boolean(includeRoster && shadeMode !== 'none' && state.printShadeSeatEnabled !== false);
  return { orientation, includeRoster, shadeMode, shadeSeatEnabled, useGender };
}

export function updatePrintOptionsModalUI() {
  const state = AppStore.getState();
  const { orientation, includeRoster, shadeMode, useGender } = getEffectivePrintOptions(state);

  document.querySelectorAll('.print-orient-btn').forEach(btn => {
    const val = btn.getAttribute('data-print-orient');
    const active = val === orientation;
    btn.className = active
      ? 'print-orient-btn py-2.5 px-3 rounded-xl text-xs font-extrabold border transition flex flex-col items-center justify-center gap-0.5 bg-indigo-600 text-white border-indigo-600 shadow-sm'
      : 'print-orient-btn py-2.5 px-3 rounded-xl text-xs font-bold border transition flex flex-col items-center justify-center gap-0.5 bg-white text-slate-700 border-slate-200 hover:bg-slate-100';
  });

  document.querySelectorAll('.print-roster-btn').forEach(btn => {
    const isOn = btn.getAttribute('data-print-roster') === 'on';
    const active = isOn === includeRoster;
    btn.className = active
      ? 'print-roster-btn py-2 px-3 rounded-xl text-xs font-extrabold border transition flex items-center justify-center gap-1.5 bg-indigo-600 text-white border-indigo-600 shadow-sm'
      : 'print-roster-btn py-2 px-3 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-1.5 bg-white text-slate-700 border-slate-200 hover:bg-slate-100';
  });

  const shadeSection = document.getElementById('printShadeOptionsSection');
  if (shadeSection) {
    if (includeRoster) {
      shadeSection.classList.remove('opacity-40', 'pointer-events-none');
    } else {
      shadeSection.classList.add('opacity-40', 'pointer-events-none');
    }
  }

  document.querySelectorAll('.print-shade-btn').forEach(btn => {
    const val = btn.getAttribute('data-print-shade');
    const genderDisabled = !useGender && (val === 'female' || val === 'male');
    btn.disabled = genderDisabled;
    const active = val === shadeMode && !genderDisabled;
    if (genderDisabled) {
      btn.className = 'print-shade-btn py-2 px-2.5 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-1 bg-slate-100 text-slate-400 border-slate-200 opacity-50 cursor-not-allowed';
    } else if (active) {
      btn.className = 'print-shade-btn py-2 px-2.5 rounded-xl text-xs font-extrabold border transition flex items-center justify-center gap-1 bg-indigo-600 text-white border-indigo-600 shadow-sm';
    } else {
      btn.className = 'print-shade-btn py-2 px-2.5 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-1 bg-white text-slate-700 border-slate-200 hover:bg-slate-100';
    }
  });

  const shadeSeatToggle = document.getElementById('printShadeToSeatToggle');
  const shadeSeatRow = document.getElementById('printShadeToSeatRow');
  if (shadeSeatToggle) {
    const isNone = shadeMode === 'none';
    shadeSeatToggle.disabled = !includeRoster || isNone;
    shadeSeatToggle.checked = !isNone && state.printShadeSeatEnabled !== false;
  }
  if (shadeSeatRow) {
    if (shadeMode === 'none') {
      shadeSeatRow.classList.add('opacity-40', 'pointer-events-none');
    } else {
      shadeSeatRow.classList.remove('opacity-40', 'pointer-events-none');
    }
  }
}

export function openPrintOptionsModal() {
  const state = AppStore.getState();
  AppStore.flushPendingCommit(false);
  const hadSelectedStudent = state.selectedStudentId !== null;
  state.selectedStudentId = null;
  if (hadSelectedStudent) {
    AppStore.requestRosterAndClassroomRender(false);
  }
  if (state.printOrientation !== 'teacher' && state.printOrientation !== 'student') {
    state.printOrientation = state.viewOrientation === 'teacher' ? 'teacher' : 'student';
  }
  if (state.rules && state.rules.useGenderDistinction === false) {
    if (state.printShadeMode === 'female' || state.printShadeMode === 'male') {
      state.printShadeMode = 'zebra';
      state.printShadeSeatEnabled = false;
    }
  }
  updatePrintOptionsModalUI();
  renderPrintView();
  const modal = document.getElementById('printOptionsModal');
  if (modal) {
    modal.classList.remove('hidden');
    modal.classList.add('flex');
  }
}

export function closePrintOptionsModal() {
  const modal = document.getElementById('printOptionsModal');
  if (modal) {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
  }
}

function formatTodayDateLabel() {
  const today = new Date();
  return `${today.getFullYear()}. ${String(today.getMonth() + 1).padStart(2, '0')}. ${String(today.getDate()).padStart(2, '0')} 기준`;
}

export function renderPrintView() {
  const state = AppStore.getState();
  AppStore.setPrintViewDirty(false);
  const tbody = document.getElementById('printRosterTableBody');
  const printStage = document.getElementById('printClassroomStage');
  const rosterWrapper = document.getElementById('printRosterWrapper');
  if (!tbody || !printStage) return;

  const { orientation, includeRoster, shadeMode, shadeSeatEnabled, useGender } = getEffectivePrintOptions(state);
  const isStudentView = orientation === 'student';

  if (rosterWrapper) {
    if (includeRoster) {
      rosterWrapper.classList.remove('hidden');
      rosterWrapper.classList.add('flex');
    } else {
      rosterWrapper.classList.add('hidden');
      rosterWrapper.classList.remove('flex');
    }
  }

  const printTable = document.getElementById('printRosterTable');
  if (printTable) {
    const count = state.students.length;
    const fontSizeClass = count > 38 ? 'text-[7.5pt]' : count > 32 ? 'text-[8.5pt]' : 'text-[9.5pt]';
    printTable.className = `w-full h-full border-collapse border-[1.5px] border-black ${fontSizeClass} leading-none table-fixed`;
  }

  const wideNum = hasWideStudentNum(state.students);
  const printNumTh = document.getElementById('printHeaderNumTh');
  const printNameTh = document.getElementById('printHeaderNameTh');
  const printGenderTh = document.getElementById('printHeaderGenderTh');
  if (printNumTh) {
    printNumTh.className = `border border-black px-1 text-center ${wideNum ? 'w-[28%]' : 'w-[22%]'}`;
  }
  if (printNameTh && printGenderTh) {
    if (useGender) {
      printNameTh.className = `border border-black px-1 text-center ${wideNum ? 'w-[48%]' : 'w-[54%]'}`;
      printGenderTh.className = 'border border-black px-1 text-center w-[24%]';
    } else {
      printNameTh.className = `border border-black px-1 text-center ${wideNum ? 'w-[72%]' : 'w-[78%]'}`;
      printGenderTh.className = 'hidden';
    }
  }

  tbody.innerHTML = '';
  state.students.forEach((st, idx) => {
    const tr = document.createElement('tr');
    const shaded = shouldShadePrintItem(st, idx, shadeMode, includeRoster, useGender);
    tr.className = shaded ? 'print-female-row' : '';
    const compactNum = escapeHtml(formatStudentNumCompact(st, idx + 1));
    if (useGender) {
      tr.innerHTML = `
        <td class="border border-black px-1 text-center font-medium whitespace-nowrap">${compactNum}</td>
        <td class="border border-black px-1 text-center font-semibold tracking-wide" style="max-width: 26mm; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${escapeHtml(st.name)}</td>
        <td class="border border-black px-1 text-center font-medium whitespace-nowrap">${escapeHtml(st.gender)}</td>
      `;
    } else {
      tr.innerHTML = `
        <td class="border border-black px-1 text-center font-medium whitespace-nowrap">${compactNum}</td>
        <td class="border border-black px-1 text-center font-semibold tracking-wide" style="max-width: 34mm; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${escapeHtml(st.name)}</td>
      `;
    }
    tbody.appendChild(tr);
  });
  const PRINT_MIN_ROWS = 10;
  for (let k = state.students.length; k < PRINT_MIN_ROWS; k++) {
    const blankTr = document.createElement('tr');
    blankTr.innerHTML = '<td class="border border-black px-1">&nbsp;</td>'.repeat(useGender ? 3 : 2);
    tbody.appendChild(blankTr);
  }

  printStage.innerHTML = '';

  // 캡처본과 동일하게 우측 좌석 프레임 상단에 학급 제목(좌)과 게시 시점 안내(우)를 표시한다.
  const headerBar = document.createElement('div');
  headerBar.className = 'w-full flex items-center justify-between gap-4 pb-2 shrink-0';
  const titleSpan = document.createElement('div');
  titleSpan.style.fontSize = '15pt';
  titleSpan.style.fontWeight = '900';
  titleSpan.style.color = '#000000';
  titleSpan.style.lineHeight = '1.2';
  titleSpan.style.overflow = 'hidden';
  titleSpan.style.textOverflow = 'ellipsis';
  titleSpan.style.whiteSpace = 'nowrap';
  titleSpan.textContent = String(state.classTitle || '우리 반 자리 배치표').trim();
  const orientSpan = document.createElement('div');
  orientSpan.style.fontSize = '9.5pt';
  orientSpan.style.fontWeight = '700';
  orientSpan.style.color = '#525252';
  orientSpan.style.whiteSpace = 'nowrap';
  orientSpan.textContent = isStudentView ? '학생 게시용' : '교탁 게시용';
  headerBar.appendChild(titleSpan);
  headerBar.appendChild(orientSpan);
  printStage.appendChild(headerBar);

  if (isStudentView) {
    const podiumEl = createPodiumAndMessageElement(true);
    podiumEl.classList.add('-mt-1');
    printStage.appendChild(podiumEl);
  } else {
    const topSpacer = document.createElement('div');
    topSpacer.className = 'h-1';
    printStage.appendChild(topSpacer);
  }

  const activeMap = state.pos;
  const posMap = {};
  state.students.forEach((s, idx) => {
    const coord = activeMap[s.id];
    if (coord) {
      posMap[`${coord[0]},${coord[1]}`] = { student: s, num: s.num || (idx + 1), rosterIdx: idx };
    }
  });

  const { c0, c1, r0, r1 } = getGridBounds(state.students, activeMap, false);
  const numCols = c1 - c0 + 1;
  const numRows = r1 - r0 + 1;

  const hasMessage = Boolean((state.teacherMessage || '').trim());
  const maxAvailableHeight = hasMessage ? 98 : 105;
  const seatHeightMm = Math.min(includeRoster ? 20 : 22, Math.floor(maxAvailableHeight / Math.max(1, numRows)));

  const columnsContainer = document.createElement('div');
  columnsContainer.className = includeRoster
    ? 'w-full max-w-[215mm] mx-auto grid gap-4 my-auto'
    : 'w-full max-w-[265mm] mx-auto grid gap-4 my-auto';
  columnsContainer.style.gridTemplateColumns = `repeat(${numCols}, minmax(0, 1fr))`;

  const colOrder = [];
  for (let c = c0; c <= c1; c++) colOrder.push(c);
  if (!isStudentView) colOrder.reverse();

  const rowOrder = [];
  for (let r = r0; r <= r1; r++) rowOrder.push(r);
  if (!isStudentView) rowOrder.reverse();

  colOrder.forEach(c => {
    const colStack = document.createElement('div');
    colStack.className = 'flex flex-col';

    rowOrder.forEach((r, visualRowIdx) => {
      const entry = posMap[`${c},${r}`];
      const borderOverlap = visualRowIdx > 0 ? '-mt-[1.5px]' : '';

      const box = document.createElement('div');
      box.style.height = `${seatHeightMm}mm`;
      if (entry) {
        const { student, num, rosterIdx } = entry;
        const seatShaded = shouldShadePrintItem(student, rosterIdx, shadeMode, includeRoster && shadeSeatEnabled, useGender);
        const shadeClass = seatShaded ? 'print-shaded-seat bg-slate-200' : 'bg-white';
        box.className = `relative border-[1.5px] border-black ${borderOverlap} flex flex-col items-center justify-center overflow-hidden ${shadeClass} text-black`;
        const numSpan = document.createElement('span');
        numSpan.className = 'absolute top-[1.2mm] left-[2mm] text-[8pt] font-semibold text-neutral-600 leading-none';
        if (numRows >= 10) {
          numSpan.style.fontSize = '6.5pt';
          numSpan.style.top = '0.5mm';
        }
        numSpan.textContent = formatStudentNumLabel(student, num);
        const nameSpan = document.createElement('span');
        nameSpan.className = 'font-bold text-[13.5pt] tracking-widest mt-[1.5mm] leading-none truncate max-w-full px-1';
        nameSpan.style.overflow = 'hidden';
        nameSpan.style.textOverflow = 'ellipsis';
        nameSpan.style.whiteSpace = 'nowrap';
        nameSpan.style.maxWidth = '100%';
        if (numRows >= 10) {
          nameSpan.style.fontSize = includeRoster ? '10pt' : '11pt';
          nameSpan.style.marginTop = '1.8mm';
        } else if (!includeRoster) {
          nameSpan.style.fontSize = '15pt';
        }
        nameSpan.textContent = student.name;
        box.appendChild(numSpan);
        box.appendChild(nameSpan);
      } else {
        box.className = `${borderOverlap} border border-transparent`;
      }
      colStack.appendChild(box);
    });

    columnsContainer.appendChild(colStack);
  });

  printStage.appendChild(columnsContainer);

  if (!isStudentView) {
    const podiumEl = createPodiumAndMessageElement(true);
    podiumEl.classList.add('mb-5');
    printStage.appendChild(podiumEl);
  } else {
    const bottomSpacer = document.createElement('div');
    bottomSpacer.className = 'h-4';
    printStage.appendChild(bottomSpacer);
  }

  const dateFooter = document.createElement('div');
  dateFooter.setAttribute('data-print-date', '1');
  dateFooter.style.width = '100%';
  dateFooter.style.textAlign = 'right';
  dateFooter.style.fontSize = '8.5pt';
  dateFooter.style.fontWeight = '600';
  dateFooter.style.color = '#64748b';
  dateFooter.style.marginTop = '4px';
  dateFooter.textContent = formatTodayDateLabel();
  printStage.appendChild(dateFooter);
}

// 오프라인 환경에서도 외부 라이브러리 없이 인쇄 레이아웃(명렬표 유무·시점·흑백 음영 연동)을 2배 초고해상도(4400x3112, SCALE=2) Canvas 2D로 직접 렌더링한다.
export function generatePrintCaptureCanvas() {
  const state = AppStore.getState();
  const SCALE = 2;
  const W = 2200;
  const H = 1556;
  const canvas = document.createElement('canvas');
  canvas.width = W * SCALE;
  canvas.height = H * SCALE;
  const ctx = canvas.getContext('2d');
  ctx.scale(SCALE, SCALE);
  const fontStack = '"Noto Sans KR", "Malgun Gothic", "맑은 고딕", "Apple SD Gothic Neo", sans-serif';

  const { orientation, includeRoster, shadeMode, shadeSeatEnabled, useGender } = getEffectivePrintOptions(state);
  const isStudentView = orientation === 'student';

  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, W, H);

  const padX = 56;
  const padY = 52;
  const gapX = includeRoster ? 38 : 0;
  const rosterW = includeRoster ? 360 : 0;
  const stageX = padX + rosterW + gapX;
  const stageW = W - stageX - padX;
  const stageY = padY;
  const stageH = H - padY * 2;

  if (includeRoster) {
    const wideNum = hasWideStudentNum(state.students);
    const totalRows = Math.max(10, state.students.length) + 1;
    const rowH = stageH / totalRows;
    const col1W = Math.round(rosterW * (wideNum ? 0.28 : 0.22));
    const col2W = useGender ? Math.round(rosterW * (wideNum ? 0.48 : 0.54)) : (rosterW - col1W);
    const col3W = useGender ? (rosterW - col1W - col2W) : 0;

    ctx.fillStyle = '#f5f5f5';
    ctx.fillRect(padX, stageY, rosterW, rowH);
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 2;
    ctx.strokeRect(padX, stageY, rosterW, rowH);

    ctx.fillStyle = '#000000';
    const fontPx = state.students.length > 38 ? 17 : state.students.length > 32 ? 19 : 21;
    ctx.font = `bold ${fontPx}px ${fontStack}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const headerCy = stageY + rowH / 2;
    ctx.fillText('번호', padX + col1W / 2, headerCy);
    ctx.fillText('성명', padX + col1W + col2W / 2, headerCy);
    if (useGender) {
      ctx.fillText('성별', padX + col1W + col2W + col3W / 2, headerCy);
    }

    const dataRowCount = Math.max(10, state.students.length);
    for (let idx = 0; idx < dataRowCount; idx++) {
      const ry = stageY + (idx + 1) * rowH;
      const st = state.students[idx] || null;
      const shaded = shouldShadePrintItem(st, idx, shadeMode, includeRoster, useGender);
      ctx.fillStyle = shaded ? '#e5e7eb' : '#ffffff';
      ctx.fillRect(padX, ry, rosterW, rowH);
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(padX, ry, rosterW, rowH);

      if (st) {
        ctx.fillStyle = '#000000';
        ctx.font = `600 ${fontPx}px ${fontStack}`;
        const cy = ry + rowH / 2;
        ctx.fillText(formatStudentNumCompact(st, idx + 1), padX + col1W / 2, cy, Math.max(36, col1W - 10));
        ctx.font = `bold ${fontPx}px ${fontStack}`;
        ctx.fillText(String(st.name || ''), padX + col1W + col2W / 2, cy, Math.max(40, col2W - 14));
        if (useGender) {
          ctx.font = `600 ${fontPx}px ${fontStack}`;
          ctx.fillText(String(st.gender || ''), padX + col1W + col2W + col3W / 2, cy);
        }
      }
    }

    ctx.beginPath();
    ctx.moveTo(padX + col1W, stageY);
    ctx.lineTo(padX + col1W, stageY + stageH);
    if (useGender) {
      ctx.moveTo(padX + col1W + col2W, stageY);
      ctx.lineTo(padX + col1W + col2W, stageY + stageH);
    }
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.lineWidth = 3;
    ctx.strokeRect(padX, stageY, rosterW, stageH);
  }

  ctx.strokeStyle = '#000000';
  ctx.lineWidth = 3;
  ctx.strokeRect(stageX, stageY, stageW, stageH);

  const msgText = String(state.teacherMessage || '').trim();
  const titleText = String(state.classTitle || '우리 반 자리 배치표').trim();
  const orientBadgeText = isStudentView ? '학생 게시용' : '교탁 게시용';

  ctx.fillStyle = '#000000';
  ctx.font = `900 34px ${fontStack}`;
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  ctx.fillText(titleText, stageX + 48, stageY + 32, Math.max(200, stageW - 340));

  ctx.fillStyle = '#525252';
  ctx.font = `bold 18px ${fontStack}`;
  ctx.textAlign = 'right';
  ctx.fillText(orientBadgeText, stageX + stageW - 48, stageY + 42);

  const drawPodiumBlock = (centerY) => {
    const podW = 340;
    const podH = 66;
    const px = stageX + (stageW - podW) / 2;
    const py = centerY - podH / 2;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(px, py, podW, podH);
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 3;
    ctx.strokeRect(px, py, podW, podH);
    ctx.fillStyle = '#000000';
    ctx.font = `900 26px ${fontStack}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('교       탁', stageX + stageW / 2, centerY);

    if (msgText) {
      const msgY = isStudentView ? (py + podH + 26) : (py - 26);
      ctx.font = `bold 21px ${fontStack}`;
      ctx.fillStyle = '#171717';
      ctx.fillText(msgText, stageX + stageW / 2, msgY, Math.max(200, stageW - 96));
    }
  };

  if (isStudentView) {
    drawPodiumBlock(stageY + 135);
  } else {
    drawPodiumBlock(stageY + stageH - 115);
  }

  const activeMap = state.pos;
  const posMap = {};
  state.students.forEach((s, idx) => {
    const coord = activeMap[s.id];
    if (coord) {
      posMap[`${coord[0]},${coord[1]}`] = { student: s, num: s.num || (idx + 1), rosterIdx: idx };
    }
  });

  const { c0, c1, r0, r1 } = getGridBounds(state.students, activeMap, false);
  const numCols = Math.max(1, c1 - c0 + 1);
  const numRows = Math.max(1, r1 - r0 + 1);

  const gridAreaTop = isStudentView ? (stageY + (msgText ? 215 : 190)) : (stageY + 100);
  const gridAreaBottom = isStudentView ? (stageY + stageH - 48) : (stageY + stageH - (msgText ? 200 : 175));
  const gridAvailH = Math.max(200, gridAreaBottom - gridAreaTop);
  const gridAvailW = stageW - (includeRoster ? 120 : 140);
  const gridStartX = stageX + (stageW - gridAvailW) / 2;

  const colGap = 24;
  const colW = (gridAvailW - colGap * (numCols - 1)) / numCols;
  const seatH = Math.min(includeRoster ? 155 : 170, Math.floor(gridAvailH / numRows));
  const totalGridH = seatH * numRows;
  const gridStartY = gridAreaTop + (gridAvailH - totalGridH) / 2;

  const colOrder = [];
  for (let c = c0; c <= c1; c++) colOrder.push(c);
  if (!isStudentView) colOrder.reverse();

  const rowOrder = [];
  for (let r = r0; r <= r1; r++) rowOrder.push(r);
  if (!isStudentView) rowOrder.reverse();

  const nameFontPx = includeRoster ? 30 : 34;
  colOrder.forEach((c, cVisualIdx) => {
    const bx = gridStartX + cVisualIdx * (colW + colGap);
    rowOrder.forEach((r, rVisualIdx) => {
      const by = gridStartY + rVisualIdx * seatH;
      const entry = posMap[`${c},${r}`];
      if (!entry) return;
      const { student, num, rosterIdx } = entry;
      const seatShaded = shouldShadePrintItem(student, rosterIdx, shadeMode, includeRoster && shadeSeatEnabled, useGender);

      ctx.fillStyle = seatShaded ? '#e5e7eb' : '#ffffff';
      ctx.fillRect(bx, by, colW, seatH);
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 2.5;
      ctx.strokeRect(bx, by, colW, seatH);

      const tightSeat = seatH < 95;
      const effNumFont = tightSeat ? 14 : 18;
      const effNameFont = tightSeat ? Math.min(nameFontPx, 24) : nameFontPx;

      ctx.fillStyle = '#525252';
      ctx.font = `bold ${effNumFont}px ${fontStack}`;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      ctx.fillText(formatStudentNumLabel(student, num), bx + 12, by + (tightSeat ? 6 : 10), Math.max(40, colW - 24));

      ctx.fillStyle = '#000000';
      ctx.font = `bold ${effNameFont}px ${fontStack}`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(String(student.name || ''), bx + colW / 2, by + seatH / 2 + (tightSeat ? 9 : 8), Math.max(40, colW - 20));
    });
  });

  // 우측 프레임 하단 오른쪽 기준 날짜 표시
  ctx.fillStyle = '#64748b';
  ctx.font = `600 18px ${fontStack}`;
  ctx.textAlign = 'right';
  ctx.textBaseline = 'bottom';
  ctx.fillText(formatTodayDateLabel(), stageX + stageW - 22, stageY + stageH - 12);

  return canvas;
}

export async function captureAndSavePrintLayout() {
  const state = AppStore.getState();
  const canvas = generatePrintCaptureCanvas();
  const orientSuffix = state.printOrientation === 'teacher' ? '교탁용' : '학생용';
  const fileName = `${sanitizeFileName(state.classTitle || '우리반_자리배치표')}_${orientSuffix}.png`;

  const blob = await new Promise(resolve => {
    canvas.toBlob(resolve, 'image/png');
  });
  if (!blob) {
    showToast('이미지 생성 중 오류가 발생했습니다.', 'warn');
    return;
  }

  let copiedToClipboard = false;
  if (navigator.clipboard && typeof navigator.clipboard.write === 'function' && typeof window.ClipboardItem === 'function') {
    try {
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
      copiedToClipboard = true;
    } catch (e) {
      copiedToClipboard = false;
    }
  }

  if (typeof window.showSaveFilePicker === 'function') {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName: fileName,
        types: [{
          description: 'PNG 고화질 이미지 파일',
          accept: { 'image/png': ['.png'] }
        }]
      });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      closePrintOptionsModal();
      const savedName = handle.name || fileName;
      if (copiedToClipboard) {
        showToast(`📸 지정한 위치에 '${savedName}' 파일이 저장되었고 클립보드(Ctrl+V)에도 복사되었습니다!`, 'success');
      } else {
        showToast(`📸 지정한 위치에 '${savedName}' 초고화질 자리 배치표 이미지가 저장되었습니다!`, 'success');
      }
      return;
    } catch (err) {
      if (err && err.name === 'AbortError') {
        if (copiedToClipboard) {
          showToast('파일 저장을 취소했습니다. (클립보드에는 이미지가 복사되어 바로 붙여넣기 가능합니다)', 'info');
        } else {
          showToast('파일 저장이 취소되었습니다.', 'info');
        }
        return;
      }
    }
  }

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);

  closePrintOptionsModal();
  if (copiedToClipboard) {
    showToast(`📸 클립보드에 이미지가 복사(Ctrl+V 붙여넣기 가능)되었고 '${fileName}' 파일로도 저장되었습니다!`, 'success');
  } else {
    showToast(`📸 '${fileName}' 초고화질 자리 배치표 이미지 파일이 저장되었습니다!`, 'success');
  }
}

export function executePrintFromModal() {
  AppStore.flushPendingCommit(true);
  renderPrintView();
  closePrintOptionsModal();
  window.print();
}

// file:// 오프라인 환경에서도 한글(HWP)·워드·엑셀에 실제 표(테두리 포함)로 붙여넣기 되도록
// DOM API(createElement + textContent)로 오프스크린 <table>을 안전하게 조립해 Range 복사한다.
function copySeatingDomTableFallback(state, orientation) {
  if (typeof document === 'undefined' || !document.body || typeof window === 'undefined' || typeof window.getSelection !== 'function') {
    return false;
  }
  const posMap = state.pos || {};
  const { c0, c1, r0, r1 } = getGridBounds(state.students, posMap, false);
  const coordToStudent = new Map();
  state.students.forEach(s => {
    const p = posMap[s.id];
    if (Array.isArray(p) && p.length === 2) coordToStudent.set(`${p[0]},${p[1]}`, s);
  });
  const rosterIndexMap = new Map((state.students || []).map((s, idx) => [String(s.id), idx]));

  const isShaded = (stu) => {
    if (state.printIncludeRoster === false || !state.printShadeSeatEnabled) return false;
    const mode = state.printShadeMode || 'female';
    if (mode === 'none') return false;
    const useGender = !(state.rules && state.rules.useGenderDistinction === false);
    if (mode === 'female' && useGender) return stu.gender === '여';
    if (mode === 'male' && useGender) return stu.gender === '남';
    if (mode === 'zebra') {
      const i = rosterIndexMap.get(String(stu.id));
      return typeof i === 'number' && (i % 2 === 1);
    }
    return false;
  };

  const isTeacherView = orientation === 'teacher';
  const rows = [];
  if (isTeacherView) { for (let r = r1; r >= r0; r--) rows.push(r); }
  else { for (let r = r0; r <= r1; r++) rows.push(r); }
  const cols = [];
  if (isTeacherView) { for (let c = c1; c >= c0; c--) cols.push(c); }
  else { for (let c = c0; c <= c1; c++) cols.push(c); }

  const totalGridCols = Math.max(1, cols.length * 2 - 1);
  const podiumSpan = cols.length === 1 ? 1 : Math.max(1, Math.min(totalGridCols, Math.round(totalGridCols * 0.45)));
  const leftPad = Math.floor((totalGridCols - podiumSpan) / 2);
  const rightPad = totalGridCols - podiumSpan - leftPad;

  const wrap = document.createElement('div');
  wrap.style.position = 'fixed';
  wrap.style.left = '-9999px';
  wrap.style.top = '0';
  wrap.style.opacity = '0';
  wrap.style.pointerEvents = 'none';
  wrap.style.userSelect = 'text';
  wrap.style.webkitUserSelect = 'text';

  const table = document.createElement('table');
  table.setAttribute('cellspacing', '0');
  table.setAttribute('cellpadding', '0');
  table.style.borderCollapse = 'collapse';
  table.style.fontFamily = "'Malgun Gothic', '맑은 고딕', sans-serif";
  const tbody = document.createElement('tbody');

  const makeSpacerRow = (h) => {
    const tr = document.createElement('tr');
    tr.style.height = `${h}px`;
    const td = document.createElement('td');
    td.colSpan = totalGridCols;
    td.style.background = 'transparent';
    td.style.padding = '0';
    td.textContent = '\u00A0';
    tr.appendChild(td);
    return tr;
  };

  const makePodiumRow = () => {
    const tr = document.createElement('tr');
    if (leftPad > 0) {
      const lTd = document.createElement('td');
      lTd.colSpan = leftPad;
      lTd.style.background = 'transparent';
      lTd.textContent = '\u00A0';
      tr.appendChild(lTd);
    }
    const pTd = document.createElement('td');
    pTd.colSpan = podiumSpan;
    pTd.style.border = '1pt solid #000000';
    pTd.style.background = '#ffffff';
    pTd.style.color = '#0f172a';
    pTd.style.fontSize = '12pt';
    pTd.style.fontWeight = 'bold';
    pTd.style.textAlign = 'center';
    pTd.style.padding = '8px 12px';
    pTd.style.letterSpacing = '6px';
    pTd.textContent = '교\u00A0\u00A0탁';
    tr.appendChild(pTd);
    if (rightPad > 0) {
      const rTd = document.createElement('td');
      rTd.colSpan = rightPad;
      rTd.style.background = 'transparent';
      rTd.textContent = '\u00A0';
      tr.appendChild(rTd);
    }
    return tr;
  };

  if (!isTeacherView) {
    tbody.appendChild(makePodiumRow());
    tbody.appendChild(makeSpacerRow(26));
  }

  rows.forEach(r => {
    const tr = document.createElement('tr');
    cols.forEach((c, ci) => {
      if (ci > 0) {
        const gapTd = document.createElement('td');
        gapTd.style.background = 'transparent';
        gapTd.style.width = '12px';
        gapTd.style.padding = '0';
        gapTd.textContent = '\u00A0';
        tr.appendChild(gapTd);
      }
      const td = document.createElement('td');
      const stu = coordToStudent.get(`${c},${r}`);
      if (!stu) {
            td.style.background = 'transparent';
        td.style.width = '112px';
        td.style.height = '62px';
        td.style.padding = '0';
        td.textContent = '\u00A0';
      } else {
        td.style.border = '1pt solid #000000';
        td.style.background = isShaded(stu) ? '#e5e7eb' : '#ffffff';
        td.style.width = '112px';
        td.style.height = '62px';
        td.style.verticalAlign = 'top';
        td.style.padding = '5px 8px 8px 8px';

        const numDiv = document.createElement('div');
        numDiv.style.fontSize = '8.5pt';
        numDiv.style.color = '#475569';
        numDiv.style.textAlign = 'left';
        numDiv.style.lineHeight = '1.1';
        numDiv.style.marginBottom = '4px';
        numDiv.textContent = formatStudentNumLabel(stu);

        const nameDiv = document.createElement('div');
        nameDiv.style.fontSize = '13pt';
        nameDiv.style.fontWeight = 'bold';
        nameDiv.style.color = '#0f172a';
        nameDiv.style.textAlign = 'center';
        nameDiv.style.lineHeight = '1.25';
        nameDiv.textContent = String(stu.name || '').replace(/[\t\r\n]+/g, ' ').trim();

        td.appendChild(numDiv);
        td.appendChild(nameDiv);
      }
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  });

  if (isTeacherView) {
    tbody.appendChild(makeSpacerRow(26));
    tbody.appendChild(makePodiumRow());
  }

  table.appendChild(tbody);

  if (state.printIncludeRoster === false) {
    wrap.appendChild(table);
  } else {
    const useGender = !(state.rules && state.rules.useGenderDistinction === false);
    const isRosterRowShaded = (stu) => {
      const mode = state.printShadeMode || 'female';
      if (mode === 'none') return false;
      if (mode === 'female' && useGender) return stu.gender === '여';
      if (mode === 'male' && useGender) return stu.gender === '남';
      if (mode === 'zebra') {
        const i = rosterIndexMap.get(String(stu.id));
        return typeof i === 'number' && (i % 2 === 1);
      }
      return false;
    };

    const rTable = document.createElement('table');
    rTable.setAttribute('cellspacing', '0');
    rTable.setAttribute('cellpadding', '2');
    rTable.style.borderCollapse = 'collapse';
    rTable.style.fontFamily = "'Malgun Gothic', '맑은 고딕', sans-serif";
    rTable.style.fontSize = '8pt';

    const rThead = document.createElement('thead');
    const rHeadTr = document.createElement('tr');
    const wideNum = hasWideStudentNum(state.students);
    const numColW = wideNum ? '54px' : '38px';
    const headers = useGender ? [['번호', numColW], ['성명', '76px'], ['성별', '38px']] : [['번호', numColW], ['성명', '104px']];
    headers.forEach(([hText, w]) => {
      const th = document.createElement('th');
      th.style.border = '1pt solid #000000';
      th.style.background = '#f1f5f9';
      th.style.padding = hText === '성명' ? '2px 6px' : '2px 3px';
      th.style.whiteSpace = 'nowrap';
      th.style.textAlign = 'center';
      th.style.fontWeight = 'bold';
      th.style.width = w;
      th.textContent = hText;
      rHeadTr.appendChild(th);
    });
    rThead.appendChild(rHeadTr);
    rTable.appendChild(rThead);

    const rTbody = document.createElement('tbody');
    state.students.forEach((stu, idx) => {
      const tr = document.createElement('tr');
      const bg = isRosterRowShaded(stu) ? '#e5e7eb' : '#ffffff';
      const compactNum = formatStudentNumCompact(stu, idx + 1);
      const vals = useGender
        ? [compactNum, String(stu.name || '').replace(/[\t\r\n]+/g, ' ').trim(), String(stu.gender || '')]
        : [compactNum, String(stu.name || '').replace(/[\t\r\n]+/g, ' ').trim()];
      vals.forEach((val, ci) => {
        const td = document.createElement('td');
        td.style.border = '1pt solid #000000';
        td.style.background = bg;
        td.style.padding = ci === 1 ? '2px 6px' : '2px 3px';
        td.style.width = headers[ci][1];
        td.style.whiteSpace = 'nowrap';
        td.style.textAlign = 'center';
        if (ci === 1) td.style.fontWeight = 'bold';
        td.textContent = val;
        tr.appendChild(td);
      });
      rTbody.appendChild(tr);
    });
    rTable.appendChild(rTbody);

    const outerTable = document.createElement('table');
    outerTable.setAttribute('cellspacing', '0');
    outerTable.setAttribute('cellpadding', '0');
    outerTable.style.borderCollapse = 'collapse';
    outerTable.style.fontFamily = "'Malgun Gothic', '맑은 고딕', sans-serif";
    const outerTbody = document.createElement('tbody');
    const outerTr = document.createElement('tr');

    const leftTd = document.createElement('td');
    leftTd.style.background = 'transparent';
    leftTd.style.verticalAlign = 'top';
    leftTd.style.padding = '0';
    leftTd.appendChild(rTable);

    const midTd = document.createElement('td');
    midTd.style.background = 'transparent';
    midTd.style.width = '24px';
    midTd.style.padding = '0';
    midTd.textContent = '\u00A0';

    const rightTd = document.createElement('td');
    rightTd.style.background = 'transparent';
    rightTd.style.verticalAlign = 'top';
    rightTd.style.padding = '0';
    rightTd.appendChild(table);

    outerTr.appendChild(leftTd);
    outerTr.appendChild(midTd);
    outerTr.appendChild(rightTd);
    outerTbody.appendChild(outerTr);
    outerTable.appendChild(outerTbody);
    wrap.appendChild(outerTable);
  }

  document.body.appendChild(wrap);

  let copied = false;
  const sel = window.getSelection();
  try {
    const range = document.createRange();
    range.selectNodeContents(wrap);
    sel.removeAllRanges();
    sel.addRange(range);
    copied = Boolean(document.execCommand && document.execCommand('copy'));
  } catch (e) {
    copied = false;
  } finally {
    try { sel.removeAllRanges(); } catch (e) {}
    wrap.remove();
  }
  return copied;
}

export async function copySeatingTableToClipboard() {
  const state = AppStore.getState();
  const orientation = state.printOrientation || 'student';
  const tsv = buildSeatingTsvText(state, orientation);
  const htmlTable = buildSeatingHtmlTable(state, orientation);
  if (!tsv || !htmlTable) {
    showToast('복사할 학생 자리 배치가 없습니다. 먼저 학생 명단을 입력해 주세요.', 'warn');
    return false;
  }

  let copied = false;
  // 1순위: ClipboardItem으로 text/html(실제 테두리 표) + text/plain(TSV) 동시 복사
  if (navigator.clipboard && typeof navigator.clipboard.write === 'function' && typeof window.ClipboardItem === 'function') {
    try {
      await navigator.clipboard.write([
        new ClipboardItem({
          'text/html': new Blob([htmlTable], { type: 'text/html' }),
          'text/plain': new Blob([tsv], { type: 'text/plain' })
        })
      ]);
      copied = true;
    } catch (e) {
      copied = false;
    }
  }

  // 2순위 (file:// 로컬 실행 환경 주 경로): 오프스크린 DOM <table> Range 선택 + execCommand('copy')
  if (!copied) {
    copied = copySeatingDomTableFallback(state, orientation);
  }

  // 3순위 (최후 폴백): 순수 텍스트 TSV 복사
  if (!copied && typeof document !== 'undefined' && document.body) {
    const ta = document.createElement('textarea');
    try {
      ta.value = tsv;
      ta.setAttribute('readonly', 'readonly');
      ta.style.position = 'fixed';
      ta.style.left = '-9999px';
      ta.style.top = '0';
      document.body.appendChild(ta);
      ta.select();
      copied = Boolean(document.execCommand && document.execCommand('copy'));
    } catch (e) {
      copied = false;
    } finally {
      ta.remove();
    }
  }

  if (copied) {
    closePrintOptionsModal();
    const orientLabel = orientation === 'teacher' ? '교탁 게시용' : '학생 게시용';
    showToast(`📋 자리 배치표를 표(${orientLabel})로 복사했습니다! 한글(HWP)·워드·엑셀에서 Ctrl+V로 붙여넣으세요.`, 'success');
    return true;
  }
  showToast('클립보드 복사가 브라우저 정책으로 차단되었습니다. 캡처 또는 출력 기능을 이용해 주세요.', 'warn');
  return false;
}
