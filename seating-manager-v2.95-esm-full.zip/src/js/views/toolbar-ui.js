// [L4-leaf] 상단 툴바 · 가리기 · 효과음 · 사이드바 · 크게보기 버튼 UI 동기화
import { AppStore } from '../state/store.js';

export function updateRevealAllButton() {
  const state = AppStore.getState();
  const group = document.getElementById('revealActionsGroup');
  const btn = document.getElementById('revealAllHiddenBtn');
  if (!group || !btn) return;
  if (state.hiddenSeatIds.length > 0 && !state.inSecretRoom) {
    group.classList.remove('hidden');
    group.classList.add('flex');
    btn.textContent = `전체 공개 (${state.hiddenSeatIds.length})`;
  } else {
    group.classList.add('hidden');
    group.classList.remove('flex');
  }
}

export function updateMaskModeButtonUI() {
  const state = AppStore.getState();
  const btn = document.getElementById('toggleMaskModeBtn');
  const label = document.getElementById('maskModeBtnLabel');
  const icon = document.getElementById('maskModeIcon');
  if (!btn || !label) return;

  if (state.maskModeEnabled) {
    btn.className = 'flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-extrabold text-xs border transition bg-amber-500 text-white border-amber-600 shadow-sm hover:bg-amber-600';
    label.textContent = '가리기: 켜짐';
    if (icon) icon.setAttribute('class', 'w-4 h-4 text-white');
  } else {
    btn.className = 'flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-bold text-xs border transition bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200';
    label.textContent = '가리기: 꺼짐';
    if (icon) icon.setAttribute('class', 'w-4 h-4 text-slate-500');
  }
  updateRevealAllButton();
}

// 효과음 토글 버튼의 활성/비활성 스타일 및 문구를 동기화한다.
export function updateSoundButtonUI() {
  const state = AppStore.getState();
  const btn = document.getElementById('toggleSoundBtn');
  const icon = document.getElementById('soundBtnIcon');
  const label = document.getElementById('soundBtnLabel');
  if (!btn || !label) return;

  const enabled = state.soundEnabled !== false;
  if (enabled) {
    btn.className = 'flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl font-extrabold text-xs border transition bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100';
    if (icon) icon.textContent = '🔊';
    label.textContent = '효과음: 켜짐';
  } else {
    btn.className = 'flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl font-bold text-xs border transition bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200';
    if (icon) icon.textContent = '🔇';
    label.textContent = '효과음: 꺼짐';
  }
}

export function toggleLeftSidebar(forceCollapse) {
  const state = AppStore.getState();
  const sidebar = document.getElementById('leftSidebar');
  const expandBtn = document.getElementById('expandSidebarBtn');
  if (!sidebar || !expandBtn) return;

  state.sidebarCollapsed = typeof forceCollapse === 'boolean' ? forceCollapse : !state.sidebarCollapsed;
  if (state.sidebarCollapsed) {
    sidebar.classList.add('hidden');
    expandBtn.classList.remove('hidden');
    expandBtn.classList.add('flex');
  } else {
    sidebar.classList.remove('hidden');
    expandBtn.classList.add('hidden');
    expandBtn.classList.remove('flex');
  }
}

// 전체화면·글자 크게 보기 버튼 UI를 현재 상태에 맞춰 갱신한다.
export function updateLargeViewButtonUI() {
  const state = AppStore.getState();
  const btn = document.getElementById('toggleLargeViewBtn');
  const icon = document.getElementById('largeViewBtnIcon');
  const label = document.getElementById('largeViewBtnLabel');
  const paperCard = document.getElementById('seatingPaperCard');
  if (!btn || !label) return;

  if (state.largeViewEnabled) {
    btn.className = 'flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-extrabold bg-indigo-600 text-white border border-indigo-600 hover:bg-indigo-700 active:scale-95 transition shadow-sm whitespace-nowrap';
    if (icon) icon.textContent = '🗗';
    label.textContent = '기본 크기';
    if (paperCard) {
      paperCard.classList.remove('max-w-5xl');
      paperCard.classList.add('max-w-full');
    }
  } else {
    btn.className = 'flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-white text-slate-700 border border-slate-200 hover:bg-indigo-50/60 hover:text-indigo-700 hover:border-indigo-300 active:scale-95 transition shadow-sm whitespace-nowrap';
    if (icon) icon.textContent = '🔍';
    label.textContent = '크게 보기';
    if (paperCard) {
      paperCard.classList.add('max-w-5xl');
      paperCard.classList.remove('max-w-full');
    }
  }
}
