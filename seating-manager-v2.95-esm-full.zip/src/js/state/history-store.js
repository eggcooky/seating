// [L2] 실행 취소(Undo) 스냅샷 스택 저장소 (복원 오케스트레이션은 L5 history-coordinator.js로 분리)
import { getActivePosMap } from '../domain/seat-queries.js';
import { AppStore } from './store.js';

const _historyHooks = {
  onStackChanged: null,
  onCleared: null
};

export function configureHistoryHooks(nextHooks = {}) {
  if (!nextHooks || typeof nextHooks !== 'object') return;
  if (typeof nextHooks.onStackChanged === 'function' || nextHooks.onStackChanged === null) {
    _historyHooks.onStackChanged = nextHooks.onStackChanged;
  }
  if (typeof nextHooks.onCleared === 'function' || nextHooks.onCleared === null) {
    _historyHooks.onCleared = nextHooks.onCleared;
  }
}

export function clearUndoHistory() {
  const state = AppStore.getState();
  state.undoStackNormal = [];
  state.undoStackSecret = [];
  if (typeof _historyHooks.onStackChanged === 'function') {
    _historyHooks.onStackChanged();
  }
  if (typeof _historyHooks.onCleared === 'function') {
    _historyHooks.onCleared();
  }
}

// 자리 변경 전 상태를 최대 7개까지 히스토리 스택에 저장한다.
export function pushUndoSnapshot(actionLabel = '자리 배치 변경', extra = null) {
  const state = AppStore.getState();
  const activeMap = getActivePosMap(state);
  const now = new Date();
  const timeStr = now.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const hasActiveRoulette = Boolean(!state.inSecretRoom && state.rouletteActiveSession);
  const snapshot = {
    actionLabel,
    timeStr,
    pos: JSON.parse(JSON.stringify(activeMap)),
    hiddenSeatIds: state.inSecretRoom ? [] : [...state.hiddenSeatIds],
    hasDeleteGapNotice: Boolean(state.hasDeleteGapNotice),
    rouletteActiveSession: hasActiveRoulette,
    rouletteRemainingStudents: hasActiveRoulette ? JSON.parse(JSON.stringify(state.rouletteRemainingStudents || [])) : [],
    rouletteTargetCoords: hasActiveRoulette ? JSON.parse(JSON.stringify(state.rouletteTargetCoords || [])) : [],
    rouletteAssignedMap: hasActiveRoulette ? JSON.parse(JSON.stringify(state.rouletteAssignedMap || {})) : {},
    rouletteDrawnIds: hasActiveRoulette ? [...(state.rouletteDrawnIds || [])] : []
  };
  if (extra && extra.locks) snapshot.locks = extra.locks;
  if (extra && Array.isArray(extra.overwrittenLockIds)) snapshot.overwrittenLockIds = [...extra.overwrittenLockIds];
  if (extra && extra.rosterBackup) snapshot.rosterBackup = extra.rosterBackup;
  if (extra && extra.prevDefaultCols) snapshot.prevDefaultCols = extra.prevDefaultCols;
  if (state.inSecretRoom) {
    if (extra && extra.rosterBackup) {
      const pairId = 'rm_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
      snapshot._rosterMirrorPairId = pairId;
      const mirrorSnap = JSON.parse(JSON.stringify(snapshot));
      mirrorSnap.pos = JSON.parse(JSON.stringify(extra.rosterBackup.pos || state.pos));
      mirrorSnap.hiddenSeatIds = [...(extra.rosterBackup.hiddenSeatIds || [])];
      mirrorSnap._mirroredRosterOp = true;
      mirrorSnap._rosterMirrorPairId = pairId;
      state.undoStackSecret.push(snapshot);
      if (state.undoStackSecret.length > 7) state.undoStackSecret.shift();
      state.undoStackNormal.push(mirrorSnap);
      if (state.undoStackNormal.length > 7) state.undoStackNormal.shift();
    } else {
      state.undoStackSecret.push(snapshot);
      if (state.undoStackSecret.length > 7) state.undoStackSecret.shift();
    }
  } else {
    state.undoStackNormal.push(snapshot);
    if (state.undoStackNormal.length > 7) state.undoStackNormal.shift();
  }
  if (typeof _historyHooks.onStackChanged === 'function') {
    _historyHooks.onStackChanged();
  }
}
