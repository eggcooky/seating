// [L5] 배치 조건 모달 열기 · 취소(롤백) · 적용(확정) 트랜잭션 코디네이터
import { ensureAllStudentsHaveValidCoords } from '../domain/grid.js';
import { stopRouletteColumnAuto, syncRouletteWithCurrentLocks } from '../features/roulette-controller.js';
import { AppStore } from '../state/store.js';
import { markDirty } from '../ui/dirty-indicator.js';
import { updateSecretPresetIndicator } from '../ui/secret-indicators.js';
import { showToast } from '../ui/toast.js';
import { updateUndoButtonState } from '../views/history-popover.js';
import { updateRulesUI } from '../views/rules-modal-view.js';

export function openRulesModal() {
  const state = AppStore.getState();
  if (!state.inSecretRoom && state.rouletteSpinning) {
    showToast('룰렛이 돌아가는 중에는 배치 조건을 열 수 없습니다.', 'warn');
    return;
  }
  const rulesModal = document.getElementById('rulesModal');
  if (!rulesModal) return;
  stopRouletteColumnAuto();
  state.rulesModalBackup = {
    rules: JSON.parse(JSON.stringify(state.rules)),
    pos: JSON.parse(JSON.stringify(state.pos)),
    secretPos: state.secretPos ? JSON.parse(JSON.stringify(state.secretPos)) : null,
    lockedIds: [...state.lockedIds],
    secretLockedIds: [...state.secretLockedIds],
    printShadeMode: state.printShadeMode,
    printShadeSeatEnabled: Boolean(state.printShadeSeatEnabled),
    hasDeleteGapNotice: Boolean(state.hasDeleteGapNotice),
    isDirty: Boolean(state.isDirty),
    undoNormal: JSON.parse(JSON.stringify(state.undoStackNormal)),
    undoSecret: JSON.parse(JSON.stringify(state.undoStackSecret))
  };
  updateRulesUI();
  rulesModal.classList.remove('hidden');
  rulesModal.classList.add('flex');
}

function closeRulesModal() {
  const rulesModal = document.getElementById('rulesModal');
  if (!rulesModal) return;
  rulesModal.classList.add('hidden');
  rulesModal.classList.remove('flex');
}

export function cancelRulesModal() {
  const state = AppStore.getState();
  if (state.rulesModalBackup) {
    state.rules = state.rulesModalBackup.rules;
    state.pos = state.rulesModalBackup.pos;
    state.secretPos = state.rulesModalBackup.secretPos;
    const curValidIds = new Set(state.students.map(s => String(s.id)));
    state.lockedIds = (state.rulesModalBackup.lockedIds || []).filter(id => curValidIds.has(String(id)));
    state.secretLockedIds = (state.rulesModalBackup.secretLockedIds || []).filter(id => curValidIds.has(String(id)));
    if (state.rules) {
      state.rules.frontRowIds = (state.rules.frontRowIds || []).filter(id => curValidIds.has(String(id)));
      state.rules.separatedPairs = (state.rules.separatedPairs || []).filter(p => Array.isArray(p) && p.length === 2 && curValidIds.has(String(p[0])) && curValidIds.has(String(p[1])));
      state.rules.togetherPairs = (state.rules.togetherPairs || []).filter(p => Array.isArray(p) && p.length === 2 && curValidIds.has(String(p[0])) && curValidIds.has(String(p[1])));
    }
    const defaultCols = Number(state.rules && state.rules.defaultCols) || 6;
    ensureAllStudentsHaveValidCoords(state.students, state.pos, defaultCols);
    if (state.secretPos) ensureAllStudentsHaveValidCoords(state.students, state.secretPos, defaultCols);
    if (state.rulesModalBackup.printShadeMode !== undefined) {
      state.printShadeMode = state.rulesModalBackup.printShadeMode;
    }
    if (state.rulesModalBackup.printShadeSeatEnabled !== undefined) {
      state.printShadeSeatEnabled = state.rulesModalBackup.printShadeSeatEnabled;
    }
    if (state.rulesModalBackup.hasDeleteGapNotice !== undefined) {
      state.hasDeleteGapNotice = Boolean(state.rulesModalBackup.hasDeleteGapNotice);
    }
    markDirty(Boolean(state.rulesModalBackup.isDirty));
    state.undoStackNormal = state.rulesModalBackup.undoNormal;
    state.undoStackSecret = state.rulesModalBackup.undoSecret;
    updateUndoButtonState();
    state.rulesModalBackup = null;
    updateSecretPresetIndicator();
    if (state.rouletteOpen) {
      syncRouletteWithCurrentLocks();
    }
    AppStore.commitChange({ roster: true, classroom: true, animate: false, print: true, rules: true, dirty: false, save: true, forcePersist: true });
    showToast('배치 조건 변경이 취소되어 이전 상태로 복원되었습니다.', 'info');
  }
  closeRulesModal();
}

export function applyRulesAndCloseModal() {
  const state = AppStore.getState();
  state.rulesModalBackup = null;
  AppStore.commitChange({ rules: true, dirty: true, save: true, forcePersist: true });
  closeRulesModal();
  showToast('배치 조건이 적용되었습니다. [자리 바꾸기] 버튼을 누르면 반영됩니다.', 'success');
}
