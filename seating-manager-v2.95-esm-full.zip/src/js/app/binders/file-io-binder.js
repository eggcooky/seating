// [L5 Binder] 파일 저장 · 엑셀 명렬표 붙여넣기 · JSON 단일/다중학급 불러오기 이벤트 바인더
import { isMultiClassBundlePayload, parseSeatFileText } from '../../domain/codec.js';
import { stopSequentialReveal } from '../../features/reveal-controller.js';
import {
  applyParsedExcelRoster,
  closeExcelPasteModal,
  openExcelPasteModal,
  updateExcelLivePreview
} from '../../features/roster-actions.js';
import { initRouletteSession, stopRouletteColumnAuto } from '../../features/roulette-controller.js';
import { saveWithFileExplorer, triggerBrowserDownload } from '../../infra/storage-io.js';
import { clearUndoHistory } from '../../state/history-store.js';
import { AppStore } from '../../state/store.js';
import { markDirty } from '../../ui/dirty-indicator.js';
import { showToast } from '../../ui/toast.js';
import { toggleSecretRoom } from '../mode-coordinator.js';
import { applyMultiClassBundleData, syncCurrentSlotTitle } from '../multiclass-coordinator.js';

export function bindFileIoEvents(ctx) {
  // 저장하기 버튼 및 파일 저장 모달 이벤트 연결
  document.getElementById('saveStateBtn').addEventListener('click', saveWithFileExplorer);

  const saveFileModal = document.getElementById('saveFileModal');
  const closeSaveFileModal = () => {
    if (!saveFileModal) return;
    saveFileModal.classList.add('hidden');
    saveFileModal.classList.remove('flex');
  };
  document.getElementById('cancelSaveModalBtn').addEventListener('click', closeSaveFileModal);
  document.getElementById('confirmSaveModalBtn').addEventListener('click', () => {
    const nameVal = document.getElementById('saveFileNameInput').value;
    closeSaveFileModal();
    triggerBrowserDownload(nameVal);
  });

  // 엑셀 명렬표 붙여넣기 모달 이벤트 연결
  const excelTextarea = document.getElementById('excelPasteTextarea');
  document.getElementById('openExcelPasteModalBtn').addEventListener('click', openExcelPasteModal);
  document.getElementById('closeExcelModalBtn').addEventListener('click', closeExcelPasteModal);
  document.getElementById('cancelExcelModalBtn').addEventListener('click', closeExcelPasteModal);
  excelTextarea.addEventListener('input', updateExcelLivePreview);
  document.getElementById('clearExcelTextareaBtn').addEventListener('click', () => {
    excelTextarea.value = '';
    updateExcelLivePreview();
    excelTextarea.focus();
  });
  const fillMixedSampleBtn = document.getElementById('fillMixedSampleExcelBtn');
  if (fillMixedSampleBtn) {
    fillMixedSampleBtn.addEventListener('click', () => {
      excelTextarea.value = '반\t번호\t성명\t성별\n1반\t1\t김철수\t남\n1반\t3\t이영희\t여\n2반\t1\t박민수\t남\n2반\t3\t최유리\t여';
      updateExcelLivePreview();
      excelTextarea.focus();
    });
  }
  document.getElementById('fillSampleExcelBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    const hasClassLabels = state.students.some(st => Boolean(st && st.classLabel));
    if (hasClassLabels) {
      excelTextarea.value = '반\t번호\t성명\t성별\n' + state.students.map(st => `${st.classLabel || ''}\t${st.num}\t${st.name}\t${st.gender}`).join('\n');
    } else {
      excelTextarea.value = state.students.map(st => `${st.num}\t${st.name}\t${st.gender}`).join('\n');
    }
    updateExcelLivePreview();
  });
  document.getElementById('applyExcelRosterBtn').addEventListener('click', () => applyParsedExcelRoster(false));

  const excelOverwriteModal = document.getElementById('excelOverwriteConfirmModal');
  const closeExcelOverwriteModal = () => {
    if (!excelOverwriteModal) return;
    excelOverwriteModal.classList.add('hidden');
    excelOverwriteModal.classList.remove('flex');
  };
  const excelOverwriteCancelBtn = document.getElementById('excelOverwriteCancelBtn');
  const excelOverwriteConfirmBtn = document.getElementById('excelOverwriteConfirmBtn');
  if (excelOverwriteCancelBtn) excelOverwriteCancelBtn.addEventListener('click', closeExcelOverwriteModal);
  if (excelOverwriteConfirmBtn) {
    excelOverwriteConfirmBtn.addEventListener('click', () => {
      closeExcelOverwriteModal();
      applyParsedExcelRoster(true);
    });
  }
  if (excelOverwriteModal) {
    excelOverwriteModal.addEventListener('click', (e) => {
      if (e.target === excelOverwriteModal) closeExcelOverwriteModal();
    });
  }

  // JSON 파일 불러오기 이벤트 연결
  const fileInput = document.getElementById('jsonFileInput');
  const jsonOverwriteModal = document.getElementById('jsonImportOverwriteConfirmModal');
  const jsonOverwriteDesc = document.getElementById('jsonImportOverwriteConfirmDesc');
  let pendingImportFile = null;

  const closeJsonOverwriteModal = (resetInput = false) => {
    if (jsonOverwriteModal) {
      jsonOverwriteModal.classList.add('hidden');
      jsonOverwriteModal.classList.remove('flex');
    }
    if (resetInput) {
      pendingImportFile = null;
      fileInput.value = '';
    }
  };

  if (ctx && ctx.modalClosers) {
    ctx.modalClosers.saveFileModal = closeSaveFileModal;
    ctx.modalClosers.excelOverwriteConfirmModal = closeExcelOverwriteModal;
    ctx.modalClosers.jsonImportOverwriteConfirmModal = () => closeJsonOverwriteModal(true);
  }

  const MAX_IMPORT_FILE_BYTES = 10 * 1024 * 1024; // 10MB 상한 가드

  const executeJsonFileImport = (file) => {
    if (!file) {
      fileInput.value = '';
      return;
    }
    if (typeof file.size === 'number' && file.size > MAX_IMPORT_FILE_BYTES) {
      showToast('파일 크기가 10MB를 초과해 불러올 수 없습니다. 올바른 자리 배치 파일인지 확인해 주세요.', 'warn');
      fileInput.value = '';
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const state = AppStore.getState();
        const parsed = parseSeatFileText(ev.target.result);
        if (isMultiClassBundlePayload(parsed)) {
          if (!applyMultiClassBundleData(parsed)) {
            showToast('올바른 다중학급 백업 파일 형식이 아닙니다.', 'warn');
          }
        } else if (AppStore.applyLoadedData(parsed, state.classTitle)) {
          const curState = AppStore.getState();
          AppStore.clearPendingCommitTimer();
          stopSequentialReveal();
          stopRouletteColumnAuto();
          AppStore.resetTransientSession();
          clearUndoHistory();
          curState.rulesModalBackup = null;
          if (curState.inSecretRoom && !curState.secretPos) {
            toggleSecretRoom(false, true);
          }
          if (curState.rouletteOpen) initRouletteSession(false);
          document.getElementById('classTitleInput').value = curState.classTitle;
          syncCurrentSlotTitle(curState.classTitle);
          markDirty(false);
          AppStore.commitChange({ roster: true, classroom: true, animate: true, print: true, rules: true, dirty: false, save: true });
          showToast('저장된 파일에서 명렬표와 자리 배치를 불러왔습니다.', 'success');
        } else {
          showToast('올바른 자리 배치 파일 형식이 아닙니다.', 'warn');
        }
      } catch (err) {
        showToast('파일을 읽는 중 오류가 발생했습니다.', 'warn');
      }
      fileInput.value = '';
    };
    reader.onerror = () => {
      showToast('파일을 읽는 중 오류가 발생했습니다. 파일 권한이나 손상 여부를 확인해 주세요.', 'warn');
      fileInput.value = '';
    };
    reader.readAsText(file);
  };

  const jsonOverwriteCancelBtn = document.getElementById('jsonImportOverwriteCancelBtn');
  const jsonOverwriteConfirmBtn = document.getElementById('jsonImportOverwriteConfirmBtn');
  if (jsonOverwriteCancelBtn) {
    jsonOverwriteCancelBtn.addEventListener('click', () => closeJsonOverwriteModal(true));
  }
  if (jsonOverwriteConfirmBtn) {
    jsonOverwriteConfirmBtn.addEventListener('click', () => {
      const targetFile = pendingImportFile;
      pendingImportFile = null;
      closeJsonOverwriteModal(false);
      executeJsonFileImport(targetFile);
    });
  }
  if (jsonOverwriteModal) {
    jsonOverwriteModal.addEventListener('click', (e) => {
      if (e.target === jsonOverwriteModal) closeJsonOverwriteModal(true);
    });
  }

  document.getElementById('importJsonBtn').addEventListener('click', () => {
    fileInput.click();
  });
  fileInput.addEventListener('change', (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    if (typeof file.size === 'number' && file.size > MAX_IMPORT_FILE_BYTES) {
      showToast('파일 크기가 10MB를 초과해 불러올 수 없습니다. 올바른 자리 배치 파일인지 확인해 주세요.', 'warn');
      fileInput.value = '';
      return;
    }
    if (AppStore.getState().isDirty && !AppStore.isRunningSelfDiagnostics() && jsonOverwriteModal) {
      pendingImportFile = file;
      if (jsonOverwriteDesc) {
        const fname = file.name ? `"${file.name}"` : '선택한 파일';
        jsonOverwriteDesc.textContent = `현재 저장되지 않은 변경 사항이 있습니다. ${fname}을(를) 불러오면 현재 작업과 되돌리기 기록이 덮어씌워집니다. 계속 불러오시겠습니까?`;
      }
      jsonOverwriteModal.classList.remove('hidden');
      jsonOverwriteModal.classList.add('flex');
      return;
    }
    executeJsonFileImport(file);
  });
}
