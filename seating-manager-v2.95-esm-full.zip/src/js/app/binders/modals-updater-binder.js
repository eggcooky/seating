// [L5 Binder] 배치 조건 · 거리두기 · 출력/캡처/표 복사 · 자가진단 · 업데이트 모달 바인더
import { sanitizeFileName } from '../../core/utils.js';
import { closeSelfTestModal, runAutomatedSelfDiagnostics } from '../../diagnostics/index.js';
import { applyDefaultGridAlignment } from '../../features/seat-actions.js';
import {
  checkForAppUpdate,
  closeAppUpdateModal,
  closeTamperWarningModal,
  downloadAndSaveLatestProgram,
  hasRemoteUpdateInfo,
  openAppUpdateModal,
  setUpdateModalStatus
} from '../../features/updater-ui.js';
import { triggerBrowserDownload } from '../../infra/storage-io.js';
import { AppStore } from '../../state/store.js';
import { isRouletteBlockingEdit } from '../../ui/guards.js';
import { showToast } from '../../ui/toast.js';
import {
  closeHelpGuideModal,
  closeSecretHelpGuideModal,
  openHelpGuideModal,
  openSecretHelpGuideModal,
  setFocusedHelpStep
} from '../../views/help-guide-view.js';
import {
  captureAndSavePrintLayout,
  closePrintOptionsModal,
  copySeatingTableToClipboard,
  executePrintFromModal,
  openPrintOptionsModal,
  updatePrintOptionsModalUI
} from '../../views/print-view.js';
import {
  addFrontRowStudentWithOverflowCheck,
  addSeparationPairRule,
  addTogetherPairRule,
  closePairOptionModal,
  openPairOptionModal,
  updateRulesUI
} from '../../views/rules-modal-view.js';
import {
  applyRulesAndCloseModal,
  cancelRulesModal,
  openRulesModal
} from '../rules-coordinator.js';

export function bindModalsAndUpdaterEvents(ctx) {
  // 자가 진단 모달 이벤트
  document.getElementById('closeSelfTestModalBtn').addEventListener('click', closeSelfTestModal);
  document.getElementById('doneSelfTestModalBtn').addEventListener('click', closeSelfTestModal);
  document.getElementById('rerunSelfTestBtn').addEventListener('click', runAutomatedSelfDiagnostics);
  document.getElementById('selfTestModal').addEventListener('click', (e) => {
    if (e.target && e.target.id === 'selfTestModal') closeSelfTestModal();
  });

  // 배치 조건 설정 모달 및 거리두기 모달 이벤트
  document.getElementById('openRulesModalBtn').addEventListener('click', openRulesModal);
  document.getElementById('closeRulesModalBtn').addEventListener('click', cancelRulesModal);
  document.getElementById('doneRulesModalBtn').addEventListener('click', cancelRulesModal);
  document.getElementById('applyRulesAndShuffleBtn').addEventListener('click', applyRulesAndCloseModal);

  document.querySelectorAll('.default-cols-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const state = AppStore.getState();
      if (isRouletteBlockingEdit()) return;
      const prevCols = Number(state.rules.defaultCols) || 6;
      state.rules.defaultCols = Number(btn.getAttribute('data-default-cols')) || 6;
      updateRulesUI();
      applyDefaultGridAlignment(true, null, prevCols);
    });
  });

  document.getElementById('modalGenderDistinctionToggle').addEventListener('change', (e) => {
    const state = AppStore.getState();
    state.rules.useGenderDistinction = e.target.checked;
    if (!state.rules.useGenderDistinction) {
      state.rules.genderPairMode = 'any';
      if (state.printShadeMode === 'female' || state.printShadeMode === 'male') {
        state.printShadeMode = 'zebra';
      }
      if (state.printShadeMode === 'zebra') {
        state.printShadeSeatEnabled = false;
      }
    }
    AppStore.commitChange({ roster: true, classroom: true, animate: false, print: true, rules: true, dirty: true, save: true });
    showToast(
      state.rules.useGenderDistinction
        ? '남/여 구분이 활성화되어 명렬표에 성별이 표시됩니다.'
        : '남/여 구분 안 함으로 설정되어 학생 명렬표에서 성별 구분이 숨겨졌습니다.',
      'info'
    );
  });

  document.querySelectorAll('.pair-rule-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const state = AppStore.getState();
      if (state.rules.useGenderDistinction === false) return;
      state.rules.genderPairMode = btn.getAttribute('data-pair-rule');
      AppStore.commitChange({ rules: true, dirty: true, save: true });
    });
  });

  document.getElementById('addSeparationBtn').addEventListener('click', addSeparationPairRule);
  document.getElementById('addTogetherBtn').addEventListener('click', addTogetherPairRule);
  document.getElementById('excludePrevSeatToggle').addEventListener('change', (e) => {
    AppStore.getState().rules.excludePreviousSeat = e.target.checked;
    AppStore.commitChange({ rules: true, dirty: true, save: true });
  });

  document.getElementById('openPairOptionModalBtn').addEventListener('click', openPairOptionModal);
  document.getElementById('closePairOptionModalBtn').addEventListener('click', closePairOptionModal);
  document.getElementById('donePairOptionModalBtn').addEventListener('click', closePairOptionModal);

  document.getElementById('clearAllSeparationsBtn').addEventListener('click', () => {
    AppStore.getState().rules.separatedPairs = [];
    AppStore.commitChange({ rules: true, dirty: true, save: true });
    showToast('등록된 모든 거리두기(짝꿍 분리) 조건이 비워졌습니다.', 'secret');
  });
  document.getElementById('clearAllTogethersBtn').addEventListener('click', () => {
    AppStore.getState().rules.togetherPairs = [];
    AppStore.commitChange({ rules: true, dirty: true, save: true });
    showToast('등록된 모든 친구끼리 붙이기(짝꿍) 조건이 비워졌습니다.', 'secret');
  });

  const frontRowOverflowModalEl = document.getElementById('frontRowOverflowModal');
  const closeFrontRowOverflowModal = () => {
    if (frontRowOverflowModalEl) {
      frontRowOverflowModalEl.classList.add('hidden');
      frontRowOverflowModalEl.classList.remove('flex');
    }
  };
  const overflowCloseBtn = document.getElementById('frontRowOverflowCloseBtn');
  if (overflowCloseBtn) overflowCloseBtn.addEventListener('click', closeFrontRowOverflowModal);
  if (frontRowOverflowModalEl) {
    frontRowOverflowModalEl.addEventListener('click', (e) => {
      if (e.target === frontRowOverflowModalEl) closeFrontRowOverflowModal();
    });
  }

  document.getElementById('addFrontRowBtn').addEventListener('click', addFrontRowStudentWithOverflowCheck);
  document.getElementById('clearFrontRowBtn').addEventListener('click', () => {
    AppStore.getState().rules.frontRowIds = [];
    AppStore.commitChange({ rules: true, dirty: true, save: true });
    showToast('앞줄 우선 배정 목록이 모두 비워졌습니다.', 'info');
  });
  document.getElementById('clearAllRulesBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    state.rules.genderPairMode = 'any';
    state.rules.excludePreviousSeat = false;
    state.rules.frontRowIds = [];
    AppStore.commitChange({ rules: true, dirty: true, save: true });
    showToast('배치 조건이 초기화되었습니다.', 'info');
  });

  // A4 가로 출력 · 캡처 · 표 복사 설정 모달 이벤트
  document.getElementById('printA4Btn').addEventListener('click', openPrintOptionsModal);
  document.getElementById('closePrintOptionsModalBtn').addEventListener('click', closePrintOptionsModal);
  document.getElementById('cancelPrintOptionsModalBtn').addEventListener('click', closePrintOptionsModal);
  document.getElementById('confirmPrintActionBtn').addEventListener('click', executePrintFromModal);
  document.getElementById('capturePrintLayoutBtn').addEventListener('click', captureAndSavePrintLayout);
  const copyPrintTableBtn = document.getElementById('copyPrintTableBtn');
  if (copyPrintTableBtn) copyPrintTableBtn.addEventListener('click', copySeatingTableToClipboard);
  const printOptionsModalEl = document.getElementById('printOptionsModal');
  if (printOptionsModalEl) {
    printOptionsModalEl.addEventListener('click', (e) => {
      if (e.target === printOptionsModalEl) closePrintOptionsModal();
    });
  }
  document.querySelectorAll('.print-orient-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      AppStore.getState().printOrientation = btn.getAttribute('data-print-orient') === 'teacher' ? 'teacher' : 'student';
      updatePrintOptionsModalUI();
      AppStore.commitChange({ print: true, dirty: false, save: true });
    });
  });
  document.querySelectorAll('.print-roster-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      AppStore.getState().printIncludeRoster = btn.getAttribute('data-print-roster') !== 'off';
      updatePrintOptionsModalUI();
      AppStore.commitChange({ print: true, dirty: false, save: true });
    });
  });
  document.querySelectorAll('.print-shade-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const state = AppStore.getState();
      const modeVal = btn.getAttribute('data-print-shade');
      if (['zebra', 'female', 'male', 'none'].includes(modeVal)) {
        const prevMode = state.printShadeMode;
        state.printShadeMode = modeVal;
        if (prevMode !== 'zebra' && modeVal === 'zebra' && state.rules && state.rules.useGenderDistinction === false) {
          state.printShadeSeatEnabled = false;
        }
        updatePrintOptionsModalUI();
        AppStore.commitChange({ print: true, dirty: false, save: true });
      }
    });
  });
  const printShadeToSeatToggleEl = document.getElementById('printShadeToSeatToggle');
  if (printShadeToSeatToggleEl) {
    printShadeToSeatToggleEl.addEventListener('change', (e) => {
      AppStore.getState().printShadeSeatEnabled = Boolean(e.target.checked);
      updatePrintOptionsModalUI();
      AppStore.commitChange({ print: true, dirty: false, save: true });
    });
  }

  // 업데이트 모달 및 손상 경고 모달 이벤트
  document.getElementById('openAppUpdateModalBtn').addEventListener('click', openAppUpdateModal);
  document.getElementById('closeAppUpdateModalBtn').addEventListener('click', closeAppUpdateModal);
  document.getElementById('doneAppUpdateModalBtn').addEventListener('click', closeAppUpdateModal);
  document.getElementById('appUpdateModal').addEventListener('click', (e) => {
    if (e.target && e.target.id === 'appUpdateModal') closeAppUpdateModal();
  });
  document.getElementById('updateModalBackupJsonBtn').addEventListener('click', () => {
    const fileName = sanitizeFileName(AppStore.getState().classTitle || '우리반_자리배치');
    triggerBrowserDownload(fileName);
    setUpdateModalStatus('① 현재 자리 JSON 백업 파일이 저장되었습니다. 이제 ② [최신 버전 받기]를 눌러 주세요.', 'info');
  });
  document.getElementById('downloadLatestProgramBtn').addEventListener('click', downloadAndSaveLatestProgram);
  document.getElementById('appVersionFooterBadge').addEventListener('click', () => {
    if (hasRemoteUpdateInfo()) {
      openAppUpdateModal();
    } else {
      checkForAppUpdate(true);
    }
  });

  const tamperConfirmBtn = document.getElementById('tamperWarningConfirmBtn');
  if (tamperConfirmBtn) {
    tamperConfirmBtn.addEventListener('click', () => {
      closeTamperWarningModal();
      openAppUpdateModal();
    });
  }

  // 첫 실행 안내 · 일반/비밀의 방 사용법 도움말 모달 이벤트
  const openHelpBtn = document.getElementById('openHelpModalBtn');
  if (openHelpBtn) {
    openHelpBtn.addEventListener('click', () => {
      if (AppStore.getState().inSecretRoom) {
        openSecretHelpGuideModal({ isAutoFirstRun: false });
      } else {
        openHelpGuideModal({ isAutoFirstRun: false });
      }
    });
  }
  const closeHelpBtn = document.getElementById('closeHelpModalBtn');
  if (closeHelpBtn) {
    closeHelpBtn.addEventListener('click', () => closeHelpGuideModal({ persistSeen: true }));
  }
  const startHelpBtn = document.getElementById('startHelpGuideBtn');
  if (startHelpBtn) {
    startHelpBtn.addEventListener('click', () => closeHelpGuideModal({ persistSeen: true }));
  }
  const helpModalEl = document.getElementById('helpGuideModal');
  if (helpModalEl) {
    helpModalEl.addEventListener('click', (e) => {
      if (e.target === helpModalEl) closeHelpGuideModal({ persistSeen: true });
    });
  }
  const helpStepListEl = document.getElementById('helpGuideStepList');
  if (helpStepListEl) {
    helpStepListEl.querySelectorAll('[data-help-step]').forEach((item) => {
      const stepNum = Number(item.getAttribute('data-help-step'));
      item.addEventListener('mouseenter', () => setFocusedHelpStep(stepNum, 'normal'));
      item.addEventListener('focus', () => setFocusedHelpStep(stepNum, 'normal'));
    });
    helpStepListEl.addEventListener('mouseleave', () => setFocusedHelpStep(null, 'normal'));
    helpStepListEl.addEventListener('focusout', (e) => {
      if (!helpStepListEl.contains(e.relatedTarget)) setFocusedHelpStep(null, 'normal');
    });
  }

  const closeSecretHelpBtn = document.getElementById('closeSecretHelpModalBtn');
  if (closeSecretHelpBtn) {
    closeSecretHelpBtn.addEventListener('click', () => closeSecretHelpGuideModal({ persistSeen: true }));
  }
  const startSecretHelpBtn = document.getElementById('startSecretHelpGuideBtn');
  if (startSecretHelpBtn) {
    startSecretHelpBtn.addEventListener('click', () => closeSecretHelpGuideModal({ persistSeen: true }));
  }
  const secretHelpModalEl = document.getElementById('secretHelpGuideModal');
  if (secretHelpModalEl) {
    secretHelpModalEl.addEventListener('click', (e) => {
      if (e.target === secretHelpModalEl) closeSecretHelpGuideModal({ persistSeen: true });
    });
  }
  const secretHelpStepListEl = document.getElementById('secretHelpGuideStepList');
  if (secretHelpStepListEl) {
    secretHelpStepListEl.querySelectorAll('[data-secret-help-step]').forEach((item) => {
      const stepNum = Number(item.getAttribute('data-secret-help-step'));
      item.addEventListener('mouseenter', () => setFocusedHelpStep(stepNum, 'secret'));
      item.addEventListener('focus', () => setFocusedHelpStep(stepNum, 'secret'));
    });
    secretHelpStepListEl.addEventListener('mouseleave', () => setFocusedHelpStep(null, 'secret'));
    secretHelpStepListEl.addEventListener('focusout', (e) => {
      if (!secretHelpStepListEl.contains(e.relatedTarget)) setFocusedHelpStep(null, 'secret');
    });
  }

  if (ctx && ctx.modalClosers) {
    ctx.modalClosers.rulesModal = cancelRulesModal;
    ctx.modalClosers.pairOptionModal = closePairOptionModal;
    ctx.modalClosers.printOptionsModal = closePrintOptionsModal;
    ctx.modalClosers.appUpdateModal = closeAppUpdateModal;
    ctx.modalClosers.selfTestModal = closeSelfTestModal;
    ctx.modalClosers.helpGuideModal = () => closeHelpGuideModal({ persistSeen: true });
    ctx.modalClosers.secretHelpGuideModal = () => closeSecretHelpGuideModal({ persistSeen: true });
  }
}
