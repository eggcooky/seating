// [L5 Binder] 이름 가리기 · 순차/전체 공개 · 효과음 · 룰렛 · 비밀의 방 배너 제어 바인더
import { runAutomatedSelfDiagnostics } from '../../diagnostics/index.js';
import { startSequentialReveal, stopSequentialReveal } from '../../features/reveal-controller.js';
import {
  initRouletteSession,
  spinRouletteColumn,
  spinRouletteOnce
} from '../../features/roulette-controller.js';
import {
  applyNormalLocksSyncToSecret,
  requestSyncNormalLocksToSecret
} from '../../features/secret-room-actions.js';
import { playSoundEffect } from '../../infra/audio.js';
import { saveToStorage } from '../../infra/storage-io.js';
import { pushUndoSnapshot } from '../../state/history-store.js';
import { AppStore } from '../../state/store.js';
import { markDirty } from '../../ui/dirty-indicator.js';
import { checkSecretRoomLayoutMismatch } from '../../ui/secret-indicators.js';
import { showToast } from '../../ui/toast.js';
import { renderClassroom } from '../../views/classroom-view.js';
import { updateUndoButtonState } from '../../views/history-popover.js';
import { renderRoster } from '../../views/roster-view.js';
import { updateRevealAllButton } from '../../views/toolbar-ui.js';
import { toggleRouletteDrawer, toggleSecretRoom } from '../mode-coordinator.js';

export function bindRevealAndRouletteEvents(ctx) {
  // 좌측 상단 아이콘(및 제목) 클릭 단축키:
  // - Ctrl(또는 Cmd) + 클릭: 비밀의 방 전환
  // - Alt + 클릭: 내장 자가 진단 실행
  const handleBrandHeaderShortcutClick = (e) => {
    if (e.altKey) {
      e.preventDefault();
      runAutomatedSelfDiagnostics();
    } else if (e.ctrlKey || e.metaKey) {
      e.preventDefault();
      toggleSecretRoom();
    }
  };
  document.getElementById('secretRoomTriggerBtn').addEventListener('click', handleBrandHeaderShortcutClick);
  document.getElementById('appHeaderTitle').addEventListener('click', handleBrandHeaderShortcutClick);

  // 비밀의 방 배너 내 제어 버튼
  document.getElementById('exitSecretRoomBtn').addEventListener('click', () => {
    toggleSecretRoom(false);
  });
  document.getElementById('copyCurrentToSecretBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    pushUndoSnapshot('현재 일반 자리 불러오기', {
      locks: { lockedIds: [...state.lockedIds], secretLockedIds: [...state.secretLockedIds] },
      overwrittenLockIds: [...state.lockedIds]
    });
    state.secretPos = JSON.parse(JSON.stringify(state.pos));
    state.secretLockedIds = [...state.lockedIds];
    state.selectedStudentId = null;
    markDirty(true);
    checkSecretRoomLayoutMismatch(false);
    renderRoster();
    renderClassroom(true);
    saveToStorage(false);
    showToast('현재 일반 화면의 자리 배치와 잠금장치를 비밀의 방으로 불러왔습니다.', 'secret');
  });
  document.getElementById('clearSecretPresetBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    state.secretPos = null;
    state.secretLockedIds = [];
    state.undoStackSecret = [];
    updateUndoButtonState();
    markDirty(true);
    toggleSecretRoom(false);
    saveToStorage(false);
  });

  // 비밀의 방 안내 모달 및 고정석 동기화 충돌 모달
  const secretNoticeModalEl = document.getElementById('secretNoticeModal');
  const closeSecretNotice = () => {
    secretNoticeModalEl.classList.add('hidden');
    secretNoticeModalEl.classList.remove('flex');
  };
  document.getElementById('secretNoticeCloseBtn').addEventListener('click', closeSecretNotice);
  secretNoticeModalEl.addEventListener('click', (e) => {
    if (e.target === secretNoticeModalEl) closeSecretNotice();
  });

  const syncLockConflictModalEl = document.getElementById('syncLockConflictModal');
  const closeSyncLockConflictModal = () => {
    if (syncLockConflictModalEl) {
      syncLockConflictModalEl.classList.add('hidden');
      syncLockConflictModalEl.classList.remove('flex');
    }
  };
  if (ctx && ctx.modalClosers) {
    ctx.modalClosers.secretNoticeModal = closeSecretNotice;
    ctx.modalClosers.syncLockConflictModal = closeSyncLockConflictModal;
  }
  document.getElementById('syncNormalLocksToSecretBtn').addEventListener('click', requestSyncNormalLocksToSecret);
  document.getElementById('syncConflictCancelBtn').addEventListener('click', closeSyncLockConflictModal);
  syncLockConflictModalEl.addEventListener('click', (e) => {
    if (e.target === syncLockConflictModalEl) closeSyncLockConflictModal();
  });
  document.getElementById('syncConflictOverwriteBtn').addEventListener('click', () => {
    closeSyncLockConflictModal();
    applyNormalLocksSyncToSecret(true);
  });
  document.getElementById('syncConflictSkipBtn').addEventListener('click', () => {
    closeSyncLockConflictModal();
    applyNormalLocksSyncToSecret(false);
  });

  // 이름 가리기 모드, 순차·전체 공개, 효과음 버튼
  document.getElementById('toggleMaskModeBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    stopSequentialReveal();
    state.maskModeEnabled = !state.maskModeEnabled;
    if (!state.maskModeEnabled) {
      state.hiddenSeatIds = [];
      showToast('자리 가리기 모드가 해제되어 모든 이름이 표시됩니다.', 'info');
    } else {
      showToast('가리기 모드가 켜졌습니다! [자리 바꾸기]를 누르면 이름이 가려집니다.', 'info');
    }
    AppStore.commitChange({ classroom: true, animate: false, dirty: true, save: true });
  });

  document.getElementById('sequentialRevealBtn').addEventListener('click', startSequentialReveal);

  document.getElementById('revealAllHiddenBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    stopSequentialReveal();
    state.hiddenSeatIds = [];
    playSoundEffect('revealAll');
    updateRevealAllButton();
    renderClassroom(true);
    saveToStorage(false);
    showToast('가려진 모든 학생의 자리 이름이 한 번에 공개되었습니다!', 'success');
  });

  document.getElementById('toggleSoundBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    state.soundEnabled = state.soundEnabled === false;
    AppStore.commitChange({ dirty: true, save: true });
    if (state.soundEnabled) {
      playSoundEffect('toggle');
      showToast('🔊 효과음이 켜졌습니다 (자리 바꾸기·수동 교환·잠금·룰렛·가리기 공개 시 재생).', 'info');
    } else {
      showToast('🔇 효과음이 꺼졌습니다.', 'info');
    }
  });

  // 룰렛 패널 열기·닫기 및 회전 버튼
  document.getElementById('toggleRouletteBtn').addEventListener('click', (e) => {
    const isCtrlPressed = Boolean(e && (e.ctrlKey || e.metaKey));
    toggleRouletteDrawer(undefined, isCtrlPressed);
  });
  document.getElementById('closeRouletteDrawerBtn').addEventListener('click', () => {
    toggleRouletteDrawer(false, false);
  });
  document.getElementById('resetRouletteSessionBtn').addEventListener('click', () => {
    initRouletteSession(false);
    showToast('룰렛 배정 순서가 처음부터 다시 초기화되었습니다.', 'info');
  });
  document.getElementById('rouletteWheelCanvas').addEventListener('click', spinRouletteOnce);
  document.getElementById('spinWheelCenterBtn').addEventListener('click', spinRouletteOnce);
  document.getElementById('spinRouletteActionBtn').addEventListener('click', spinRouletteOnce);
  document.getElementById('spinRouletteColumnBtn').addEventListener('click', spinRouletteColumn);
}
