// [L5] AppStore 동기 Hook · View 핸들러 · History 훅 단일 조립기 (의존성 역전 종착점)
import { animateSingleDeskById, revealSeat } from '../features/reveal-controller.js';
import { deleteStudentById, toggleRosterNumEditMode, updateStudentNumInline } from '../features/roster-actions.js';
import { drawRouletteWheel, updateRouletteStatusUI } from '../features/roulette-controller.js';
import { handleEmptySlotClick, handleStudentPick, toggleSeatLock } from '../features/seat-actions.js';
import { saveToStorage } from '../infra/storage-io.js';
import { configureHistoryHooks } from '../state/history-store.js';
import { AppStore } from '../state/store.js';
import { markDirty } from '../ui/dirty-indicator.js';
import { applyDefaultModeStatusPillStyle } from '../ui/toast.js';
import { bindClassroomHandlers, renderClassroom } from '../views/classroom-view.js';
import { bindHistoryPopoverHandlers, updateUndoButtonState } from '../views/history-popover.js';
import { renderPrintView } from '../views/print-view.js';
import { bindRosterHandlers, renderRoster } from '../views/roster-view.js';
import { updateRulesUI } from '../views/rules-modal-view.js';
import {
  updateLargeViewButtonUI,
  updateMaskModeButtonUI,
  updateRevealAllButton,
  updateSoundButtonUI
} from '../views/toolbar-ui.js';
import { restoreHistoryAtIndex } from './history-coordinator.js';

function syncViewsImpl({ roster = true, classroom = true, animate = false, print = false, rules = true } = {}) {
  const state = AppStore.getState();
  updateMaskModeButtonUI();
  updateSoundButtonUI();
  updateLargeViewButtonUI();
  updateRevealAllButton();
  const genderColorToggle = document.getElementById('showGenderColorToggle');
  if (genderColorToggle) {
    genderColorToggle.checked = Boolean(state.showGenderColor);
  }
  if (roster) renderRoster();
  if (classroom) renderClassroom(animate);
  if (print) {
    renderPrintView();
  }
  if (rules) updateRulesUI();
}

function commitChangeImpl({ roster = false, classroom = false, animate = false, print = false, rules = false, roulette = false } = {}) {
  const state = AppStore.getState();
  if (roster || classroom || print || rules) {
    // 인쇄 전용 뷰(#printSheetContainer)는 평상시 지연 렌더링(_printViewDirty=true)을 유지한다.
    AppStore.syncViews({ roster, classroom, animate, print: false, rules });
  } else {
    updateMaskModeButtonUI();
    updateSoundButtonUI();
    updateLargeViewButtonUI();
    updateRevealAllButton();
  }
  if (roulette && state.rouletteOpen && !state.inSecretRoom) {
    updateRouletteStatusUI();
    drawRouletteWheel();
  }
}

export function wireAppCoordinators() {
  AppStore.configureHooks({
    onSyncViews: syncViewsImpl,
    onCommit: commitChangeImpl,
    onFlushPrint: renderPrintView,
    onPersist: saveToStorage,
    onMarkDirty: markDirty,
    onRenderClassroom: (animate = false) => renderClassroom(animate),
    onRenderRosterAndClassroom: (animate = false) => {
      renderRoster();
      renderClassroom(animate);
    }
  });

  configureHistoryHooks({
    onStackChanged: updateUndoButtonState,
    onCleared: applyDefaultModeStatusPillStyle
  });

  bindClassroomHandlers({
    onStudentPick: handleStudentPick,
    onEmptySlotClick: handleEmptySlotClick,
    onToggleLock: toggleSeatLock,
    onRevealSeat: revealSeat,
    onAnimateDesk: animateSingleDeskById,
    onRouletteTargetPicked: updateRouletteStatusUI
  });

  bindRosterHandlers({
    onStudentPick: handleStudentPick,
    onDeleteStudent: deleteStudentById,
    onRouletteRedraw: drawRouletteWheel,
    onUpdateStudentNum: updateStudentNumInline,
    onExitNumEdit: () => toggleRosterNumEditMode(false)
  });

  bindHistoryPopoverHandlers({
    onRestoreHistory: restoreHistoryAtIndex
  });
}
