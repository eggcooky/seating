// 자가 진단 스위트 2: 비밀의 방 · 룰렛 · UI 조작 · A4 인쇄/캡처 · 엑셀/난독화/Undo (항목 8~12)
import { restoreHistoryAtIndex } from '../app/history-coordinator.js';
import { toggleSecretRoom } from '../app/mode-coordinator.js';
import { isSimpleObfuscatedText, parseSeatFileText } from '../domain/codec.js';
import { parseExcelRosterWithDiagnostics } from '../domain/excel-parser.js';
import {
  getLockedSeatConflicts,
  isNormalSeatLocked,
  isSeatHidden,
  isSeatLocked
} from '../domain/seat-queries.js';
import { revealSeat, toggleLargeViewMode } from '../features/reveal-controller.js';
import { finalizeRoulettePick, initRouletteSession, spinRouletteOnce } from '../features/roulette-controller.js';
import {
  applyDefaultGridAlignment,
  handleEmptySlotClick,
  handleStudentPick,
  toggleSeatLock
} from '../features/seat-actions.js';
import { arrangeByStudentNumber, handleShuffleButtonClick } from '../features/seating-actions.js';
import {
  applyNormalLocksSyncToSecret,
  requestSyncNormalLocksToSecret
} from '../features/secret-room-actions.js';
import { getActiveStorageKey, getObfuscatedPayload, loadFromStorage } from '../infra/storage-io.js';
import { pushUndoSnapshot } from '../state/history-store.js';
import { AppStore, setRunningSelfDiagnostics } from '../state/store.js';
import { updateSecretPresetIndicator } from '../ui/secret-indicators.js';
import {
  closePrintOptionsModal,
  generatePrintCaptureCanvas,
  openPrintOptionsModal,
  renderPrintView
} from '../views/print-view.js';
import { updateRevealAllButton, updateSoundButtonUI } from '../views/toolbar-ui.js';

export function runFeatureDiagnostics({ recordTest, setupClassRoster, assertValidUniqueCoords }) {
  // 8. 비밀의 방 사전 지정 적용 및 고정석 충돌 감지 검증
  recordTest('8. 비밀의 방 사전 지정 및 고정석 충돌 감지 검증', () => {
    let state = setupClassRoster(30, 6);
    state.secretPos = JSON.parse(JSON.stringify(state.pos));
    const st1 = state.students[0];
    const st2 = state.students[1];
    const targetPos1 = [...state.secretPos[st2.id]];
    const targetPos2 = [...state.secretPos[st1.id]];
    state.secretPos[st1.id] = targetPos1;
    state.secretPos[st2.id] = targetPos2;

    state.lockedIds = [st1.id];
    const conflictNames = getLockedSeatConflicts(state);
    if (conflictNames.length !== 1 || conflictNames[0] !== st1.name) {
      throw new Error('고정석 충돌 학생명 감지 실패');
    }
    state.lockedIds = [];
    handleShuffleButtonClick({ ctrlKey: true });
    if (state.pos[st1.id][0] !== targetPos1[0] || state.pos[st1.id][1] !== targetPos1[1]) {
      throw new Error('Ctrl+자리바꾸기 실행 후 비밀의 방 좌표 미적용');
    }
    // 일반 화면에서 가리기 배정 후 비밀의 방에 들어가 섞거나 번호순 배치를 해도 일반 화면 가리기 목록(hiddenSeatIds)이 보존되는지 검증
    state.maskModeEnabled = true;
    handleShuffleButtonClick({});
    if (state.hiddenSeatIds.length !== 30) throw new Error('일반 화면 30명 가리기 실패');
    toggleSecretRoom(true);
    handleShuffleButtonClick({});
    arrangeByStudentNumber();
    toggleSecretRoom(false);
    if (state.hiddenSeatIds.length !== 30) {
      throw new Error('비밀의 방 내부 섞기·번호순 배치 후 일반 화면 가리기 상태가 풀림');
    }
    state.maskModeEnabled = false;
    state.hiddenSeatIds = [];
    // 일반 화면 섞기 후 비밀의 방에서 고정석을 지정하고 일반 화면에서 되돌리기(Undo)를 눌러도 비밀의 방 고정석이 보존되는지 검증
    toggleSecretRoom(true);
    state.secretLockedIds = ['s1', 's2'];
    toggleSecretRoom(false);
    restoreHistoryAtIndex(state.undoStackNormal.length - 1);
    if (state.secretLockedIds.length !== 2 || !state.secretLockedIds.includes('s1')) {
      throw new Error('일반 화면 되돌리기(Undo) 실행으로 비밀의 방 고정석이 삭제됨');
    }
    // [v2.57 보강] 일반방 고정석 동기화(충돌 유지·양쪽 잠금 보호·자기충돌 감지·0명 빈Undo 차단·덮어쓰기) 및 현재 자리 불러오기 Undo 검증
    state.lockedIds = ['s3', 's4'];
    toggleSecretRoom(true);
    const s3NormalCoord = [...state.pos['s3']];
    const s4NormalCoord = [...state.pos['s4']];
    state.secretPos['s3'] = [...s4NormalCoord];
    state.secretPos['s4'] = [...s3NormalCoord];
    state.secretLockedIds = ['s4'];
    const secUndoBeforeNoOp = state.undoStackSecret.length;
    applyNormalLocksSyncToSecret(false); // 충돌 시 유지 (s3·s4 모두 보호, 0명 동기화)
    if (state.secretPos['s4'][0] !== s3NormalCoord[0] || state.secretPos['s4'][1] !== s3NormalCoord[1]) {
      throw new Error('일반방 고정석 동기화(충돌 유지) 시 양쪽 잠금 학생의 비밀 고정석이 덮어써짐');
    }
    if (state.undoStackSecret.length !== secUndoBeforeNoOp) {
      throw new Error('0명 동기화(전원 유지) 시 불필요한 빈 Undo 스냅샷이 기록됨');
    }
    // 자기충돌(본인 비밀잠금이 다른 위치) 모달 감지 검증
    state.lockedIds = ['s3'];
    state.secretLockedIds = ['s3'];
    requestSyncNormalLocksToSecret();
    const syncConflictModalEl = document.getElementById('syncLockConflictModal');
    if (!syncConflictModalEl || syncConflictModalEl.classList.contains('hidden')) {
      throw new Error('본인 비밀 고정석 위치 불일치(자기충돌) 시 충돌 해결 모달 미표시');
    }
    syncConflictModalEl.classList.add('hidden');
    syncConflictModalEl.classList.remove('flex');
    // 덮어쓰기 검증
    state.lockedIds = ['s3'];
    state.secretLockedIds = ['s4'];
    applyNormalLocksSyncToSecret(true);
    if (state.secretPos['s3'][0] !== s3NormalCoord[0] || state.secretPos['s3'][1] !== s3NormalCoord[1] || !state.secretLockedIds.includes('s3') || state.secretLockedIds.includes('s4')) {
      throw new Error('일반방 고정석 동기화(덮어쓰기) 실패');
    }
    // [현재 일반 자리 불러오기] Undo 지원 검증 (서로 다른 위치의 비밀 고정석 덮어쓰기 후 원복 포함)
    state.secretPos['s3'] = [...s4NormalCoord];
    state.secretPos['s4'] = [...s3NormalCoord];
    state.secretLockedIds = ['s3'];
    const secBeforeCopy = JSON.parse(JSON.stringify(state.secretPos));
    const secUndoBeforeCopy = state.undoStackSecret.length;
    document.getElementById('copyCurrentToSecretBtn').click();
    if (state.undoStackSecret.length !== secUndoBeforeCopy + 1) {
      throw new Error('현재 일반 자리 불러오기 실행 시 Undo 스냅샷 미기록');
    }
    restoreHistoryAtIndex(state.undoStackSecret.length - 1);
    const copyUndoAllMatch = state.students.every(st => {
      const a = secBeforeCopy[st.id], b = state.secretPos[st.id];
      return a && b && a[0] === b[0] && a[1] === b[1];
    });
    if (!copyUndoAllMatch) {
      throw new Error('현재 일반 자리 불러오기 Undo 복원 불일치');
    }
    toggleSecretRoom(false);
    // [v2.59 보강] 일반 화면에서 비밀 옵션(거리두기)만 충돌할 때 비밀 문구 미노출·중립 재시도 경고 검증
    state = setupClassRoster(4, 2);
    state.rules.separatedPairs = [['s1','s2'],['s1','s3'],['s1','s4'],['s2','s3'],['s2','s4'],['s3','s4']];
    try {
      setRunningSelfDiagnostics(false);
      handleShuffleButtonClick({});
    } finally {
      setRunningSelfDiagnostics(true);
    }
    const stealthToast = (document.getElementById('modeStatusText') || {}).textContent || '';
    if (stealthToast.includes('거리두기') || stealthToast.includes('붙이기') || !stealthToast.includes('최적의 자리 배치를 찾지 못했습니다')) {
      throw new Error('일반 화면 비밀 옵션 충돌 시 스텔스 중립 경고 처리 실패: ' + stealthToast);
    }
    // [v2.95 보강] 일반 화면 충돌 시 상세 원인이 대기 알림에 저장되고(일반 화면 모달 미표시), 첫 비밀방 진입·비밀방 내부 섞기(방안 A) 시 모달 표시 검증
    const noticeModalEl = document.getElementById('secretNoticeModal');
    const noticeListEl = document.getElementById('secretNoticeList');
    if (noticeModalEl && !noticeModalEl.classList.contains('hidden')) {
      throw new Error('일반 화면 충돌 직후 비밀 알림 모달이 노출됨(스텔스 위반)');
    }
    if (!Array.isArray(state.pendingSecretNotices) || state.pendingSecretNotices.length < 2 ||
        !state.pendingSecretNotices.some(msg => msg.includes('거리두기'))) {
      throw new Error('일반 화면 충돌 원인(pendingSecretNotices) 미기록');
    }
    state.secretPos = null; // 첫 비밀방 진입(!hadExistingSecretPreset)에서도 대기 알림이 초기화되지 않는지 검증
    toggleSecretRoom(true, true);
    const enterNoticeText = noticeListEl ? noticeListEl.textContent : '';
    if (!noticeModalEl || noticeModalEl.classList.contains('hidden') || !enterNoticeText.includes('거리두기') || state.pendingSecretNotices.length !== 0) {
      throw new Error('비밀의 방 첫 진입 시 충돌 원인 진단 모달 자동 표시 실패');
    }
    noticeModalEl.classList.add('hidden');
    noticeModalEl.classList.remove('flex');
    // 방안 A: 비밀의 방 내부 랜덤 섞기 충돌 시 즉시 모달 표시
    handleShuffleButtonClick({});
    const inSecretNoticeText = noticeListEl ? noticeListEl.textContent : '';
    if (noticeModalEl.classList.contains('hidden') || !inSecretNoticeText.includes('비밀 자리 섞기 미충족 원인') || !inSecretNoticeText.includes('거리두기')) {
      throw new Error('비밀의 방 내부 섞기 충돌 시 즉시 원인 모달(방안 A) 표시 실패');
    }
    noticeModalEl.classList.add('hidden');
    noticeModalEl.classList.remove('flex');
    toggleSecretRoom(false, true);
    // 충돌 0건 재섞기 시 대기 알림 자동 초기화 검증
    state.rules.separatedPairs = [];
    state.pendingSecretNotices = ['이전 낡은 충돌 알림'];
    handleShuffleButtonClick({});
    if (state.pendingSecretNotices.length !== 0) {
      throw new Error('정상 배정(충돌 0건) 후 대기 중이던 충돌 알림 미초기화');
    }
    state.lockedIds = [];
    state.secretLockedIds = [];
    return '30명 비밀의 방 스텔스·충돌원인모달(진입/내부)·Ctrl+적용·가리기·고정석 동기화·불러오기Undo 확인';
  });

  // 9. [누락 영역 보강 1] 룰렛 추첨(일반 및 비밀의 방 연동) 전 과정 검증
  recordTest('9. 룰렛 추첨(일반 · 비밀의 방 연동) 전 과정 검증', () => {
    const state = setupClassRoster(30, 6);
    state.secretPos = JSON.parse(JSON.stringify(state.pos));
    // 비밀의 방에서 1번과 30번 자리를 교환해 사전 배치 구성
    const p1 = [...state.secretPos['s1']];
    const p30 = [...state.secretPos['s30']];
    state.secretPos['s1'] = p30;
    state.secretPos['s30'] = p1;

    // 일반 화면 고정석 2명 설정 후 비밀의 방 연동 룰렛 세션 초기화
    state.lockedIds = ['s5', 's10'];
    initRouletteSession(true);
    if (!state.rouletteActiveSession || state.rouletteRemainingStudents.length !== 28) {
      throw new Error('고정석 2명을 제외한 28명 룰렛 대기열 생성 실패');
    }
    // 28명 전원 연속 추첨 시뮬레이션
    while (state.rouletteRemainingStudents.length > 0) {
      const targetCoord = state.rouletteTargetCoords[0];
      const secretMatchIdx = state.rouletteRemainingStudents.findIndex(s => {
        const sp = state.secretPos[s.id];
        return sp && sp[0] === targetCoord[0] && sp[1] === targetCoord[1];
      });
      const pickIdx = secretMatchIdx !== -1 ? secretMatchIdx : 0;
      const winner = state.rouletteRemainingStudents[pickIdx];
      finalizeRoulettePick(pickIdx, winner, targetCoord);
    }
    assertValidUniqueCoords(state.pos, 30);
    if (state.pos['s1'][0] !== p30[0] || state.pos['s1'][1] !== p30[1]) {
      throw new Error('룰렛 추첨 완료 후 비밀의 방 사전 지정 좌표 불일치');
    }
    // 가리기 모드에서 룰렛 전원 배정 완료 후 실수로 원판을 한 번 더 클릭해도 가려진 좌석(hiddenSeatIds)이 풀리지 않는지 검증
    state.maskModeEnabled = true;
    initRouletteSession(false);
    while (state.rouletteRemainingStudents.length > 0) {
      const tc = state.rouletteTargetCoords[0];
      const w = state.rouletteRemainingStudents[0];
      finalizeRoulettePick(0, w, tc);
    }
    if (state.hiddenSeatIds.length !== 28) {
      throw new Error('가리기+룰렛 완료 후 가려진 좌석 수(28석) 불일치');
    }
    const posAfterComplete = JSON.stringify(state.pos);
    spinRouletteOnce({}); // 완료 후 추가 클릭 시뮬레이션
    if (state.hiddenSeatIds.length !== 28 || state.rouletteActiveSession !== false || JSON.stringify(state.pos) !== posAfterComplete) {
      throw new Error('룰렛 완료 후 추가 클릭 시 가려진 좌석 또는 배정 결과가 초기화됨');
    }
    state.maskModeEnabled = false;
    state.hiddenSeatIds = [];
    // 1줄(세로) 뽑기 검증: 1열(col=1) 좌석들만 연속 배정되고 2열 시작 전에 멈추는지 확인
    state.lockedIds = [];
    initRouletteSession(false);
    const firstCol = state.rouletteTargetCoords[0][0];
    state.rouletteAutoColumnTarget = firstCol;
    while (state.rouletteAutoColumnTarget !== null && state.rouletteRemainingStudents.length > 0) {
      const tc = state.rouletteTargetCoords[0];
      const w = state.rouletteRemainingStudents[0];
      finalizeRoulettePick(0, w, tc);
    }
    if (state.rouletteRemainingStudents.length !== 25 || state.rouletteTargetCoords[0][0] === firstCol) {
      throw new Error('룰렛 1줄(세로) 뽑기 후 남은 인원(25명) 또는 다음 열 전환 불일치');
    }
    // 룰렛 1명 배정 후 해당 학생 잠금(🔒) -> 되돌리기(Undo) -> 남은 룰렛 완료 시 잠긴 학생이 이동하지 않는지 검증
    state.rouletteOpen = true;
    initRouletteSession(false);
    const wFirst = state.rouletteRemainingStudents[0];
    finalizeRoulettePick(0, wFirst, state.rouletteTargetCoords[0]);
    toggleSeatLock(wFirst.id);
    restoreHistoryAtIndex(state.undoStackNormal.length - 1);
    if (!isNormalSeatLocked(state, wFirst.id) || state.rouletteRemainingStudents.some(s => s.id === wFirst.id)) {
      throw new Error('룰렛 배정 학생 잠금 후 되돌리기 시 잠금 해제되거나 대기열에서 제외되지 않음');
    }
    const lockedPosAfterUndo = [...state.pos[wFirst.id]];
    while (state.rouletteRemainingStudents.length > 0) {
      finalizeRoulettePick(0, state.rouletteRemainingStudents[0], state.rouletteTargetCoords[0]);
    }
    assertValidUniqueCoords(state.pos, 30);
    if (state.pos[wFirst.id][0] !== lockedPosAfterUndo[0] || state.pos[wFirst.id][1] !== lockedPosAfterUndo[1]) {
      throw new Error('룰렛 잠금+되돌리기 후 잔여 추첨 중 잠긴 학생 위치가 변경됨');
    }
    // [v2.43 보강] 룰렛 도중 미추첨 학생 잠금/해제 시 대기열·목표좌석 수 실시간 일치 및 전원 잠금 시 세션 비활성화 검증
    state.lockedIds = [];
    initRouletteSession(false);
    const midTarget = state.rouletteRemainingStudents[5];
    toggleSeatLock(midTarget.id);
    if (state.rouletteRemainingStudents.some(s => s.id === midTarget.id) ||
        state.rouletteRemainingStudents.length !== state.rouletteTargetCoords.length) {
      throw new Error('룰렛 도중 잠금 시 대기열 제외 또는 목표 좌석 수 불일치');
    }
    toggleSeatLock(midTarget.id); // 다시 잠금 해제
    if (!state.rouletteRemainingStudents.some(s => s.id === midTarget.id) ||
        state.rouletteRemainingStudents.length !== state.rouletteTargetCoords.length) {
      throw new Error('룰렛 도중 잠금 해제 시 대기열 복귀 또는 목표 좌석 수 불일치');
    }
    state.lockedIds = state.students.map(s => String(s.id));
    initRouletteSession(false);
    if (state.rouletteActiveSession !== false) {
      throw new Error('전원 잠금 상태에서 룰렛 세션이 활성(편집 차단) 상태로 남음');
    }
    // [v2.50 보강] 룰렛 열림 + 일반 자리바꾸기 후 좌석 잠금 시 rouletteActiveSession이 강제로 켜지지 않는지 검증
    state.lockedIds = [];
    initRouletteSession(false);
    handleShuffleButtonClick({});
    toggleSeatLock('s1');
    if (state.rouletteActiveSession !== false) {
      throw new Error('자리바꾸기 후 좌석 잠금 시 꺼져 있던 룰렛 세션이 강제 활성화됨');
    }
    // [v2.88 보강] 비밀 연동 룰렛 중 Ctrl+클릭 자리바꾸기 및 resetTransientSession() 시 rouletteUseSecretPreset 초기화 검증
    state.lockedIds = [];
    state.secretPos = JSON.parse(JSON.stringify(state.pos));
    initRouletteSession(true);
    if (state.rouletteUseSecretPreset !== true) {
      throw new Error('비밀 연동 룰렛 초기화 시 rouletteUseSecretPreset 미활성화');
    }
    handleShuffleButtonClick({ ctrlKey: true });
    if (state.rouletteUseSecretPreset !== false) {
      throw new Error('Ctrl+클릭 자리바꾸기 후 rouletteUseSecretPreset 상태 잔류 발생');
    }
    state.rouletteUseSecretPreset = true;
    AppStore.resetTransientSession();
    if (state.rouletteUseSecretPreset !== false) {
      throw new Error('resetTransientSession() 호출 후 rouletteUseSecretPreset 미초기화');
    }
    state.lockedIds = [];
    state.rouletteOpen = false;
    state.lockedIds = [];
    return '30명 룰렛(일반·비밀·1줄연속·잠금후Undo·완료후가리기보존) 통과';
  });

  // 10. 이름 가리기 · 효과음 토글 · 수동 자리교환 · 책상이동 · 자물쇠 잠금 통합 검증
  recordTest('10. 가리기 · 효과음 · 수동 자리교환 · 책상이동 · 자물쇠 잠금 검증', () => {
    const state = setupClassRoster(30, 6);
    // (A) 자물쇠 잠금 토글 검증
    toggleSeatLock('s1');
    toggleSeatLock('s2');
    if (!isSeatLocked(state, 's1') || !isSeatLocked(state, 's2')) {
      throw new Error('자물쇠 잠금(toggleSeatLock) 상태 반영 실패');
    }
    // (B) 이름 가리기 모드 및 개별·전체 공개 검증
    state.maskModeEnabled = true;
    handleShuffleButtonClick({});
    if (state.hiddenSeatIds.length !== 28 || isSeatHidden(state, 's1') || isSeatHidden(state, 's2')) {
      throw new Error('이름 가리기 대상 인원(28명) 또는 고정석 예외 처리 오류');
    }
    revealSeat('s3', false);
    if (isSeatHidden(state, 's3') || state.hiddenSeatIds.length !== 27) {
      throw new Error('개별 좌석 클릭 공개(revealSeat) 동작 오류');
    }
    state.hiddenSeatIds = [];
    updateRevealAllButton();

    // (C) 마우스 클릭 1:1 수동 자리 맞바꾸기(handleStudentPick) 검증
    const p3Before = [...state.pos['s3']];
    const p4Before = [...state.pos['s4']];
    handleStudentPick('s3');
    if (state.selectedStudentId !== 's3') throw new Error('첫 번째 학생 클릭 선택 실패');
    // ESC 키로 선택 취소 후 다시 선택 검증
    window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape' }));
    if (state.selectedStudentId !== null) throw new Error('ESC 키 입력 시 학생 선택 취소 실패');
    handleStudentPick('s3');
    handleStudentPick('s4');
    if (state.selectedStudentId !== null ||
        state.pos['s3'][0] !== p4Before[0] || state.pos['s3'][1] !== p4Before[1] ||
        state.pos['s4'][0] !== p3Before[0] || state.pos['s4'][1] !== p3Before[1]) {
      throw new Error('마우스 수동 1:1 자리 맞바꾸기 좌표 교환 실패');
    }

    // (D) v2.50 학생 클릭 통합 책상 이동(모드 전환 없이 학생 선택 후 빈칸 클릭 즉시 이동) 및 삭제 알림 점 검증
    handleStudentPick('s5');
    handleEmptySlotClick(9, 9);
    if (state.pos['s5'][0] !== 9 || state.pos['s5'][1] !== 9 || state.selectedStudentId !== null) {
      throw new Error('학생 클릭 통합 빈칸 이동 실패');
    }
    state.hasDeleteGapNotice = true;
    updateSecretPresetIndicator();
    const gapDotEl = document.getElementById('alignGapAlertDot');
    if (!gapDotEl || gapDotEl.classList.contains('hidden')) {
      throw new Error('학생 삭제 빈자리 알림 빨간 점 미표시');
    }
    applyDefaultGridAlignment(false, null);
    if (!gapDotEl.classList.contains('hidden')) {
      throw new Error('기본 대형 정렬 후 삭제 빈자리 알림 빨간 점 미해제');
    }

    // (E) 효과음 토글 상태 전환 및 UI 버튼 동기화 검증
    state.soundEnabled = false;
    updateSoundButtonUI();
    const soundLabel = document.getElementById('soundBtnLabel');
    if (soundLabel && !soundLabel.textContent.includes('꺼짐')) {
      throw new Error('효과음 꺼짐 UI 동기화 실패');
    }
    state.soundEnabled = true;
    updateSoundButtonUI();
    if (soundLabel && !soundLabel.textContent.includes('켜짐')) {
      throw new Error('효과음 켜짐 UI 동기화 실패');
    }
    // (F) 전체화면 · 글자 크게 보기(toggleLargeViewMode) 전환 및 복원 검증
    toggleLargeViewMode(true);
    const largeLabel = document.getElementById('largeViewBtnLabel');
    if (!state.largeViewEnabled || !state.sidebarCollapsed || (largeLabel && !largeLabel.textContent.includes('기본 크기'))) {
      throw new Error('글자 크게 보기 모드 활성화 실패');
    }
    toggleLargeViewMode(false);
    if (state.largeViewEnabled || state.sidebarCollapsed || (largeLabel && !largeLabel.textContent.includes('크게 보기'))) {
      throw new Error('글자 크게 보기 모드 해제 복원 실패');
    }
    return '가리기·효과음·글자크게보기·1:1수동교환·책상이동·자물쇠 모두 정상';
  });

  // 11. A4 인쇄 · 캡처 옵션 모달(시점 · 명렬표 유무 · 4종 흑백 음영 좌석 연동 · Canvas 캡처) 검증
  recordTest('11. A4 인쇄 · 캡처 옵션(명렬표 유무 · 4종 음영 좌석 연동 · 이미지 생성) 검증', () => {
    const state = setupClassRoster(30, 6);
    state.rules.useGenderDistinction = true;
    state.printOrientation = 'student';
    state.printIncludeRoster = true;
    state.printShadeMode = 'female';
    renderPrintView();
    const printTable = document.getElementById('printRosterTable');
    const tbody = document.getElementById('printRosterTableBody');
    const genderTh = document.getElementById('printHeaderGenderTh');
    const printStage = document.getElementById('printClassroomStage');
    const rosterWrapper = document.getElementById('printRosterWrapper');
    if (!printTable || !tbody || !genderTh || !printStage || !rosterWrapper) {
      throw new Error('인쇄 전용 테이블 또는 스테이지 DOM 요소 누락');
    }
    const printDateEl = printStage.querySelector('[data-print-date="1"]');
    if (!printDateEl || !printDateEl.textContent.includes('기준')) {
      throw new Error('인쇄 뷰 우측 하단 기준 날짜 요소 누락');
    }
    if (genderTh.className.includes('hidden')) {
      throw new Error('성별 구분 활성화 상태에서 인쇄 표 성별 헤더가 숨겨짐');
    }
    // (A) 4종 음영('female', 'male', 'zebra', 'none') 및 책상 반영 스위치(ON/OFF) 검증
    state.printShadeSeatEnabled = true;
    for (const [mode, expectedCount] of [['female', 15], ['male', 15], ['zebra', 15], ['none', 0]]) {
      state.printShadeMode = mode;
      renderPrintView();
      const shadedRows = tbody.querySelectorAll('.print-female-row').length;
      const shadedSeats = printStage.querySelectorAll('.print-shaded-seat').length;
      if (shadedRows !== expectedCount || shadedSeats !== expectedCount) {
        throw new Error(mode + ' 음영 모드(스위치 ON)에서 명렬표(' + shadedRows + ') 또는 좌석표(' + shadedSeats + ') 음영 수 불일치');
      }
    }
    // 책상 반영 스위치 OFF 시 명렬표만 음영 유지되고 책상 음영은 0개인지 검증
    state.printShadeMode = 'female';
    state.printShadeSeatEnabled = false;
    renderPrintView();
    if (tbody.querySelectorAll('.print-female-row').length !== 15 || printStage.querySelectorAll('.print-shaded-seat').length !== 0) {
      throw new Error('책상 음영 반영 스위치 OFF 시 명렬표(15) 및 좌석표(0) 분리 반영 실패');
    }
    state.printShadeSeatEnabled = true;
    // (B) 명렬표 제외(printIncludeRoster = false) 시 좌측 명렬표가 숨겨지고 좌석표가 전체 폭(265mm)으로 확장되는지 확인
    state.printIncludeRoster = false;
    renderPrintView();
    const stageText11 = printStage.textContent || '';
    if (!stageText11.includes(String(state.classTitle || '우리 반 자리 배치표').trim()) || !stageText11.includes('게시용')) {
      throw new Error('인쇄 뷰 우측 프레임 학급 제목·게시 시점 헤더 누락');
    }
    if (!rosterWrapper.className.includes('hidden') || !printStage.innerHTML.includes('max-w-[265mm]')) {
      throw new Error('명렬표 제외 옵션 선택 시 명렬표 숨김 또는 좌석표 폭 확장 미반영');
    }
    state.printIncludeRoster = true;
    state.printShadeMode = 'female';
    // (C) 성별 구분 비활성화 시 인쇄 표 성별 헤더 숨김, 홀짝번 음영('zebra') 전환 및 책상 반영 스위치 자동 OFF 확인
    state.rules.useGenderDistinction = false;
    openPrintOptionsModal();
    closePrintOptionsModal();
    if (!genderTh.className.includes('hidden') || state.printShadeMode !== 'zebra' || state.printShadeSeatEnabled !== false) {
      throw new Error('성별 구분 해제 시 홀짝번 음영 전환 또는 책상 반영 스위치 기본 OFF 연동 실패');
    }
    if (tbody.querySelectorAll('.print-female-row').length !== 15 || printStage.querySelectorAll('.print-shaded-seat').length !== 0) {
      throw new Error('성별 구분 해제 + 홀짝번 음영 상태에서 책상 음영 자동 해제 미반영');
    }
    // (D) 오프라인 Canvas 2D 2배 초고해상도 캡처 엔진(generatePrintCaptureCanvas: 4400x3112) 무결성 검증
    const capCanvas = generatePrintCaptureCanvas();
    if (!capCanvas || capCanvas.width !== 4400 || capCanvas.height !== 3112) {
      throw new Error('오프라인 캡처 Canvas 2배 해상도(4400x3112) 생성 실패');
    }
    // (E) 지연 렌더링(beforeprint) 검증
    state.students[0].name = '지연렌더링확인학생';
    AppStore.commitChange({ classroom: true, dirty: false, save: false });
    if (AppStore.isPrintViewDirty() !== true || tbody.textContent.includes('지연렌더링확인학생')) {
      throw new Error('평상시 화면 갱신 시 인쇄 뷰 지연 플래그(isPrintViewDirty) 미작동');
    }
    window.dispatchEvent(new Event('beforeprint'));
    if (AppStore.isPrintViewDirty() !== false || !tbody.textContent.includes('지연렌더링확인학생')) {
      throw new Error('beforeprint 이벤트 발생 시 인쇄 뷰 즉시 렌더링 동기화 실패');
    }
    return '시점·명렬표유무·4종음영(좌석연동 15/15)·고화질캡처·지연렌더링 통과';
  });

  // 12. 엑셀 예외·영문이름 방어 · 0명 새로고침 보존 · 난독화(simple-v1) · Undo 검증
  recordTest('12. 엑셀 예외·영문이름 · 0명 설정보존 · 난독화 · 실행 취소 검증', () => {
    let state = setupClassRoster(30, 6);
    state.rules.useGenderDistinction = true;
    const longName50 = '가'.repeat(50);
    const parsed = parseExcelRosterWithDiagnostics("번호\t이름\t성별\r1\t고길동\t010-9876-5432\t남\r\n2번\n3\t남\n1\t김·이\t여\t01011112222\n1\tJohn F O'Neil\t010-1234-5678\n성명진\t남\n이름이\t여\n6\t" + longName50 + "\t남");
    if (parsed.students.length !== 6 || parsed.students[0].name !== '고길동' || parsed.students[1].name !== '김·이' || parsed.students[2].name !== "John F O'Neil" || parsed.students[3].name !== '성명진' || parsed.students[4].name !== '이름이' || parsed.students[5].name.length !== 30 || parsed.students[1].num === parsed.students[0].num) {
      throw new Error('엑셀 \r 줄바꿈·전화번호(하이픈 유무) 제외·성명진/이름이 헤더 오인 방지·30자 제한·중복번호 보정 오류');
    }
    const parsedGenderOrder = parseExcelRosterWithDiagnostics("번호\t성별\t성명\n1\t여\t또치\n2\t김철수\t남\t반장");
    if (parsedGenderOrder.students.length !== 2 || parsedGenderOrder.students[0].name !== '또치' || parsedGenderOrder.students[0].gender !== '여' || parsedGenderOrder.students[1].name !== '김철수' || parsedGenderOrder.students[1].gender !== '남') {
      throw new Error('엑셀 성별 선행 열(1\t여\t또치) 또는 성별 뒤 비고 열(2\t김철수\t남\t반장) 파싱 오류');
    }
    // 프로토타입 오염 예약어(__proto__, constructor, prototype) ID 필터링 및 학급명(40자)·교탁메시지(80자) 길이 상한 검증
    AppStore.applyLoadedData({ classTitle: '보'.repeat(120), teacherMessage: '안'.repeat(200), students: [{ id: '__proto__', num: 1, name: '오염시도', gender: '남' }, { id: 's1', num: 2, name: '정상학생', gender: '여' }], pos: { s1: [1, 1] } }, '기본', false);
    if (state.students.length !== 1 || state.students[0].id !== 's1' || state.classTitle.length !== 40 || state.teacherMessage.length !== 80) {
      throw new Error('예약어(__proto__) 필터링 또는 학급명(40자)·교탁메시지(80자) 길이 상한 검증 실패');
    }
    // 구버전(v1 -> v2) 자동 마이그레이션, 미래 상위 버전(v99) 열람 거부 및 상태 4분할(domain/prefs/ui/session) 직렬화 일치 검증
    const migrated = AppStore.migratePayloadSchema({ classTitle: '마이그레이션반', students: [{ id: 's1', num: 1, name: '홍길동', gender: '남' }], pos: { s1: [1, 1] }, rules: { genderPairMode: 'mixed' } });
    if (!migrated || migrated.schemaVersion !== 2 || migrated.rules.defaultCols !== 6) {
      throw new Error('schemaVersion(v1 -> v2) 자동 마이그레이션 실패');
    }
    if (AppStore.migratePayloadSchema({ schemaVersion: 99, classTitle: '미래버전반', students: [{ id: 's1', num: 1, name: '홍길동', gender: '남' }], pos: { s1: [1, 1] } }) !== null ||
        AppStore.applyLoadedData({ schemaVersion: 99, classTitle: '미래버전반', students: [{ id: 's1', num: 1, name: '홍길동', gender: '남' }], pos: { s1: [1, 1] } }, '기본', false) !== false) {
      throw new Error('상위 미래 schemaVersion(v99) 파일이 거부되지 않음');
    }
    const domSlice = AppStore.getDomainState();
    const prefsSlice = AppStore.getPrefsState();
    const persistedSlice = AppStore.getPersistedState();
    const uiSlice = AppStore.getUiState();
    const sesSlice = AppStore.getSessionState();
    if (!('students' in domSlice) || !('viewOrientation' in prefsSlice) || !('viewOrientation' in persistedSlice) || ('sidebarCollapsed' in persistedSlice) || !('sidebarCollapsed' in uiSlice) || !('rouletteSpinning' in sesSlice)) {
      throw new Error('AppStore 도메인·환경설정·UI·세션 상태 분류 및 저장 경계 오류');
    }
    // 외부 JSON 불러오기(allowEmptyRoster=false)는 0명 명단을 거부하고, 로컬 저장소 복원(allowEmptyRoster=true)은 0명과 학급 제목을 유지해야 함
    if (AppStore.applyLoadedData({ classTitle: '빈명단거부반', students: [], pos: {} }, '기본', false) !== false) {
      throw new Error('외부 불량 JSON 빈 명단(0명)이 거부되지 않음');
    }
    if (AppStore.applyLoadedData({ classTitle: '3학년2반', students: [], pos: {} }, '기본', true) !== true || state.classTitle !== '3학년2반' || state.students.length !== 0) {
      throw new Error('전원 삭제(0명) 후 로컬 저장소 복원 시 학급 제목·설정 유지 실패');
    }

    state = setupClassRoster(30, 6);
    const snapBefore = JSON.stringify(state.pos);
    pushUndoSnapshot('30명 자리 이동 전');
    const obfuscated = getObfuscatedPayload();
    const decoded = parseSeatFileText(obfuscated);
    if (!isSimpleObfuscatedText(obfuscated) || !decoded || decoded.students.length !== 30) {
      throw new Error('30명 데이터 simple-v1 난독화·디코딩 불일치');
    }
    const tmp = state.pos['s1'];
    state.pos['s1'] = state.pos['s30'];
    state.pos['s30'] = tmp;
    restoreHistoryAtIndex(state.undoStackNormal.length - 1);
    if (JSON.stringify(state.pos) !== snapBefore) {
      throw new Error('실행 취소(Undo) 후 30명 좌석 좌표 복원 불일치');
    }
    // [v2.95 보강] Ctrl+Z 단축키 Undo 검증 (모달/입력창/키반복 차단 · 한글 IME KeyZ · 일반방/비밀방 스택 분기)
    pushUndoSnapshot('Ctrl+Z 단축키 검증');
    const tmpZ = state.pos['s1'];
    state.pos['s1'] = state.pos['s30'];
    state.pos['s30'] = tmpZ;
    const swappedJsonZ = JSON.stringify(state.pos);
    // 1) 자가진단/모달 열림 상태에서는 Ctrl+Z 차단
    window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', code: 'KeyZ', ctrlKey: true, cancelable: true }));
    if (JSON.stringify(state.pos) !== swappedJsonZ) {
      throw new Error('열린 모달/자가진단 중 Ctrl+Z Undo 차단 실패');
    }
    const openDialogsBeforeZ = Array.from(document.querySelectorAll('[role="dialog"]:not(.hidden)'));
    const titleInputEl = document.getElementById('classTitleInput');
    try {
      openDialogsBeforeZ.forEach(dlg => {
        dlg.classList.add('hidden');
        dlg.classList.remove('flex');
      });
      setRunningSelfDiagnostics(false);
      // 2) 입력창 포커스 중 차단
      if (titleInputEl) {
        titleInputEl.focus();
        titleInputEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', code: 'KeyZ', ctrlKey: true, bubbles: true, cancelable: true }));
        titleInputEl.blur();
        if (JSON.stringify(state.pos) !== swappedJsonZ) {
          throw new Error('입력창 포커스 중 Ctrl+Z Undo 차단 실패');
        }
      }
      if (document.activeElement && typeof document.activeElement.blur === 'function') {
        document.activeElement.blur();
      }
      // 3) 키 꾹 누름(repeat: true) 차단
      window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', code: 'KeyZ', ctrlKey: true, repeat: true, cancelable: true }));
      if (JSON.stringify(state.pos) !== swappedJsonZ) {
        throw new Error('키 반복(repeat) Ctrl+Z 차단 실패');
      }
      // 4) 한글 IME(Ctrl+ㅋ, code: KeyZ) 정상 복원
      window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ㅋ', code: 'KeyZ', ctrlKey: true, cancelable: true }));
      if (JSON.stringify(state.pos) !== snapBefore) {
        throw new Error('한글 IME Ctrl+Z(KeyZ) 일반방 Undo 복원 실패');
      }
      // 5) 비밀의 방 스택 분기 Ctrl+Z 검증
      toggleSecretRoom(true, true);
      const secSnapZ = JSON.stringify(state.secretPos);
      pushUndoSnapshot('비밀방 Ctrl+Z 검증');
      const secTmpZ = state.secretPos['s1'];
      state.secretPos['s1'] = state.secretPos['s2'];
      state.secretPos['s2'] = secTmpZ;
      window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', code: 'KeyZ', ctrlKey: true, cancelable: true }));
      if (JSON.stringify(state.secretPos) !== secSnapZ) {
        throw new Error('비밀의 방 Ctrl+Z Undo 복원 실패');
      }
      toggleSecretRoom(false, true);
    } finally {
      setRunningSelfDiagnostics(true);
      openDialogsBeforeZ.forEach(dlg => {
        dlg.classList.remove('hidden');
        dlg.classList.add('flex');
      });
    }
    // 손상된 로컬 저장소 데이터 감지 시 _corrupted_backup 자동 대피 검증
    try {
      localStorage.setItem(getActiveStorageKey(), '{"_enc":"simple-v1","data":"CORRUPTED_DATA"}');
      const okCorrupt = loadFromStorage();
      const backedUp = localStorage.getItem(getActiveStorageKey() + '_corrupted_backup');
      if (okCorrupt !== false || !backedUp || !backedUp.includes('CORRUPTED_DATA')) {
        throw new Error('손상된 로컬 저장소 데이터 백업(_corrupted_backup) 실패');
      }
    } catch (err) {
      if (err instanceof ReferenceError || err instanceof TypeError || (err && err.message && err.message.includes('_corrupted_backup'))) {
        throw err;
      }
    }
    return '엑셀·영문이름 파싱, 0명 설정 보존, 30명 난독화 왕복, 손상백업·Undo 100% 일치';
  });
}
