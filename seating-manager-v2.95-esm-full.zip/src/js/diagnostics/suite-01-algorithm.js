// 자가 진단 스위트 1: 초기 상태 · 스트레스 · 자리 배정 알고리즘 100회 채점 (항목 1~7)
import { canRegisterPairRule, generateOptimalSeatAssignment } from '../domain/algorithm-engine.js';
import { ensureAllStudentsHaveValidCoords } from '../domain/grid.js';
import { isSeatLocked } from '../domain/seat-queries.js';
import { AppStore } from '../state/store.js';
import { addFrontRowStudentWithOverflowCheck, updateRulesUI } from '../views/rules-modal-view.js';

export function runAlgorithmDiagnostics({ recordTest, setupClassRoster, assertValidUniqueCoords }) {
  // 1. 기본 명단(8명) 및 초기 좌표 무결성 직접 검증
  recordTest('1. 초기 상태 및 기본 명단 무결성 검증', () => {
    const state = AppStore.resetState();
    if (!Array.isArray(state.students) || state.students.length !== 8) {
      throw new Error('기본 명단 인원수(8명) 불일치');
    }
    assertValidUniqueCoords(state.pos, 8);
    return '기본 8명 명단(고길동~고영희) 및 초기 좌표 중복 0건 직접 확인';
  });

  // 2. 인원수 급감·급증(1명 ↔ 30명 ↔ 45명 ↔ 8명) 스트레스 검증
  recordTest('2. 인원수 증감 스트레스 검증 (1명 ↔ 30명 ↔ 45명)', () => {
    for (const targetCount of [1, 15, 28, 30, 35, 45, 8]) {
      const state = setupClassRoster(targetCount, 6);
      ensureAllStudentsHaveValidCoords(state.students, state.pos, state.rules.defaultCols);
      assertValidUniqueCoords(state.pos, targetCount);
    }
    return '1명·15명·28명·30명·35명·45명·8명 전환 시 좌표 누락·중첩 0건';
  });

  // 3. [30명 학급 · 100회 반복] 고정석(🔒) 잠금 보존 독립 좌표 검증
  recordTest('3. 고정석(🔒) 보존 검증 (30명 학급 · 100회 반복)', () => {
    const state = setupClassRoster(30, 6);
    const lockedTargets = ['s1', 's8', 's15', 's22', 's30'];
    const lockedOrigCoords = {};
    lockedTargets.forEach(id => { lockedOrigCoords[id] = [...state.pos[id]]; });
    state.lockedIds = [...lockedTargets];

    for (let run = 0; run < 100; run++) {
      const res = generateOptimalSeatAssignment({ students: state.students, pos: state.pos, rules: state.rules, lockedIds: state.lockedIds });
      assertValidUniqueCoords(res.map, 30);
      for (const lid of lockedTargets) {
        const cur = res.map[lid];
        const orig = lockedOrigCoords[lid];
        if (cur[0] !== orig[0] || cur[1] !== orig[1]) {
          throw new Error((run + 1) + '회차에서 고정석(' + lid + ') 좌표가 변경됨');
        }
      }
      state.pos = res.map;
    }
    // 순수 함수 입력({ students, pos, rules, lockedIds, rng }) 및 시드 난수(rng) 결정론적 재현·전역 state 독립성 검증
    const makeSeededRng = (seed) => {
      let s = seed >>> 0;
      return () => {
        s = (s + 0x6D2B79F5) >>> 0;
        let t = Math.imul(s ^ (s >>> 15), 1 | s);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
      };
    };
    const detachedStudents = JSON.parse(JSON.stringify(state.students));
    const detachedPos = JSON.parse(JSON.stringify(state.pos));
    const detachedRules = {
      ...JSON.parse(JSON.stringify(state.rules)),
      useGenderDistinction: true,
      genderPairMode: 'mixed',
      excludePreviousSeat: true,
      separatedPairs: [['s2', 's3']],
      togetherPairs: [['s4', 's5']],
      frontRowIds: ['s6', 's7']
    };
    const savedGlobalSnap = {
      students: state.students,
      rules: state.rules,
      lockedIds: state.lockedIds,
      inSecretRoom: state.inSecretRoom
    };
    // 전역 state(students, rules, lockedIds, inSecretRoom)를 모두 오염시켜도 순수 입력만으로 독립 동작해야 함
    state.students = [];
    state.rules = { genderPairMode: 'same', separatedPairs: [['s6', 's7']], togetherPairs: [], frontRowIds: [] };
    state.lockedIds = ['s1', 's2', 's3', 's4', 's5', 's6'];
    state.inSecretRoom = true;
    let detRun1, detRun2;
    try {
      detRun1 = generateOptimalSeatAssignment({
        students: detachedStudents,
        pos: detachedPos,
        rules: detachedRules,
        lockedIds: lockedTargets,
        rng: makeSeededRng(20260406)
      });
      detRun2 = generateOptimalSeatAssignment({
        students: detachedStudents,
        pos: detachedPos,
        rules: detachedRules,
        lockedIds: lockedTargets,
        rng: makeSeededRng(20260406)
      });
    } finally {
      state.students = savedGlobalSnap.students;
      state.rules = savedGlobalSnap.rules;
      state.lockedIds = savedGlobalSnap.lockedIds;
      state.inSecretRoom = savedGlobalSnap.inSecretRoom;
    }
    assertValidUniqueCoords(detRun1.map, 30);
    if (JSON.stringify(detRun1.map) !== JSON.stringify(detRun2.map)) {
      throw new Error('동일 시드(rng) 주입 시 배정 결과 재현 불일치');
    }
    return '30명 고정석 100회 보존 + 순수 함수({students,pos,rules,lockedIds,rng}) 시드 재현 100% 일치';
  });

  // 4. [30명 학급 · 100회 반복] 짝꿍 성별 4종 및 교차(지그재그) vs 랜덤 세부 패턴 구분 채점
  recordTest('4. 남녀 짝 · 동성 짝 (교차·랜덤 4종 및 지그재그 패턴 구분) 채점', () => {
    const state = setupClassRoster(30, 6); // 남 15명, 여 15명 (6열×5행 = 15쌍의 2인 책상)
    const genderOf = {};
    state.students.forEach(s => { genderOf[s.id] = s.gender; });

    let mixedRandomNonZigzagCount = 0;
    let sameCrossAdjacentDiffSum = 0;
    let sameRandomAdjacentDiffSum = 0;

    // 독립 채점기: 짝꿍 성별 구성뿐만 아니라 교차배정(지그재그) 패턴 일치 여부까지 직접 측정
    const verifyPairsAndPattern = (mapObj, modeKey, runIdx) => {
      assertValidUniqueCoords(mapObj, 30);
      const coordToGender = {};
      for (const st of state.students) {
        const p = mapObj[st.id];
        coordToGender[p[0] + ',' + p[1]] = genderOf[st.id];
      }
      const isMix = (modeKey === 'mixed' || modeKey === 'mixed_random');
      let validPairs = 0;
      let zigzagMatchesFlip0 = 0;
      let zigzagMatchesFlip1 = 0;

      for (let row = 1; row <= 5; row++) {
        for (const leftCol of [1, 3, 5]) {
          const gL = coordToGender[leftCol + ',' + row];
          const gR = coordToGender[(leftCol + 1) + ',' + row];
          if (!gL || !gR) throw new Error('짝꿍 좌석 좌표 누락');
          if (isMix && gL !== gR) {
            validPairs++;
            const exp0 = ((row - 1) % 2 === 0) ? '남' : '여';
            if (gL === exp0) zigzagMatchesFlip0++; else zigzagMatchesFlip1++;
          }
          if (!isMix && gL === gR) {
            validPairs++;
          }
        }
      }
      const minRequired = isMix ? 15 : 14;
      if (validPairs < minRequired) {
        throw new Error(modeKey + ' 모드 ' + (runIdx + 1) + '회차 짝 성별 미달 (' + validPairs + '/' + minRequired + '쌍)');
      }

      // (A) 남녀 짝 교차배정(mixed)은 15쌍 전원이 앞뒤 행마다 남-여 / 여-남 지그재그로 100% 정렬되어야 함
      if (modeKey === 'mixed') {
        const bestZigzag = Math.max(zigzagMatchesFlip0, zigzagMatchesFlip1);
        if (bestZigzag !== 15) {
          throw new Error('남녀 짝 교차배정(mixed) 지그재그 패턴 불일치 (' + bestZigzag + '/15쌍)');
        }
      }
      // (B) 남녀 짝 랜덤배정(mixed_random)은 지그재그 단일 패턴에 고정되지 않고 무작위 좌우 순서가 섞여야 함
      if (modeKey === 'mixed_random') {
        if (Math.max(zigzagMatchesFlip0, zigzagMatchesFlip1) < 15) {
          mixedRandomNonZigzagCount++;
        }
      }
      // (C) 동성 짝 교차배정(same) vs 랜덤배정(same_random)의 상하·좌우 인접 짝 성별 교차율 측정
      if (!isMix) {
        let adjDiff = 0;
        for (let row = 1; row <= 5; row++) {
          for (const leftCol of [1, 3, 5]) {
            const gCur = coordToGender[leftCol + ',' + row];
            if (row < 5 && coordToGender[leftCol + ',' + (row + 1)] !== gCur) adjDiff++;
            if (leftCol < 5 && coordToGender[(leftCol + 2) + ',' + row] !== gCur) adjDiff++;
          }
        }
        if (modeKey === 'same') sameCrossAdjacentDiffSum += adjDiff;
        if (modeKey === 'same_random') sameRandomAdjacentDiffSum += adjDiff;
      }
    };

    state.rules.useGenderDistinction = true;
    for (const modeKey of ['mixed', 'mixed_random', 'same', 'same_random']) {
      state.rules.genderPairMode = modeKey;
      for (let i = 0; i < 25; i++) {
        const res = generateOptimalSeatAssignment({ students: state.students, pos: state.pos, rules: state.rules, lockedIds: state.lockedIds });
        verifyPairsAndPattern(res.map, modeKey, i);
      }
    }
    if (mixedRandomNonZigzagCount === 0) {
      throw new Error('남녀 짝 랜덤배정(mixed_random)이 지그재그 교차 패턴으로만 고정됨');
    }
    if (sameCrossAdjacentDiffSum <= sameRandomAdjacentDiffSum) {
      throw new Error('동성 짝 교차배정(same)의 인접 교차율이 랜덤배정보다 높지 않음');
    }
    return '4종 성별 짝 충족 및 교차(지그재그 15/15) vs 랜덤 패턴 차이 검증 완료';
  });

  // 5. [30명 학급 · 100회 반복] 거리두기 + 친구끼리 붙이기 및 동시 등록 차단 독립 검증
  recordTest('5. 거리두기 · 친구끼리 붙이기 및 상호 배타성 독립 채점 (30명 · 100회)', () => {
    const state = setupClassRoster(30, 6);
    const sepTestPairs = [
      ['s1', 's2'],
      ['s5', 's12'],
      ['s14', 's21']
    ];
    const togTestPairs = [
      ['s3', 's4'],
      ['s9', 's10'],
      ['s25', 's26']
    ];
    state.rules.separatedPairs = [...sepTestPairs];
    state.rules.togetherPairs = [...togTestPairs];

    // (A) 거리두기에 등록된 조합을 붙이기에 등록 시도 시 차단되는지 확인
    if (canRegisterPairRule('s1', 's2', 'tog', state.rules).ok || canRegisterPairRule('s2', 's1', 'tog', state.rules).ok) {
      throw new Error('거리두기 등록 학생 쌍이 친구끼리 붙이기에 중복 허용됨');
    }
    // (B) 붙이기에 등록된 조합을 거리두기에 등록 시도 시 차단되는지 확인
    if (canRegisterPairRule('s3', 's4', 'sep', state.rules).ok || canRegisterPairRule('s4', 's3', 'sep', state.rules).ok) {
      throw new Error('친구끼리 붙이기 등록 학생 쌍이 거리두기에 중복 허용됨');
    }
    // (C) 이미 다른 친구와 붙이기로 묶인 학생을 제3의 학생과 붙이기 시도 시 차단되는지 확인
    if (canRegisterPairRule('s3', 's15', 'tog', state.rules).ok) {
      throw new Error('이미 짝이 지정된 학생의 중복 붙이기 등록이 허용됨');
    }

    // (D) 100회 연속 배정 시 거리두기(8방향 분리)와 친구끼리 붙이기(같은 2인 짝꿍) 동시 충족 직접 검증
    for (let run = 0; run < 100; run++) {
      const res = generateOptimalSeatAssignment({ students: state.students, pos: state.pos, rules: state.rules, lockedIds: state.lockedIds });
      assertValidUniqueCoords(res.map, 30);
      for (const [idA, idB] of sepTestPairs) {
        const pA = res.map[idA];
        const pB = res.map[idB];
        if (Math.abs(pA[0] - pB[0]) <= 1 && Math.abs(pA[1] - pB[1]) <= 1) {
          throw new Error((run + 1) + '회차 거리두기 위반: ' + idA + ' ↔ ' + idB);
        }
      }
      for (const [idA, idB] of togTestPairs) {
        const pA = res.map[idA];
        const pB = res.map[idB];
        const sameRow = (pA[1] === pB[1]);
        const sameDeskPair = Math.floor((pA[0] - 1) / 2) === Math.floor((pB[0] - 1) / 2) && Math.abs(pA[0] - pB[0]) === 1;
        if (!sameRow || !sameDeskPair) {
          throw new Error((run + 1) + '회차 친구끼리 붙이기 미충족: ' + idA + '(' + pA + ') ♥ ' + idB + '(' + pB + ')');
        }
      }
      state.pos = res.map;
    }
    return '동시 등록 원천 차단 및 거리두기3쌍+친구붙이기3쌍 100회 연속 독립 채점 통과';
  });

  // 6. [30명 학급 · 100회 반복] 이전 자리 배제 독립 좌표 비교 검증
  recordTest('6. 이전 자리 배제 독립 좌표 검증 (30명 · 100회 연속 배정)', () => {
    const state = setupClassRoster(30, 6);
    state.rules.excludePreviousSeat = true;

    for (let run = 0; run < 100; run++) {
      const prevSnapshot = JSON.parse(JSON.stringify(state.pos));
      const res = generateOptimalSeatAssignment({ students: state.students, pos: state.pos, rules: state.rules, lockedIds: state.lockedIds });
      assertValidUniqueCoords(res.map, 30);
      // 내장 판정기 대신 모든 학생의 이전 좌표(prevSnapshot)와 새 좌표(res.map)를 직접 비교
      for (const st of state.students) {
        const oldP = prevSnapshot[st.id];
        const newP = res.map[st.id];
        if (oldP[0] === newP[0] && oldP[1] === newP[1]) {
          throw new Error((run + 1) + '회차에서 ' + st.name + ' 학생이 직전 자리(' + oldP + ')에 그대로 배정됨');
        }
      }
      state.pos = res.map;
    }
    return '30명 전원 100회 연속 자리 바꾸기(총 3,000석 이동) 중 직전 좌석 중복 0건';
  });

  // 7. [실전 복합 & 변형 배치] 30명 정규 격자 + 홀수 인원(29·31명) 및 통로·외톨이석 변형 배치 검증
  recordTest('7. 실전 복합 조건 · 홀수 인원(29·31명) · 변형 배치(통로·외톨이석) 검증', () => {
    // (파트 A) 30명 정규 격자에서 고정석2 + 거리두기3쌍 + 친구붙이기1쌍 + 남녀짝 + 이전자리배제 20회 연속 검증
    let state = setupClassRoster(30, 6);
    state.lockedIds = ['s1', 's16'];
    const lock1 = [...state.pos['s1']];
    const lock16 = [...state.pos['s16']];
    state.rules.useGenderDistinction = true;
    state.rules.genderPairMode = 'mixed';
    state.rules.excludePreviousSeat = true;
    state.rules.frontRowIds = ['s11', 's18', 's24', 's29']; // 앞줄(1~2행) 배려석 4명 지정
    state.rules.separatedPairs = [['s3', 's4'], ['s7', 's14'], ['s20', 's25']];
    state.rules.togetherPairs = [['s9', 's10']];

    for (let run = 0; run < 20; run++) {
      const prevSnap = JSON.parse(JSON.stringify(state.pos));
      const unlocked = state.students.filter(s => !isSeatLocked(state, s.id));
      const res = generateOptimalSeatAssignment({ students: state.students, pos: state.pos, rules: state.rules, lockedIds: state.lockedIds });
      assertValidUniqueCoords(res.map, 30);

      if (res.map['s1'][0] !== lock1[0] || res.map['s1'][1] !== lock1[1] ||
          res.map['s16'][0] !== lock16[0] || res.map['s16'][1] !== lock16[1]) {
        throw new Error('정규 격자 복합 조건 중 고정석 위치 이탈');
      }
      for (const [idA, idB] of state.rules.separatedPairs) {
        if (Math.abs(res.map[idA][0] - res.map[idB][0]) <= 1 && Math.abs(res.map[idA][1] - res.map[idB][1]) <= 1) {
          throw new Error('정규 격자 복합 조건 거리두기 충돌');
        }
      }
      const p9 = res.map['s9'], p10 = res.map['s10'];
      if (p9[1] !== p10[1] || Math.abs(p9[0] - p10[0]) !== 1) {
        throw new Error('정규 격자 복합 조건 친구끼리 붙이기 미충족');
      }
      for (const fId of state.rules.frontRowIds) {
        if (res.map[fId][1] > 2) {
          throw new Error('시력 보호·배려석 학생(' + fId + ')이 앞줄(1~2행)을 벗어남: ' + res.map[fId][1] + '행');
        }
      }
      for (const st of unlocked) {
        if (res.map[st.id][0] === prevSnap[st.id][0] && res.map[st.id][1] === prevSnap[st.id][1]) {
          throw new Error('정규 격자 복합 조건 이전 자리 중복');
        }
      }
      state.pos = res.map;
    }

    // (파트 B) 홀수 인원(29명, 31명) + 중간 통로(3열 비움) + 뒤쪽 외톨이 단독 좌석이 있는 변형 배치 20회 검증
    for (const oddCount of [29, 31]) {
      state = setupClassRoster(oddCount, 6);
      state.students.forEach((st, idx) => {
        if (idx === oddCount - 1) {
          state.pos[st.id] = [7, 8]; // 떨어진 외톨이 단독 좌석 1
        } else if (idx === oddCount - 2 && oddCount === 31) {
          state.pos[st.id] = [1, 8]; // 떨어진 외톨이 단독 좌석 2
        } else {
          const baseCol = (idx % 6) + 1;
          const shiftedCol = baseCol >= 3 ? baseCol + 1 : baseCol; // 3열을 빈 통로로 비움
          const row = Math.floor(idx / 6) + 1;
          state.pos[st.id] = [shiftedCol, row];
        }
      });
      const origCoordKeySet = new Set(state.students.map(s => state.pos[s.id].join(',')));
      state.lockedIds = ['s1'];
      const oddLock1 = [...state.pos['s1']];
      state.rules.useGenderDistinction = true;
      state.rules.genderPairMode = (oddCount === 29) ? 'mixed_random' : 'same';
      state.rules.excludePreviousSeat = true;
      state.rules.separatedPairs = [['s2', 's3'], ['s5', 's6']];
      state.rules.togetherPairs = [['s7', 's8']];

      for (let r = 0; r < 10; r++) {
        const prevOdd = JSON.parse(JSON.stringify(state.pos));
        const unlockedOdd = state.students.filter(s => !isSeatLocked(state, s.id));
        const resOdd = generateOptimalSeatAssignment({ students: state.students, pos: state.pos, rules: state.rules, lockedIds: state.lockedIds });
        assertValidUniqueCoords(resOdd.map, oddCount);

        for (const st of state.students) {
          const k = resOdd.map[st.id].join(',');
          if (!origCoordKeySet.has(k)) {
            throw new Error(oddCount + '명 변형 배치에서 허용되지 않은 좌표(' + k + ')로 책상이 이탈함');
          }
        }
        if (resOdd.map['s1'][0] !== oddLock1[0] || resOdd.map['s1'][1] !== oddLock1[1]) {
          throw new Error(oddCount + '명 변형 배치 고정석 이탈');
        }
        for (const [idA, idB] of state.rules.separatedPairs) {
          if (Math.abs(resOdd.map[idA][0] - resOdd.map[idB][0]) <= 1 && Math.abs(resOdd.map[idA][1] - resOdd.map[idB][1]) <= 1) {
            throw new Error(oddCount + '명 변형 배치 거리두기 위반');
          }
        }
        const p7 = resOdd.map['s7'], p8 = resOdd.map['s8'];
        if (p7[1] !== p8[1] || Math.abs(p7[0] - p8[0]) !== 1) {
          throw new Error(oddCount + '명 변형 배치 친구끼리 붙이기 위반');
        }
        for (const st of unlockedOdd) {
          if (resOdd.map[st.id][0] === prevOdd[st.id][0] && resOdd.map[st.id][1] === prevOdd[st.id][1]) {
            throw new Error(oddCount + '명 변형 배치 이전 자리 배제 위반');
          }
        }
        state.pos = resOdd.map;
      }
    }
    // (파트 C) 반고정/동성 친구 붙이기 + 남녀 짝 모드 시 성별 인원 차감 정합성 및 거짓 충돌 경고(BUG-04) 0건 검증
    state = setupClassRoster(12, 6);
    state.lockedIds = ['s1']; // s1(남, [1,1]) 고정 -> 옆자리 [2,1]은 반쪽 고정석(halfLocked)
    state.rules.useGenderDistinction = true;
    state.rules.genderPairMode = 'mixed';
    state.rules.excludePreviousSeat = false;
    state.rules.separatedPairs = [];
    state.rules.togetherPairs = [['s1', 's3'], ['s5', 's7']]; // 반고정 남-남 1쌍 + 미고정 남-남 1쌍
    const res12 = generateOptimalSeatAssignment({ students: state.students, pos: state.pos, rules: state.rules, lockedIds: state.lockedIds });
    if (res12.conflicts.includes('남녀 짝꿍')) {
      throw new Error('반고정·동성 붙이기 우선 배정 시 남녀 짝꿍 거짓 충돌 경고(오탐) 발생');
    }

    // (파트 D) 시력보호 드롭다운 선택 표시(✓ [지정됨]·음영) 및 정원 초과 팝업 검증
    state = setupClassRoster(18, 6);
    state.rules.frontRowIds = ['s1', 's2'];
    updateRulesUI();
    const frontSel = document.getElementById('frontRowStudentSelect');
    if (frontSel && (!frontSel.innerHTML.includes('✓ [지정됨]') || !frontSel.innerHTML.includes('#fef3c7'))) {
      throw new Error('시력 보호 드롭다운에 이미 지정된 학생 음영·체크 표시 누락');
    }
    // 12명(1~2행 정원) 채운 뒤 13번째 학생 추가 시 #frontRowOverflowModal 실제 트리거 검증
    state.rules.frontRowIds = Array.from({ length: 12 }, (_, idx) => 's' + (idx + 1));
    updateRulesUI();
    if (frontSel) {
      frontSel.value = 's13';
      addFrontRowStudentWithOverflowCheck();
      const ovModal = document.getElementById('frontRowOverflowModal');
      if (!ovModal || ovModal.classList.contains('hidden')) {
        throw new Error('앞줄 1~2행 정원 초과 시 #frontRowOverflowModal 안내 팝업 미표시');
      }
      ovModal.classList.add('hidden');
      ovModal.classList.remove('flex');
    }

    // (파트 E) 앞줄 성비 초과(ST-13) 및 앞줄 고정석 반고정 충돌(ST-18) 자동 행 확장 검증
    state = setupClassRoster(20, 4);
    state.rules.useGenderDistinction = true;
    state.rules.genderPairMode = 'mixed';
    state.rules.frontRowIds = ['s1','s3','s5','s7','s9','s11','s13','s15','s17','s19','s2','s4','s6','s8'];
    state.rules.togetherPairs = [['s2','s4'], ['s6','s8']];
    for (let r = 0; r < 10; r++) {
      const res13 = generateOptimalSeatAssignment({ students: state.students, pos: state.pos, rules: state.rules, lockedIds: [] });
      assertValidUniqueCoords(res13.map, 20);
      if (res13.conflicts.length > 0) {
        throw new Error('앞줄 남초+동성붙이기(ST-13) 충돌 발생: ' + res13.conflicts.join(', '));
      }
    }
    state = setupClassRoster(30, 6);
    state.lockedIds = ['s2', 's4', 's8', 's10'];
    state.rules.useGenderDistinction = true;
    state.rules.genderPairMode = 'same';
    state.rules.frontRowIds = ['s13', 's15', 's17', 's19', 's21', 's23'];
    for (let r = 0; r < 10; r++) {
      const res18 = generateOptimalSeatAssignment({ students: state.students, pos: state.pos, rules: state.rules, lockedIds: state.lockedIds });
      assertValidUniqueCoords(res18.map, 30);
      if (res18.conflicts.length > 0) {
        throw new Error('앞줄 고정석 반고정 충돌(ST-18) 발생: ' + res18.conflicts.join(', '));
      }
    }
    return '앞줄 배려석(선택음영·초과팝업·ST-13/ST-18) + 정규·홀수·변형 배치 + 오탐 0건 통과';
  });
}
