// 자가 진단 공통 픽스처, 결정적 시드 난수 및 전역 불변식 검증 헬퍼
import { MAX_COLS, MAX_ROWS } from '../core/constants.js';
import { isSeatLocked } from '../domain/seat-queries.js';
import { AppStore } from '../state/store.js';

// 고정 시드 결정적 난수 생성기 (Mulberry32)
export const createSeededRng = (seed = 20261120) => {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};

// 30명(남15·여15, 6열×5행) 실제 학급 규모 테스트 픽스처 생성 헬퍼
export const setupClassRoster = (count = 30, cols = 6) => {
  const state = AppStore.resetState();
  state.rules.defaultCols = cols;
  const roster = [];
  const posMap = {};
  for (let i = 1; i <= count; i++) {
    const id = 's' + i;
    roster.push({
      id,
      num: i,
      name: '학생' + i,
      gender: (i % 2 === 1) ? '남' : '여'
    });
    const col = ((i - 1) % cols) + 1;
    const row = Math.floor((i - 1) / cols) + 1;
    posMap[id] = [col, row];
  }
  state.students = roster;
  state.pos = posMap;
  state.secretPos = null;
  state.lockedIds = [];
  state.secretLockedIds = [];
  state.hiddenSeatIds = [];
  state.rules.frontRowIds = [];
  state.rules.separatedPairs = [];
  state.rules.togetherPairs = [];
  state.rules.genderPairMode = 'any';
  state.rules.excludePreviousSeat = false;
  return state;
};

// 독립 채점 헬퍼 1: 모든 학생의 좌표 존재 여부 및 중복 좌석 0건 직접 검증
export const assertValidUniqueCoords = (mapObj, expectedCount) => {
  const state = AppStore.getState();
  if (!mapObj || typeof mapObj !== 'object') {
    throw new Error('좌표 맵 객체가 비어 있음');
  }
  const seen = new Set();
  for (const st of state.students) {
    const p = mapObj[st.id];
    if (!Array.isArray(p) || p.length !== 2 || !Number.isInteger(p[0]) || !Number.isInteger(p[1])) {
      throw new Error(st.name + '의 좌표 형식이 유효하지 않음');
    }
    if (p[0] < 0 || p[0] >= MAX_COLS || p[1] < 0 || p[1] >= MAX_ROWS) {
      throw new Error(st.name + '의 좌표 범위 이탈: (' + p[0] + ',' + p[1] + ')');
    }
    const key = p[0] + ',' + p[1];
    if (seen.has(key)) {
      throw new Error('좌석 좌표 중첩 발생: (' + key + ')');
    }
    seen.add(key);
  }
  if (seen.size !== expectedCount) {
    throw new Error('배정된 고유 좌석 수(' + seen.size + ')가 학생 수(' + expectedCount + ')와 다름');
  }
};

// 독립 채점 헬퍼 2: 전역 상태 불변식(고스트 ID · 좌표 경계/고아 키 · 룰렛 정합성) 검증
export const assertGlobalInvariants = (ctxLabel = '') => {
  const state = AppStore.getState();
  const prefix = ctxLabel ? `[${ctxLabel}] ` : '';
  const validIds = new Set(state.students.map(s => String(s.id)));

  // 1) pos 및 secretPos 좌표 경계·중복·고아 키 검사
  const checkPosMap = (mapObj, mapName) => {
    const keys = Object.keys(mapObj || {});
    for (const k of keys) {
      if (!validIds.has(String(k))) {
        throw new Error(`${prefix}${mapName}에 존재하지 않는 고아 학생 키 발견: ${k}`);
      }
    }
    assertValidUniqueCoords(mapObj, state.students.length);
  };
  checkPosMap(state.pos, 'pos');
  if (state.secretPos) {
    checkPosMap(state.secretPos, 'secretPos');
  }

  // 2) 고스트 ID 및 중복 ID 검사
  const checkIdList = (arr, listName) => {
    const seen = new Set();
    for (const raw of (arr || [])) {
      const id = String(raw);
      if (!validIds.has(id)) {
        throw new Error(`${prefix}${listName}에 고스트 ID 잔류: ${id}`);
      }
      if (seen.has(id)) {
        throw new Error(`${prefix}${listName}에 중복 ID 잔류: ${id}`);
      }
      seen.add(id);
    }
  };
  checkIdList(state.lockedIds, 'lockedIds');
  checkIdList(state.secretLockedIds, 'secretLockedIds');
  checkIdList(state.hiddenSeatIds, 'hiddenSeatIds');
  checkIdList(state.rules && state.rules.frontRowIds, 'rules.frontRowIds');
  checkIdList(state.rouletteDrawnIds, 'rouletteDrawnIds');

  for (const [pairKey, pairs] of [['separatedPairs', state.rules && state.rules.separatedPairs], ['togetherPairs', state.rules && state.rules.togetherPairs]]) {
    for (const p of (pairs || [])) {
      if (!Array.isArray(p) || p.length !== 2 || !validIds.has(String(p[0])) || !validIds.has(String(p[1])) || String(p[0]) === String(p[1])) {
        throw new Error(`${prefix}rules.${pairKey}에 유효하지 않거나 고스트 ID 포함: ${JSON.stringify(p)}`);
      }
    }
  }
  if (state.selectedStudentId !== null && state.selectedStudentId !== undefined && !validIds.has(String(state.selectedStudentId))) {
    throw new Error(`${prefix}selectedStudentId 고스트 ID 잔류: ${state.selectedStudentId}`);
  }

  // 3) 활성 룰렛 세션 정합성 검사
  if (state.rouletteActiveSession && !state.inSecretRoom) {
    const rem = state.rouletteRemainingStudents || [];
    const targets = state.rouletteTargetCoords || [];
    if (rem.length !== targets.length) {
      throw new Error(`${prefix}룰렛 남은 학생(${rem.length})과 목표 좌표(${targets.length}) 수 불일치`);
    }
    for (const st of rem) {
      if (!validIds.has(String(st.id))) {
        throw new Error(`${prefix}룰렛 대기 명단에 고스트 ID 포함: ${st.id}`);
      }
      if (isSeatLocked(state, st.id)) {
        throw new Error(`${prefix}룰렛 대기 명단에 잠금 학생 포함: ${st.id}`);
      }
    }
    const assigned = state.rouletteAssignedMap || {};
    for (const [coordKey, stuId] of Object.entries(assigned)) {
      if (!validIds.has(String(stuId))) {
        throw new Error(`${prefix}룰렛 배정 맵에 고스트 ID 포함: ${stuId}`);
      }
      const p = state.pos[stuId];
      if (!p || `${p[0]},${p[1]}` !== coordKey) {
        throw new Error(`${prefix}룰렛 배정 맵(${coordKey})과 state.pos(${p}) 불일치: ${stuId}`);
      }
    }
  }
};
