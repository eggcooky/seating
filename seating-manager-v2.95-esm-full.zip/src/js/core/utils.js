// [L0] 완전 순수 유틸리티 함수 (DOM·상태 비의존 리프 모듈)

export function escapeHtml(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, (ch) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[ch]));
}

export function sanitizeFileName(rawTitle) {
  const cleaned = String(rawTitle || '우리반_자리배치표')
    .trim()
    .replace(/[\\/:*?"<>|]+/g, '_')
    .replace(/\s+/g, '_')
    .slice(0, 80);
  return cleaned || '우리반_자리배치표';
}

// 선택적 학반 표기(예: '1반', '3-1', 'A반') 정화 — 빈 값이면 '' 반환
export function sanitizeClassLabel(rawLabel) {
  if (rawLabel === null || rawLabel === undefined) return '';
  return String(rawLabel)
    .replace(/[\t\r\n\u200B-\u200D\uFEFF]+/g, ' ')
    .replace(/[^\p{L}\p{N}\-·]/gu, '')
    .trim()
    .slice(0, 10);
}

// 명렬표 · A4 인쇄 표 · 표 복사용 짧은 학번/반-번호 포맷 (예: '3', '1-3', '3-1-15', '30103')
export function formatStudentNumCompact(student, fallbackNum = '') {
  const rawNum = student && student.num !== undefined && student.num !== null && student.num !== ''
    ? Number(student.num)
    : fallbackNum;
  const numStr = rawNum !== '' && rawNum !== null && rawNum !== undefined && !Number.isNaN(Number(rawNum))
    ? String(rawNum)
    : String(fallbackNum || '');
  const cl = sanitizeClassLabel(student && student.classLabel);
  if (!cl) return numStr;
  const shortClass = cl.endsWith('반') && cl.length > 1 ? cl.slice(0, -1) : cl;
  return numStr ? `${shortClass}-${numStr}` : shortClass;
}

// 책상 상단 · 조건 모달 · 룰렛 결과용 학번/반-번호 포맷 (1~99번은 '3번', 100 이상 학번은 '30103', 학반 있으면 '1반 3번' / '3-1 15번')
export function formatStudentNumLabel(student, fallbackNum = '') {
  const rawNum = student && student.num !== undefined && student.num !== null && student.num !== ''
    ? Number(student.num)
    : fallbackNum;
  const numVal = Number(rawNum);
  const numStr = Number.isFinite(numVal) && rawNum !== '' && rawNum !== null
    ? String(numVal)
    : String(fallbackNum || '');
  const cl = sanitizeClassLabel(student && student.classLabel);
  if (cl) {
    return numStr ? `${cl} ${numStr}번` : cl;
  }
  if (Number.isFinite(numVal) && numVal >= 100) {
    return String(numVal);
  }
  return numStr ? `${numStr}번` : '';
}

// 학급 내 학반 표기 또는 3자리 이상 학번이 1명이라도 있으면 넓은 번호 열 레이아웃 사용 여부를 반환한다.
export function hasWideStudentNum(students) {
  if (!Array.isArray(students)) return false;
  return students.some((s) => Boolean(sanitizeClassLabel(s && s.classLabel)) || (Number(s && s.num) >= 100));
}

function compareNaturalLabel(a, b) {
  if (a === b) return 0;
  if (!a) return -1;
  if (!b) return 1;
  const pa = a.match(/\d+|\D+/g) || [a];
  const pb = b.match(/\d+|\D+/g) || [b];
  const len = Math.min(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const sa = pa[i];
    const sb = pb[i];
    if (sa === sb) continue;
    const na = /^\d+$/.test(sa);
    const nb = /^\d+$/.test(sb);
    if (na && nb) {
      const diff = Number(sa) - Number(sb);
      if (diff !== 0) return diff;
    }
    return sa < sb ? -1 : 1;
  }
  return pa.length - pb.length;
}

// 학생 번호순 정렬 비교기: 학반(classLabel) 자연정렬('1반'<'2반'<'10반') 우선 후 번호(num) 오름차순
export function compareStudentsByNumber(a, b) {
  const clA = sanitizeClassLabel(a && a.classLabel);
  const clB = sanitizeClassLabel(b && b.classLabel);
  if (clA !== clB) {
    return compareNaturalLabel(clA, clB);
  }
  return (Number(a && a.num) || 0) - (Number(b && b.num) || 0);
}

// 명렬표 1칸 번호 입력값('3', '1-3', '1반 3', '3-1-15', '30103')을 { ok, num, classLabel }로 해석한다.
export function parseInlineStudentNumInput(rawText, maxNum = 99999) {
  const s = String(rawText == null ? '' : rawText)
    .replace(/[\t\r\n\u200B-\u200D\uFEFF]+/g, ' ')
    .trim();
  if (!s) return { ok: false };

  let classLabel = '';
  let num = NaN;

  const neis3 = s.match(/^(\d{1,2}-\d{1,2})-(\d{1,3})\s*번?$/);
  const spaceGradeCls = !neis3 && s.match(/^(\d{1,2}-\d{1,2})\s+(\d{1,3})\s*번?$/);
  const explicitBan = !neis3 && !spaceGradeCls && s.match(/^((?:\d{1,2}-)?\d{1,2}|[A-Za-z]\d?)\s*반\s*(\d{1,3})\s*번?$/);
  const hyphen2 = !neis3 && !spaceGradeCls && !explicitBan && s.match(/^([0-9A-Za-z가-힣]{1,6})-(\d{1,3})\s*번?$/);
  const pureNum = !neis3 && !spaceGradeCls && !explicitBan && !hyphen2 && s.match(/^(\d{1,5})\s*번?$/);

  if (neis3) {
    classLabel = sanitizeClassLabel(neis3[1]);
    num = parseInt(neis3[2], 10);
  } else if (spaceGradeCls) {
    classLabel = sanitizeClassLabel(spaceGradeCls[1]);
    num = parseInt(spaceGradeCls[2], 10);
  } else if (explicitBan) {
    const rawCls = explicitBan[1];
    classLabel = sanitizeClassLabel(/^\d{1,2}$/.test(rawCls) ? `${parseInt(rawCls, 10)}반` : `${rawCls}반`);
    num = parseInt(explicitBan[2], 10);
  } else if (hyphen2) {
    const rawPrefix = hyphen2[1];
    classLabel = sanitizeClassLabel(/^\d{1,2}$/.test(rawPrefix) ? `${parseInt(rawPrefix, 10)}반` : rawPrefix);
    num = parseInt(hyphen2[2], 10);
  } else if (pureNum) {
    classLabel = '';
    num = parseInt(pureNum[1], 10);
  } else {
    return { ok: false };
  }

  const limit = Number.isInteger(maxNum) && maxNum > 0 ? maxNum : 99999;
  if (!Number.isInteger(num) || num < 1 || num > limit) {
    return { ok: false };
  }
  return { ok: true, num, classLabel };
}
