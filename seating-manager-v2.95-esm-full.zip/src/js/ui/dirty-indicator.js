// [L3] 미저장(isDirty) 상태 표시기
import { AppStore } from '../state/store.js';

export function markDirty(dirty = true) {
  const state = AppStore.getState();
  state.isDirty = dirty;
  const saveText = document.getElementById('saveStateBtnText');
  if (saveText) {
    saveText.textContent = dirty ? '저장하기 ●' : '저장하기';
  }
}
