// [L3] 상단 상태 표시줄 토스트 알림, 가변 줄바꿈 동기화 및 기본 필 스타일 복원
import { AppStore } from '../state/store.js';

let statusPillRevertTimer = null;
let _headerResizeObserver = null;
let _headerLayoutRafId = 0;

// 상태창이 1줄 가용 폭을 넘길 때만 학급명·우측 버튼은 1줄에 고정하고 상태창만 2줄 왼쪽으로 일시 이동한다.
export function syncHeaderStatusLayout() {
  const header = document.getElementById('mainTopHeader');
  const leftGroup = document.getElementById('headerLeftGroup');
  const rightGroup = document.getElementById('headerRightGroup');
  const pill = document.getElementById('modeStatusPill');
  const textEl = document.getElementById('modeStatusText');
  if (!header || !leftGroup || !rightGroup || !pill || !textEl) return;

  const headerWidth = header.clientWidth;
  if (headerWidth <= 0) return;

  const cs = typeof getComputedStyle === 'function' ? getComputedStyle(header) : null;
  const padX = cs ? ((parseFloat(cs.paddingLeft) || 0) + (parseFloat(cs.paddingRight) || 0)) : 32;
  const innerWidth = headerWidth - padX;
  const leftW = leftGroup.getBoundingClientRect().width;
  const rightW = rightGroup.getBoundingClientRect().width;

  const pillRectW = pill.getBoundingClientRect().width;
  const textRectW = textEl.getBoundingClientRect().width;
  const textFullW = textEl.scrollWidth;
  const pillNaturalW = Math.ceil(Math.max(pillRectW, (pillRectW - textRectW) + textFullW));

  // gap-3(12px) × 2 + 여유(4px) = 28px
  const shouldWrap = (leftW + pillNaturalW + rightW + 28) > innerWidth;
  header.classList.toggle('is-status-wrapped', shouldWrap);
}

export function initHeaderStatusLayoutObserver() {
  const header = document.getElementById('mainTopHeader');
  const leftGroup = document.getElementById('headerLeftGroup');
  const rightGroup = document.getElementById('headerRightGroup');
  if (!header) return;

  const scheduleSync = () => {
    if (_headerLayoutRafId) return;
    _headerLayoutRafId = requestAnimationFrame(() => {
      _headerLayoutRafId = 0;
      syncHeaderStatusLayout();
    });
  };
  if (!_headerResizeObserver && typeof ResizeObserver === 'function') {
    _headerResizeObserver = new ResizeObserver(scheduleSync);
    _headerResizeObserver.observe(header);
    if (leftGroup) _headerResizeObserver.observe(leftGroup);
    if (rightGroup) _headerResizeObserver.observe(rightGroup);
  }
  syncHeaderStatusLayout();
}

export function applyDefaultModeStatusPillStyle() {
  if (statusPillRevertTimer) {
    clearTimeout(statusPillRevertTimer);
    statusPillRevertTimer = null;
  }
  const modeStatusPill = document.getElementById('modeStatusPill');
  const modeStatusDot = document.getElementById('modeStatusDot');
  const modeStatusText = document.getElementById('modeStatusText');
  if (!modeStatusPill || !modeStatusDot || !modeStatusText) return;

  const state = AppStore.getState();
  const stack = state.inSecretRoom ? state.undoStackSecret : state.undoStackNormal;
  const latestEntry = (stack && stack.length > 0) ? stack[stack.length - 1] : null;

  if (state.inSecretRoom) {
    modeStatusPill.className = 'px-3.5 py-1.5 rounded-full text-xs font-bold bg-slate-900 text-amber-300 border border-amber-500/40 hover:bg-slate-800 transition-all flex items-center gap-2 cursor-pointer shadow-sm max-w-full';
    modeStatusDot.className = 'w-2 h-2 rounded-full bg-amber-400 animate-ping shrink-0';
    modeStatusText.textContent = latestEntry
      ? `[비밀의 방] 최근: ${latestEntry.actionLabel}`
      : '비밀의 방: 학생들 몰래 배정할 목표 자리를 클릭해 맞추세요';
  } else {
    modeStatusPill.className = 'px-3.5 py-1.5 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 hover:bg-indigo-100/80 transition-all flex items-center gap-2 cursor-pointer shadow-sm max-w-full';
    modeStatusDot.className = 'w-2 h-2 rounded-full bg-indigo-600 shrink-0';
    modeStatusText.textContent = latestEntry
      ? `최근 변화: ${latestEntry.actionLabel}`
      : '상태창';
  }
  modeStatusText.title = modeStatusText.textContent;
  syncHeaderStatusLayout();
}

// 상단 상태 표시줄에 알림 메시지를 표시하고 일정 시간 후 기본 상태로 복원한다.
export function showToast(message, type = 'info') {
  if (AppStore.isRunningSelfDiagnostics()) return;
  const modeStatusPill = document.getElementById('modeStatusPill');
  const modeStatusDot = document.getElementById('modeStatusDot');
  const modeStatusText = document.getElementById('modeStatusText');
  if (!modeStatusPill || !modeStatusDot || !modeStatusText) return;

  if (statusPillRevertTimer) {
    clearTimeout(statusPillRevertTimer);
    statusPillRevertTimer = null;
  }

  const pillStyles = {
    success: 'px-3.5 py-1.5 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-300 hover:bg-emerald-100 transition-all flex items-center gap-2 cursor-pointer shadow-sm max-w-full',
    info: 'px-3.5 py-1.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-800 border border-indigo-300 hover:bg-indigo-100 transition-all flex items-center gap-2 cursor-pointer shadow-sm max-w-full',
    warn: 'px-3.5 py-1.5 rounded-full text-xs font-bold bg-amber-50 text-amber-900 border border-amber-400 hover:bg-amber-100 transition-all flex items-center gap-2 cursor-pointer shadow-sm max-w-full',
    secret: 'px-3.5 py-1.5 rounded-full text-xs font-bold bg-slate-900 text-amber-300 border border-amber-500/50 hover:bg-slate-800 transition-all flex items-center gap-2 cursor-pointer shadow-sm max-w-full'
  };
  const dotStyles = {
    success: 'w-2 h-2 rounded-full bg-emerald-500 animate-ping shrink-0',
    info: 'w-2 h-2 rounded-full bg-indigo-600 animate-ping shrink-0',
    warn: 'w-2 h-2 rounded-full bg-amber-500 animate-ping shrink-0',
    secret: 'w-2 h-2 rounded-full bg-amber-400 animate-ping shrink-0'
  };

  modeStatusPill.className = pillStyles[type] || pillStyles.info;
  modeStatusDot.className = dotStyles[type] || dotStyles.info;
  modeStatusText.textContent = message;
  modeStatusText.title = message;
  syncHeaderStatusLayout();

  statusPillRevertTimer = setTimeout(() => {
    applyDefaultModeStatusPillStyle();
  }, 3600);
}
