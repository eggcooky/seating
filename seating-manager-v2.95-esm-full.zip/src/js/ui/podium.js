// [L3] 교탁 및 선생님 안내 문구 공용 DOM 생성기 (화면·인쇄 공용)
import { AppStore } from '../state/store.js';

export function createPodiumAndMessageElement(isPrint = false) {
  const state = AppStore.getState();
  const wrapper = document.createElement('div');
  wrapper.className = 'w-full flex flex-col items-center justify-center gap-2 my-0.5 shrink-0';

  // 교탁 요소 생성
  const box = document.createElement('div');
  if (isPrint) {
    box.className = 'w-64 h-11 border-[1.5px] border-black flex items-center justify-center font-bold text-xl tracking-[1.2em] pl-[1.2em] bg-white text-black';
  } else {
    const podiumHeightCls = state.largeViewEnabled ? 'podium-box-large podium-text-large' : 'podium-box-responsive text-xl';
    box.className = `w-64 md:w-72 ${podiumHeightCls} border-2 border-slate-800 rounded-md flex items-center justify-center font-extrabold tracking-[1.1em] pl-[1.1em] bg-white text-slate-900 shadow-sm`;
  }
  box.textContent = '교탁';
  wrapper.appendChild(box);

  // 교탁 하단 선생님 안내 문구 영역 생성
  if (isPrint) {
    const msg = (state.teacherMessage || '').trim();
    if (msg) {
      const msgBox = document.createElement('div');
      msgBox.className = 'max-w-[190mm] mt-[1pt] px-4 py-1 text-center text-[12.5pt] font-bold text-black tracking-wide border-b border-black/40';
      msgBox.textContent = msg;
      wrapper.appendChild(msgBox);
    }
  } else {
    const inputWrap = document.createElement('div');
    inputWrap.className = 'w-full max-w-md flex items-center justify-center';
    const msgInput = document.createElement('input');
    msgInput.type = 'text';
    msgInput.maxLength = 80;
    msgInput.value = state.teacherMessage || '';
    msgInput.placeholder = '✏️ 교탁 아래 인쇄 문구 입력 (예: 바른 자세로 경청하며 서로 배려해요!)';
    msgInput.className = 'w-full text-center text-sm font-bold text-slate-700 bg-slate-50/90 hover:bg-slate-100/80 focus:bg-white border border-dashed border-slate-300 focus:border-indigo-500 rounded-lg px-3 py-1.5 focus:outline-none transition placeholder:text-slate-400 placeholder:text-xs placeholder:font-normal';
    msgInput.addEventListener('input', (e) => {
      const curState = AppStore.getState();
      curState.teacherMessage = e.target.value;
      AppStore.scheduleDebouncedCommit(200);
    });
    inputWrap.appendChild(msgInput);
    wrapper.appendChild(inputWrap);
  }

  return wrapper;
}
