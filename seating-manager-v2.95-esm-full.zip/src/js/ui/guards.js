// [L3] 룰렛 진행 중 수동 편집 차단 가드
import { AppStore } from '../state/store.js';
import { showToast } from './toast.js';

export function isRouletteBlockingEdit() {
  const state = AppStore.getState();
  if (state.rouletteActiveSession && !state.inSecretRoom) {
    showToast('룰렛 진행 중에는 자리를 직접 바꿀 수 없습니다. 룰렛을 닫거나 [자리 바꾸기]로 종료한 뒤 이용해 주세요.', 'warn');
    return true;
  }
  return false;
}
