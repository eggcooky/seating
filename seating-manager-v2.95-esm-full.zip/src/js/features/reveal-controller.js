// [L4] 이름 가리기 개별·순차 공개 타이머 및 크게 보기(전체화면) 제어
import { getActivePosMap, isSeatHidden } from '../domain/seat-queries.js';
import { playSoundEffect } from '../infra/audio.js';
import { saveToStorage } from '../infra/storage-io.js';
import { AppStore } from '../state/store.js';
import { showToast } from '../ui/toast.js';
import { toggleLeftSidebar, updateLargeViewButtonUI, updateRevealAllButton } from '../views/toolbar-ui.js';

let sequentialRevealTimer = null;

export function stopSequentialReveal(persist = false) {
  const wasRunning = Boolean(sequentialRevealTimer);
  if (sequentialRevealTimer) {
    clearInterval(sequentialRevealTimer);
    sequentialRevealTimer = null;
  }
  const seqBtn = document.getElementById('sequentialRevealBtn');
  if (seqBtn) {
    seqBtn.innerHTML = '<span>✨ 순차 공개</span>';
  }
  if (wasRunning && persist) {
    saveToStorage(false);
  }
}

export function revealSeat(studentId, fromTimer = false) {
  const state = AppStore.getState();
  const id = String(studentId);
  state.hiddenSeatIds = state.hiddenSeatIds.filter(x => String(x) !== id);
  playSoundEffect(state.hiddenSeatIds.length === 0 ? 'win' : 'reveal');
  if (!fromTimer && state.hiddenSeatIds.length === 0 && sequentialRevealTimer) {
    stopSequentialReveal();
  }
  updateRevealAllButton();
  if (!fromTimer) {
    saveToStorage(false);
  }
}

export function animateSingleDeskById(studentId) {
  const safeId = (typeof CSS !== "undefined" && CSS.escape) ? CSS.escape(String(studentId)) : String(studentId).replace(/["\\]/g, "\\$&");
  const nameEl = document.querySelector(`[data-student-name-id="${safeId}"]`);
  if (nameEl && nameEl.parentElement) {
    nameEl.parentElement.classList.add('animate-pop');
  }
}

export function startSequentialReveal() {
  const state = AppStore.getState();
  if (sequentialRevealTimer) {
    stopSequentialReveal(true);
    showToast('순차 공개가 일시 정지되었습니다.', 'info');
    return;
  }
  if (state.hiddenSeatIds.length === 0) return;

  const seqBtn = document.getElementById('sequentialRevealBtn');
  if (seqBtn) {
    seqBtn.innerHTML = '<span>⏸ 공개 중...</span>';
  }

  sequentialRevealTimer = setInterval(() => {
    const curState = AppStore.getState();
    const remainingHidden = curState.hiddenSeatIds.filter(id => isSeatHidden(curState, id));
    if (remainingHidden.length === 0) {
      stopSequentialReveal(true);
      showToast('🎉 모든 학생의 자리가 공개되었습니다!', 'success');
      return;
    }
    const activeMap = getActivePosMap(curState);
    const isStudentView = curState.viewOrientation === 'student';
    remainingHidden.sort((idA, idB) => {
      const pA = activeMap[idA] || [0, 0];
      const pB = activeMap[idB] || [0, 0];
      const colDiff = isStudentView ? (pA[0] - pB[0]) : (pB[0] - pA[0]);
      if (colDiff !== 0) return colDiff;
      return isStudentView ? (pA[1] - pB[1]) : (pB[1] - pA[1]);
    });
    const nextId = remainingHidden[0];
    const activeEl = document.activeElement;
    const restorePodiumFocus = (
      activeEl &&
      activeEl.tagName === 'INPUT' &&
      activeEl.closest &&
      activeEl.closest('#classroomStage')
    ) ? {
      selectionStart: activeEl.selectionStart,
      selectionEnd: activeEl.selectionEnd
    } : null;
    revealSeat(nextId, true);
    AppStore.requestClassroomRender(false);
    if (restorePodiumFocus) {
      const podiumInput = document.querySelector('#classroomStage input[type="text"]');
      if (podiumInput) {
        podiumInput.focus({ preventScroll: true });
        if (typeof restorePodiumFocus.selectionStart === 'number') {
          try {
            podiumInput.setSelectionRange(restorePodiumFocus.selectionStart, restorePodiumFocus.selectionEnd);
          } catch (_) {}
        }
      }
    }
    animateSingleDeskById(nextId);

    if (AppStore.getState().hiddenSeatIds.length === 0) {
      stopSequentialReveal(true);
      showToast('🎉 모든 학생의 자리가 공개되었습니다!', 'success');
    }
  }, 420);
}

// 전체화면 및 칠판 투사용 글자 크게 보기 모드를 전환한다.
export function toggleLargeViewMode(forceState) {
  const state = AppStore.getState();
  const nextState = typeof forceState === 'boolean' ? forceState : !state.largeViewEnabled;
  state.largeViewEnabled = nextState;
  toggleLeftSidebar(nextState);
  updateLargeViewButtonUI();
  AppStore.requestClassroomRender(false);

  if (!AppStore.isRunningSelfDiagnostics() && typeof document !== 'undefined') {
    try {
      if (nextState && document.documentElement && typeof document.documentElement.requestFullscreen === 'function' && !document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(() => {});
      } else if (!nextState && typeof document.exitFullscreen === 'function' && document.fullscreenElement) {
        document.exitFullscreen().catch(() => {});
      }
    } catch (e) {}
  }
  playSoundEffect('toggle');
}
