// [L4] 자리 바꾸기(랜덤 배정) 및 학생 번호순 배치 실행 액션
import { compareStudentsByNumber } from '../core/utils.js';
import { generateOptimalSeatAssignment } from '../domain/algorithm-engine.js';
import {
  doesSecretLayoutMatchCurrent,
  getActivePosMap,
  hasValidSecretPreset,
  isSeatLocked
} from '../domain/seat-queries.js';
import { playSoundEffect } from '../infra/audio.js';
import { pushUndoSnapshot } from '../state/history-store.js';
import { AppStore } from '../state/store.js';
import { showSecretNoticePopup } from '../ui/secret-indicators.js';
import { showToast } from '../ui/toast.js';
import { stopSequentialReveal } from './reveal-controller.js';
import { stopRouletteColumnAuto } from './roulette-controller.js';

function haltPlaybackAndAnimateShuffleIcon(state) {
  stopSequentialReveal();
  stopRouletteColumnAuto();
  state.rouletteSessionToken = (state.rouletteSessionToken || 0) + 1;
  state.rouletteSpinning = false;

  const icon = document.getElementById('shuffleIcon');
  if (icon) {
    icon.classList.add('rotate-180');
    setTimeout(() => icon.classList.remove('rotate-180'), 500);
  }
}

// 자리 바꾸기 실행 처리 (일반 랜덤 배정 및 비밀의 방 사전 지정 배치 적용)
export function handleShuffleButtonClick(event) {
  const state = AppStore.getState();
  const isCtrlPressed = Boolean(event && (event.ctrlKey || event.metaKey));

  // 일반 화면에서 Ctrl(또는 Cmd)+클릭 시 비밀의 방 배열이 유효하고 현재 배열·고정석과 일치(doesSecretLayoutMatchCurrent)하면 사전 지정 배치를 즉시 적용한다.
  if (!state.inSecretRoom && isCtrlPressed && hasValidSecretPreset(state) && doesSecretLayoutMatchCurrent(state)) {
    haltPlaybackAndAnimateShuffleIcon(state);
    pushUndoSnapshot('자리 바꾸기 (랜덤 배정)');
    state.rouletteActiveSession = false;
    state.rouletteUseSecretPreset = false;
    state.rouletteAssignedMap = {};
    state.rouletteDrawnIds = [];
    state.pendingSecretNotices = [];
    state.pos = JSON.parse(JSON.stringify(state.secretPos));

    const unlockedStudents = state.students.filter(s => !isSeatLocked(state, s.id));
    if (state.maskModeEnabled) {
      state.hiddenSeatIds = unlockedStudents.map(s => String(s.id));
    } else {
      state.hiddenSeatIds = [];
    }
    state.rouletteRemainingStudents = [...unlockedStudents];
    state.rouletteTargetCoords = unlockedStudents
      .map(s => state.pos[s.id])
      .filter(Boolean)
      .map(c => [...c])
      .sort((a, b) => (a[0] - b[0]) || (a[1] - b[1]));
    state.selectedStudentId = null;
    AppStore.commitChange({ roster: true, classroom: true, animate: true, print: true, roulette: true, dirty: true, save: true });

    playSoundEffect('shuffle');
    if (state.maskModeEnabled) {
      showToast('자리가 배정되어 가려졌습니다! 각 책상을 클릭하거나 하단 [✨ 순차 공개]를 눌러보세요.', 'info');
    } else {
      showToast('랜덤 자리 바꾸기가 완료되었습니다!', 'success');
    }
    return;
  }

  // 일반 랜덤 배정 또는 비밀의 방 내부 랜덤 배정을 수행한다.
  const activeMap = getActivePosMap(state);
  const activeLockedIds = state.inSecretRoom ? state.secretLockedIds : state.lockedIds;
  const unlockedStudents = state.students.filter(s => !isSeatLocked(state, s.id));
  if (unlockedStudents.length <= 1) {
    showToast('랜덤으로 섞을 수 있는 고정 해제된 자리가 부족합니다.', 'warn');
    return;
  }

  const { map: bestCandidateMap, conflicts, conflictDetails } = generateOptimalSeatAssignment({
    students: state.students,
    pos: activeMap,
    rules: state.rules,
    lockedIds: activeLockedIds,
    rng: Math.random
  });

  if (!bestCandidateMap) {
    showToast('⚠️ 최적의 자리 배치를 찾지 못했습니다. 다시 한 번 시도해 주세요.', 'warn');
    return;
  }

  haltPlaybackAndAnimateShuffleIcon(state);
  // 되돌리기(Undo) 시 진행 중이던 룰렛 대기열이 복원되도록 상태 초기화 전에 스냅샷을 먼저 기록한다(BUG-01 방어).
  pushUndoSnapshot(state.inSecretRoom ? '비밀의 방 자리 랜덤 섞기' : '자리 바꾸기 (랜덤 배정)');
  if (!state.inSecretRoom) {
    state.rouletteActiveSession = false;
    state.rouletteAssignedMap = {};
    state.rouletteDrawnIds = [];
    state.rouletteUseSecretPreset = false;
  }

  if (state.inSecretRoom) {
    state.secretPos = bestCandidateMap;
  } else {
    state.pos = bestCandidateMap;
  }

  if (!state.inSecretRoom) {
    state.hiddenSeatIds = state.maskModeEnabled ? unlockedStudents.map(s => String(s.id)) : [];
    state.rouletteRemainingStudents = [...unlockedStudents];
    state.rouletteTargetCoords = unlockedStudents
      .map(s => state.pos[s.id])
      .filter(Boolean)
      .map(c => [...c])
      .sort((a, b) => (a[0] - b[0]) || (a[1] - b[1]));
  }

  state.selectedStudentId = null;
  playSoundEffect('shuffle');
  AppStore.commitChange({ roster: true, classroom: true, animate: true, print: true, roulette: true, dirty: true, save: true });

  if (conflicts && conflicts.length > 0) {
    const detailLines = (Array.isArray(conflictDetails) && conflictDetails.length > 0)
      ? conflictDetails
      : [`[규칙 충돌] 여러 배치 조건(${conflicts.join(', ')})이 동시에 겹쳐 모든 조건을 충족하지 못했습니다.`];
    if (state.inSecretRoom) {
      state.pendingSecretNotices = [];
      showToast(`⚠️ 모든 조건(${conflicts.join(', ')})을 동시에 만족하는 배치를 찾을 수 없어 가장 근접한 배치로 적용되었습니다.`, 'warn');
      showSecretNoticePopup([
        `[비밀 자리 섞기 미충족 원인] 요약: ${conflicts.join(', ')}`,
        ...detailLines
      ]);
    } else {
      // 스텔스 원칙: 일반 화면에서는 비밀의 방 전용 옵션(거리두기·친구 붙이기) 명칭을 절대 노출하지 않고,
      // 상세 원인은 비밀의 방 진입 시 모달로 확인할 수 있도록 대기 알림에 최신 1건만 보관한다.
      state.pendingSecretNotices = [
        `[최근 자리 바꾸기 미충족 원인] 요약: ${conflicts.join(', ')}`,
        ...detailLines
      ];
      const visibleConflicts = conflicts.filter(c => !/^(?:거리두기|친구 붙이기)/.test(String(c)));
      if (visibleConflicts.length > 0) {
        showToast(`⚠️ 일부 조건(${visibleConflicts.join(', ')})을 모두 만족하는 배치를 찾지 못해 가장 근접한 배치로 적용되었습니다.`, 'warn');
      } else {
        showToast('⚠️ 최적의 자리 배치를 찾지 못했습니다. 다시 한 번 시도해 주세요.', 'warn');
      }
    }
  } else {
    state.pendingSecretNotices = [];
    if (state.inSecretRoom) {
      showToast('비밀의 방 자리 배치가 무작위로 섞였습니다. 원하는 자리끼리 클릭해 조정하세요.', 'secret');
    } else if (state.maskModeEnabled) {
      showToast('자리가 배정되어 가려졌습니다! 각 책상을 클릭하거나 하단 [✨ 순차 공개]를 눌러보세요.', 'info');
    } else {
      showToast('랜덤 자리 바꾸기가 완료되었습니다!', 'success');
    }
  }
}

export function arrangeByStudentNumber() {
  const state = AppStore.getState();
  stopSequentialReveal();
  const unlockedStudents = state.students.filter(s => !isSeatLocked(state, s.id));
  if (unlockedStudents.length === 0) {
    showToast('번호순으로 배치할 고정 해제된 학생이 없습니다.', 'warn');
    return;
  }
  pushUndoSnapshot('학생 번호순 자리 배치');
  state.pendingSecretNotices = [];
  if (!state.inSecretRoom) {
    stopRouletteColumnAuto();
    state.rouletteSessionToken = (state.rouletteSessionToken || 0) + 1;
    state.rouletteSpinning = false;
    state.rouletteActiveSession = false;
    state.rouletteUseSecretPreset = false;
    state.rouletteAssignedMap = {};
    state.rouletteDrawnIds = [];
    state.hiddenSeatIds = [];
  }

  const activeMap = getActivePosMap(state);
  const unlockedCoords = unlockedStudents.map(s => activeMap[s.id]).filter(Boolean);
  unlockedCoords.sort((a, b) => (a[0] - b[0]) || (a[1] - b[1]));

  const sortedUnlocked = [...unlockedStudents].sort(compareStudentsByNumber);
  sortedUnlocked.forEach((st, idx) => {
    if (unlockedCoords[idx]) {
      activeMap[st.id] = [...unlockedCoords[idx]];
    }
  });
  if (!state.inSecretRoom) {
    state.rouletteRemainingStudents = [...unlockedStudents];
    state.rouletteTargetCoords = unlockedStudents
      .map(s => state.pos[s.id])
      .filter(Boolean)
      .map(c => [...c])
      .sort((a, b) => (a[0] - b[0]) || (a[1] - b[1]));
  }

  state.selectedStudentId = null;
  playSoundEffect('swap');
  AppStore.commitChange({ roster: true, classroom: true, animate: true, print: true, roulette: true, dirty: true, save: true });
  showToast('학생 번호 순서대로 자리를 배치했습니다.', 'info');
}
