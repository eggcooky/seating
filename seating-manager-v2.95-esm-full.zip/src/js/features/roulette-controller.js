// [L4] 원형 룰렛 배정 세션 · 원판 렌더링 · 1명/1줄 회전 제어 (드로어 상호배타 전환은 L5 mode-coordinator.js)
import { compareStudentsByNumber, formatStudentNumLabel } from '../core/utils.js';
import { getGridBounds } from '../domain/grid.js';
import {
  doesSecretLayoutMatchCurrent,
  getStudentById,
  isNormalSeatLocked,
  isSeatHidden,
  isSeatLocked
} from '../domain/seat-queries.js';
import { playSoundEffect } from '../infra/audio.js';
import { pushUndoSnapshot } from '../state/history-store.js';
import { AppStore } from '../state/store.js';
import { showToast } from '../ui/toast.js';
import { stopSequentialReveal } from './reveal-controller.js';

const WHEEL_PALETTE = [
  '#6366f1', '#8b5cf6', '#ec4899', '#f43f5e',
  '#f59e0b', '#10b981', '#06b6d4', '#3b82f6'
];
let rouletteColumnTimer = null;

export function stopRouletteColumnAuto() {
  const state = AppStore.getState();
  if (rouletteColumnTimer) {
    clearTimeout(rouletteColumnTimer);
    rouletteColumnTimer = null;
  }
  state.rouletteAutoColumnTarget = null;
  const colBtn = document.getElementById('spinRouletteColumnBtn');
  if (colBtn) {
    const remaining = (state.rouletteRemainingStudents || []).length;
    const unlockedTotal = state.students.filter(s => !isSeatLocked(state, s.id)).length;
    if (remaining === 0 && unlockedTotal > 0) {
      colBtn.className = 'col-span-2 py-2 px-4 rounded-xl font-bold text-xs bg-slate-100 text-slate-400 border border-slate-200 transition flex items-center justify-center gap-1.5';
      colBtn.innerHTML = '<span>📋 1줄(세로) 뽑기 완료</span>';
    } else {
      colBtn.className = 'col-span-2 py-2 px-4 rounded-xl font-extrabold text-xs bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-200 shadow-sm transition flex items-center justify-center gap-1.5';
      colBtn.innerHTML = '<span>📋 1줄(세로) 뽑기 (현재 분단 연속 배정)</span>';
    }
  }
}

function formatVisualSeatLabel(state, col, row) {
  const { c0, r0 } = getGridBounds(state.students, state.pos, false);
  const vCol = (col - c0) + 1;
  const vRow = (row - r0) + 1;
  return `${vCol}열 ${vRow}행`;
}

export function initRouletteSession(useSecret = false) {
  const state = AppStore.getState();
  stopSequentialReveal();
  stopRouletteColumnAuto();
  state.rouletteSessionToken = (state.rouletteSessionToken || 0) + 1;
  state.rouletteSpinning = false;
  state.rouletteWheelAngle = 0;
  state.rouletteUseSecretPreset = Boolean(useSecret && doesSecretLayoutMatchCurrent(state));

  const unlockedStudents = state.students.filter(s => !isSeatLocked(state, s.id));
  state.rouletteRemainingStudents = [...unlockedStudents];

  const targetCoords = unlockedStudents
    .map(s => state.pos[s.id])
    .filter(Boolean)
    .map(c => [...c]);
  targetCoords.sort((a, b) => (a[0] - b[0]) || (a[1] - b[1]));
  state.rouletteTargetCoords = targetCoords;

  state.rouletteDrawnIds = [];
  state.rouletteAssignedMap = {};
  state.students.forEach(s => {
    if (isSeatLocked(state, s.id) && state.pos[s.id]) {
      const [c, r] = state.pos[s.id];
      state.rouletteAssignedMap[`${c},${r}`] = s.id;
    }
  });

  state.rouletteActiveSession = unlockedStudents.length > 0;
  state.hiddenSeatIds = [];

  const subEl = document.getElementById('rouletteResultSub');
  const mainEl = document.getElementById('rouletteResultMain');
  if (subEl && mainEl) {
    subEl.textContent = '원판(룰렛)을 클릭해 첫 번째 친구를 뽑아보세요!';
    mainEl.textContent = `대상 인원 ${state.rouletteRemainingStudents.length}명`;
  }

  updateRouletteStatusUI();
  drawRouletteWheel();
  AppStore.requestClassroomRender(false);
}

export function updateRouletteStatusUI() {
  const state = AppStore.getState();
  const unlockedTotal = state.students.filter(s => !isSeatLocked(state, s.id)).length;
  const remaining = state.rouletteRemainingStudents.length;
  const assignedCount = Math.max(0, unlockedTotal - remaining);

  const badge = document.getElementById('rouletteProgressBadge');
  const nextText = document.getElementById('rouletteNextSeatText');
  if (badge) {
    badge.textContent = `${assignedCount} / ${unlockedTotal}명 배정됨`;
  }
  if (nextText) {
    if (state.students.length === 0) {
      nextText.textContent = '명단이 비어 있습니다';
    } else if (unlockedTotal === 0) {
      nextText.textContent = '고정 해제된 학생이 없습니다';
    } else if (remaining === 0) {
      nextText.textContent = '모든 자리 배정 완료! 🎉';
    } else if (state.rouletteTargetCoords.length > 0) {
      const [nc, nr] = state.rouletteTargetCoords[0];
      nextText.textContent = `다음 자리: ${formatVisualSeatLabel(state, nc, nr)}`;
    }
  }
  const centerBtn = document.getElementById('spinWheelCenterBtn');
  const actionBtn = document.getElementById('spinRouletteActionBtn');
  const colBtn = document.getElementById('spinRouletteColumnBtn');
  if (remaining === 0 && unlockedTotal > 0) {
    if (centerBtn) {
      centerBtn.innerHTML = '<span>완료</span><span class="text-[9px] font-medium text-emerald-300">배정 끝!</span>';
    }
    if (actionBtn) {
      actionBtn.innerHTML = '<span>🎉 모든 자리 배정 완료 (다시 뽑기: 상단 초기화)</span>';
    }
    if (colBtn) {
      colBtn.className = 'col-span-2 py-2 px-4 rounded-xl font-bold text-xs bg-slate-100 text-slate-400 border border-slate-200 transition flex items-center justify-center gap-1.5';
      colBtn.innerHTML = '<span>📋 1줄(세로) 뽑기 완료</span>';
    }
  } else {
    if (centerBtn) {
      centerBtn.innerHTML = '<span>SPIN</span><span class="text-[9px] font-medium text-violet-200">클릭!</span>';
    }
    if (actionBtn) {
      actionBtn.innerHTML = '<span>🎯 룰렛 돌리기 (1명 배정)</span>';
    }
    if (colBtn) {
      if (state.rouletteAutoColumnTarget !== null) {
        const { c0 } = getGridBounds(state.students, state.pos, false);
        const vCol = (state.rouletteAutoColumnTarget - c0) + 1;
        colBtn.className = 'col-span-2 py-2 px-4 rounded-xl font-extrabold text-xs bg-amber-500 text-white hover:bg-amber-600 border border-amber-600 shadow-sm transition flex items-center justify-center gap-1.5';
        colBtn.innerHTML = `<span>⏸ ${vCol}열(세로 1줄) 연속 추첨 중... (클릭 시 정지)</span>`;
      } else {
        colBtn.className = 'col-span-2 py-2 px-4 rounded-xl font-extrabold text-xs bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-200 shadow-sm transition flex items-center justify-center gap-1.5';
        colBtn.innerHTML = '<span>📋 1줄(세로) 뽑기 (현재 분단 연속 배정)</span>';
      }
    }
  }
}

export function drawRouletteWheel() {
  const state = AppStore.getState();
  const canvas = document.getElementById('rouletteWheelCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const LOGICAL_SIZE = 290;
  const dpr = Math.min(3, Math.max(1, (typeof window !== 'undefined' && Number(window.devicePixelRatio)) || 1));
  if (canvas.width !== Math.round(LOGICAL_SIZE * dpr) || canvas.height !== Math.round(LOGICAL_SIZE * dpr)) {
    canvas.width = Math.round(LOGICAL_SIZE * dpr);
    canvas.height = Math.round(LOGICAL_SIZE * dpr);
    if (canvas.style) {
      canvas.style.width = LOGICAL_SIZE + 'px';
      canvas.style.height = LOGICAL_SIZE + 'px';
    }
  }
  if (typeof ctx.setTransform === 'function') {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  const W = LOGICAL_SIZE;
  const H = LOGICAL_SIZE;
  const cx = W / 2;
  const cy = H / 2;
  const radius = Math.min(cx, cy) - 6;

  ctx.clearRect(0, 0, W, H);

  const items = state.rouletteRemainingStudents;
  if (!items || items.length === 0) {
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.fillStyle = '#f3e8ff';
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#9333ea';
    ctx.stroke();

    ctx.fillStyle = '#581c87';
    ctx.font = 'bold 16px "Malgun Gothic", "맑은 고딕", "Apple SD Gothic Neo", "Noto Sans KR", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const unlockedTotalWheel = state.students.filter(s => !isSeatLocked(state, s.id)).length;
    const emptyWheelLabel = state.students.length === 0
      ? '명단이 비어 있습니다'
      : (unlockedTotalWheel === 0 ? '🔒 전원 고정됨' : '🎉 전원 배정 완료!');
    ctx.fillText(emptyWheelLabel, cx, cy - 38);
    return;
  }

  const sliceAngle = (Math.PI * 2) / items.length;

  for (let i = 0; i < items.length; i++) {
    const startAngle = state.rouletteWheelAngle + i * sliceAngle;
    const endAngle = startAngle + sliceAngle;

    ctx.beginPath();
    if (items.length === 1) {
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    } else {
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, radius, startAngle, endAngle);
      ctx.closePath();
    }
    ctx.fillStyle = WHEEL_PALETTE[i % WHEEL_PALETTE.length];
    ctx.fill();
    if (items.length > 1) {
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = '#ffffff';
      ctx.stroke();
    }

    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(startAngle + sliceAngle / 2);
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#ffffff';
    const fontSize = items.length > 20 ? 10.5 : items.length > 12 ? 12 : 14;
    ctx.font = `bold ${fontSize}px "Noto Sans KR", "Inter", "Malgun Gothic", "맑은 고딕", "Apple SD Gothic Neo", sans-serif`;
    const liveStudent = getStudentById(state, items[i].id);
    const wheelLabel = liveStudent ? liveStudent.name : items[i].name;
    ctx.fillText(wheelLabel, radius - 12, 0, Math.max(40, radius - 48));
    ctx.restore();
  }
}

export function spinRouletteOnce() {
  const state = AppStore.getState();
  if (state.inSecretRoom || state.rouletteSpinning) return;

  if (!state.rouletteActiveSession || state.rouletteRemainingStudents.length === 0) {
    const unlockedCount = state.students.filter(s => !isSeatLocked(state, s.id)).length;
    if (unlockedCount === 0) {
      showToast('룰렛으로 추첨할 고정 해제된 학생이 없습니다.', 'warn');
      return;
    }
    if (state.rouletteRemainingStudents.length === 0 && Object.keys(state.rouletteAssignedMap || {}).length > 0) {
      showToast('모든 자리 배정이 완료되었습니다! 처음부터 다시 뽑으려면 상단 [처음부터 다시]를 눌러주세요.', 'info');
      return;
    }
    if (state.maskModeEnabled && Array.isArray(state.hiddenSeatIds) && state.hiddenSeatIds.length > 0) {
      showToast('현재 가려진 자리가 있습니다. 룰렛을 새로 시작하려면 상단 [처음부터 다시]를 눌러주세요.', 'info');
      return;
    }
    initRouletteSession(state.rouletteUseSecretPreset);
    showToast('새 룰렛 배정 세션이 시작되었습니다. 다시 한 번 눌러 돌려보세요!', 'info');
    return;
  }

  const items = state.rouletteRemainingStudents;
  const targetCoord = state.rouletteTargetCoords[0];
  if (!targetCoord || items.length === 0) return;

  state.rouletteSpinning = true;

  // 비밀의 방 연동 모드로 시작된 룰렛 세션인 경우 해당 목표 좌표의 학생을 우선 선택한다.
  let winnerIdx = -1;

  if (state.rouletteUseSecretPreset && doesSecretLayoutMatchCurrent(state)) {
    const [tc, tr] = targetCoord;
    const secretStudent = state.students.find(s => {
      const sp = state.secretPos[s.id];
      return sp && sp[0] === tc && sp[1] === tr;
    });
    if (secretStudent) {
      winnerIdx = items.findIndex(st => String(st.id) === String(secretStudent.id));
    }
  }

  if (winnerIdx === -1) {
    winnerIdx = Math.floor(Math.random() * items.length);
  }
  const winner = items[winnerIdx];

  const sliceAngle = (Math.PI * 2) / items.length;
  const desiredMod = (-Math.PI / 2 - (winnerIdx + 0.5) * sliceAngle);
  const currentAngle = state.rouletteWheelAngle;
  const extraSpins = (3 + Math.floor(Math.random() * 2)) * Math.PI * 2;

  const delta = ((desiredMod - currentAngle) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
  const targetAngle = currentAngle + extraSpins + delta;

  const duration = items.length === 1 ? 350 : 1050;
  const startTime = performance.now();
  const spinToken = state.rouletteSessionToken;
  let lastTickSlice = Math.floor((state.rouletteWheelAngle) / Math.max(0.15, sliceAngle));

  function animateWheel(now) {
    const curState = AppStore.getState();
    if (spinToken !== curState.rouletteSessionToken || !curState.rouletteOpen || !curState.rouletteActiveSession) {
      curState.rouletteSpinning = false;
      return;
    }
    const elapsed = now - startTime;
    const progress = Math.max(0, Math.min(1, elapsed / duration));
    const eased = 1 - Math.pow(1 - progress, 3);
    curState.rouletteWheelAngle = currentAngle + (targetAngle - currentAngle) * eased;
    const curSlice = Math.floor((curState.rouletteWheelAngle) / Math.max(0.15, sliceAngle));
    if (curSlice !== lastTickSlice) {
      lastTickSlice = curSlice;
      playSoundEffect('tick');
    }
    drawRouletteWheel();

    if (progress < 1) {
      requestAnimationFrame(animateWheel);
    } else {
      finalizeRoulettePick(winnerIdx, winner, targetCoord);
    }
  }

  requestAnimationFrame(animateWheel);
}

export function finalizeRoulettePick(winnerIdx, winner, targetCoord) {
  const state = AppStore.getState();
  if (state.inSecretRoom) return;
  const liveWinner = getStudentById(state, winner.id) || winner;
  playSoundEffect('win');
  pushUndoSnapshot(`룰렛 배정: ${liveWinner.name} (${formatVisualSeatLabel(state, targetCoord[0], targetCoord[1])})`);

  const [targetC, targetR] = targetCoord;
  const coordKey = `${targetC},${targetR}`;

  const currentOccupant = state.students.find(s => {
    const p = state.pos[s.id];
    return p && p[0] === targetC && p[1] === targetR;
  });

  const winnerOldCoord = state.pos[winner.id];
  state.pos[winner.id] = [targetC, targetR];
  if (currentOccupant && String(currentOccupant.id) !== String(winner.id) && winnerOldCoord) {
    state.pos[currentOccupant.id] = [...winnerOldCoord];
  }

  if (!Array.isArray(state.rouletteDrawnIds)) state.rouletteDrawnIds = [];
  if (!state.rouletteDrawnIds.includes(String(winner.id))) {
    state.rouletteDrawnIds.push(String(winner.id));
  }
  state.rouletteAssignedMap[coordKey] = winner.id;
  state.rouletteRemainingStudents.splice(winnerIdx, 1);
  const coordIdx = state.rouletteTargetCoords.findIndex(tc => tc[0] === targetC && tc[1] === targetR);
  if (coordIdx !== -1) {
    state.rouletteTargetCoords.splice(coordIdx, 1);
  } else {
    state.rouletteTargetCoords.shift();
  }

  if (state.maskModeEnabled && !isSeatHidden(state, winner.id)) {
    state.hiddenSeatIds.push(String(winner.id));
  }

  if (state.rouletteRemainingStudents.length === 0) {
    state.rouletteActiveSession = false;
  }

  state.rouletteSpinning = false;
  state.rouletteWheelAngle = 0;

  const subEl = document.getElementById('rouletteResultSub');
  const mainEl = document.getElementById('rouletteResultMain');
  if (subEl && mainEl) {
    subEl.textContent = `${formatVisualSeatLabel(state, targetC, targetR)} 자리 당첨!`;
    mainEl.textContent = state.maskModeEnabled
      ? '🔒 가려짐 (책상 클릭 시 공개)'
      : `🎉 ${formatStudentNumLabel(liveWinner)} ${liveWinner.name}`;
  }

  // 1줄(세로) 연속 뽑기 모드가 켜져 있는 경우, 다음 배정 좌석이 같은 세로줄(열)이면 연속 회전하고 줄이 바뀌거나 끝나면 멈춘다.
  if (state.rouletteAutoColumnTarget !== null) {
    const targetCol = state.rouletteAutoColumnTarget;
    const hasMoreInSameCol = state.rouletteActiveSession &&
      state.rouletteRemainingStudents.length > 0 &&
      state.rouletteTargetCoords.length > 0 &&
      state.rouletteTargetCoords[0][0] === targetCol;
    if (hasMoreInSameCol) {
      if (!AppStore.isRunningSelfDiagnostics()) {
        const token = state.rouletteSessionToken;
        if (rouletteColumnTimer) clearTimeout(rouletteColumnTimer);
        rouletteColumnTimer = setTimeout(() => {
          const curState = AppStore.getState();
          if (token === curState.rouletteSessionToken && curState.rouletteOpen && curState.rouletteAutoColumnTarget === targetCol) {
            spinRouletteOnce();
          }
        }, 260);
      }
    } else {
      const { c0 } = getGridBounds(state.students, state.pos, false);
      const finishedVCol = (targetCol - c0) + 1;
      stopRouletteColumnAuto();
      showToast(`🎉 ${finishedVCol}열(세로 1줄) 자리 배정이 완료되었습니다!`, 'success');
    }
  }

  AppStore.commitChange({ roster: true, classroom: true, animate: true, print: true, roulette: true, dirty: true, save: true });
}

// 룰렛 진행 중 또는 되돌리기(Undo) 시 좌석 잠금(🔒) 변경을 룰렛 대기열·목표 좌석·배정 맵에 실시간 동기화한다.
export function syncRouletteWithCurrentLocks() {
  const state = AppStore.getState();
  if (state.inSecretRoom) return;
  const drawnSet = new Set((state.rouletteDrawnIds || []).map(String));
  const unlockedUndrawn = state.students.filter(s => !isNormalSeatLocked(state, s.id) && !drawnSet.has(String(s.id)));

  const prevOrder = new Map((state.rouletteRemainingStudents || []).map((s, idx) => [String(s.id), idx]));
  unlockedUndrawn.sort((a, b) => {
    const hasA = prevOrder.has(String(a.id));
    const hasB = prevOrder.has(String(b.id));
    if (hasA && hasB) return prevOrder.get(String(a.id)) - prevOrder.get(String(b.id));
    if (hasA) return -1;
    if (hasB) return 1;
    return compareStudentsByNumber(a, b);
  });
  state.rouletteRemainingStudents = unlockedUndrawn.map(s => ({ ...s }));

  const targetCoords = unlockedUndrawn
    .map(s => state.pos[s.id])
    .filter(Boolean)
    .map(c => [...c]);
  targetCoords.sort((a, b) => (a[0] - b[0]) || (a[1] - b[1]));
  state.rouletteTargetCoords = targetCoords;

  const remainingIdSet = new Set(unlockedUndrawn.map(s => String(s.id)));
  const nextAssignedMap = {};
  state.students.forEach(s => {
    if (!remainingIdSet.has(String(s.id)) && Array.isArray(state.pos[s.id])) {
      const [c, r] = state.pos[s.id];
      nextAssignedMap[`${c},${r}`] = s.id;
    }
  });
  state.rouletteAssignedMap = nextAssignedMap;

  state.rouletteActiveSession = Boolean(state.rouletteActiveSession && state.rouletteRemainingStudents.length > 0);
  if (!state.rouletteActiveSession) {
    stopRouletteColumnAuto();
  }
  if (state.rouletteOpen) {
    updateRouletteStatusUI();
    drawRouletteWheel();
  }
}

// 현재 배정 차례인 세로줄(같은 열의 앞자리~뒷자리)이 다 찰 때까지 룰렛을 한 명씩 연속으로 회전시켜 배정한다.
export function spinRouletteColumn() {
  const state = AppStore.getState();
  if (state.rouletteAutoColumnTarget !== null) {
    stopRouletteColumnAuto();
    showToast('1줄(세로) 연속 뽑기가 중지되었습니다.', 'info');
    return;
  }
  if (!state.rouletteActiveSession || state.rouletteRemainingStudents.length === 0) {
    spinRouletteOnce();
    return;
  }
  if (state.rouletteTargetCoords.length === 0) return;
  const targetCol = state.rouletteTargetCoords[0][0];
  state.rouletteAutoColumnTarget = targetCol;
  updateRouletteStatusUI();
  const { c0 } = getGridBounds(state.students, state.pos, false);
  const vCol = (targetCol - c0) + 1;
  showToast(`📋 ${vCol}열(세로 1줄) 연속 추첨을 시작합니다!`, 'info');
  if (!state.rouletteSpinning) {
    spinRouletteOnce();
  }
}
