// [L4] 비밀의 방 고정석 동기화 액션 (모드 전환 toggleSecretRoom은 L5 mode-coordinator.js)
import { ensureAllStudentsHaveValidCoords } from '../domain/grid.js';
import { getStudentById, hasValidSecretPreset } from '../domain/seat-queries.js';
import { pushUndoSnapshot } from '../state/history-store.js';
import { AppStore } from '../state/store.js';
import { updateSecretPresetIndicator } from '../ui/secret-indicators.js';
import { showToast } from '../ui/toast.js';

// 일반방의 고정석(lockedIds)을 비밀의 방(secretPos, secretLockedIds)에 동기화한다.
// overwriteConflicts === true이면 비밀의 방 고정석과 충돌하는 자리도 일반방 고정석으로 덮어쓰고,
// false이면 비밀의 방 고정석이 있는 자리는 건너뛰고 충돌 없는 고정석만 동기화한다.
export function applyNormalLocksSyncToSecret(overwriteConflicts = false) {
  const state = AppStore.getState();
  if (!state.inSecretRoom || !hasValidSecretPreset(state)) return;
  const normalLockIds = [...new Set((state.lockedIds || []).map(String))].filter(id => Array.isArray(state.pos[id]));
  if (normalLockIds.length === 0) return;

  const secretLockSet = new Set((state.secretLockedIds || []).map(String));
  const pendingOps = [];
  let skippedCount = 0;

  normalLockIds.forEach(lid => {
    const targetCoord = state.pos[lid];
    if (!Array.isArray(targetCoord)) return;
    const curSecret = state.secretPos[lid];
    const sameSpot = Array.isArray(curSecret) && curSecret[0] === targetCoord[0] && curSecret[1] === targetCoord[1];
    const selfSecretConflict = secretLockSet.has(lid) && !sameSpot;
    const occupant = state.students.find(s => {
      const sp = state.secretPos[s.id];
      return String(s.id) !== lid && Array.isArray(sp) && sp[0] === targetCoord[0] && sp[1] === targetCoord[1];
    });
    const occupantSecretConflict = Boolean(occupant && secretLockSet.has(String(occupant.id)));

    if (!overwriteConflicts && (selfSecretConflict || occupantSecretConflict)) {
      skippedCount++;
      return;
    }
    if (sameSpot && secretLockSet.has(lid)) {
      return;
    }
    pendingOps.push({ lid, targetCoord });
  });

  if (pendingOps.length === 0) {
    updateSecretPresetIndicator();
    showToast(
      skippedCount > 0
        ? `충돌된 비밀 고정석 ${skippedCount}명을 유지하여 변경된 자리가 없습니다.`
        : '이미 모든 일반방 고정석이 비밀의 방과 동일합니다.',
      'secret'
    );
    return;
  }

  pushUndoSnapshot('일반방 고정석 동기화', {
    locks: { lockedIds: [...state.lockedIds], secretLockedIds: [...state.secretLockedIds] },
    overwrittenLockIds: pendingOps.map(op => op.lid)
  });

  let syncedCount = 0;
  pendingOps.forEach(({ lid, targetCoord }) => {
    const curSecret = state.secretPos[lid] ? [...state.secretPos[lid]] : null;
    const occupant = state.students.find(s => {
      const sp = state.secretPos[s.id];
      return String(s.id) !== lid && Array.isArray(sp) && sp[0] === targetCoord[0] && sp[1] === targetCoord[1];
    });
    if (occupant && secretLockSet.has(String(occupant.id))) {
      if (!overwriteConflicts) {
        skippedCount++;
        return;
      }
      secretLockSet.delete(String(occupant.id));
    }
    if (occupant && curSecret) {
      state.secretPos[occupant.id] = curSecret;
    }
    state.secretPos[lid] = [targetCoord[0], targetCoord[1]];
    secretLockSet.add(lid);
    syncedCount++;
  });

  state.secretLockedIds = [...secretLockSet];
  ensureAllStudentsHaveValidCoords(state.students, state.secretPos, Number(state.rules && state.rules.defaultCols) || 6);
  AppStore.commitChange({ roster: true, classroom: true, animate: true, print: true, dirty: true, save: true });
  updateSecretPresetIndicator();
  if (skippedCount > 0) {
    showToast(`일반방 고정석 ${syncedCount}명 동기화 완료 (충돌된 비밀 고정석 ${skippedCount}명 유지)`, 'secret');
  } else {
    showToast(`일반방 고정석 ${syncedCount}명이 비밀의 방에 동기화되었습니다.`, 'secret');
  }
}

export function requestSyncNormalLocksToSecret() {
  const state = AppStore.getState();
  if (!state.inSecretRoom || !hasValidSecretPreset(state)) return;
  const normalLockIds = [...new Set((state.lockedIds || []).map(String))].filter(id => Array.isArray(state.pos[id]));
  if (normalLockIds.length === 0) {
    showToast('일반방에 잠겨 있는 고정석 학생이 없습니다.', 'info');
    return;
  }
  const secretLockSet = new Set((state.secretLockedIds || []).map(String));
  const conflicts = [];
  normalLockIds.forEach(lid => {
    const targetCoord = state.pos[lid];
    const lockedSt = getStudentById(state, lid);
    const curSecret = state.secretPos[lid];
    const sameSpot = Array.isArray(curSecret) && curSecret[0] === targetCoord[0] && curSecret[1] === targetCoord[1];
    if (secretLockSet.has(lid) && !sameSpot) {
      conflicts.push(`• ${lockedSt ? lockedSt.name : lid} 학생이 비밀의 방의 다른 자리에 이미 고정되어 있음`);
    }
    const occupant = state.students.find(s => {
      const sp = state.secretPos[s.id];
      return String(s.id) !== lid && Array.isArray(sp) && sp[0] === targetCoord[0] && sp[1] === targetCoord[1];
    });
    if (occupant && secretLockSet.has(String(occupant.id))) {
      conflicts.push(`• ${lockedSt ? lockedSt.name : lid}의 일반방 고정석 ↔ 비밀의 방 '${occupant.name}' 고정석 충돌`);
    }
  });

  if (conflicts.length > 0) {
    const modal = document.getElementById('syncLockConflictModal');
    const listEl = document.getElementById('syncLockConflictList');
    if (modal && listEl) {
      listEl.innerHTML = '';
      conflicts.forEach(line => {
        const div = document.createElement('div');
        div.textContent = line;
        listEl.appendChild(div);
      });
      modal.classList.remove('hidden');
      modal.classList.add('flex');
      return;
    }
  }
  applyNormalLocksSyncToSecret(false);
}
