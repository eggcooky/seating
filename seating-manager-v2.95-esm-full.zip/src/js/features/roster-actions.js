// [L4] 학생 추가·삭제 · 반/번호 직접 편집 · 명렬표 정렬 및 엑셀 명렬표 붙여넣기 모달·적용 액션
import { MAX_COLS, MAX_ROWS, MAX_STUDENT_NUM, MAX_STUDENTS } from '../core/constants.js';
import {
  compareStudentsByNumber,
  escapeHtml,
  formatStudentNumLabel,
  parseInlineStudentNumInput,
  sanitizeClassLabel
} from '../core/utils.js';
import { parseExcelRosterWithDiagnostics } from '../domain/excel-parser.js';
import { findFreeCoordinate } from '../domain/grid.js';
import { pushUndoSnapshot } from '../state/history-store.js';
import { AppStore } from '../state/store.js';
import { isRouletteBlockingEdit } from '../ui/guards.js';
import { checkSecretRoomLayoutMismatch } from '../ui/secret-indicators.js';
import { showToast } from '../ui/toast.js';
import { stopSequentialReveal } from './reveal-controller.js';
import { initRouletteSession } from './roulette-controller.js';

export function deleteStudentById(student) {
  const state = AppStore.getState();
  if (!student || isRouletteBlockingEdit()) return;
  pushUndoSnapshot(`학생 삭제 (${student.name})`, {
    rosterBackup: {
      students: JSON.parse(JSON.stringify(state.students)),
      pos: JSON.parse(JSON.stringify(state.pos)),
      secretPos: state.secretPos ? JSON.parse(JSON.stringify(state.secretPos)) : null,
      lockedIds: [...state.lockedIds],
      secretLockedIds: [...state.secretLockedIds],
      hiddenSeatIds: [...state.hiddenSeatIds],
      pendingSecretNotices: [...(state.pendingSecretNotices || [])],
      hasDeleteGapNotice: Boolean(state.hasDeleteGapNotice),
      rules: JSON.parse(JSON.stringify(state.rules))
    }
  });
  state.students = state.students.filter(s => s.id !== student.id);
  delete state.pos[student.id];

  // 일반 화면에서 학생 삭제 시 비밀의 방에서는 다른 학생(고정석 포함)을 강제 연쇄 이동시키지 않고 해당 자리만 빈칸(블랭크)으로 남긴다.
  if (state.secretPos) {
    delete state.secretPos[student.id];
  }
  state.hasDeleteGapNotice = state.students.length > 0;

  state.lockedIds = state.lockedIds.filter(id => String(id) !== String(student.id));
  state.secretLockedIds = state.secretLockedIds.filter(id => String(id) !== String(student.id));
  state.hiddenSeatIds = state.hiddenSeatIds.filter(id => String(id) !== String(student.id));
  state.rules.separatedPairs = (state.rules.separatedPairs || []).filter(
    pair => String(pair[0]) !== String(student.id) && String(pair[1]) !== String(student.id)
  );
  state.rules.togetherPairs = (state.rules.togetherPairs || []).filter(
    pair => String(pair[0]) !== String(student.id) && String(pair[1]) !== String(student.id)
  );
  state.rules.frontRowIds = (state.rules.frontRowIds || []).filter(
    id => String(id) !== String(student.id)
  );
  state.rouletteSessionToken = (state.rouletteSessionToken || 0) + 1;
  state.rouletteSpinning = false;
  state.rouletteActiveSession = false;
  if (String(state.selectedStudentId) === String(student.id)) state.selectedStudentId = null;
  if (state.rouletteOpen) initRouletteSession(false);
  AppStore.commitChange({ roster: true, classroom: true, animate: false, print: true, rules: true, dirty: true, save: true });
  if (state.inSecretRoom) {
    checkSecretRoomLayoutMismatch(false);
    showToast(`${student.name} 학생이 명렬표에서 삭제되었습니다.`, 'secret');
  } else {
    showToast(`${student.name} 학생이 명렬표에서 삭제되었습니다.`, 'info');
  }
}

export function updateExcelLivePreview() {
  const state = AppStore.getState();
  const excelTextarea = document.getElementById('excelPasteTextarea');
  const excelPreviewCount = document.getElementById('excelParsePreviewCount');
  const excelSamplePreview = document.getElementById('excelParseSamplePreview');
  if (!excelTextarea || !excelPreviewCount) return;
  const useGender = state.rules.useGenderDistinction !== false;
  const { students: parsed, warnings } = parseExcelRosterWithDiagnostics(excelTextarea.value, useGender);
  const warnBox = document.getElementById('excelParseWarningsBox');
  const warnList = document.getElementById('excelParseWarningsList');

  if (parsed.length === 0) {
    excelPreviewCount.textContent = '0명 대기 중';
    if (excelSamplePreview) {
      excelSamplePreview.textContent = '';
      excelSamplePreview.classList.add('hidden');
    }
  } else {
    const boys = parsed.filter(st => st.gender === '남').length;
    const girls = parsed.length - boys;
    const capNote = parsed.length > MAX_STUDENTS ? ` — 최대 ${MAX_STUDENTS}명 상한 적용` : '';
    excelPreviewCount.textContent = (useGender
      ? `총 ${parsed.length}명 인식됨 (남 ${boys}명 · 여 ${girls}명)`
      : `총 ${parsed.length}명 인식됨`) + capNote;
    if (excelSamplePreview) {
      const classSet = [];
      parsed.forEach((st) => {
        const cl = sanitizeClassLabel(st.classLabel);
        if (cl && !classSet.includes(cl)) classSet.push(cl);
      });
      const sampleNames = parsed.slice(0, 3).map(st => `${formatStudentNumLabel(st)} ${st.name}`).join(', ');
      const suffix = parsed.length > 3 ? ' 등' : '';
      const classPrefix = classSet.length > 0
        ? `감지된 학반(${classSet.length}개: ${classSet.slice(0, 5).join('·')}${classSet.length > 5 ? '…' : ''}) · `
        : '';
      excelSamplePreview.textContent = `${classPrefix}미리보기: ${sampleNames}${suffix}`;
      excelSamplePreview.classList.remove('hidden');
    }
  }

  if (warnBox && warnList) {
    const allWarnings = [...warnings];
    if (parsed.length > MAX_STUDENTS) {
      allWarnings.unshift(`인식된 인원(${parsed.length}명)이 최대 한도(${MAX_STUDENTS}명)를 초과하여 앞 ${MAX_STUDENTS}명만 등록됩니다.`);
    }
    if (allWarnings.length > 0) {
      warnBox.classList.remove('hidden');
      const visibleWarnings = allWarnings.slice(0, 20);
      let itemsHtml = visibleWarnings.map(w => `<li>${escapeHtml(w)}</li>`).join('');
      if (allWarnings.length > 20) {
        itemsHtml += `<li class="font-bold">...외 ${allWarnings.length - 20}건의 추가 확인 안내가 있습니다.</li>`;
      }
      warnList.innerHTML = itemsHtml;
    } else {
      warnBox.classList.add('hidden');
      warnList.innerHTML = '';
    }
  }
}

export function addNewStudent() {
  const state = AppStore.getState();
  if (isRouletteBlockingEdit()) return;
  if (state.students.length >= MAX_STUDENTS) {
    showToast(`학생은 최대 ${MAX_STUDENTS}명까지 등록할 수 있습니다.`, 'warn');
    return;
  }
  const lastStudent = state.students.length > 0 ? state.students[state.students.length - 1] : null;
  const inheritedClassLabel = sanitizeClassLabel(lastStudent && lastStudent.classLabel);
  const numScope = inheritedClassLabel
    ? state.students.filter(s => sanitizeClassLabel(s.classLabel) === inheritedClassLabel)
    : state.students;
  const maxNum = numScope.reduce((acc, s) => Math.max(acc, Number(s.num) || 0), 0);
  let nextNum = maxNum + 1;
  if (nextNum > MAX_STUDENT_NUM) {
    const usedNums = new Set(numScope.map(s => Number(s.num) || 0));
    nextNum = 1;
    while (usedNums.has(nextNum) && nextNum < MAX_STUDENT_NUM) nextNum++;
  }
  const defaultCols = Number(state.rules && state.rules.defaultCols) || 6;
  const freeCoord = findFreeCoordinate(state.pos, null, defaultCols);
  const newStudent = {
    id: (() => { let nid = 's_' + Date.now(); let k = 0; while (state.students.some(x => x.id === nid)) nid = 's_' + Date.now() + '_' + (++k); return nid; })(),
    num: nextNum,
    name: `새학생${nextNum}`,
    gender: '여'
  };
  if (inheritedClassLabel) {
    newStudent.classLabel = inheritedClassLabel;
  }
  pushUndoSnapshot(`학생 추가 (${newStudent.name})`, {
    rosterBackup: {
      students: JSON.parse(JSON.stringify(state.students)),
      pos: JSON.parse(JSON.stringify(state.pos)),
      secretPos: state.secretPos ? JSON.parse(JSON.stringify(state.secretPos)) : null,
      lockedIds: [...state.lockedIds],
      secretLockedIds: [...state.secretLockedIds],
      hiddenSeatIds: [...state.hiddenSeatIds],
      pendingSecretNotices: [...(state.pendingSecretNotices || [])],
      hasDeleteGapNotice: Boolean(state.hasDeleteGapNotice),
      rules: JSON.parse(JSON.stringify(state.rules))
    }
  });
  state.students.push(newStudent);
  state.pos[newStudent.id] = freeCoord;
  if (state.secretPos) {
    state.secretPos[newStudent.id] = findFreeCoordinate(state.secretPos, null, defaultCols);
  }
  state.selectedStudentId = null;
  state.rouletteSessionToken = (state.rouletteSessionToken || 0) + 1;
  state.rouletteSpinning = false;
  state.rouletteActiveSession = false;
  if (state.rouletteOpen) initRouletteSession(false);
  AppStore.commitChange({ roster: true, classroom: true, animate: true, print: true, rules: true, dirty: true, save: true });
  const rosterContainer = document.getElementById('rosterListContainer');
  if (rosterContainer) rosterContainer.scrollTop = rosterContainer.scrollHeight;
  showToast(`${newStudent.name} 학생이 추가되었습니다.`, 'success');
}

export function openExcelPasteModal() {
  const excelModal = document.getElementById('excelPasteModal');
  const excelTextarea = document.getElementById('excelPasteTextarea');
  if (!excelModal || !excelTextarea) return;
  excelTextarea.value = '';
  updateExcelLivePreview();
  excelModal.classList.remove('hidden');
  excelModal.classList.add('flex');
  setTimeout(() => excelTextarea.focus(), 50);
}

export function closeExcelPasteModal() {
  const excelModal = document.getElementById('excelPasteModal');
  if (!excelModal) return;
  excelModal.classList.add('hidden');
  excelModal.classList.remove('flex');
}

export function applyParsedExcelRoster(skipConfirm = false) {
  const state = AppStore.getState();
  if (isRouletteBlockingEdit()) return;
  const excelTextarea = document.getElementById('excelPasteTextarea');
  const useGender = state.rules.useGenderDistinction !== false;
  const { students: parsed, warnings } = parseExcelRosterWithDiagnostics(excelTextarea ? excelTextarea.value : '', useGender);
  if (parsed.length === 0) {
    showToast('붙여넣은 내용에서 유효한 학생 이름을 찾을 수 없습니다. 입력 형식을 확인해 주세요.', 'warn');
    return;
  }
  if (!skipConfirm && !AppStore.isRunningSelfDiagnostics() && state.students.length > 0) {
    const confirmModal = document.getElementById('excelOverwriteConfirmModal');
    const confirmDesc = document.getElementById('excelOverwriteConfirmDesc');
    if (confirmModal) {
      const targetCount = Math.min(parsed.length, MAX_STUDENTS);
      if (confirmDesc) {
        confirmDesc.textContent = `기존 명단(${state.students.length}명), 좌석 잠금 및 배치 조건이 초기화되고 새 명렬표(${targetCount}명)로 교체됩니다. 적용 후에도 [되돌리기]로 복원할 수 있습니다. 계속 적용하시겠습니까?`;
      }
      confirmModal.classList.remove('hidden');
      confirmModal.classList.add('flex');
      return;
    }
  }
  let overflowCount = 0;
  if (parsed.length > MAX_STUDENTS) {
    overflowCount = parsed.length - MAX_STUDENTS;
    parsed.length = MAX_STUDENTS;
  }
  stopSequentialReveal();
  // 비밀의 방에서 엑셀 일괄 적용 시 이전 비밀방 스냅샷만 먼저 정리하고 새 엑셀 스냅샷을 유지한다(#2).
  if (state.inSecretRoom && state.students.length > 0) {
    state.undoStackSecret = [];
  }
  if (state.students.length > 0) {
    pushUndoSnapshot('엑셀 명렬표 일괄 적용', {
      locks: {
        lockedIds: [...state.lockedIds],
        secretLockedIds: [...state.secretLockedIds]
      },
      rosterBackup: {
        students: JSON.parse(JSON.stringify(state.students)),
        pos: JSON.parse(JSON.stringify(state.pos)),
        secretPos: state.secretPos ? JSON.parse(JSON.stringify(state.secretPos)) : null,
        lockedIds: [...state.lockedIds],
        secretLockedIds: [...state.secretLockedIds],
        hiddenSeatIds: [...state.hiddenSeatIds],
        pendingSecretNotices: [...(state.pendingSecretNotices || [])],
        hasDeleteGapNotice: Boolean(state.hasDeleteGapNotice),
        rules: JSON.parse(JSON.stringify(state.rules))
      }
    });
  }
  state.students = parsed;
  state.lockedIds = [];
  state.secretLockedIds = [];
  state.hiddenSeatIds = [];
  state.rules.frontRowIds = [];
  state.rules.separatedPairs = [];
  state.rules.togetherPairs = [];

  const targetCols = Math.min(8, Math.max(4, Number(state.rules.defaultCols) || 6));
  const newPos = {};
  parsed.forEach((st, idx) => {
    const col = (idx % targetCols) + 1;
    const row = Math.floor(idx / targetCols) + 1;
    newPos[st.id] = [Math.min(MAX_COLS - 1, col), Math.min(MAX_ROWS - 1, row)];
  });
  state.pos = newPos;
  if (state.inSecretRoom) {
    state.secretPos = JSON.parse(JSON.stringify(newPos));
  } else {
    state.secretPos = null;
    state.undoStackSecret = [];
  }
  state.pendingSecretNotices = [];
  state.hasDeleteGapNotice = false;
  state.selectedStudentId = null;
  state.rosterNumEditMode = false;
  state.rouletteSessionToken = (state.rouletteSessionToken || 0) + 1;
  state.rouletteSpinning = false;
  state.rouletteActiveSession = false;

  if (state.rouletteOpen) initRouletteSession(false);
  AppStore.commitChange({ roster: true, classroom: true, animate: true, print: true, rules: true, dirty: true, save: true });
  closeExcelPasteModal();
  const overflowSuffix = overflowCount > 0 ? ` (최대 ${MAX_STUDENTS}명 제한으로 초과 ${overflowCount}명 제외)` : '';
  if (warnings.length > 0 || overflowCount > 0) {
    const warnDetail = warnings.length > 0 ? ` (${warnings.length}건 기본값 보정)` : '';
    showToast(`총 ${parsed.length}명이 배정되었습니다${warnDetail}${overflowSuffix}.`, 'warn');
  } else {
    showToast(`엑셀 명렬표에서 총 ${parsed.length}명이 등록되어 자리에 자동 배정되었습니다!`, 'success');
  }
}

// 좌측 명렬표 반·번호 직접 편집 모드를 켜거나 끈다.
export function toggleRosterNumEditMode(forceEnabled) {
  const state = AppStore.getState();
  const next = typeof forceEnabled === 'boolean' ? forceEnabled : !state.rosterNumEditMode;
  if (next && isRouletteBlockingEdit()) return false;
  if (Boolean(state.rosterNumEditMode) === next) return next;

  state.rosterNumEditMode = next;
  if (next) {
    state.selectedStudentId = null;
  }
  AppStore.syncViews({ roster: true, classroom: true, animate: false, print: false, rules: false });
  if (next) {
    const firstInput = document.querySelector('#rosterListContainer [data-roster-num-input]');
    if (firstInput && typeof firstInput.focus === 'function') {
      firstInput.focus();
      firstInput.select();
    }
  }
  return next;
}

// 명렬표 번호 입력칸의 단일 문자열('3', '1-3', '1반 3', '3-1-15', '30103')을 해석해 학생 반·번호를 즉시 갱신한다.
export function updateStudentNumInline(student, rawText) {
  if (!student) return { ok: false, changed: false };
  const parsed = parseInlineStudentNumInput(rawText, MAX_STUDENT_NUM);
  if (!parsed.ok) {
    showToast('번호 형식을 확인해 주세요. (예: 3, 1-3, 1반 3, 3-1-15, 30103)', 'warn');
    return { ok: false, changed: false };
  }
  const prevNum = Number(student.num) || 0;
  const prevLabel = sanitizeClassLabel(student.classLabel);
  if (prevNum === parsed.num && prevLabel === parsed.classLabel) {
    return { ok: true, changed: false };
  }
  student.num = parsed.num;
  if (parsed.classLabel) {
    student.classLabel = parsed.classLabel;
  } else {
    delete student.classLabel;
  }
  // 포커스 연속 이동(Enter/Tab)을 유지하기 위해 roster 재렌더 없이 교실·인쇄·조건·룰렛만 동기화한다.
  AppStore.commitChange({ roster: false, classroom: true, animate: false, print: true, rules: true, roulette: true, dirty: true, save: true });
  return { ok: true, changed: true };
}

// 좌측 명렬표 행 순서를 학반 자연정렬 → 번호 오름차순으로 정리한다 (Undo 백업 포함).
export function sortRosterListByNumber() {
  const state = AppStore.getState();
  if (isRouletteBlockingEdit()) return false;
  if (!Array.isArray(state.students) || state.students.length <= 1) {
    showToast('정리할 학생이 2명 이상 필요합니다.', 'info');
    return false;
  }
  const sorted = [...state.students].sort(compareStudentsByNumber);
  const isAlreadySorted = sorted.every((st, idx) => String(st.id) === String(state.students[idx].id));
  if (isAlreadySorted) {
    showToast('이미 반·번호 순서대로 정렬되어 있습니다.', 'info');
    return false;
  }
  pushUndoSnapshot('명렬표 반·번호순 정리', {
    rosterBackup: {
      students: JSON.parse(JSON.stringify(state.students)),
      pos: JSON.parse(JSON.stringify(state.pos)),
      secretPos: state.secretPos ? JSON.parse(JSON.stringify(state.secretPos)) : null,
      lockedIds: [...state.lockedIds],
      secretLockedIds: [...state.secretLockedIds],
      hiddenSeatIds: [...state.hiddenSeatIds],
      pendingSecretNotices: [...(state.pendingSecretNotices || [])],
      hasDeleteGapNotice: Boolean(state.hasDeleteGapNotice),
      rules: JSON.parse(JSON.stringify(state.rules))
    }
  });
  state.students = sorted;
  AppStore.commitChange({ roster: true, classroom: false, animate: false, print: true, rules: true, roulette: true, dirty: true, save: true });
  showToast('명렬표를 반·번호 순서대로 정리했습니다.', 'success');
  return true;
}
