// ES Module 진입점 (Webpack IIFE 단일 HTML 번들링 대상)
import { initApp } from './app/bootstrap.js';

if (document.readyState === 'loading') {
  window.addEventListener('DOMContentLoaded', initApp);
} else {
  initApp();
}
