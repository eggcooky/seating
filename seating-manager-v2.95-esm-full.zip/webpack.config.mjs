import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));

export default {
  mode: 'production',
  entry: path.join(ROOT, 'src/js/main.js'),
  output: {
    path: path.join(ROOT, 'build'),
    filename: 'bundle.js',
    iife: true,
  },
  devtool: false,
  optimization: {
    minimize: false,
  },
  performance: {
    hints: false,
  },
};
