#!/usr/bin/env node
/**
 * 무의존 Node.js ES 모듈 정적 의존성 · 순환참조(Tarjan SCC) · 계층 경계 검사기
 *
 * 사용법:
 *   node scripts/check-cycles.mjs
 *   node scripts/check-cycles.mjs --strict
 *   node scripts/check-cycles.mjs --max-scc=1 --max-2cycles=0 --enforce-layers
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SRC_JS = path.join(ROOT, 'src/js');

const LAYER_ORDER = new Map([
  ['core', 0],
  ['domain', 1],
  ['state', 2],
  ['infra', 3],
  ['ui', 3],
  ['views', 4],
  ['features', 4],
  ['app', 5],
  ['diagnostics', 5]
]);

function walkJs(dir) {
  let out = [];
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, ent.name);
    if (ent.isDirectory()) out = out.concat(walkJs(full));
    else if (ent.name.endsWith('.js')) out.push(full);
  }
  return out.sort();
}

function getLayer(relPath) {
  if (relPath === 'main.js') return 6;
  const top = relPath.split('/')[0];
  return LAYER_ORDER.has(top) ? LAYER_ORDER.get(top) : null;
}

function stripComments(code) {
  return code
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/(^|[^:\\])\/\/.*$/gm, '$1');
}

function extractExports(src) {
  const names = new Set();
  const clean = stripComments(src);
  for (const m of clean.matchAll(/^\s*export\s+(?:async\s+function|function|const|let|var|class)\s+([A-Za-z0-9_$]+)/gm)) {
    names.add(m[1]);
  }
  for (const m of clean.matchAll(/^\s*export\s*\{([\s\S]*?)\}(?:\s*from\s*['"][^'"]+['"])?/gm)) {
    for (const part of m[1].split(',')) {
      const t = part.trim();
      if (!t) continue;
      const asMatch = t.match(/\bas\s+([A-Za-z0-9_$]+)$/);
      names.add(asMatch ? asMatch[1] : t);
    }
  }
  return names;
}

function extractImports(filePath, src) {
  const deps = new Map();
  const clean = stripComments(src);
  const re = /(?:import|export)\s+(?:(?:\{([\s\S]*?)\})|(\*\s+as\s+[A-Za-z0-9_$]+)|([A-Za-z0-9_$]+))\s+from\s+['"]([^'"]+)['"]/g;
  for (const m of clean.matchAll(re)) {
    const spec = m[4];
    if (!spec.startsWith('.')) continue;
    const resolvedFull = path.resolve(path.dirname(filePath), spec);
    const resolvedRel = path.relative(SRC_JS, resolvedFull).replaceAll('\\', '/');
    const rawSyms = m[1] || m[2] || m[3] || '';
    const syms = rawSyms
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean)
      .map((s) => {
        const asMatch = s.match(/^([A-Za-z0-9_$]+)\s+as\s+[A-Za-z0-9_$]+$/);
        return asMatch ? asMatch[1] : s;
      });
    if (!deps.has(resolvedRel)) deps.set(resolvedRel, []);
    deps.get(resolvedRel).push(...syms);
  }
  return deps;
}

function tarjanScc(graph) {
  let idx = 0;
  const stack = [];
  const onStack = new Set();
  const indices = new Map();
  const lowlink = new Map();
  const sccs = [];

  function strongconnect(v) {
    indices.set(v, idx);
    lowlink.set(v, idx);
    idx++;
    stack.push(v);
    onStack.add(v);

    for (const w of (graph.get(v) || new Map()).keys()) {
      if (!graph.has(w)) continue;
      if (!indices.has(w)) {
        strongconnect(w);
        lowlink.set(v, Math.min(lowlink.get(v), lowlink.get(w)));
      } else if (onStack.has(w)) {
        lowlink.set(v, Math.min(lowlink.get(v), indices.get(w)));
      }
    }

    if (lowlink.get(v) === indices.get(v)) {
      const comp = [];
      while (true) {
        const w = stack.pop();
        onStack.delete(w);
        comp.push(w);
        if (w === v) break;
      }
      sccs.push(comp.sort());
    }
  }

  for (const v of graph.keys()) {
    if (!indices.has(v)) strongconnect(v);
  }
  return sccs;
}

export function runCycleAndArchitectureCheck(options = {}) {
  const {
    maxScc = 1,
    maxTwoCycles = 0,
    enforceLayers = true,
    checkTopLevelStateCache = true
  } = options;

  const files = walkJs(SRC_JS);
  const graph = new Map();
  const exportsMap = new Map();
  const errors = [];

  for (const f of files) {
    const rel = path.relative(SRC_JS, f).replaceAll('\\', '/');
    const src = fs.readFileSync(f, 'utf8');
    exportsMap.set(rel, extractExports(src));
    graph.set(rel, extractImports(f, src));

    if (checkTopLevelStateCache) {
      const topStateCache = src.match(/^(?:const|let|var)\s+state\s*=\s*AppStore\.getState\(\)/m);
      if (topStateCache) {
        errors.push(`[STALE-STATE] ${rel}: 모듈 최상위에서 AppStore.getState() 캐싱 금지`);
      }
    }
  }

  // 1. 미존재 파일 / 미정의 심볼 import 검사
  let totalEdges = 0;
  for (const [a, deps] of graph) {
    for (const [b, syms] of deps) {
      totalEdges++;
      if (!exportsMap.has(b)) {
        errors.push(`[IMPORT] ${a} -> ${b}: 대상 모듈 파일이 존재하지 않음`);
        continue;
      }
      const targetExports = exportsMap.get(b);
      for (const sym of syms) {
        if (sym.startsWith('*')) continue;
        if (!targetExports.has(sym)) {
          errors.push(`[SYMBOL] ${a} -> ${b}: export 되지 않은 심볼 '${sym}' 참조`);
        }
      }
    }
  }

  // 2. Tarjan SCC 검사
  const sccs = tarjanScc(graph);
  const cyclicSccs = sccs.filter((c) => c.length > 1);
  const maxSccSize = sccs.reduce((acc, c) => Math.max(acc, c.length), 1);

  // 3. 직접 2-Cycle 검사
  const seenPairs = new Set();
  const twoCycles = [];
  for (const [a, depsA] of graph) {
    for (const b of depsA.keys()) {
      if (graph.has(b) && graph.get(b).has(a)) {
        const key = [a, b].sort().join(' <-> ');
        if (!seenPairs.has(key)) {
          seenPairs.add(key);
          twoCycles.push(key);
        }
      }
    }
  }

  // 4. 계층 방향 규칙 검사 (L_k -> L_0..L_k 허용, L_k -> L_>k 금지)
  const layerViolations = [];
  if (enforceLayers) {
    for (const [a, deps] of graph) {
      const la = getLayer(a);
      if (la === null) continue;
      for (const b of deps.keys()) {
        const lb = getLayer(b);
        if (lb === null) continue;
        if (lb > la) {
          layerViolations.push(`${a} (L${la}) -> ${b} (L${lb})`);
        } else if (a.startsWith('app/binders/') && b.startsWith('app/binders/')) {
          layerViolations.push(`${a} -> ${b} (바인더 간 수평 참조 금지)`);
        }
      }
    }
  }

  if (maxSccSize > maxScc) {
    errors.push(`[CYCLE-SCC] 최대 SCC 크기 ${maxSccSize} > 허용치 ${maxScc} (${cyclicSccs.map((c) => `[${c.join(', ')}]`).join('; ')})`);
  }
  if (twoCycles.length > maxTwoCycles) {
    errors.push(`[CYCLE-2] 직접 2-Cycle ${twoCycles.length}쌍 > 허용치 ${maxTwoCycles}쌍`);
  }
  for (const v of layerViolations) {
    errors.push(`[LAYER] 역방향 계층 의존 위반: ${v}`);
  }

  return {
    ok: errors.length === 0,
    fileCount: files.length,
    totalEdges,
    maxSccSize,
    cyclicSccs,
    twoCycles,
    layerViolations,
    errors
  };
}

if (path.resolve(process.argv[1] || '') === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  const strict = args.includes('--strict');
  const getNumArg = (prefix, fallback) => {
    const found = args.find((a) => a.startsWith(prefix));
    return found ? Number(found.slice(prefix.length)) : fallback;
  };
  const maxScc = strict ? 1 : getNumArg('--max-scc=', 1);
  const maxTwoCycles = strict ? 0 : getNumArg('--max-2cycles=', 0);
  const enforceLayers = strict || !args.includes('--no-layers');

  const res = runCycleAndArchitectureCheck({ maxScc, maxTwoCycles, enforceLayers });
  if (!res.ok) {
    console.error('[check-cycles] ❌ ES 모듈 아키텍처 검증 실패:');
    for (const e of res.errors) console.error('  -', e);
    process.exit(1);
  }
  console.log(
    `[check-cycles] ✅ PASS (${res.fileCount}개 모듈 | ${res.totalEdges}개 간선 | 최대 SCC=${res.maxSccSize} | 2-Cycle=${res.twoCycles.length}쌍 | 계층위반=${res.layerViolations.length}건)`
  );
}
