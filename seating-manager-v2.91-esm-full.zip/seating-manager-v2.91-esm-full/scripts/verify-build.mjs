#!/usr/bin/env node
/**
 * 빌드 타임 Node.js 정적 무결성 검증 스크립트 (v2.69+)
 * 1) DOM ID 참조 무결성 + 중복 ID + label/aria 참조 검사
 * 2) 오프라인 CSS 클래스 감사 (body.html + src/js/*.js 정적/삼항 분기/classList -> style.css 셀렉터)
 * 3) 버전 동기화 지점 일치 검사
 * 4) 스텔스 금지어(version.json · src/shell.html) 0건 검사
 * 5) 배포본 HTML SHA-256 · __app_pkg__ 디코딩 · 내장 APP_VERSION 일치 검사
 */

import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { runCycleAndArchitectureCheck } from './check-cycles.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const CONSTANTS_CANDIDATES = ['src/js/core/constants.js', 'src/js/00-constants.js'];
const CYCLE_POLICY = { maxScc: 1, maxTwoCycles: 0, enforceLayers: true };
const XOR_KEY = 'ClassroomSeatingManager::simple-enc';
const BANNED_STEALTH_WORDS = ['비밀의 방', '거리두기', '붙이기'];
// 순수 JS 이벤트 바인딩·상태 마커 클래스 (스타일시트 정의 불필요)
const JS_HOOK_CLASS_WHITELIST = new Set([
  'default-cols-btn',
  'pair-rule-btn',
  'print-orient-btn',
  'print-roster-btn',
  'print-shade-btn',
  'seat-card',
  'desk-card',
  'roster-row',
  'group'
]);

function walkJs(dir) {
  let out = [];
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, ent.name);
    if (ent.isDirectory()) out = out.concat(walkJs(full));
    else if (ent.name.endsWith('.js')) out.push(full);
  }
  return out;
}

function xorBuffer(buf, keyBuf) {
  const out = Buffer.allocUnsafe(buf.length);
  const klen = keyBuf.length;
  for (let i = 0; i < buf.length; i++) {
    out[i] = buf[i] ^ keyBuf[i % klen];
  }
  return out;
}

function extractCssDefinedClasses(cssText) {
  const cssDefined = new Set();
  const noComments = cssText.replace(/\/\*[\s\S]*?\*\//g, '');
  const selectorOnly = noComments.replace(/\{[^{}]*\}/g, ' ');
  for (const m of selectorOnly.matchAll(/\.((?:\\.|[A-Za-z_-])(?:\\.|[A-Za-z0-9_-])*)/g)) {
    cssDefined.add(m[1].replace(/\\(.)/g, '$1'));
  }
  return cssDefined;
}

function pushValidTokens(str, outArr) {
  for (const tk of str.trim().split(/\s+/)) {
    if (!tk || tk.includes('${') || tk.includes('}') || !/^[A-Za-z0-9_:\-\/\[\].!%]+$/.test(tk)) continue;
    outArr.push(tk);
  }
}

function extractJsStaticClassTokens(jsText) {
  const tokens = [];
  const patterns = [
    /\.className\s*=\s*'([^']+)'/g,
    /\.className\s*=\s*"([^"]+)"/g,
    /\.className\s*=\s*`([^`]+)`/g,
    /\bclass="([^"]+)"/g
  ];
  for (const re of patterns) {
    for (const m of jsText.matchAll(re)) {
      const raw = m[1];
      // 보간 외부 정적 클래스
      pushValidTokens(raw.replace(/\$\{[^}]*\}/g, ' '), tokens);
      // 보간(${...}) 내부 삼항 분기 등 문자열 리터럴 클래스
      for (const expr of raw.matchAll(/\$\{([^}]*)\}/g)) {
        for (const lit of expr[1].matchAll(/'([^']+)'|"([^"]+)"/g)) {
          pushValidTokens(lit[1] || lit[2], tokens);
        }
      }
    }
  }
  // classList.add / remove / toggle / contains 리터럴 인자
  for (const m of jsText.matchAll(/classList\.(?:add|remove|toggle|contains)\(([^)]+)\)/g)) {
    for (const lit of m[1].matchAll(/'([^']+)'|"([^"]+)"/g)) {
      pushValidTokens(lit[1] || lit[2], tokens);
    }
  }
  return tokens;
}

export function runStaticBuildVerification() {
  const errors = [];
  const bodyHtml = fs.readFileSync(path.join(ROOT, 'src/body.html'), 'utf8');
  const styleCss = fs.readFileSync(path.join(ROOT, 'src/style.css'), 'utf8');
  const shellHtml = fs.readFileSync(path.join(ROOT, 'src/shell.html'), 'utf8');
  const constantsRel = CONSTANTS_CANDIDATES.find((p) => fs.existsSync(path.join(ROOT, p)));
  const constantsJs = constantsRel ? fs.readFileSync(path.join(ROOT, constantsRel), 'utf8') : '';
  const buildMjs = fs.readFileSync(path.join(ROOT, 'build.mjs'), 'utf8');
  const pkgJson = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  const readmeMd = fs.readFileSync(path.join(ROOT, 'README.md'), 'utf8');
  const jsFiles = walkJs(path.join(ROOT, 'src/js'));

  // 1. DOM ID 참조 무결성 + 중복 ID + label/aria 참조 검사
  const bodyIdCounts = new Map();
  const definedIds = new Set();
  for (const m of bodyHtml.matchAll(/\bid="([^"]+)"/g)) {
    definedIds.add(m[1]);
    bodyIdCounts.set(m[1], (bodyIdCounts.get(m[1]) || 0) + 1);
  }
  for (const [id, cnt] of bodyIdCounts.entries()) {
    if (cnt > 1) errors.push(`[DOM-ID] src/body.html 중복 ID 발견: #${id} (${cnt}회)`);
  }
  for (const m of bodyHtml.matchAll(/\b(?:for|aria-labelledby|aria-describedby)="([^"]+)"/g)) {
    for (const refId of m[1].trim().split(/\s+/)) {
      if (!bodyIdCounts.has(refId)) errors.push(`[DOM-REF] src/body.html 깨진 참조: ${m[0]}`);
    }
  }
  for (const f of jsFiles) {
    const txt = fs.readFileSync(f, 'utf8');
    for (const m of txt.matchAll(/\.id\s*=\s*['"]([^'"]+)['"]/g)) definedIds.add(m[1]);
    for (const m of txt.matchAll(/id=\\"([^\\"]+)\\"|id="([^"]+)"/g)) definedIds.add(m[1] || m[2]);
  }
  let checkedIdRefs = 0;
  for (const f of jsFiles) {
    const txt = fs.readFileSync(f, 'utf8');
    const rel = path.relative(ROOT, f).replaceAll('\\', '/');
    for (const m of txt.matchAll(/getElementById\(\s*['"]([^'"]+)['"]\s*\)/g)) {
      checkedIdRefs++;
      if (!definedIds.has(m[1])) errors.push(`[DOM-ID] ${rel}: 미존재 ID 참조 getElementById('${m[1]}')`);
    }
    for (const m of txt.matchAll(/(?:querySelector|querySelectorAll|closest)\(\s*['"]#([A-Za-z0-9_-]+)/g)) {
      checkedIdRefs++;
      if (!definedIds.has(m[1])) errors.push(`[DOM-ID] ${rel}: 미존재 ID 선택자 #${m[1]}`);
    }
  }

  // 2. 오프라인 CSS 클래스 감사 (body.html + src/js/*.js 정적/삼항/classList)
  const cssDefined = extractCssDefinedClasses(styleCss);
  const missingHtmlCss = new Set();
  for (const m of bodyHtml.matchAll(/\bclass="([^"]+)"/g)) {
    for (const cls of m[1].trim().split(/\s+/)) {
      if (!cls || JS_HOOK_CLASS_WHITELIST.has(cls)) continue;
      if (!cssDefined.has(cls)) missingHtmlCss.add(cls);
    }
  }
  if (missingHtmlCss.size > 0) {
    errors.push(`[CSS/HTML] src/style.css 미정의 클래스: ${[...missingHtmlCss].sort().join(', ')}`);
  }

  const missingJsCss = new Set();
  for (const f of jsFiles) {
    const normPath = f.replaceAll('\\', '/');
    const isDiagNonIndex = normPath.includes('/diagnostics/') && !normPath.endsWith('/diagnostics/index.js');
    if (isDiagNonIndex) continue;
    const txt = fs.readFileSync(f, 'utf8');
    for (const cls of extractJsStaticClassTokens(txt)) {
      if (JS_HOOK_CLASS_WHITELIST.has(cls)) continue;
      if (!cssDefined.has(cls)) missingJsCss.add(cls);
    }
  }
  if (missingJsCss.size > 0) {
    errors.push(`[CSS/JS] src/style.css 미정의 JS 동적 클래스: ${[...missingJsCss].sort().join(', ')}`);
  }

  // 2-2. 오프라인 CSS 핵심 캐스케이드(선언 순서) 역전 정적 검사 (v2.88+)
  const idxMediaMd = styleCss.indexOf('@media (min-width: 768px)');
  const idxGridCols1 = styleCss.lastIndexOf('.grid-cols-1 {');
  if (idxMediaMd !== -1 && idxGridCols1 !== -1 && idxGridCols1 > idxMediaMd) {
    errors.push('[CSS/CASCADE] .grid-cols-1이 @media (min-width: 768px) 뒤에 선언되어 .md:grid-cols-2를 무력화합니다.');
  }
  const idxShadowMd = styleCss.indexOf('.shadow-md {');
  const idxShadowIndigo = styleCss.indexOf('.shadow-indigo-500\\/20');
  if (idxShadowMd !== -1 && idxShadowIndigo !== -1 && idxShadowIndigo < idxShadowMd) {
    errors.push('[CSS/CASCADE] .shadow-indigo-500/20이 .shadow-md 앞에 선언되어 인디고 그림자가 덮어씌워집니다.');
  }
  const idxShadowLg = styleCss.indexOf('.shadow-lg {');
  const idxRing2 = styleCss.indexOf('.ring-2 {');
  if (idxShadowLg !== -1 && idxRing2 !== -1 && idxRing2 < idxShadowLg) {
    errors.push('[CSS/CASCADE] .ring-2가 .shadow-lg 앞에 선언되어 링 테두리가 그림자에 덮어씌워집니다.');
  }
  const resetBlock = (styleCss.match(/\*,\s*::before,\s*::after\s*\{[^}]*\}/) || [''])[0];
  if (!resetBlock.includes('--tw-ring-shadow:') || !resetBlock.includes('--tw-shadow:')) {
    errors.push('[CSS/RESET] *, ::before, ::after 리셋에 --tw-ring-shadow / --tw-shadow 초기화가 누락되어 자식 상속 누수가 발생합니다.');
  }

  // 2-3. 다중학급 슬롯 수(MULTI_CLASS_SLOT_COUNT)와 body.html <select> option 개수 일치 검사 (v2.89+)
  const slotCountConst = Number((constantsJs.match(/MULTI_CLASS_SLOT_COUNT\s*=\s*(\d+)/) || [])[1]);
  const slotSelectBlock = (bodyHtml.match(/<select[^>]*id="multiClassSlotSelect"[^>]*>[\s\S]*?<\/select>/) || [''])[0];
  const slotOptionCount = (slotSelectBlock.match(/<option\b/g) || []).length;
  if (Number.isFinite(slotCountConst) && slotCountConst > 0 && slotOptionCount !== slotCountConst) {
    errors.push(`[MULTI_CLASS] #multiClassSlotSelect option 수(${slotOptionCount})와 MULTI_CLASS_SLOT_COUNT(${slotCountConst}) 불일치`);
  }

  // 3. 버전 동기화 검사
  const verConst = (constantsJs.match(/APP_VERSION\s*=\s*'([^']+)'/) || [])[1];
  const verBuild = (buildMjs.match(/APP_VERSION\s*=\s*'([^']+)'/) || [])[1];
  const verPkg = String(pkgJson.version || '').replace(/\.0$/, '');
  if (!verConst || verConst !== verBuild || verConst !== verPkg) {
    errors.push(`[VERSION] 불일치: 00-constants(${verConst}) / build.mjs(${verBuild}) / package.json(${verPkg})`);
  }
  const escapedVer = (verConst || '').replaceAll('.', '\\.');
  const bodyVerCount = (bodyHtml.match(new RegExp(`v${escapedVer}`, 'g')) || []).length;
  if (bodyVerCount < 4) {
    errors.push(`[VERSION] src/body.html 내 v${verConst} 표기 부족 (${bodyVerCount}/4)`);
  }
  if (!readmeMd.includes(`v${verConst}`)) {
    errors.push(`[VERSION] README.md에 v${verConst} 미반영`);
  }

  // 4. 스텔스 금지어 및 XOR 키 일관성 검사
  for (const word of BANNED_STEALTH_WORDS) {
    if (shellHtml.includes(word)) errors.push(`[STEALTH] src/shell.html에 금지어 포함: ${word}`);
  }
  const constXor = (constantsJs.match(/OBFUSCATION_XOR_KEY\s*=\s*'([^']+)'/) || [])[1];
  const shellXor = (shellHtml.match(/TextEncoder\(\)\.encode\('([^']+)'\)/) || [])[1];
  const buildXor = (buildMjs.match(/XOR_KEY\s*=\s*'([^']+)'/) || [])[1];
  if (!constXor || constXor !== XOR_KEY || shellXor !== XOR_KEY || buildXor !== XOR_KEY) {
    errors.push(`[XOR-KEY] 난독화 키 불일치: 00-constants(${constXor}) / shell.html(${shellXor}) / build.mjs(${buildXor}) / verify-build(${XOR_KEY})`);
  }

  // 5. dist 산출물 검증
  const distVerPath = path.join(ROOT, 'dist/version.json');
  const distHtmlPath = path.join(ROOT, 'dist', `자리바꾸기(v${verConst}).html`);
  let distChecked = false;
  if (fs.existsSync(distVerPath) && fs.existsSync(distHtmlPath)) {
    distChecked = true;
    const distVerRaw = fs.readFileSync(distVerPath, 'utf8');
    const distVerObj = JSON.parse(distVerRaw);
    const distHtmlBytes = fs.readFileSync(distHtmlPath);
    const actualSha = crypto.createHash('sha256').update(distHtmlBytes).digest('hex');

    if (distVerObj.version !== verConst) {
      errors.push(`[DIST] version.json version(${distVerObj.version}) !== ${verConst}`);
    }
    if (distVerObj.sha256 !== actualSha) {
      errors.push(`[DIST] SHA-256 불일치: version.json(${distVerObj.sha256}) !== actual(${actualSha})`);
    }
    for (const word of BANNED_STEALTH_WORDS) {
      if (distVerRaw.includes(word)) errors.push(`[STEALTH] dist/version.json에 금지어 포함: ${word}`);
    }
    const htmlStr = distHtmlBytes.toString('utf8');
    const pkgMatch = htmlStr.match(/__app_pkg__\s*=\s*"([^"]+)"/) || htmlStr.match(/id="__app_pkg__"[^>]*>([^<]+)</);
    if (!pkgMatch) {
      errors.push('[DIST] 배포본 HTML에서 __app_pkg__ 페이로드를 찾을 수 없음');
    } else {
      const actualPkgSha = crypto.createHash('sha256').update(pkgMatch[1].trim(), 'utf8').digest('hex');
      if (distVerObj.pkgSha256 !== actualPkgSha) {
        errors.push(`[DIST] pkgSha256 불일치: version.json(${distVerObj.pkgSha256}) !== actual(${actualPkgSha})`);
      }
      const known = distVerObj.knownPkgHashes;
      if (!known || typeof known !== 'object' || Array.isArray(known)) {
        errors.push('[DIST] version.json에 knownPkgHashes 객체가 누락됨');
      } else {
        const keys = Object.keys(known);
        if (keys.length === 0 || keys.length > 10) {
          errors.push(`[DIST] knownPkgHashes 항목 수 범위 위반(${keys.length}, 허용 1~10)`);
        }
        if (known[verConst] !== actualPkgSha) {
          errors.push(`[DIST] knownPkgHashes[${verConst}] 불일치`);
        }
      }
      const decodedBuf = xorBuffer(Buffer.from(pkgMatch[1].trim(), 'base64'), Buffer.from(XOR_KEY, 'utf8'));
      const decodedObj = JSON.parse(decodedBuf.toString('utf8'));
      if (!decodedObj.style || !decodedObj.body || !decodedObj.script) {
        errors.push('[DIST] __app_pkg__ 디코딩 구조(style/body/script) 누락');
      } else {
        const updaterVerPattern = new RegExp(`APP_VERSION\\s*=\\s*['"]${escapedVer}['"]`);
        if (!updaterVerPattern.test(decodedObj.script)) {
          errors.push(`[DIST] __app_pkg__ 번들 script에 구버전 업데이터 호환 패턴(APP_VERSION = '${verConst}') 미포함`);
        }
        if (decodedObj.style !== styleCss) {
          errors.push('[DIST] __app_pkg__ style이 현재 src/style.css와 불일치(구버전 dist)');
        }
        if (decodedObj.body !== bodyHtml) {
          errors.push('[DIST] __app_pkg__ body가 현재 src/body.html과 불일치(구버전 dist)');
        }
        if (!decodedObj.script.includes('app/bootstrap.js')) {
          errors.push('[DIST] __app_pkg__ script가 6계층 모듈 번들(app/bootstrap.js)이 아님(구버전 dist)');
        }
      }
    }
  }

  // 6. ES 모듈 순환참조 · 심볼 정합성 · 계층 경계 검증
  const cycleRes = runCycleAndArchitectureCheck(CYCLE_POLICY);
  if (!cycleRes.ok) {
    errors.push(...cycleRes.errors);
  }

  // 7. README.md 모듈 수 문서-코드 일치 검증
  const readmePath = path.join(ROOT, 'README.md');
  if (fs.existsSync(readmePath)) {
    const readmeText = fs.readFileSync(readmePath, 'utf8');
    const modCountMatch = readmeText.match(/(\d+)\s*개\s*모듈/);
    if (modCountMatch && Number(modCountMatch[1]) !== cycleRes.fileCount) {
      errors.push(`[DOC] README.md 모듈 수(${modCountMatch[1]}개)와 실제 src/js 모듈 수(${cycleRes.fileCount}개) 불일치`);
    }
  }

  if (errors.length > 0) {
    console.error('[verify-build] ❌ 정적 검증 실패:');
    for (const e of errors) console.error('  -', e);
    process.exit(1);
  }
  const distStatus = distChecked ? 'dist SHA-256·__app_pkg__·버전 정상' : 'dist 미생성(소스 정적 검증만 수행)';
  console.log(`[verify-build] ✅ PASS (v${verConst} | DOM ID ${checkedIdRefs}건/${definedIds.size}정의·중복0 | CSS 셀렉터 ${cssDefined.size}종(HTML+JS·삼항·classList) | ${distStatus})`);
}

if (path.resolve(process.argv[1] || '') === fileURLToPath(import.meta.url)) {
  runStaticBuildVerification();
}
