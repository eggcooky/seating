// [L4] 첫 실행 안내 · 도움말 모달 및 SVG 컷아웃 스포트라이트 렌더러
import { markHelpGuideSeen } from '../infra/storage-io.js';
import { AppStore } from '../state/store.js';
import { toggleLeftSidebar } from './toolbar-ui.js';

const SVG_NS = 'http://www.w3.org/2000/svg';
const SPOTLIGHT_MIN_VIEWPORT_WIDTH = 960;
const HOLE_PAD = 5;
const CALLOUT_GAP = 10;

// 실제 DOM 기준 6개 핵심 메뉴 타깃 정의 (②와 ⑥은 같은 행이므로 방향 분리)
const SPOTLIGHT_TARGETS = [
  { num: 1, selector: '#openExcelPasteModalBtn', label: '엑셀 명단 붙여넣기', placement: 'bottom' },
  { num: 2, selector: '#openRulesModalBtn', label: '열·성별·짝·앞줄', placement: 'top' },
  { num: 3, selector: '#randomShuffleBtn', label: '자동 배정 · 룰렛', placement: 'top' },
  { num: 4, selector: '#classroomStage .seat-box-responsive, #classroomStage .seat-box-large', fallback: '#seatingPaperCard', label: '클릭 교환·이동·고정', placement: 'top' },
  { num: 5, selector: '#printA4Btn', label: '인쇄 · 이미지 · 표 복사', placement: 'bottom' },
  { num: 6, selector: '#multiClassToggleWrapper', label: '최대 7학급 전환', placement: 'right' }
];

let _isAutoFirstRunOpen = false;
let _lastTriggerEl = null;
let _resizeRafId = 0;
let _openRafId = 0;
let _sidebarSettleTimer = null;
let _temporarilyExpandedSidebar = false;
let _listenersAttached = false;
let _focusedStepNum = null;

function isRectVisibleInViewport(rect) {
  if (!rect || rect.width <= 0 || rect.height <= 0) return false;
  return rect.right > 4 && rect.left < window.innerWidth - 4 && rect.bottom > 4 && rect.top < window.innerHeight - 4;
}

function rectsOverlap(a, b, pad = 6) {
  return !(
    a.right + pad <= b.left ||
    a.left - pad >= b.right ||
    a.bottom + pad <= b.top ||
    a.top - pad >= b.bottom
  );
}

function resolveTargetElement(spec, modalRect) {
  const candidates = document.querySelectorAll(spec.selector);
  if (candidates.length === 1) {
    const r = candidates[0].getBoundingClientRect();
    if (isRectVisibleInViewport(r)) return candidates[0];
  } else if (candidates.length > 1) {
    // 4번 책상 등 다수 요소인 경우 모달 카드와 겹치지 않는 첫 가시 요소를 우선 선택
    let firstVisible = null;
    for (const el of candidates) {
      const r = el.getBoundingClientRect();
      if (!isRectVisibleInViewport(r)) continue;
      if (!firstVisible) firstVisible = el;
      if (!modalRect || !rectsOverlap(r, modalRect, 4)) return el;
    }
    if (firstVisible) return firstVisible;
  }
  if (spec.fallback) {
    const fb = document.querySelector(spec.fallback);
    if (fb && isRectVisibleInViewport(fb.getBoundingClientRect())) return fb;
  }
  return null;
}

function computeCalloutPosition(holeRect, width, height, placement) {
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  let left = holeRect.left;
  let top = holeRect.bottom + CALLOUT_GAP;
  let arrow = '↑';

  if (placement === 'top') {
    left = holeRect.left + (holeRect.width - width) / 2;
    top = holeRect.top - height - CALLOUT_GAP;
    arrow = '↓';
  } else if (placement === 'bottom') {
    left = holeRect.left + (holeRect.width - width) / 2;
    top = holeRect.bottom + CALLOUT_GAP;
    arrow = '↑';
  } else if (placement === 'right') {
    left = holeRect.right + CALLOUT_GAP;
    top = holeRect.top + (holeRect.height - height) / 2;
    arrow = '←';
  } else if (placement === 'left') {
    left = holeRect.left - width - CALLOUT_GAP;
    top = holeRect.top + (holeRect.height - height) / 2;
    arrow = '→';
  }

  left = Math.max(8, Math.min(vw - width - 8, left));
  top = Math.max(8, Math.min(vh - height - 8, top));
  return {
    left,
    top,
    right: left + width,
    bottom: top + height,
    arrow
  };
}

function getPlacementTryOrder(primary) {
  if (primary === 'top') return ['top', 'bottom', 'left', 'right'];
  if (primary === 'bottom') return ['bottom', 'top', 'left', 'right'];
  if (primary === 'right') return ['right', 'left', 'top', 'bottom'];
  return ['left', 'right', 'top', 'bottom'];
}

export function clearHelpSpotlights() {
  const holesEl = document.getElementById('helpSpotlightHoles');
  const calloutsEl = document.getElementById('helpSpotlightCallouts');
  if (holesEl) holesEl.textContent = '';
  if (calloutsEl) calloutsEl.textContent = '';
}

export function setFocusedHelpStep(stepNum) {
  _focusedStepNum = stepNum === null || stepNum === undefined ? null : Number(stepNum);
  const calloutsEl = document.getElementById('helpSpotlightCallouts');
  const stepListEl = document.getElementById('helpGuideStepList');

  if (stepListEl) {
    stepListEl.querySelectorAll('[data-help-step]').forEach((item) => {
      const n = Number(item.getAttribute('data-help-step'));
      item.classList.toggle('is-active', _focusedStepNum !== null && n === _focusedStepNum);
    });
  }
  if (calloutsEl) {
    calloutsEl.querySelectorAll('[data-spot-step]').forEach((el) => {
      const n = Number(el.getAttribute('data-spot-step'));
      const hasFocus = _focusedStepNum !== null;
      el.classList.toggle('is-focused', hasFocus && n === _focusedStepNum);
      el.classList.toggle('is-dimmed', hasFocus && n !== _focusedStepNum);
    });
  }
}

export function renderHelpSpotlights() {
  const modalEl = document.getElementById('helpGuideModal');
  const cardEl = document.getElementById('helpGuideModalCard');
  const holesEl = document.getElementById('helpSpotlightHoles');
  const calloutsEl = document.getElementById('helpSpotlightCallouts');
  const subtitleEl = document.getElementById('helpGuideSubtitle');

  if (!modalEl || modalEl.classList.contains('hidden') || !holesEl || !calloutsEl) return;
  clearHelpSpotlights();

  // 좁은 화면(960px 미만)에서는 스포트라이트 컷아웃·말풍선을 생략해 모달 가독성을 보호한다.
  if (window.innerWidth < SPOTLIGHT_MIN_VIEWPORT_WIDTH) {
    if (subtitleEl) subtitleEl.textContent = '설치 없이 브라우저에서 바로 쓰는 오프라인 자리 배치 도구';
    return;
  }

  const modalRect = cardEl ? cardEl.getBoundingClientRect() : null;
  const placedCalloutRects = [];
  let renderedCount = 0;

  for (const spec of SPOTLIGHT_TARGETS) {
    const targetEl = resolveTargetElement(spec, modalRect);
    if (!targetEl) continue;
    const rawRect = targetEl.getBoundingClientRect();
    // 모달 카드 아래에 완전히 가려진 요소는 컷아웃 제외
    if (modalRect && rectsOverlap(rawRect, modalRect, -4)) continue;

    const hLeft = Math.max(2, rawRect.left - HOLE_PAD);
    const hTop = Math.max(2, rawRect.top - HOLE_PAD);
    const hRight = Math.min(window.innerWidth - 2, rawRect.right + HOLE_PAD);
    const hBottom = Math.min(window.innerHeight - 2, rawRect.bottom + HOLE_PAD);
    const holeRect = {
      left: hLeft,
      top: hTop,
      right: hRight,
      bottom: hBottom,
      width: Math.max(0, hRight - hLeft),
      height: Math.max(0, hBottom - hTop)
    };

    // 1) SVG 마스크 컷아웃(검정 rect = 투명 구멍)
    const maskRect = document.createElementNS(SVG_NS, 'rect');
    maskRect.setAttribute('x', String(Math.round(holeRect.left)));
    maskRect.setAttribute('y', String(Math.round(holeRect.top)));
    maskRect.setAttribute('width', String(Math.round(holeRect.width)));
    maskRect.setAttribute('height', String(Math.round(holeRect.height)));
    maskRect.setAttribute('rx', '12');
    maskRect.setAttribute('fill', 'black');
    holesEl.appendChild(maskRect);

    // 2) 노란 강조 테두리 링
    const ringEl = document.createElement('div');
    ringEl.className = 'help-spot-ring';
    ringEl.setAttribute('data-spot-step', String(spec.num));
    ringEl.style.left = `${Math.round(holeRect.left)}px`;
    ringEl.style.top = `${Math.round(holeRect.top)}px`;
    ringEl.style.width = `${Math.round(holeRect.width)}px`;
    ringEl.style.height = `${Math.round(holeRect.height)}px`;
    calloutsEl.appendChild(ringEl);
    renderedCount++;

    // 3) 번호 화살표 말풍선 (실제 크기 측정 후 모달·타 말풍선 겹침 회피)
    const calloutEl = document.createElement('div');
    calloutEl.className = 'help-spot-callout';
    calloutEl.setAttribute('data-spot-step', String(spec.num));

    const arrowSpan = document.createElement('span');
    arrowSpan.className = 'help-spot-arrow';
    arrowSpan.textContent = '→';
    const badgeSpan = document.createElement('span');
    badgeSpan.className = 'help-spot-badge';
    badgeSpan.textContent = String(spec.num);
    const labelSpan = document.createElement('span');
    labelSpan.textContent = spec.label;

    calloutEl.appendChild(arrowSpan);
    calloutEl.appendChild(badgeSpan);
    calloutEl.appendChild(labelSpan);
    calloutEl.style.left = '-9999px';
    calloutEl.style.top = '-9999px';
    calloutsEl.appendChild(calloutEl);

    const cw = calloutEl.offsetWidth || 130;
    const ch = calloutEl.offsetHeight || 28;
    const tryOrder = getPlacementTryOrder(spec.placement);
    let chosen = null;

    for (const dir of tryOrder) {
      const candidate = computeCalloutPosition(holeRect, cw, ch, dir);
      const hitsModal = modalRect && rectsOverlap(candidate, modalRect, 6);
      const hitsOther = placedCalloutRects.some((r) => rectsOverlap(candidate, r, 4));
      const hitsHole = rectsOverlap(candidate, holeRect, 4);
      if (!hitsModal && !hitsOther && !hitsHole) {
        chosen = candidate;
        break;
      }
    }

    if (chosen) {
      arrowSpan.textContent = chosen.arrow;
      calloutEl.style.left = `${Math.round(chosen.left)}px`;
      calloutEl.style.top = `${Math.round(chosen.top)}px`;
      placedCalloutRects.push(chosen);
    } else {
      // 모든 방향이 겹치면 말풍선만 숨기고 노란 링은 유지
      calloutEl.remove();
    }
  }

  if (subtitleEl) {
    if (renderedCount > 0) {
      subtitleEl.textContent = '';
      subtitleEl.append(
        document.createTextNode('배경의 노란 번호와 아래 항목을 함께 확인하세요'),
        document.createElement('br'),
        document.createTextNode('(항목에 마우스를 올리면 해당 위치가 강조됩니다)')
      );
    } else {
      subtitleEl.textContent = '설치 없이 브라우저에서 바로 쓰는 오프라인 자리 배치 도구';
    }
  }
  if (_focusedStepNum !== null) {
    setFocusedHelpStep(_focusedStepNum);
  }
}

function handleViewportRelayout() {
  if (_resizeRafId) cancelAnimationFrame(_resizeRafId);
  _resizeRafId = requestAnimationFrame(() => {
    _resizeRafId = 0;
    renderHelpSpotlights();
  });
}

function attachSpotlightListeners() {
  if (_listenersAttached) return;
  window.addEventListener('resize', handleViewportRelayout);
  _listenersAttached = true;
}

function detachSpotlightListeners() {
  if (_resizeRafId) {
    cancelAnimationFrame(_resizeRafId);
    _resizeRafId = 0;
  }
  if (!_listenersAttached) return;
  window.removeEventListener('resize', handleViewportRelayout);
  _listenersAttached = false;
}

export function openHelpGuideModal({ isAutoFirstRun = false } = {}) {
  if (isAutoFirstRun && AppStore.isRunningSelfDiagnostics()) return false;
  const modalEl = document.getElementById('helpGuideModal');
  if (!modalEl) return false;

  const alreadyOpen = !modalEl.classList.contains('hidden');
  _isAutoFirstRunOpen = Boolean(isAutoFirstRun);
  _focusedStepNum = null;
  if (!alreadyOpen) {
    _lastTriggerEl = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    if (
      window.innerWidth >= SPOTLIGHT_MIN_VIEWPORT_WIDTH &&
      !AppStore.isRunningSelfDiagnostics() &&
      AppStore.getState().sidebarCollapsed
    ) {
      toggleLeftSidebar(false);
      _temporarilyExpandedSidebar = true;
    } else {
      _temporarilyExpandedSidebar = false;
    }
  }
  modalEl.classList.toggle('help-sidebar-open', !AppStore.getState().sidebarCollapsed);

  const checkWrap = document.getElementById('helpDontShowAgainWrap');
  const checkEl = document.getElementById('helpDontShowAgainCheckbox');
  const startBtn = document.getElementById('startHelpGuideBtn');

  if (checkWrap) {
    if (_isAutoFirstRunOpen) {
      checkWrap.classList.remove('hidden');
      checkWrap.classList.add('flex');
    } else {
      checkWrap.classList.add('hidden');
      checkWrap.classList.remove('flex');
    }
  }
  if (checkEl && _isAutoFirstRunOpen) {
    checkEl.checked = true;
  }
  if (startBtn) {
    startBtn.textContent = _isAutoFirstRunOpen ? '시작하기' : '닫기';
  }

  modalEl.classList.remove('hidden');
  modalEl.classList.add('flex');
  attachSpotlightListeners();
  if (_openRafId) cancelAnimationFrame(_openRafId);
  if (_sidebarSettleTimer) {
    clearTimeout(_sidebarSettleTimer);
    _sidebarSettleTimer = null;
  }
  _openRafId = requestAnimationFrame(() => {
    _openRafId = 0;
    if (modalEl.classList.contains('hidden')) return;
    renderHelpSpotlights();
    if (startBtn) startBtn.focus();
  });
  if (_temporarilyExpandedSidebar) {
    _sidebarSettleTimer = setTimeout(() => {
      _sidebarSettleTimer = null;
      if (!modalEl.classList.contains('hidden')) renderHelpSpotlights();
    }, 320);
  }
  return true;
}

export function closeHelpGuideModal({ persistSeen = true } = {}) {
  const modalEl = document.getElementById('helpGuideModal');
  if (!modalEl || modalEl.classList.contains('hidden')) return false;

  const checkEl = document.getElementById('helpDontShowAgainCheckbox');
  if (persistSeen && _isAutoFirstRunOpen && (!checkEl || checkEl.checked)) {
    markHelpGuideSeen();
  }

  if (_openRafId) {
    cancelAnimationFrame(_openRafId);
    _openRafId = 0;
  }
  if (_sidebarSettleTimer) {
    clearTimeout(_sidebarSettleTimer);
    _sidebarSettleTimer = null;
  }
  detachSpotlightListeners();
  clearHelpSpotlights();
  setFocusedHelpStep(null);
  modalEl.classList.add('hidden');
  modalEl.classList.remove('flex');
  modalEl.classList.remove('help-sidebar-open');
  _isAutoFirstRunOpen = false;
  if (_temporarilyExpandedSidebar) {
    _temporarilyExpandedSidebar = false;
    if (!AppStore.isRunningSelfDiagnostics()) {
      toggleLeftSidebar(true);
    }
  }

  if (_lastTriggerEl && typeof _lastTriggerEl.focus === 'function' && document.contains(_lastTriggerEl)) {
    _lastTriggerEl.focus();
  }
  _lastTriggerEl = null;
  return true;
}
