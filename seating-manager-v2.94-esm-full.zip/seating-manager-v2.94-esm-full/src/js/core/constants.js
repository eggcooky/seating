// [L0] 전역 상수 정의 (의존성 없는 순수 리프 모듈)
export const MAX_COLS = 12; // 최대 열 범위 (0~11)
export const MAX_ROWS = 16; // 최대 행 범위 (0~15)
export const MAX_STUDENTS = 45; // 등록 가능한 최대 학생 수
export const MAX_STUDENT_NUM = 99999; // 허용 최대 학생 번호·학번 (최대 5자리)
export const STORAGE_KEY = 'classroom_seating_manager_v2';
export const MULTI_CLASS_SLOT_COUNT = 7; // 사용자 노출 다중학급 슬롯 수 (1~7)
export const MULTI_CLASS_META_KEY = `${STORAGE_KEY}_multi_meta`; // 다중학급 메타 키
export const DIAG_SANDBOX_STORAGE_KEY = `${STORAGE_KEY}_slot_6_diag`; // 자가진단 전용 샌드박스 키 (구버전 정리 호환 유지)
export const HELP_GUIDE_SEEN_KEY = `${STORAGE_KEY}_help_seen`; // 첫 실행 사용 안내 열람 여부 키
export const SECRET_HELP_GUIDE_SEEN_KEY = `${STORAGE_KEY}_secret_help_seen`; // 비밀의 방 최초 사용 안내 열람 여부 키

// 프로그램 버전 및 원격 업데이트 확인·다운로드용 상수 정의
// 외부 서버로 사용자 데이터를 전송하지 않으며, 오직 아래 두 주소에 대한 읽기(GET) 요청만 수행한다.
// [난독화 설계 의도] 배포본 HTML의 __app_pkg__ 난독화(XOR+Base64) 패키징은
// 교실 환경에서 학생이 브라우저 소스 보기(Ctrl+U)로 교사 전용 사전 배치 기능(비밀의 방)의
// 존재를 우연히 발견하는 것을 방지하기 위한 UI 보호 장치이며, 암호학적 기밀성 목적이 아니다.
export const APP_VERSION = '2.94';
export const OBFUSCATION_XOR_KEY = 'ClassroomSeatingManager::simple-enc';
export const VERSION_URL = 'https://eggcooky.github.io/seating/version.json';
export const PROGRAM_URL = 'https://eggcooky.github.io/seating/seating.html';
export const UPDATE_CHECK_INTERVAL_MS = 60 * 60 * 1000; // 자동 업데이트 확인 최소 간격(1시간)
export const MIN_VALID_HTML_LENGTH = 50000; // 오류 페이지나 잘린 파일을 걸러내기 위한 최소 HTML 길이 기준
// 이전 버전 저장소 키 목록 (초기 로드 시 현재 키로 마이그레이션 후 정리한다)
export const LEGACY_STORAGE_KEYS = ['classroom_seating_manager_v2_07'];
export const CURRENT_SCHEMA_VERSION = 2;

/**
 * @typedef {{ id: string, num: number, name: string, gender: '남'|'여', classLabel?: string }} Student
 * @typedef {[number, number]} SeatCoord
 * @typedef {{
 *   defaultCols: number,
 *   useGenderDistinction: boolean,
 *   genderPairMode: 'any'|'mixed'|'mixed_random'|'same'|'same_random',
 *   excludePreviousSeat: boolean,
 *   frontRowIds: string[],
 *   separatedPairs: [string, string][],
 *   togetherPairs: [string, string][]
 * }} SeatingRules
 * @typedef {{
 *   students: Student[],
 *   pos: Record<string, SeatCoord>,
 *   rules: SeatingRules,
 *   lockedIds?: string[],
 *   rng?: () => number
 * }} AlgorithmInput
 */
