# 학급 스마트 자리 배치 매니저 (v2.90 — 무순환 6계층 ES Module 프로젝트)

`자리바꾸기(v2.90).html`을 **순환참조 0건(Tarjan SCC 최대 크기 = 1) · 6계층 단방향 DAG ES Module 구조(50개 모듈)**로 근본 리팩토링하고, 빌드 시 IIFE로 번들링해 원래와 동일한 오프라인 단일 HTML(`dist/자리바꾸기(v2.90).html`)을 생성하는 프로젝트입니다.

## 아키텍처 핵심 개선 (순환참조 0건 달성)
- **거대 순환 덩어리(13개 모듈 SCC, 2-Cycle 24쌍) 완전 해소**: Tarjan SCC = 1, 직접 2-Cycle = 0쌍, 계층 역전 = 0건.
- **6계층 단방향 DAG (`L0` → `L5`)**: 모든 모듈은 동일·하위 계층만 비순환으로 `import`합니다.
  - `L0 core/`: 전역 상수([constants.js](src/js/core/constants.js)) · 순수 유틸([utils.js](src/js/core/utils.js))
  - `L1 domain/`: DOM·전역상태 비의존 100% 순수 비즈니스 로직 (알고리즘 엔진, 격자 좌표, 상태 쿼리, 스키마/마이그레이션, XOR+Base64 코덱, 엑셀 파서, SHA-256·HTML 검증) — 브라우저 없이 `node --test` 단독 단위 테스트 가능
  - `L2 state/`: 단일 진실 원천 상태 컨테이너([store.js](src/js/state/store.js)) · Undo 스냅샷 스택([history-store.js](src/js/state/history-store.js)) — `export let state` 가변 바인딩 제거 및 `AppStore.getState()` + 동기 Hook DIP 적용
  - `L3 infra/ · ui/`: 오디오·저장소 I/O 어댑터 및 횡단 원자 UI(토스트, 미저장 표시, 룰렛 가드, 교탁, 비밀방 경고 인디케이터)
  - `L4 views/ · features/`: 핸들러 주입형 독립 뷰 렌더러 7종 및 단일 도메인 기능 모듈 7종 (`View ↔ Action` 및 `Feature ↔ Feature` 순환 0건)
  - `L5 app/ · diagnostics/`: 최상위 동기 조립기([view-sync-coordinator.js](src/js/app/view-sync-coordinator.js)), 상호배타 모드([mode-coordinator.js](src/js/app/mode-coordinator.js)), 다중학급 전환([multiclass-coordinator.js](src/js/app/multiclass-coordinator.js)), 다단계 Undo 복원([history-coordinator.js](src/js/app/history-coordinator.js)), 조건 모달 트랜잭션([rules-coordinator.js](src/js/app/rules-coordinator.js)), 앱 부트스트랩([bootstrap.js](src/js/app/bootstrap.js)) 및 내장 자가진단 18항목
- **빌드 타임 영구 가드레일**: `scripts/check-cycles.mjs`가 `scripts/verify-build.mjs`에 통합되어 순환참조·미정의 심볼·계층 역전·모듈 최상위 `AppStore.getState()` 캐싱·구버전 업데이터 `APP_VERSION` 정규식 패턴을 자동 검증합니다.
- **단일 오프라인 HTML 배포 유지**: 단일 고정 번들러(`webpack`, `iife: true`, `minimize: false`)가 IIFE로 묶어 `file://` 오프라인 실행 및 구버전 자동 업데이트 무결성 검증을 100% 호환합니다.

## 디렉터리 구조 (`src/js/main.js` 진입점)

| 계층 | 경로 | 파일 수 | 주요 모듈 |
| :---: | :--- | :---: | :--- |
| **L0** | `src/js/core/` | 2 | `constants.js`, `utils.js` |
| **L1** | `src/js/domain/` | 7 | `grid.js`, `seat-queries.js`, `schema.js`, `codec.js`, `excel-parser.js`, `algorithm-engine.js`, `updater-core.js` |
| **L2** | `src/js/state/` | 2 | `store.js`, `history-store.js` |
| **L3** | `src/js/infra/`, `src/js/ui/` | 7 | `audio.js`, `storage-io.js`, `toast.js`, `dirty-indicator.js`, `guards.js`, `podium.js`, `secret-indicators.js` |
| **L4** | `src/js/views/`, `src/js/features/` | 14 | `help-guide-view.js`, `toolbar-ui.js`, `classroom-view.js`, `roster-view.js`, `print-view.js`, `rules-modal-view.js`, `history-popover.js`, `reveal-controller.js`, `roulette-controller.js`, `secret-room-actions.js`, `seat-actions.js`, `roster-actions.js`, `seating-actions.js`, `updater-ui.js` |
| **L5** | `src/js/app/`, `src/js/app/binders/`, `src/js/diagnostics/` | 17 | `view-sync-coordinator.js`, `mode-coordinator.js`, `multiclass-coordinator.js`, `history-coordinator.js`, `rules-coordinator.js`, `bootstrap.js`, `binders/*`(5개: `classroom-controls`, `file-io`, `keyboard-sync`, `modals-updater`, `reveal-roulette`), `diagnostics/*`(6개) |
| **진입** | `src/js/main.js` | 1 | DOMContentLoaded → `initApp()` |

## 빌드 및 검증 명령어

```bash
# 1. 최초 1회 번들러(webpack) 설치
npm install

# 2. 순환참조 · 계층 경계 · 심볼 정합성 엄격 검증 (0-Cycle 정책)
npm run check:cycles

# 3. L0/L1 순수 도메인 Node.js 단위 테스트 (브라우저 불필요)
npm run test:unit

# 4. ES 모듈 번들링 + 단일 HTML(__app_pkg__) + SHA-256 version.json + 전체 정적 검증
npm run build
```

- 빌드 결과물: `dist/자리바꾸기(v2.90).html`, `dist/version.json`
- **배포 시 주의**: 원격 업데이트 시 SHA-256 무결성 검증을 수행하므로, 반드시 **같은 빌드에서 함께 생성된 HTML과 `version.json` 쌍**을 배포 저장소에 올려야 합니다.
