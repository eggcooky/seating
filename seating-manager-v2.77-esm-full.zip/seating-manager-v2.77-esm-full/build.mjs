#!/usr/bin/env node
/**
 * ES Module 번들링 + 단일 오프라인 HTML(__app_pkg__) 패키징 + version.json(SHA-256 자동 기입) 빌드 스크립트.
 *
 * [난독화 설계 의도]
 * 단일 HTML 내부의 __app_pkg__ 난독화(XOR+Base64) 패키징은 교실 환경에서 학생이
 * 브라우저 소스 보기(Ctrl+U)를 통해 교사 전용 사전 배치 기능(비밀의 방)을 우연히 발견하는 것을
 * 방지하기 위한 UI 보호 장치이다.
 */

import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { runStaticBuildVerification } from './scripts/verify-build.mjs';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const BUILD_DIR = path.join(ROOT, 'build');
const BUNDLE_PATH = path.join(BUILD_DIR, 'bundle.js');
const XOR_KEY = 'ClassroomSeatingManager::simple-enc';
const BODY_CLASS = 'h-screen overflow-hidden flex flex-col select-none';
const APP_VERSION = '2.77';
const RELEASE_DATE = '2026-11-22';
const MAX_KNOWN_HASH_HISTORY = 10;
const VERSION_HISTORY_PATH = path.join(ROOT, 'version-history.json');
const RELEASE_NOTES = [
  'CSP 보안 정책 메타 태그 적용으로 외부 통신을 공식 업데이트 주소 1곳으로 브라우저 차원 제한',
  '파일 확인 경고 문구를 손상 안내 표현으로 통일하고 배정 결과 없음 방어 가드 추가'
];
const DEFAULT_OUT = path.join(ROOT, 'dist', `자리바꾸기(v${APP_VERSION}).html`);

function xorBuffer(buf, keyBuf) {
  const out = Buffer.allocUnsafe(buf.length);
  const klen = keyBuf.length;
  for (let i = 0; i < buf.length; i++) {
    out[i] = buf[i] ^ keyBuf[i % klen];
  }
  return out;
}

function tryCommand(cmd, args) {
  try {
    execFileSync(cmd, args, { cwd: ROOT, stdio: 'pipe' });
    return true;
  } catch {
    return false;
  }
}

function bundleESM() {
  fs.mkdirSync(BUILD_DIR, { recursive: true });
  const webpackConfig = path.join(ROOT, 'webpack.config.mjs');
  const localWebpack = path.join(
    ROOT,
    'node_modules',
    '.bin',
    process.platform === 'win32' ? 'webpack.cmd' : 'webpack'
  );
  if (fs.existsSync(localWebpack)) {
    execFileSync(localWebpack, ['--config', webpackConfig], { cwd: ROOT, stdio: 'inherit' });
    console.log('[build.mjs] 번들러: local webpack (단일 고정)');
    return;
  }

  const globalWebpack = process.platform === 'win32' ? 'webpack.cmd' : 'webpack';
  if (tryCommand(globalWebpack, ['--config', webpackConfig])) {
    console.log('[build.mjs] 번들러: global webpack (단일 고정)');
    return;
  }

  throw new Error(
    'webpack 번들러를 찾지 못했습니다. 먼저 `npm install`을 실행해 webpack을 설치한 뒤 다시 `npm run build`를 실행하세요.'
  );
}

function packageSingleHtml(outPath) {
  const shell = fs.readFileSync(path.join(ROOT, 'src/shell.html'), 'utf8');
  const style = fs.readFileSync(path.join(ROOT, 'src/style.css'), 'utf8');
  const body = fs.readFileSync(path.join(ROOT, 'src/body.html'), 'utf8');
  const script = fs.readFileSync(BUNDLE_PATH, 'utf8');

  const payload = {
    style,
    bodyClass: BODY_CLASS,
    body,
    script,
  };
  const rawJson = Buffer.from(JSON.stringify(payload), 'utf8');
  const encodedB64 = xorBuffer(rawJson, Buffer.from(XOR_KEY, 'utf8')).toString('base64');

  const finalHtml = shell.replace('{{APP_PKG}}', encodedB64);
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(outPath, finalHtml, 'utf8');

  const sha256 = crypto.createHash('sha256').update(finalHtml, 'utf8').digest('hex');
  const pkgSha256 = crypto.createHash('sha256').update(encodedB64, 'utf8').digest('hex');

  // 소스 폴더의 version-history.json에 최근 10개 버전의 pkgSha256 이력을 자동 누적 관리한다.
  let prevHashes = {};
  if (fs.existsSync(VERSION_HISTORY_PATH)) {
    try {
      const histObj = JSON.parse(fs.readFileSync(VERSION_HISTORY_PATH, 'utf8'));
      if (histObj && histObj.knownPkgHashes && typeof histObj.knownPkgHashes === 'object') {
        prevHashes = histObj.knownPkgHashes;
      }
    } catch (_) {}
  }
  const orderedEntries = [[APP_VERSION, pkgSha256]];
  for (const [verKey, hashVal] of Object.entries(prevHashes)) {
    if (verKey === APP_VERSION) continue;
    if (typeof hashVal === 'string' && /^[a-f0-9]{64}$/i.test(hashVal.trim())) {
      orderedEntries.push([verKey, hashVal.trim().toLowerCase()]);
    }
    if (orderedEntries.length >= MAX_KNOWN_HASH_HISTORY) break;
  }
  const knownPkgHashes = Object.fromEntries(orderedEntries);
  fs.writeFileSync(
    VERSION_HISTORY_PATH,
    JSON.stringify({ maxEntries: MAX_KNOWN_HASH_HISTORY, knownPkgHashes }, null, 2) + '\n',
    'utf8'
  );

  const verJsonPath = path.join(path.dirname(outPath), 'version.json');
  const versionJson = {
    version: APP_VERSION,
    date: RELEASE_DATE,
    sha256,
    pkgSha256,
    knownPkgHashes,
    notes: RELEASE_NOTES
  };
  fs.writeFileSync(verJsonPath, JSON.stringify(versionJson, null, 2) + '\n', 'utf8');

  console.log(`[build.mjs] 단일 HTML 생성 완료: ${outPath} (${Buffer.byteLength(finalHtml, 'utf8').toLocaleString()} bytes)`);
  console.log(`[build.mjs] SHA-256: ${sha256}`);
  console.log(`[build.mjs] version.json 생성 완료: ${verJsonPath}`);
}

const outIdx = process.argv.findIndex((a) => a === '-o' || a === '--output');
const outPath = outIdx >= 0 ? path.resolve(process.argv[outIdx + 1]) : DEFAULT_OUT;

bundleESM();
packageSingleHtml(outPath);
runStaticBuildVerification();
