// [L2] 단일 진실 원천 상태 컨테이너 (AppStore — 동기 Hook DIP 적용, 상위 UI/스토리지 역참조 0)
import {
  DOMAIN_STATE_KEYS,
  PREFS_STATE_KEYS,
  PERSISTED_STATE_KEYS,
  UI_STATE_KEYS,
  SESSION_STATE_KEYS,
  migratePayloadSchema,
  createInitialState,
  applyLoadedDataToState
} from '../domain/schema.js';

let _state = createInitialState();
let _runningSelfDiagnostics = false;
let _printViewDirty = true;
let _debouncedCommitTimer = null;

const _hooks = {
  onSyncViews: null,
  onCommit: null,
  onFlushPrint: null,
  onPersist: null,
  onMarkDirty: null,
  onRenderClassroom: null,
  onRenderRosterAndClassroom: null
};

export function isRunningSelfDiagnostics() {
  return _runningSelfDiagnostics;
}

export function setRunningSelfDiagnostics(value) {
  _runningSelfDiagnostics = Boolean(value);
}

export const AppStore = {
  getState() {
    return _state;
  },
  isRunningSelfDiagnostics() {
    return _runningSelfDiagnostics;
  },
  setRunningSelfDiagnostics(value) {
    _runningSelfDiagnostics = Boolean(value);
  },
  isPrintViewDirty() {
    return _printViewDirty;
  },
  setPrintViewDirty(value) {
    _printViewDirty = Boolean(value);
  },
  clearPendingCommitTimer() {
    if (_debouncedCommitTimer !== null) {
      clearTimeout(_debouncedCommitTimer);
      _debouncedCommitTimer = null;
    }
  },
  configureHooks(nextHooks = {}) {
    if (!nextHooks || typeof nextHooks !== 'object') return;
    Object.keys(_hooks).forEach((k) => {
      if (typeof nextHooks[k] === 'function' || nextHooks[k] === null) {
        _hooks[k] = nextHooks[k];
      }
    });
  },
  // 영속 저장 및 Undo 대상이 되는 순수 도메인 데이터 슬라이스만 추출한다.
  getDomainState(sourceState = _state) {
    const out = {};
    if (!sourceState) return out;
    DOMAIN_STATE_KEYS.forEach(k => { if (k in sourceState) out[k] = sourceState[k]; });
    return out;
  },
  // 로컬 저장소 및 파일에 함께 보존되는 사용자 환경설정 슬라이스를 추출한다.
  getPrefsState(sourceState = _state) {
    const out = {};
    if (!sourceState) return out;
    PREFS_STATE_KEYS.forEach(k => { if (k in sourceState) out[k] = sourceState[k]; });
    return out;
  },
  // 파일·로컬 저장소에 직렬화할 전체 영속 데이터(DOMAIN_STATE_KEYS + PREFS_STATE_KEYS + lastSavedAt)를 단일 기준표로 추출한다.
  getPersistedState(sourceState = _state) {
    const out = {};
    if (!sourceState) return out;
    PERSISTED_STATE_KEYS.forEach(k => { if (k in sourceState) out[k] = sourceState[k]; });
    return out;
  },
  // 화면 보기·토글 등 비저장 UI 상태 슬라이스만 추출한다.
  getUiState(sourceState = _state) {
    const out = {};
    if (!sourceState) return out;
    UI_STATE_KEYS.forEach(k => { if (k in sourceState) out[k] = sourceState[k]; });
    return out;
  },
  // 룰렛 회전·선택 대기·히스토리 스택 등 일회성 세션 슬라이스만 추출한다.
  getSessionState(sourceState = _state) {
    const out = {};
    if (!sourceState) return out;
    SESSION_STATE_KEYS.forEach(k => { if (k in sourceState) out[k] = sourceState[k]; });
    return out;
  },
  migratePayloadSchema,
  replaceState(nextState) {
    if (nextState && typeof nextState === 'object') {
      _state = nextState;
    }
    return _state;
  },
  resetState() {
    _state = createInitialState();
    return _state;
  },
  // 진행 중인 룰렛 추첨 대기 세션과 선택 상태를 일괄 초기화한다.
  resetTransientSession() {
    _state.selectedStudentId = null;
    _state.rouletteSessionToken = (_state.rouletteSessionToken || 0) + 1;
    _state.rouletteSpinning = false;
    _state.rouletteActiveSession = false;
    _state.rouletteDrawnIds = [];
    _state.rouletteAutoColumnTarget = null;
    _state.pendingSecretNotices = [];
  },
  // 로컬 저장소(loadFromStorage)와 외부 JSON 파일 불러오기(importJson)의 데이터 검증·정화를 단일 경로로 통합한다.
  applyLoadedData(rawParsed, fallbackTitle = '우리 반 자리 배치표', allowEmptyRoster = false) {
    return applyLoadedDataToState(_state, rawParsed, fallbackTitle, allowEmptyRoster);
  },
  syncViews(options = {}) {
    const opts = { roster: true, classroom: true, animate: false, print: false, rules: true, ...options };
    if (typeof _hooks.onSyncViews === 'function') {
      _hooks.onSyncViews(opts);
    } else if (typeof console !== 'undefined' && console.warn) {
      console.warn('[AppStore] onSyncViews hook is not configured');
    }
    _printViewDirty = !opts.print;
  },
  requestClassroomRender(animate = false) {
    if (typeof _hooks.onRenderClassroom === 'function') {
      _hooks.onRenderClassroom(animate);
    }
  },
  requestRosterAndClassroomRender(animate = false) {
    if (typeof _hooks.onRenderRosterAndClassroom === 'function') {
      _hooks.onRenderRosterAndClassroom(animate);
    }
  },
  // 인쇄 직전(beforeprint 또는 [A4 가로 출력] 클릭 시) 지연된 인쇄 뷰 DOM과 대기 중인 저장 작업을 즉시 플러시한다.
  flushPendingCommit(ensurePrintDom = false) {
    if (_debouncedCommitTimer !== null) {
      clearTimeout(_debouncedCommitTimer);
      _debouncedCommitTimer = null;
      if (!_state.rulesModalBackup && typeof _hooks.onPersist === 'function') {
        _hooks.onPersist(false);
      }
    }
    if (ensurePrintDom && _printViewDirty) {
      if (typeof _hooks.onFlushPrint === 'function') {
        _hooks.onFlushPrint();
      }
      _printViewDirty = false;
    }
  },
  // 연속 타이핑(input 이벤트) 중 매 자모마다 전체 인쇄 DOM 재생성 및 난독화 저장이 반복되지 않도록 디바운싱 처리한다.
  scheduleDebouncedCommit(delayMs = 200) {
    _printViewDirty = true;
    if (!_state.rulesModalBackup && typeof _hooks.onMarkDirty === 'function') {
      _hooks.onMarkDirty(true);
    }
    if (_debouncedCommitTimer !== null) {
      clearTimeout(_debouncedCommitTimer);
    }
    _debouncedCommitTimer = setTimeout(() => {
      _debouncedCommitTimer = null;
      if (!_state.rulesModalBackup && typeof _hooks.onPersist === 'function') {
        _hooks.onPersist(false);
      }
    }, delayMs);
  },
  // 상태 변경 후 미저장 표시(markDirty), 화면 렌더링 동기화(syncViews), 룰렛 UI 갱신, 로컬 저장(saveToStorage)을 단일 파이프라인으로 처리한다.
  // 배치 조건 모달(#rulesModal) 편집 중(state.rulesModalBackup 존재 시)에는 [조건 적용] 확정 전까지 markDirty 및 saveToStorage를 자동 보류한다.
  commitChange({ roster = false, classroom = false, animate = false, print = false, rules = false, roulette = false, dirty = true, save = true, forcePersist = false } = {}) {
    if (_debouncedCommitTimer !== null) {
      clearTimeout(_debouncedCommitTimer);
      _debouncedCommitTimer = null;
    }
    _printViewDirty = true;
    const canPersist = forcePersist || !_state.rulesModalBackup;
    if (dirty === true && canPersist && typeof _hooks.onMarkDirty === 'function') {
      _hooks.onMarkDirty(true);
    }
    if (typeof _hooks.onCommit === 'function') {
      _hooks.onCommit({ roster, classroom, animate, print, rules, roulette });
    } else if (typeof console !== 'undefined' && console.warn) {
      console.warn('[AppStore] onCommit hook is not configured');
    }
    if (save && canPersist && typeof _hooks.onPersist === 'function') {
      _hooks.onPersist(false);
    }
  }
};
