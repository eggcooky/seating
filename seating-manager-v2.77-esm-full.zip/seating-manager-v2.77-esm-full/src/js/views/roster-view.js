// [L4] 좌측 학생 명렬표 뷰 렌더러 (선택/삭제/룰렛재초기화 액션은 L5에서 주입받아 순환참조 차단)
import { isSeatHidden } from '../domain/seat-queries.js';
import { AppStore } from '../state/store.js';

const _handlers = {
  onStudentPick: null,
  onDeleteStudent: null,
  onRouletteRedraw: null
};

export function bindRosterHandlers(nextHandlers = {}) {
  if (!nextHandlers || typeof nextHandlers !== 'object') return;
  Object.keys(_handlers).forEach((k) => {
    if (typeof nextHandlers[k] === 'function' || nextHandlers[k] === null) {
      _handlers[k] = nextHandlers[k];
    }
  });
}

export function updateStudentNameOnBoard(studentId, newName) {
  const safeId = (typeof CSS !== "undefined" && CSS.escape) ? CSS.escape(String(studentId)) : String(studentId).replace(/["\\]/g, "\\$&");
  const nameEls = document.querySelectorAll(`[data-student-name-id="${safeId}"]`);
  nameEls.forEach(el => {
    el.textContent = newName || '·';
  });
}

export function renderRoster() {
  const state = AppStore.getState();
  const container = document.getElementById('rosterListContainer');
  const badge = document.getElementById('studentCountBadge');
  if (!container) return;

  const useGender = state.rules.useGenderDistinction !== false;
  const boyCount = state.students.filter(s => s.gender === '남').length;
  const girlCount = state.students.length - boyCount;

  if (useGender) {
    badge.textContent = `총 ${state.students.length}명 (남${boyCount}·여${girlCount})`;
  } else {
    badge.textContent = `총 ${state.students.length}명`;
  }

  const hdNameCol = document.getElementById('rosterHeaderNameCol');
  const hdGenderCol = document.getElementById('rosterHeaderGenderCol');
  if (hdNameCol && hdGenderCol) {
    if (useGender) {
      hdNameCol.className = 'col-span-6 text-left pl-2';
      hdGenderCol.className = 'col-span-2';
    } else {
      hdNameCol.className = 'col-span-8 text-left pl-2';
      hdGenderCol.className = 'hidden';
    }
  }

  const paperGenderLabel = document.getElementById('paperGenderColorLabel');
  if (paperGenderLabel) {
    if (useGender) {
      paperGenderLabel.classList.remove('hidden');
      paperGenderLabel.classList.add('flex');
    } else {
      paperGenderLabel.classList.add('hidden');
      paperGenderLabel.classList.remove('flex');
    }
  }

  container.innerHTML = '';

  state.students.forEach((student, idx) => {
    const isSelected = String(state.selectedStudentId) === String(student.id);
    const row = document.createElement('div');
    row.className = `grid grid-cols-12 items-center px-3 py-1.5 transition group text-xs ${
      isSelected ? 'bg-amber-50/90 ring-1 ring-amber-400' : 'hover:bg-indigo-50/40'
    }`;

    // 번호 버튼
    const numCol = document.createElement('div');
    numCol.className = 'col-span-2 flex justify-center';
    const numBtn = document.createElement('button');
    numBtn.type = 'button';
    numBtn.title = '클릭하여 이 학생 자리 선택/맞바꾸기';
    numBtn.className = `w-7 h-7 rounded-lg font-bold text-xs transition flex items-center justify-center ${
      isSelected
        ? 'bg-indigo-600 text-white shadow-sm'
        : 'bg-slate-100 text-slate-600 hover:bg-indigo-100 hover:text-indigo-700'
    }`;
    numBtn.textContent = student.num || (idx + 1);
    numBtn.addEventListener('click', () => {
      if (typeof _handlers.onStudentPick === 'function') {
        _handlers.onStudentPick(student.id);
      }
    });
    numCol.appendChild(numBtn);

    // 성명 입력란 (부분 DOM 패치로 한글 입력 포커스 보존)
    const nameCol = document.createElement('div');
    nameCol.className = useGender ? 'col-span-6 pl-1 pr-1' : 'col-span-8 pl-1 pr-1';
    const nameInput = document.createElement('input');
    nameInput.type = 'text';
    nameInput.maxLength = 30;
    nameInput.value = student.name;
    nameInput.placeholder = '이름 입력';
    nameInput.className = 'w-full font-bold text-slate-800 bg-slate-50/70 border border-transparent hover:border-slate-200 focus:border-indigo-500 focus:bg-white rounded-lg px-2 py-1 focus:outline-none transition';
    nameInput.addEventListener('input', (e) => {
      const curState = AppStore.getState();
      student.name = e.target.value;
      if (!isSeatHidden(curState, student.id) || curState.inSecretRoom) {
        updateStudentNameOnBoard(student.id, student.name);
      }
      if (curState.rouletteOpen && typeof _handlers.onRouletteRedraw === 'function') {
        _handlers.onRouletteRedraw();
      }
      AppStore.scheduleDebouncedCommit(200);
    });
    nameCol.appendChild(nameInput);

    // 성별 전환 버튼
    const genderCol = document.createElement('div');
    genderCol.className = useGender ? 'col-span-2 flex justify-center' : 'hidden';
    const genderBtn = document.createElement('button');
    genderBtn.type = 'button';
    const isFemale = student.gender === '여';
    genderBtn.className = `px-2 py-0.5 rounded-md text-[11px] font-bold transition ${
      isFemale
        ? 'bg-rose-50 text-rose-600 border border-rose-200 hover:bg-rose-100'
        : 'bg-sky-50 text-sky-600 border border-sky-200 hover:bg-sky-100'
    }`;
    genderBtn.textContent = student.gender;
    genderBtn.addEventListener('click', () => {
      student.gender = student.gender === '여' ? '남' : '여';
      AppStore.commitChange({ roster: true, classroom: true, animate: false, print: true, dirty: true, save: true });
    });
    genderCol.appendChild(genderBtn);

    // 삭제 버튼
    const actionCol = document.createElement('div');
    actionCol.className = 'col-span-2 flex items-center justify-center';

    const delBtn = document.createElement('button');
    delBtn.type = 'button';
    delBtn.title = '학생 삭제';
    delBtn.className = 'p-1 rounded hover:bg-rose-100 text-slate-400 hover:text-rose-600 transition';
    delBtn.innerHTML = `
      <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
      </svg>
    `;
    delBtn.addEventListener('click', () => {
      if (typeof _handlers.onDeleteStudent === 'function') {
        _handlers.onDeleteStudent(student);
      }
    });

    actionCol.appendChild(delBtn);

    row.appendChild(numCol);
    row.appendChild(nameCol);
    row.appendChild(genderCol);
    row.appendChild(actionCol);
    container.appendChild(row);
  });
}
