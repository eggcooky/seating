// [L4] 되돌리기(Undo) 버튼 배지 및 히스토리 팝오버 뷰 (복원 실행 콜백은 L5에서 주입)
import { escapeHtml } from '../core/utils.js';
import { AppStore } from '../state/store.js';

const _handlers = {
  onRestoreHistory: null
};

export function bindHistoryPopoverHandlers(nextHandlers = {}) {
  if (!nextHandlers || typeof nextHandlers !== 'object') return;
  if (typeof nextHandlers.onRestoreHistory === 'function' || nextHandlers.onRestoreHistory === null) {
    _handlers.onRestoreHistory = nextHandlers.onRestoreHistory;
  }
}

function renderStatusHistoryPopover() {
  const state = AppStore.getState();
  const listEl = document.getElementById('statusHistoryList');
  if (!listEl) return;
  const stack = state.inSecretRoom ? state.undoStackSecret : state.undoStackNormal;
  listEl.innerHTML = '';

  if (!stack || stack.length === 0) {
    listEl.innerHTML = `
      <div class="px-4 py-6 text-center text-xs text-slate-400">
        아직 기록된 자리 변화 내역이 없습니다.<br/>
        <span class="text-[11px]">자리를 클릭해 이동하거나 랜덤 배정을 실행하면 최근 7개 변화 내역이 이곳에 기록됩니다.</span>
      </div>
    `;
    return;
  }

  // 최신 변경 내역부터 역순으로 목록을 렌더링한다.
  for (let i = stack.length - 1; i >= 0; i--) {
    const item = stack[i];
    const stepsAgo = stack.length - i;
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'w-full px-4 py-2.5 text-left hover:bg-indigo-50/80 transition flex items-center justify-between gap-2 group';
    btn.innerHTML = `
      <div class="min-w-0 flex-1">
        <div class="flex items-center gap-1.5">
          <span class="px-1.5 py-0.2 rounded text-[10px] font-extrabold bg-indigo-100 text-indigo-700 shrink-0">${stepsAgo === 1 ? '방금 전' : stepsAgo + '단계 전'}</span>
          <span class="text-xs font-bold text-slate-800 truncate">${escapeHtml(item.actionLabel || '자리 배치 변경')}</span>
        </div>
        <div class="text-[10px] text-slate-400 mt-0.5 pl-0.5">${escapeHtml(item.timeStr || '')} 실행됨</div>
      </div>
      <span class="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-slate-100 text-slate-600 group-hover:bg-indigo-600 group-hover:text-white transition shrink-0">
        이 시점 이전으로 복원
      </span>
    `;
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (typeof _handlers.onRestoreHistory === 'function') {
        _handlers.onRestoreHistory(i);
      }
    });
    listEl.appendChild(btn);
  }
}

export function updateUndoButtonState() {
  const state = AppStore.getState();
  const undoBtn = document.getElementById('undoSeatBtn');
  const countBadge = document.getElementById('statusHistoryCountBadge');
  const stack = state.inSecretRoom ? state.undoStackSecret : state.undoStackNormal;
  const count = stack ? stack.length : 0;

  if (undoBtn) {
    undoBtn.disabled = count === 0;
  }
  if (countBadge) {
    if (count > 0) {
      countBadge.classList.remove('hidden');
      countBadge.textContent = String(Math.min(7, count));
    } else {
      countBadge.classList.add('hidden');
    }
  }
  const pop = document.getElementById('statusHistoryPopover');
  if (pop && !pop.classList.contains('hidden')) {
    renderStatusHistoryPopover();
  }
}

export function toggleStatusHistoryPopover() {
  const pop = document.getElementById('statusHistoryPopover');
  const chev = document.getElementById('statusHistoryChevron');
  if (!pop) return;
  const isHidden = pop.classList.contains('hidden');
  if (isHidden) {
    renderStatusHistoryPopover();
    pop.classList.remove('hidden');
    if (chev) chev.classList.add('rotate-180');
  } else {
    pop.classList.add('hidden');
    if (chev) chev.classList.remove('rotate-180');
  }
}

export function closeStatusHistoryPopover() {
  const pop = document.getElementById('statusHistoryPopover');
  const chev = document.getElementById('statusHistoryChevron');
  if (pop) pop.classList.add('hidden');
  if (chev) chev.classList.remove('rotate-180');
}
