// [L4] A4 가로 인쇄 화면 렌더링, 출력 옵션 모달 및 고해상도 이미지 캡처
import { escapeHtml, sanitizeFileName } from '../core/utils.js';
import { getGridBounds } from '../domain/grid.js';
import { AppStore } from '../state/store.js';
import { createPodiumAndMessageElement } from '../ui/podium.js';
import { showToast } from '../ui/toast.js';

// 선택된 음영 옵션('zebra' | 'female' | 'male' | 'none')에 따라 명렬표 행 및 우측 좌석 칸의 흑백 음영 적용 여부를 판별한다.
function shouldShadePrintItem(student, zeroBasedOrderIdx, shadeMode, includeRoster, useGender) {
  if (!includeRoster || shadeMode === 'none' || !student) return false;
  if (shadeMode === 'zebra') {
    return (zeroBasedOrderIdx % 2) === 1;
  }
  if (shadeMode === 'female') {
    return Boolean(useGender && student.gender === '여');
  }
  if (shadeMode === 'male') {
    return Boolean(useGender && student.gender === '남');
  }
  return false;
}

function getEffectivePrintOptions(state) {
  const useGender = state.rules && state.rules.useGenderDistinction !== false;
  const orientation = (state.printOrientation === 'teacher' || state.printOrientation === 'student')
    ? state.printOrientation
    : (state.viewOrientation === 'teacher' ? 'teacher' : 'student');
  const includeRoster = state.printIncludeRoster !== false;
  let shadeMode = ['zebra', 'female', 'male', 'none'].includes(state.printShadeMode)
    ? state.printShadeMode
    : 'female';
  if (!useGender && (shadeMode === 'female' || shadeMode === 'male')) {
    shadeMode = 'zebra';
  }
  const shadeSeatEnabled = Boolean(includeRoster && shadeMode !== 'none' && state.printShadeSeatEnabled !== false);
  return { orientation, includeRoster, shadeMode, shadeSeatEnabled, useGender };
}

export function updatePrintOptionsModalUI() {
  const state = AppStore.getState();
  const { orientation, includeRoster, shadeMode, useGender } = getEffectivePrintOptions(state);

  document.querySelectorAll('.print-orient-btn').forEach(btn => {
    const val = btn.getAttribute('data-print-orient');
    const active = val === orientation;
    btn.className = active
      ? 'print-orient-btn py-2.5 px-3 rounded-xl text-xs font-extrabold border transition flex flex-col items-center justify-center gap-0.5 bg-indigo-600 text-white border-indigo-600 shadow-sm'
      : 'print-orient-btn py-2.5 px-3 rounded-xl text-xs font-bold border transition flex flex-col items-center justify-center gap-0.5 bg-white text-slate-700 border-slate-200 hover:bg-slate-100';
  });

  document.querySelectorAll('.print-roster-btn').forEach(btn => {
    const isOn = btn.getAttribute('data-print-roster') === 'on';
    const active = isOn === includeRoster;
    btn.className = active
      ? 'print-roster-btn py-2 px-3 rounded-xl text-xs font-extrabold border transition flex items-center justify-center gap-1.5 bg-indigo-600 text-white border-indigo-600 shadow-sm'
      : 'print-roster-btn py-2 px-3 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-1.5 bg-white text-slate-700 border-slate-200 hover:bg-slate-100';
  });

  const shadeSection = document.getElementById('printShadeOptionsSection');
  if (shadeSection) {
    if (includeRoster) {
      shadeSection.classList.remove('opacity-40', 'pointer-events-none');
    } else {
      shadeSection.classList.add('opacity-40', 'pointer-events-none');
    }
  }

  document.querySelectorAll('.print-shade-btn').forEach(btn => {
    const val = btn.getAttribute('data-print-shade');
    const genderDisabled = !useGender && (val === 'female' || val === 'male');
    btn.disabled = genderDisabled;
    const active = val === shadeMode && !genderDisabled;
    if (genderDisabled) {
      btn.className = 'print-shade-btn py-2 px-2.5 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-1 bg-slate-100 text-slate-400 border-slate-200 opacity-50 cursor-not-allowed';
    } else if (active) {
      btn.className = 'print-shade-btn py-2 px-2.5 rounded-xl text-xs font-extrabold border transition flex items-center justify-center gap-1 bg-indigo-600 text-white border-indigo-600 shadow-sm';
    } else {
      btn.className = 'print-shade-btn py-2 px-2.5 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-1 bg-white text-slate-700 border-slate-200 hover:bg-slate-100';
    }
  });

  const shadeSeatToggle = document.getElementById('printShadeToSeatToggle');
  const shadeSeatRow = document.getElementById('printShadeToSeatRow');
  if (shadeSeatToggle) {
    const isNone = shadeMode === 'none';
    shadeSeatToggle.disabled = !includeRoster || isNone;
    shadeSeatToggle.checked = !isNone && state.printShadeSeatEnabled !== false;
  }
  if (shadeSeatRow) {
    if (shadeMode === 'none') {
      shadeSeatRow.classList.add('opacity-40', 'pointer-events-none');
    } else {
      shadeSeatRow.classList.remove('opacity-40', 'pointer-events-none');
    }
  }
}

export function openPrintOptionsModal() {
  const state = AppStore.getState();
  AppStore.flushPendingCommit(false);
  const hadSelectedStudent = state.selectedStudentId !== null;
  state.selectedStudentId = null;
  if (hadSelectedStudent) {
    AppStore.requestRosterAndClassroomRender(false);
  }
  if (state.printOrientation !== 'teacher' && state.printOrientation !== 'student') {
    state.printOrientation = state.viewOrientation === 'teacher' ? 'teacher' : 'student';
  }
  if (state.rules && state.rules.useGenderDistinction === false) {
    if (state.printShadeMode === 'female' || state.printShadeMode === 'male') {
      state.printShadeMode = 'zebra';
      state.printShadeSeatEnabled = false;
    }
  }
  updatePrintOptionsModalUI();
  renderPrintView();
  const modal = document.getElementById('printOptionsModal');
  if (modal) {
    modal.classList.remove('hidden');
    modal.classList.add('flex');
  }
}

export function closePrintOptionsModal() {
  const modal = document.getElementById('printOptionsModal');
  if (modal) {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
  }
}

export function renderPrintView() {
  const state = AppStore.getState();
  AppStore.setPrintViewDirty(false);
  const tbody = document.getElementById('printRosterTableBody');
  const printStage = document.getElementById('printClassroomStage');
  const rosterWrapper = document.getElementById('printRosterWrapper');
  if (!tbody || !printStage) return;

  const { orientation, includeRoster, shadeMode, shadeSeatEnabled, useGender } = getEffectivePrintOptions(state);
  const isStudentView = orientation === 'student';

  if (rosterWrapper) {
    if (includeRoster) {
      rosterWrapper.classList.remove('hidden');
      rosterWrapper.classList.add('flex');
    } else {
      rosterWrapper.classList.add('hidden');
      rosterWrapper.classList.remove('flex');
    }
  }

  const printTable = document.getElementById('printRosterTable');
  if (printTable) {
    const count = state.students.length;
    const fontSizeClass = count > 38 ? 'text-[7.5pt]' : count > 32 ? 'text-[8.5pt]' : 'text-[9.5pt]';
    printTable.className = `w-full h-full border-collapse border-[1.5px] border-black ${fontSizeClass} leading-none table-fixed`;
  }

  const printNameTh = document.getElementById('printHeaderNameTh');
  const printGenderTh = document.getElementById('printHeaderGenderTh');
  if (printNameTh && printGenderTh) {
    if (useGender) {
      printNameTh.className = 'border border-black px-1 text-center w-[54%]';
      printGenderTh.className = 'border border-black px-1 text-center w-[24%]';
    } else {
      printNameTh.className = 'border border-black px-1 text-center w-[78%]';
      printGenderTh.className = 'hidden';
    }
  }

  tbody.innerHTML = '';
  state.students.forEach((st, idx) => {
    const tr = document.createElement('tr');
    const shaded = shouldShadePrintItem(st, idx, shadeMode, includeRoster, useGender);
    tr.className = shaded ? 'print-female-row' : '';
    if (useGender) {
      tr.innerHTML = `
        <td class="border border-black px-1 text-center font-medium whitespace-nowrap">${escapeHtml(st.num || (idx + 1))}</td>
        <td class="border border-black px-1 text-center font-semibold tracking-wide" style="max-width: 26mm; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${escapeHtml(st.name)}</td>
        <td class="border border-black px-1 text-center font-medium whitespace-nowrap">${escapeHtml(st.gender)}</td>
      `;
    } else {
      tr.innerHTML = `
        <td class="border border-black px-1 text-center font-medium whitespace-nowrap">${escapeHtml(st.num || (idx + 1))}</td>
        <td class="border border-black px-1 text-center font-semibold tracking-wide" style="max-width: 34mm; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${escapeHtml(st.name)}</td>
      `;
    }
    tbody.appendChild(tr);
  });
  const PRINT_MIN_ROWS = 10;
  for (let k = state.students.length; k < PRINT_MIN_ROWS; k++) {
    const blankTr = document.createElement('tr');
    blankTr.innerHTML = '<td class="border border-black px-1">&nbsp;</td>'.repeat(useGender ? 3 : 2);
    tbody.appendChild(blankTr);
  }

  printStage.innerHTML = '';

  if (isStudentView) {
    const podiumEl = createPodiumAndMessageElement(true);
    podiumEl.classList.add('-mt-1');
    printStage.appendChild(podiumEl);
  } else {
    const topSpacer = document.createElement('div');
    topSpacer.className = 'h-1';
    printStage.appendChild(topSpacer);
  }

  const activeMap = state.pos;
  const posMap = {};
  state.students.forEach((s, idx) => {
    const coord = activeMap[s.id];
    if (coord) {
      posMap[`${coord[0]},${coord[1]}`] = { student: s, num: s.num || (idx + 1), rosterIdx: idx };
    }
  });

  const { c0, c1, r0, r1 } = getGridBounds(state.students, activeMap, false);
  const numCols = c1 - c0 + 1;
  const numRows = r1 - r0 + 1;

  const hasMessage = Boolean((state.teacherMessage || '').trim());
  const maxAvailableHeight = hasMessage ? 108 : 115;
  const seatHeightMm = Math.min(includeRoster ? 20 : 22, Math.floor(maxAvailableHeight / Math.max(1, numRows)));

  const columnsContainer = document.createElement('div');
  columnsContainer.className = includeRoster
    ? 'w-full max-w-[215mm] mx-auto grid gap-4 my-auto'
    : 'w-full max-w-[265mm] mx-auto grid gap-4 my-auto';
  columnsContainer.style.gridTemplateColumns = `repeat(${numCols}, minmax(0, 1fr))`;

  const colOrder = [];
  for (let c = c0; c <= c1; c++) colOrder.push(c);
  if (!isStudentView) colOrder.reverse();

  const rowOrder = [];
  for (let r = r0; r <= r1; r++) rowOrder.push(r);
  if (!isStudentView) rowOrder.reverse();

  colOrder.forEach(c => {
    const colStack = document.createElement('div');
    colStack.className = 'flex flex-col';

    rowOrder.forEach((r, visualRowIdx) => {
      const entry = posMap[`${c},${r}`];
      const borderOverlap = visualRowIdx > 0 ? '-mt-[1.5px]' : '';

      const box = document.createElement('div');
      box.style.height = `${seatHeightMm}mm`;
      if (entry) {
        const { student, num, rosterIdx } = entry;
        const seatShaded = shouldShadePrintItem(student, rosterIdx, shadeMode, includeRoster && shadeSeatEnabled, useGender);
        const shadeClass = seatShaded ? 'print-shaded-seat bg-neutral-100' : 'bg-white';
        box.className = `relative border-[1.5px] border-black ${borderOverlap} flex flex-col items-center justify-center overflow-hidden ${shadeClass} text-black`;
        const numSpan = document.createElement('span');
        numSpan.className = 'absolute top-[1.2mm] left-[2mm] text-[8pt] font-semibold text-neutral-600 leading-none';
        if (numRows >= 10) {
          numSpan.style.fontSize = '6.5pt';
          numSpan.style.top = '0.5mm';
        }
        numSpan.textContent = `${num}번`;
        const nameSpan = document.createElement('span');
        nameSpan.className = 'font-bold text-[13.5pt] tracking-widest mt-[1.5mm] leading-none truncate max-w-full px-1';
        nameSpan.style.overflow = 'hidden';
        nameSpan.style.textOverflow = 'ellipsis';
        nameSpan.style.whiteSpace = 'nowrap';
        nameSpan.style.maxWidth = '100%';
        if (numRows >= 10) {
          nameSpan.style.fontSize = includeRoster ? '10pt' : '11pt';
          nameSpan.style.marginTop = '1.8mm';
        } else if (!includeRoster) {
          nameSpan.style.fontSize = '15pt';
        }
        nameSpan.textContent = student.name;
        box.appendChild(numSpan);
        box.appendChild(nameSpan);
      } else {
        box.className = `${borderOverlap} border border-transparent`;
      }
      colStack.appendChild(box);
    });

    columnsContainer.appendChild(colStack);
  });

  printStage.appendChild(columnsContainer);

  if (!isStudentView) {
    const podiumEl = createPodiumAndMessageElement(true);
    podiumEl.classList.add('mb-5');
    printStage.appendChild(podiumEl);
  } else {
    const bottomSpacer = document.createElement('div');
    bottomSpacer.className = 'h-4';
    printStage.appendChild(bottomSpacer);
  }
}

// 오프라인 환경에서도 외부 라이브러리 없이 인쇄 레이아웃(명렬표 유무·시점·흑백 음영 연동)을 2배 초고해상도(4400x3112, SCALE=2) Canvas 2D로 직접 렌더링한다.
export function generatePrintCaptureCanvas() {
  const state = AppStore.getState();
  const SCALE = 2;
  const W = 2200;
  const H = 1556;
  const canvas = document.createElement('canvas');
  canvas.width = W * SCALE;
  canvas.height = H * SCALE;
  const ctx = canvas.getContext('2d');
  ctx.scale(SCALE, SCALE);
  const fontStack = '"Noto Sans KR", "Malgun Gothic", "맑은 고딕", "Apple SD Gothic Neo", sans-serif';

  const { orientation, includeRoster, shadeMode, shadeSeatEnabled, useGender } = getEffectivePrintOptions(state);
  const isStudentView = orientation === 'student';

  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, W, H);

  const padX = 56;
  const padY = 52;
  const gapX = includeRoster ? 38 : 0;
  const rosterW = includeRoster ? 360 : 0;
  const stageX = padX + rosterW + gapX;
  const stageW = W - stageX - padX;
  const stageY = padY;
  const stageH = H - padY * 2;

  if (includeRoster) {
    const totalRows = Math.max(10, state.students.length) + 1;
    const rowH = stageH / totalRows;
    const col1W = Math.round(rosterW * 0.22);
    const col2W = useGender ? Math.round(rosterW * 0.54) : (rosterW - col1W);
    const col3W = useGender ? (rosterW - col1W - col2W) : 0;

    ctx.fillStyle = '#f5f5f5';
    ctx.fillRect(padX, stageY, rosterW, rowH);
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 2;
    ctx.strokeRect(padX, stageY, rosterW, rowH);

    ctx.fillStyle = '#000000';
    const fontPx = state.students.length > 38 ? 17 : state.students.length > 32 ? 19 : 21;
    ctx.font = `bold ${fontPx}px ${fontStack}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const headerCy = stageY + rowH / 2;
    ctx.fillText('번호', padX + col1W / 2, headerCy);
    ctx.fillText('성명', padX + col1W + col2W / 2, headerCy);
    if (useGender) {
      ctx.fillText('성별', padX + col1W + col2W + col3W / 2, headerCy);
    }

    const dataRowCount = Math.max(10, state.students.length);
    for (let idx = 0; idx < dataRowCount; idx++) {
      const ry = stageY + (idx + 1) * rowH;
      const st = state.students[idx] || null;
      const shaded = shouldShadePrintItem(st, idx, shadeMode, includeRoster, useGender);
      ctx.fillStyle = shaded ? '#e5e7eb' : '#ffffff';
      ctx.fillRect(padX, ry, rosterW, rowH);
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(padX, ry, rosterW, rowH);

      if (st) {
        ctx.fillStyle = '#000000';
        ctx.font = `600 ${fontPx}px ${fontStack}`;
        const cy = ry + rowH / 2;
        ctx.fillText(String(st.num || (idx + 1)), padX + col1W / 2, cy);
        ctx.font = `bold ${fontPx}px ${fontStack}`;
        ctx.fillText(String(st.name || ''), padX + col1W + col2W / 2, cy, Math.max(40, col2W - 14));
        if (useGender) {
          ctx.font = `600 ${fontPx}px ${fontStack}`;
          ctx.fillText(String(st.gender || ''), padX + col1W + col2W + col3W / 2, cy);
        }
      }
    }

    ctx.beginPath();
    ctx.moveTo(padX + col1W, stageY);
    ctx.lineTo(padX + col1W, stageY + stageH);
    if (useGender) {
      ctx.moveTo(padX + col1W + col2W, stageY);
      ctx.lineTo(padX + col1W + col2W, stageY + stageH);
    }
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.lineWidth = 3;
    ctx.strokeRect(padX, stageY, rosterW, stageH);
  }

  ctx.strokeStyle = '#000000';
  ctx.lineWidth = 3;
  ctx.strokeRect(stageX, stageY, stageW, stageH);

  const msgText = String(state.teacherMessage || '').trim();
  const titleText = String(state.classTitle || '우리 반 자리 배치표').trim();
  const orientBadgeText = isStudentView ? '학생 게시용 (교탁이 위쪽)' : '교탁 게시용 (교탁이 아래쪽)';

  ctx.fillStyle = '#000000';
  ctx.font = `900 34px ${fontStack}`;
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  ctx.fillText(titleText, stageX + 48, stageY + 32, Math.max(200, stageW - 340));

  ctx.fillStyle = '#525252';
  ctx.font = `bold 18px ${fontStack}`;
  ctx.textAlign = 'right';
  ctx.fillText(orientBadgeText, stageX + stageW - 48, stageY + 42);

  const drawPodiumBlock = (centerY) => {
    const podW = 340;
    const podH = 66;
    const px = stageX + (stageW - podW) / 2;
    const py = centerY - podH / 2;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(px, py, podW, podH);
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 3;
    ctx.strokeRect(px, py, podW, podH);
    ctx.fillStyle = '#000000';
    ctx.font = `900 26px ${fontStack}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('교       탁', stageX + stageW / 2, centerY);

    if (msgText) {
      const msgY = isStudentView ? (py + podH + 26) : (py - 26);
      ctx.font = `bold 21px ${fontStack}`;
      ctx.fillStyle = '#171717';
      ctx.fillText(msgText, stageX + stageW / 2, msgY, Math.max(200, stageW - 96));
    }
  };

  if (isStudentView) {
    drawPodiumBlock(stageY + 135);
  } else {
    drawPodiumBlock(stageY + stageH - 115);
  }

  const activeMap = state.pos;
  const posMap = {};
  state.students.forEach((s, idx) => {
    const coord = activeMap[s.id];
    if (coord) {
      posMap[`${coord[0]},${coord[1]}`] = { student: s, num: s.num || (idx + 1), rosterIdx: idx };
    }
  });

  const { c0, c1, r0, r1 } = getGridBounds(state.students, activeMap, false);
  const numCols = Math.max(1, c1 - c0 + 1);
  const numRows = Math.max(1, r1 - r0 + 1);

  const gridAreaTop = isStudentView ? (stageY + (msgText ? 215 : 190)) : (stageY + 100);
  const gridAreaBottom = isStudentView ? (stageY + stageH - 48) : (stageY + stageH - (msgText ? 200 : 175));
  const gridAvailH = Math.max(200, gridAreaBottom - gridAreaTop);
  const gridAvailW = stageW - (includeRoster ? 120 : 140);
  const gridStartX = stageX + (stageW - gridAvailW) / 2;

  const colGap = 24;
  const colW = (gridAvailW - colGap * (numCols - 1)) / numCols;
  const seatH = Math.min(includeRoster ? 155 : 170, Math.floor(gridAvailH / numRows));
  const totalGridH = seatH * numRows;
  const gridStartY = gridAreaTop + (gridAvailH - totalGridH) / 2;

  const colOrder = [];
  for (let c = c0; c <= c1; c++) colOrder.push(c);
  if (!isStudentView) colOrder.reverse();

  const rowOrder = [];
  for (let r = r0; r <= r1; r++) rowOrder.push(r);
  if (!isStudentView) rowOrder.reverse();

  const nameFontPx = includeRoster ? 30 : 34;
  colOrder.forEach((c, cVisualIdx) => {
    const bx = gridStartX + cVisualIdx * (colW + colGap);
    rowOrder.forEach((r, rVisualIdx) => {
      const by = gridStartY + rVisualIdx * seatH;
      const entry = posMap[`${c},${r}`];
      if (!entry) return;
      const { student, num, rosterIdx } = entry;
      const seatShaded = shouldShadePrintItem(student, rosterIdx, shadeMode, includeRoster && shadeSeatEnabled, useGender);

      ctx.fillStyle = seatShaded ? '#e5e7eb' : '#ffffff';
      ctx.fillRect(bx, by, colW, seatH);
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 2.5;
      ctx.strokeRect(bx, by, colW, seatH);

      const tightSeat = seatH < 95;
      const effNumFont = tightSeat ? 14 : 18;
      const effNameFont = tightSeat ? Math.min(nameFontPx, 24) : nameFontPx;

      ctx.fillStyle = '#525252';
      ctx.font = `bold ${effNumFont}px ${fontStack}`;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      ctx.fillText(`${num}번`, bx + 12, by + (tightSeat ? 6 : 10));

      ctx.fillStyle = '#000000';
      ctx.font = `bold ${effNameFont}px ${fontStack}`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(String(student.name || ''), bx + colW / 2, by + seatH / 2 + (tightSeat ? 9 : 8), Math.max(40, colW - 20));
    });
  });

  return canvas;
}

export async function captureAndSavePrintLayout() {
  const state = AppStore.getState();
  const canvas = generatePrintCaptureCanvas();
  const orientSuffix = state.printOrientation === 'teacher' ? '교탁용' : '학생용';
  const fileName = `${sanitizeFileName(state.classTitle || '우리반_자리배치표')}_${orientSuffix}.png`;

  const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
  if (!blob) {
    showToast('이미지 생성 중 오류가 발생했습니다.', 'warn');
    return;
  }

  let copiedToClipboard = false;
  if (navigator.clipboard && typeof navigator.clipboard.write === 'function' && typeof window.ClipboardItem === 'function') {
    try {
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
      copiedToClipboard = true;
    } catch (e) {
      copiedToClipboard = false;
    }
  }

  if (typeof window.showSaveFilePicker === 'function') {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName: fileName,
        types: [{
          description: 'PNG 고화질 이미지 파일',
          accept: { 'image/png': ['.png'] }
        }]
      });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      closePrintOptionsModal();
      const savedName = handle.name || fileName;
      if (copiedToClipboard) {
        showToast(`📸 지정한 위치에 '${savedName}' 파일이 저장되었고 클립보드(Ctrl+V)에도 복사되었습니다!`, 'success');
      } else {
        showToast(`📸 지정한 위치에 '${savedName}' 초고화질 자리 배치표 이미지가 저장되었습니다!`, 'success');
      }
      return;
    } catch (err) {
      if (err && err.name === 'AbortError') {
        if (copiedToClipboard) {
          showToast('파일 저장을 취소했습니다. (클립보드에는 이미지가 복사되어 바로 붙여넣기 가능합니다)', 'info');
        } else {
          showToast('파일 저장이 취소되었습니다.', 'info');
        }
        return;
      }
    }
  }

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);

  closePrintOptionsModal();
  if (copiedToClipboard) {
    showToast(`📸 클립보드에 이미지가 복사(Ctrl+V 붙여넣기 가능)되었고 '${fileName}' 파일로도 저장되었습니다!`, 'success');
  } else {
    showToast(`📸 '${fileName}' 초고화질 자리 배치표 이미지 파일이 저장되었습니다!`, 'success');
  }
}

export function executePrintFromModal() {
  AppStore.flushPendingCommit(true);
  renderPrintView();
  closePrintOptionsModal();
  window.print();
}
