// [L5] 다단계 실행 취소(Undo) 복원 트랜잭션 코디네이터
import { ensureAllStudentsHaveValidCoords } from '../domain/grid.js';
import {
  doesSecretLayoutMatchCurrent,
  isNormalSeatLocked,
  isSeatLocked
} from '../domain/seat-queries.js';
import { stopSequentialReveal } from '../features/reveal-controller.js';
import { stopRouletteColumnAuto, syncRouletteWithCurrentLocks } from '../features/roulette-controller.js';
import { AppStore } from '../state/store.js';
import { checkSecretRoomLayoutMismatch, updateSecretPresetIndicator } from '../ui/secret-indicators.js';
import { showToast } from '../ui/toast.js';
import { closeStatusHistoryPopover, updateUndoButtonState } from '../views/history-popover.js';

export function restoreHistoryAtIndex(targetIdx) {
  const state = AppStore.getState();
  const stack = state.inSecretRoom ? state.undoStackSecret : state.undoStackNormal;
  if (!stack || targetIdx < 0 || targetIdx >= stack.length) return;

  stopSequentialReveal();
  state.rouletteSessionToken = (state.rouletteSessionToken || 0) + 1;
  state.rouletteSpinning = false;

  const targetSnapshot = stack[targetIdx];
  // 복원 전 현재 시점의 좌석 맵과 고정석 목록, 그리고 비밀의 방 좌표 일치 여부를 먼저 기록한다.
  const preUndoStudentIdSet = new Set(state.students.map(s => String(s.id)));
  const preUndoNormalPos = JSON.parse(JSON.stringify(state.pos || {}));
  const preUndoSecretPos = state.secretPos ? JSON.parse(JSON.stringify(state.secretPos)) : null;
  const preUndoNormalLocks = [...state.lockedIds];
  const preUndoSecretLocks = [...state.secretLockedIds];
  const secretMatchedBeforeUndo = state.inSecretRoom && doesSecretLayoutMatchCurrent(state);

  // 선택한 시점(targetIdx)부터 최신 스냅샷 사이에 열 수(4~8열) 변경으로 기록된 prevDefaultCols가 있으면 복원한다.
  let earliestPrevDefaultCols = null;
  for (let k = targetIdx; k < stack.length; k++) {
    if (stack[k] && stack[k].prevDefaultCols) {
      earliestPrevDefaultCols = stack[k].prevDefaultCols;
      break;
    }
  }

  // 선택한 시점(targetIdx)부터 최신 스냅샷 사이에 학생 삭제·추가 등으로 백업된 명단(rosterBackup)이 있으면 가장 앞선 시점의 명단·규칙을 복원하되,
  // 기존에 남아 있던 학생들의 현재 잠금 상태(preUndoNormalLocks / preUndoSecretLocks)는 유지한다(설계 원칙 ⑥).
  let earliestRosterBackup = null;
  let earliestRosterBackupIdx = -1;
  for (let k = targetIdx; k < stack.length; k++) {
    if (stack[k] && stack[k].rosterBackup) {
      earliestRosterBackup = stack[k].rosterBackup;
      earliestRosterBackupIdx = k;
      break;
    }
  }
  if (earliestRosterBackup) {
    state.students = JSON.parse(JSON.stringify(earliestRosterBackup.students || []));
    const restoredIdSet = new Set(state.students.map(s => String(s.id)));
    const backupNormalLockSet = new Set((earliestRosterBackup.lockedIds || []).map(String));
    const backupSecretLockSet = new Set((earliestRosterBackup.secretLockedIds || []).map(String));
    // 기존 학생은 현재 잠금 상태를 유지하고, 삭제되었다가 복원된 학생은 삭제 직전 잠금 상태를 복원한다.
    const mergedNormalLocks = new Set(preUndoNormalLocks.map(String).filter(id => restoredIdSet.has(id)));
    const mergedSecretLocks = new Set(preUndoSecretLocks.map(String).filter(id => restoredIdSet.has(id)));
    state.students.forEach(s => {
      const sid = String(s.id);
      if (!preUndoStudentIdSet.has(sid)) {
        if (backupNormalLockSet.has(sid)) mergedNormalLocks.add(sid);
        if (backupSecretLockSet.has(sid)) mergedSecretLocks.add(sid);
      }
    });
    state.lockedIds = [...mergedNormalLocks];
    state.secretLockedIds = [...mergedSecretLocks];
    state.hiddenSeatIds = [...(earliestRosterBackup.hiddenSeatIds || [])].filter(id => restoredIdSet.has(String(id)));
    state.pendingSecretNotices = [...(earliestRosterBackup.pendingSecretNotices || [])];
    if (earliestRosterBackup.hasDeleteGapNotice !== undefined) {
      state.hasDeleteGapNotice = Boolean(earliestRosterBackup.hasDeleteGapNotice);
    }
    if (earliestRosterBackup.rules) {
      state.rules = JSON.parse(JSON.stringify(earliestRosterBackup.rules));
    }
    if (earliestRosterBackup.secretPos) {
      state.secretPos = JSON.parse(JSON.stringify(earliestRosterBackup.secretPos));
    } else {
      state.secretPos = null;
      state.secretLockedIds = [];
      state.undoStackSecret = [];
    }
    // 비밀의 방에서 삭제/추가되어 양쪽 스택에 미러링된 스냅샷이었다면 반대쪽 스택의 대응 스냅샷도 양방향으로 정확히 제거한다(BUG-05).
    const otherStack = state.inSecretRoom ? state.undoStackNormal : state.undoStackSecret;
    if (Array.isArray(otherStack) && otherStack.length > 0) {
      const restoredPairIds = new Set();
      for (let k = targetIdx; k < stack.length; k++) {
        if (stack[k] && stack[k]._rosterMirrorPairId) {
          restoredPairIds.add(stack[k]._rosterMirrorPairId);
        }
      }
      if (restoredPairIds.size > 0) {
        let earliestOtherIdx = -1;
        for (let oi = 0; oi < otherStack.length; oi++) {
          if (otherStack[oi] && restoredPairIds.has(otherStack[oi]._rosterMirrorPairId)) {
            earliestOtherIdx = oi;
            break;
          }
        }
        if (earliestOtherIdx !== -1) {
          otherStack.length = earliestOtherIdx;
        }
      } else if (otherStack[otherStack.length - 1]._mirroredRosterOp) {
        otherStack.pop();
      }
    }
  }

  if (earliestPrevDefaultCols !== null && state.rules) {
    state.rules.defaultCols = earliestPrevDefaultCols;
  }

  // 선택한 시점(targetIdx)부터 최신 스냅샷 사이에 [기본 대형으로 되돌리기]·[현재 일반 자리 불러오기]·[고정석 동기화] 등으로 백업된 고정석 목록(locks)이 있으면 가장 앞선 시점의 잠금 목록을 복원한다(BUG-04 방어).
  let earliestLocksBackup = null;
  let earliestLocksBackupIdx = -1;
  const overwrittenLockSet = new Set();
  for (let k = targetIdx; k < stack.length; k++) {
    if (stack[k] && stack[k].locks && !earliestLocksBackup) {
      earliestLocksBackup = stack[k].locks;
      earliestLocksBackupIdx = k;
    }
    if (stack[k] && Array.isArray(stack[k].overwrittenLockIds)) {
      stack[k].overwrittenLockIds.forEach(id => overwrittenLockSet.add(String(id)));
    }
  }
  const curValidStudentIdsAfterRestore = new Set(state.students.map(s => String(s.id)));
  if (earliestLocksBackup && (earliestRosterBackupIdx === -1 || earliestLocksBackupIdx <= earliestRosterBackupIdx)) {
    if (state.inSecretRoom) {
      state.secretLockedIds = (earliestLocksBackup.secretLockedIds || []).filter(id => curValidStudentIdsAfterRestore.has(String(id)));
    } else {
      state.lockedIds = (earliestLocksBackup.lockedIds || []).filter(id => curValidStudentIdsAfterRestore.has(String(id)));
    }
  } else {
    state.lockedIds = (state.lockedIds || []).filter(id => curValidStudentIdsAfterRestore.has(String(id)));
    state.secretLockedIds = (state.secretLockedIds || []).filter(id => curValidStudentIdsAfterRestore.has(String(id)));
  }
  // 선택한 시점 이후의 히스토리를 정리하고 해당 시점의 상태로 복원한다.
  stack.length = targetIdx;

  // 설계 원칙 ⑥: 현재 자물쇠(🔒)로 잠겨 있는 학생은 되돌리기(Undo) 실행 시에도 현재 고정된 좌석 위치를 이탈하지 않도록 보호하고,
  // 스냅샷에서 해당 좌석에 앉아 있던 미고정 학생을 잠긴 학생의 이전 스냅샷 좌표(또는 빈 좌표)로 겹침 없이 치환한다(BUG-03 & 삭제 Undo 충돌 방어).
  const preserveLockedPositions = (snapshotPos, currentMap, isLockedFn) => {
    const snap = snapshotPos || {};
    const cur = currentMap || {};
    const nextMap = {};
    const usedCoordKeys = new Set();
    const displacedPool = [];

    // 1단계: 현재 잠겨 있는 학생(전원)을 현재 좌표(cur[s.id])에 최우선 고정한다.
    const lockedStudents = state.students.filter(s => isLockedFn(s.id) && Array.isArray(cur[s.id]));
    lockedStudents.forEach(s => {
      const sid = String(s.id);
      const c = cur[sid];
      const key = `${c[0]},${c[1]}`;
      if (!usedCoordKeys.has(key)) {
        nextMap[sid] = [c[0], c[1]];
        usedCoordKeys.add(key);
      }
    });
    lockedStudents.forEach(s => {
      const sid = String(s.id);
      const sc = snap[sid];
      if (Array.isArray(sc)) {
        const skey = `${sc[0]},${sc[1]}`;
        if (!usedCoordKeys.has(skey)) {
          displacedPool.push([sc[0], sc[1]]);
        }
      }
    });

    // 2단계: 잠기지 않은 학생 중 스냅샷 좌표가 비어 있는 학생은 원래 스냅샷 좌표로 배치하고, 잠긴 학생에게 자리를 내어준 학생은 대기열에 넣는다.
    const displacedUnlocked = [];
    state.students.forEach(s => {
      const sid = String(s.id);
      if (nextMap[sid]) return;
      const sc = snap[sid];
      if (Array.isArray(sc)) {
        const skey = `${sc[0]},${sc[1]}`;
        if (!usedCoordKeys.has(skey)) {
          nextMap[sid] = [sc[0], sc[1]];
          usedCoordKeys.add(skey);
          return;
        }
      }
      displacedUnlocked.push(sid);
    });

    // 3단계: 자리를 내어준 미고정 학생들에게 잠긴 학생의 옛 스냅샷 좌표(displacedPool)를 순서대로 배정한다.
    let poolIdx = 0;
    displacedUnlocked.forEach(sid => {
      while (poolIdx < displacedPool.length) {
        const cand = displacedPool[poolIdx++];
        const ckey = `${cand[0]},${cand[1]}`;
        if (!usedCoordKeys.has(ckey)) {
          nextMap[sid] = [cand[0], cand[1]];
          usedCoordKeys.add(ckey);
          return;
        }
      }
    });

    return nextMap;
  };

  const fallbackRosterPos = earliestRosterBackup
    ? (state.inSecretRoom ? (earliestRosterBackup.secretPos || earliestRosterBackup.pos || {}) : (earliestRosterBackup.pos || {}))
    : {};
  const baseSnapPos = { ...fallbackRosterPos, ...(targetSnapshot.pos || {}) };

  const preUndoNormalLockSet = new Set(preUndoNormalLocks.map(String));
  const preUndoSecretLockSet = new Set(preUndoSecretLocks.map(String));
  const wasLockedBeforeUndoNormal = (id) => !overwrittenLockSet.has(String(id)) && preUndoNormalLockSet.has(String(id)) && isNormalSeatLocked(state, id);
  const wasLockedBeforeUndoSecret = (id) => !overwrittenLockSet.has(String(id)) && preUndoSecretLockSet.has(String(id)) && isSeatLocked(state, id);

  const defaultCols = Number(state.rules && state.rules.defaultCols) || 6;

  if (state.inSecretRoom) {
    state.secretPos = preserveLockedPositions(baseSnapPos, preUndoSecretPos, wasLockedBeforeUndoSecret);
    ensureAllStudentsHaveValidCoords(state.students, state.secretPos, defaultCols);
    const snapHadDeletedStudents = Object.keys(baseSnapPos).some(id => !preUndoStudentIdSet.has(String(id)));
    if (earliestRosterBackup && earliestRosterBackup.pos) {
      const mergedNormalPos = {};
      state.students.forEach(s => {
        const sid = String(s.id);
        if (preUndoStudentIdSet.has(sid) && Array.isArray(preUndoNormalPos[sid])) {
          mergedNormalPos[sid] = [...preUndoNormalPos[sid]];
        } else if (Array.isArray(earliestRosterBackup.pos[sid])) {
          mergedNormalPos[sid] = [...earliestRosterBackup.pos[sid]];
        }
      });
      state.pos = preserveLockedPositions(mergedNormalPos, preUndoNormalPos, wasLockedBeforeUndoNormal);
      ensureAllStudentsHaveValidCoords(state.students, state.pos, defaultCols);
    } else if (secretMatchedBeforeUndo && snapHadDeletedStudents) {
      const validNormalCoordSet = new Set(
        state.students.map(s => state.pos[s.id]).filter(Boolean).map(p => `${p[0]},${p[1]}`)
      );
      const usedSecretCoords = new Set();
      const orphanStudentIds = [];
      state.students.forEach(s => {
        const sp = state.secretPos[s.id];
        const key = sp ? `${sp[0]},${sp[1]}` : '';
        if (sp && validNormalCoordSet.has(key) && !usedSecretCoords.has(key)) {
          usedSecretCoords.add(key);
        } else {
          orphanStudentIds.push(String(s.id));
        }
      });
      if (orphanStudentIds.length > 0) {
        const missingNormalCoords = state.students
          .map(s => state.pos[s.id])
          .filter(Boolean)
          .filter(p => !usedSecretCoords.has(`${p[0]},${p[1]}`));
        orphanStudentIds.forEach((sid, idx) => {
          if (missingNormalCoords[idx]) {
            state.secretPos[sid] = [...missingNormalCoords[idx]];
          }
        });
      }
    }
    checkSecretRoomLayoutMismatch(false);
  } else {
    state.pos = preserveLockedPositions(baseSnapPos, preUndoNormalPos, wasLockedBeforeUndoNormal);
    ensureAllStudentsHaveValidCoords(state.students, state.pos, defaultCols);
    const validRestoredIdSet = new Set(state.students.map(s => String(s.id)));
    if (Array.isArray(targetSnapshot.hiddenSeatIds)) {
      state.hiddenSeatIds = targetSnapshot.hiddenSeatIds.map(String).filter(id => validRestoredIdSet.has(id));
    } else if (!earliestRosterBackup) {
      state.hiddenSeatIds = [];
    }
    stopRouletteColumnAuto();
    state.rouletteActiveSession = Boolean(targetSnapshot.rouletteActiveSession && state.rouletteOpen);
    if (state.rouletteActiveSession) {
      const snapRemainingIds = new Set((targetSnapshot.rouletteRemainingStudents || []).map(s => String(s.id)));
      const inferredDrawn = Array.isArray(targetSnapshot.rouletteDrawnIds)
        ? targetSnapshot.rouletteDrawnIds.map(String)
        : state.students.map(s => String(s.id)).filter(id => !snapRemainingIds.has(id) && !isNormalSeatLocked(state, id));
      state.rouletteDrawnIds = inferredDrawn.filter(id => validRestoredIdSet.has(String(id)) && !isNormalSeatLocked(state, id));
      state.rouletteRemainingStudents = (targetSnapshot.rouletteRemainingStudents || []).filter(s => !isNormalSeatLocked(state, s.id));
      syncRouletteWithCurrentLocks();
    } else if (state.rouletteOpen) {
      state.rouletteDrawnIds = [];
      state.rouletteRemainingStudents = [];
      syncRouletteWithCurrentLocks();
    } else {
      state.rouletteRemainingStudents = [];
      state.rouletteTargetCoords = [];
      state.rouletteAssignedMap = {};
      state.rouletteDrawnIds = [];
    }
  }

  if (targetSnapshot.hasDeleteGapNotice !== undefined) {
    state.hasDeleteGapNotice = Boolean(targetSnapshot.hasDeleteGapNotice && state.students.length > 0);
  }
  state.selectedStudentId = null;
  updateUndoButtonState();
  updateSecretPresetIndicator();
  if (state.rouletteOpen) {
    const subEl = document.getElementById('rouletteResultSub');
    const mainEl = document.getElementById('rouletteResultMain');
    if (subEl && mainEl) {
      subEl.textContent = '이전 상태로 되돌렸습니다.';
      mainEl.textContent = `남은 인원 ${(state.rouletteRemainingStudents || []).length}명`;
    }
  }
  AppStore.commitChange({ roster: true, classroom: true, animate: true, print: true, rules: Boolean(earliestRosterBackup || earliestPrevDefaultCols !== null), dirty: true, save: true });
  closeStatusHistoryPopover();
  showToast(`'${targetSnapshot.actionLabel}' 이전 상태로 되돌렸습니다.`, 'info');
}
