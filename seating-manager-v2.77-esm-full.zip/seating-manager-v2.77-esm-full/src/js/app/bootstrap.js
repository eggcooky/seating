// [L5] 앱 초기화 및 UI 이벤트 바인딩 (BootstrapModule)
import { APP_VERSION, STORAGE_KEY } from '../core/constants.js';
import { sanitizeFileName } from '../core/utils.js';
import { closeSelfTestModal, runAutomatedSelfDiagnostics } from '../diagnostics/index.js';
import { parseSeatFileText } from '../domain/codec.js';
import {
  startSequentialReveal,
  stopSequentialReveal,
  toggleLargeViewMode
} from '../features/reveal-controller.js';
import {
  addNewStudent,
  applyParsedExcelRoster,
  closeExcelPasteModal,
  openExcelPasteModal,
  updateExcelLivePreview
} from '../features/roster-actions.js';
import {
  initRouletteSession,
  spinRouletteColumn,
  spinRouletteOnce,
  stopRouletteColumnAuto
} from '../features/roulette-controller.js';
import { applyDefaultGridAlignment } from '../features/seat-actions.js';
import { arrangeByStudentNumber, handleShuffleButtonClick } from '../features/seating-actions.js';
import {
  applyNormalLocksSyncToSecret,
  requestSyncNormalLocksToSecret
} from '../features/secret-room-actions.js';
import {
  checkForAppUpdate,
  closeAppUpdateModal,
  closeTamperWarningModal,
  downloadAndSaveLatestProgram,
  getRuntimePkgSha256,
  hasRemoteUpdateInfo,
  openAppUpdateModal,
  setUpdateModalStatus
} from '../features/updater-ui.js';
import { playSoundEffect } from '../infra/audio.js';
import {
  loadFromStorage,
  saveToStorage,
  saveWithFileExplorer,
  triggerBrowserDownload
} from '../infra/storage-io.js';
import { clearUndoHistory, pushUndoSnapshot } from '../state/history-store.js';
import { AppStore } from '../state/store.js';
import { markDirty } from '../ui/dirty-indicator.js';
import { isRouletteBlockingEdit } from '../ui/guards.js';
import {
  checkSecretRoomLayoutMismatch,
  updateSecretPresetIndicator
} from '../ui/secret-indicators.js';
import { showToast } from '../ui/toast.js';
import { renderClassroom } from '../views/classroom-view.js';
import {
  closeStatusHistoryPopover,
  toggleStatusHistoryPopover,
  updateUndoButtonState
} from '../views/history-popover.js';
import {
  captureAndSavePrintLayout,
  closePrintOptionsModal,
  executePrintFromModal,
  openPrintOptionsModal,
  updatePrintOptionsModalUI
} from '../views/print-view.js';
import { renderRoster } from '../views/roster-view.js';
import {
  addFrontRowStudentWithOverflowCheck,
  addSeparationPairRule,
  addTogetherPairRule,
  closePairOptionModal,
  openPairOptionModal,
  updateRulesUI
} from '../views/rules-modal-view.js';
import {
  toggleLeftSidebar,
  updateLargeViewButtonUI,
  updateRevealAllButton
} from '../views/toolbar-ui.js';
import { restoreHistoryAtIndex } from './history-coordinator.js';
import { toggleRouletteDrawer, toggleSecretRoom } from './mode-coordinator.js';
import {
  applyRulesAndCloseModal,
  cancelRulesModal,
  openRulesModal
} from './rules-coordinator.js';
import { wireAppCoordinators } from './view-sync-coordinator.js';

export function initApp() {
  // 0단계: 모든 Store 훅 및 View 핸들러를 최우선으로 동기 등록한다.
  wireAppCoordinators();

  const loaded = loadFromStorage();
  const hadCorruptedStorage = Boolean(AppStore.getState()._corruptedStorageRecovered);
  if (!loaded) {
    AppStore.resetState();
  }

  const dateEl = document.getElementById('paperDateDisplay');
  if (dateEl) {
    const today = new Date();
    dateEl.textContent = `${today.getFullYear()}. ${String(today.getMonth() + 1).padStart(2, '0')}. ${String(today.getDate()).padStart(2, '0')} 기준`;
  }

  document.getElementById('closeSelfTestModalBtn').addEventListener('click', closeSelfTestModal);
  document.getElementById('doneSelfTestModalBtn').addEventListener('click', closeSelfTestModal);
  document.getElementById('rerunSelfTestBtn').addEventListener('click', runAutomatedSelfDiagnostics);
  document.getElementById('selfTestModal').addEventListener('click', (e) => {
    if (e.target && e.target.id === 'selfTestModal') closeSelfTestModal();
  });

  // 좌측 상단 아이콘(및 제목) 클릭 단축키:
  // - Ctrl(또는 Cmd) + 클릭: 비밀의 방 전환
  // - Alt + 클릭: 내장 자가 진단(자동화 테스트) 실행
  const handleBrandHeaderShortcutClick = (e) => {
    if (e.altKey) {
      e.preventDefault();
      runAutomatedSelfDiagnostics();
    } else if (e.ctrlKey || e.metaKey) {
      e.preventDefault();
      toggleSecretRoom();
    }
  };
  document.getElementById('secretRoomTriggerBtn').addEventListener('click', handleBrandHeaderShortcutClick);
  document.getElementById('appHeaderTitle').addEventListener('click', handleBrandHeaderShortcutClick);

  // 전역 키보드 단축키:
  // - Alt + Shift + T: 내장 자가 진단 실행
  // - Escape(ESC): 잘못 선택한 학생(책상) 이동 대기 상태 취소, 1줄 연속 룰렛 정지, 팝오버 닫기
  window.addEventListener('keydown', (e) => {
    const state = AppStore.getState();
    if (e.altKey && e.shiftKey && (e.key === 'T' || e.key === 't' || e.code === 'KeyT')) {
      e.preventDefault();
      runAutomatedSelfDiagnostics();
      return;
    }
    if (e.key === 'Escape' || e.code === 'Escape') {
      const overflowModal = document.getElementById('frontRowOverflowModal');
      if (overflowModal && !overflowModal.classList.contains('hidden')) {
        overflowModal.classList.add('hidden');
        overflowModal.classList.remove('flex');
        return;
      }
      const tamperModalEl = document.getElementById('tamperWarningModal');
      if (tamperModalEl && !tamperModalEl.classList.contains('hidden')) {
        closeTamperWarningModal();
        return;
      }
      const closeBtnModalPairs = [
        ['alignLockConfirmModal', 'alignCancelModalBtn'],
        ['syncLockConflictModal', 'syncConflictCancelBtn'],
        ['printOptionsModal', 'closePrintOptionsModalBtn'],
        ['appUpdateModal', 'closeAppUpdateModalBtn'],
        ['jsonImportOverwriteConfirmModal', 'jsonImportOverwriteCancelBtn'],
        ['saveFileModal', 'cancelSaveModalBtn'],
        ['excelOverwriteConfirmModal', 'excelOverwriteCancelBtn'],
        ['excelPasteModal', 'closeExcelModalBtn'],
        ['secretNoticeModal', 'secretNoticeCloseBtn'],
        ['pairOptionModal', 'closePairOptionModalBtn'],
        ['rulesModal', 'closeRulesModalBtn'],
        ['selfTestModal', 'closeSelfTestModalBtn']
      ];
      for (const [modalId, closeBtnId] of closeBtnModalPairs) {
        if (modalId === 'selfTestModal' && AppStore.isRunningSelfDiagnostics()) continue;
        const mEl = document.getElementById(modalId);
        if (mEl && !mEl.classList.contains('hidden')) {
          const cBtn = document.getElementById(closeBtnId);
          if (cBtn) cBtn.click();
          else { mEl.classList.add('hidden'); mEl.classList.remove('flex'); }
          return;
        }
      }
      if (state.selectedStudentId !== null) {
        state.selectedStudentId = null;
        playSoundEffect('unlock');
        renderRoster();
        renderClassroom(false);
        showToast('학생 자리 선택이 취소되었습니다.', 'info');
        return;
      }
      if (state.rouletteAutoColumnTarget !== null) {
        stopRouletteColumnAuto();
        showToast('1줄(세로) 연속 뽑기가 취소되었습니다.', 'info');
        return;
      }
      closeStatusHistoryPopover();
    }
  });

  // 비밀의 방 배너 내 제어 버튼 이벤트 연결
  document.getElementById('exitSecretRoomBtn').addEventListener('click', () => {
    toggleSecretRoom(false);
  });
  document.getElementById('copyCurrentToSecretBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    pushUndoSnapshot('현재 일반 자리 불러오기', {
      locks: { lockedIds: [...state.lockedIds], secretLockedIds: [...state.secretLockedIds] },
      overwrittenLockIds: [...state.lockedIds]
    });
    state.secretPos = JSON.parse(JSON.stringify(state.pos));
    state.secretLockedIds = [...state.lockedIds];
    state.selectedStudentId = null;
    markDirty(true);
    checkSecretRoomLayoutMismatch(false);
    renderRoster();
    renderClassroom(true);
    saveToStorage(false);
    showToast('현재 일반 화면의 자리 배치와 잠금장치를 비밀의 방으로 불러왔습니다.', 'secret');
  });
  document.getElementById('clearSecretPresetBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    state.secretPos = null;
    state.secretLockedIds = [];
    state.undoStackSecret = [];
    updateUndoButtonState();
    markDirty(true);
    toggleSecretRoom(false);
    saveToStorage(false);
  });

  // 좌측 사이드바 접기 및 펼치기 버튼 이벤트 연결
  document.getElementById('collapseSidebarBtn').addEventListener('click', () => {
    toggleLeftSidebar(true);
  });
  document.getElementById('expandSidebarBtn').addEventListener('click', () => {
    toggleLeftSidebar(false);
  });

  // 학급 제목 입력 이벤트 연결 (연속 타이핑 중 인쇄 뷰 및 스토리지 기록 디바운싱)
  const titleInput = document.getElementById('classTitleInput');
  titleInput.value = AppStore.getState().classTitle;
  titleInput.addEventListener('input', (e) => {
    AppStore.getState().classTitle = e.target.value;
    AppStore.scheduleDebouncedCommit(200);
  });
  window.addEventListener('beforeprint', () => AppStore.flushPendingCommit(true));
  window.addEventListener('beforeunload', () => AppStore.flushPendingCommit(false));
  // 다중 탭 동시 실행 시 다른 탭에서 저장한 최신 학급 상태를 실시간으로 동기화하여 이전 탭이 새 작업을 덮어쓰지 않도록 보호한다.
  window.addEventListener('storage', (e) => {
    const state = AppStore.getState();
    if (!e || e.key !== STORAGE_KEY || !e.newValue) return;
    if (AppStore.isRunningSelfDiagnostics() || state.rouletteSpinning) return;
    try {
      const parsed = parseSeatFileText(e.newValue);
      if (AppStore.applyLoadedData(parsed, state.classTitle, true)) {
        const curState = AppStore.getState();
        AppStore.clearPendingCommitTimer();
        stopSequentialReveal();
        AppStore.resetTransientSession();
        clearUndoHistory();
        curState.rulesModalBackup = null;
        curState.lastSavedAt = parsed.lastSavedAt || curState.lastSavedAt || null;
        if (curState.inSecretRoom && !curState.secretPos) {
          toggleSecretRoom(false, true);
        }
        if (titleInput) titleInput.value = curState.classTitle;
        if (curState.rouletteOpen) {
          initRouletteSession(false);
        }
        updateSecretPresetIndicator();
        markDirty(false);
        AppStore.syncViews({ roster: true, classroom: true, animate: false, print: true, rules: true });
        const savedTimeEl = document.getElementById('savedTimeText');
        if (savedTimeEl && curState.lastSavedAt) {
          savedTimeEl.textContent = `자동저장 (${curState.lastSavedAt})`;
        }
        showToast('다른 탭에서 변경된 자리 배치가 자동으로 동기화되었습니다.', 'info');
      }
    } catch (err) {}
  });

  const secretNoticeModalEl = document.getElementById('secretNoticeModal');
  const closeSecretNotice = () => { secretNoticeModalEl.classList.add('hidden'); secretNoticeModalEl.classList.remove('flex'); };
  document.getElementById('secretNoticeCloseBtn').addEventListener('click', closeSecretNotice);
  secretNoticeModalEl.addEventListener('click', (e) => { if (e.target === secretNoticeModalEl) closeSecretNotice(); });

  const alignLockConfirmModalEl = document.getElementById('alignLockConfirmModal');
  const closeAlignLockConfirmModal = () => {
    if (alignLockConfirmModalEl) {
      alignLockConfirmModalEl.classList.add('hidden');
      alignLockConfirmModalEl.classList.remove('flex');
    }
  };
  document.getElementById('alignCancelModalBtn').addEventListener('click', closeAlignLockConfirmModal);
  alignLockConfirmModalEl.addEventListener('click', (e) => { if (e.target === alignLockConfirmModalEl) closeAlignLockConfirmModal(); });
  document.getElementById('alignKeepLocksBtn').addEventListener('click', () => {
    closeAlignLockConfirmModal();
    applyDefaultGridAlignment(true, null);
  });
  document.getElementById('alignUnlockAllBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    closeAlignLockConfirmModal();
    const locksBefore = { lockedIds: [...state.lockedIds], secretLockedIds: [...state.secretLockedIds] };
    if (state.inSecretRoom) {
      state.secretLockedIds = [];
    } else {
      state.lockedIds = [];
    }
    applyDefaultGridAlignment(true, locksBefore);
  });

  document.getElementById('RestoreStandardDesksBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    if (isRouletteBlockingEdit()) return;
    const activeLocks = state.inSecretRoom ? state.secretLockedIds : state.lockedIds;
    if (Array.isArray(activeLocks) && activeLocks.length > 0 && alignLockConfirmModalEl) {
      const descEl = document.getElementById('alignLockConfirmDesc');
      if (descEl) {
        descEl.textContent = `현재 자물쇠(🔒)로 고정된 학생이 ${activeLocks.length}명 있습니다. 기본 대형 정렬 시 고정된 학생의 자리를 어떻게 처리할까요?`;
      }
      alignLockConfirmModalEl.classList.remove('hidden');
      alignLockConfirmModalEl.classList.add('flex');
      return;
    }
    applyDefaultGridAlignment(true, null);
  });

  const syncLockConflictModalEl = document.getElementById('syncLockConflictModal');
  const closeSyncLockConflictModal = () => {
    if (syncLockConflictModalEl) {
      syncLockConflictModalEl.classList.add('hidden');
      syncLockConflictModalEl.classList.remove('flex');
    }
  };
  document.getElementById('syncNormalLocksToSecretBtn').addEventListener('click', requestSyncNormalLocksToSecret);
  document.getElementById('syncConflictCancelBtn').addEventListener('click', closeSyncLockConflictModal);
  syncLockConflictModalEl.addEventListener('click', (e) => { if (e.target === syncLockConflictModalEl) closeSyncLockConflictModal(); });
  document.getElementById('syncConflictOverwriteBtn').addEventListener('click', () => {
    closeSyncLockConflictModal();
    applyNormalLocksSyncToSecret(true);
  });
  document.getElementById('syncConflictSkipBtn').addEventListener('click', () => {
    closeSyncLockConflictModal();
    applyNormalLocksSyncToSecret(false);
  });

  // 되돌리기 버튼 및 상태 표시줄 히스토리 팝업 이벤트 연결
  document.getElementById('undoSeatBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    const stack = state.inSecretRoom ? state.undoStackSecret : state.undoStackNormal;
    if (!stack || stack.length === 0) return;
    restoreHistoryAtIndex(stack.length - 1);
  });

  document.getElementById('modeStatusPill').addEventListener('click', (e) => {
    e.stopPropagation();
    toggleStatusHistoryPopover();
  });

  document.addEventListener('click', (e) => {
    const wrapper = document.getElementById('statusHistoryWrapper');
    if (wrapper && !wrapper.contains(e.target)) {
      closeStatusHistoryPopover();
    }
  });

  // 저장하기 버튼 이벤트 연결
  document.getElementById('saveStateBtn').addEventListener('click', saveWithFileExplorer);

  // 파일 저장 모달 버튼 이벤트 연결
  const saveFileModal = document.getElementById('saveFileModal');
  document.getElementById('cancelSaveModalBtn').addEventListener('click', () => {
    saveFileModal.classList.add('hidden');
    saveFileModal.classList.remove('flex');
  });
  document.getElementById('confirmSaveModalBtn').addEventListener('click', () => {
    const nameVal = document.getElementById('saveFileNameInput').value;
    saveFileModal.classList.add('hidden');
    saveFileModal.classList.remove('flex');
    triggerBrowserDownload(nameVal);
  });

  // 이름 가리기 모드 및 순차·전체 공개 버튼 이벤트 연결
  document.getElementById('toggleMaskModeBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    stopSequentialReveal();
    state.maskModeEnabled = !state.maskModeEnabled;
    if (!state.maskModeEnabled) {
      state.hiddenSeatIds = [];
      showToast('자리 가리기 모드가 해제되어 모든 이름이 표시됩니다.', 'info');
    } else {
      showToast('가리기 모드가 켜졌습니다! [자리 바꾸기]를 누르면 이름이 가려집니다.', 'info');
    }
    AppStore.commitChange({ classroom: true, animate: false, dirty: true, save: true });
  });

  document.getElementById('sequentialRevealBtn').addEventListener('click', startSequentialReveal);

  document.getElementById('revealAllHiddenBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    stopSequentialReveal();
    state.hiddenSeatIds = [];
    playSoundEffect('revealAll');
    updateRevealAllButton();
    renderClassroom(true);
    saveToStorage(false);
    showToast('가려진 모든 학생의 자리 이름이 한 번에 공개되었습니다!', 'success');
  });

  document.getElementById('toggleSoundBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    state.soundEnabled = state.soundEnabled === false;
    AppStore.commitChange({ dirty: true, save: true });
    if (state.soundEnabled) {
      playSoundEffect('toggle');
      showToast('🔊 효과음이 켜졌습니다 (자리 바꾸기·수동 교환·잠금·룰렛·가리기 공개 시 재생).', 'info');
    } else {
      showToast('🔇 효과음이 꺼졌습니다.', 'info');
    }
  });

  // 룰렛 패널 열기·닫기 및 회전 버튼 이벤트 연결
  document.getElementById('toggleRouletteBtn').addEventListener('click', (e) => {
    const isCtrlPressed = Boolean(e && (e.ctrlKey || e.metaKey));
    toggleRouletteDrawer(undefined, isCtrlPressed);
  });
  document.getElementById('closeRouletteDrawerBtn').addEventListener('click', () => {
    toggleRouletteDrawer(false, false);
  });
  document.getElementById('resetRouletteSessionBtn').addEventListener('click', () => {
    initRouletteSession(false);
    showToast('룰렛 배정 순서가 처음부터 다시 초기화되었습니다.', 'info');
  });
  document.getElementById('rouletteWheelCanvas').addEventListener('click', spinRouletteOnce);
  document.getElementById('spinWheelCenterBtn').addEventListener('click', spinRouletteOnce);
  document.getElementById('spinRouletteActionBtn').addEventListener('click', spinRouletteOnce);
  document.getElementById('spinRouletteColumnBtn').addEventListener('click', spinRouletteColumn);

  // 배치 조건 설정 모달 및 거리두기 모달 이벤트 연결
  document.getElementById('openRulesModalBtn').addEventListener('click', openRulesModal);
  document.getElementById('closeRulesModalBtn').addEventListener('click', cancelRulesModal);
  document.getElementById('doneRulesModalBtn').addEventListener('click', cancelRulesModal);
  document.getElementById('applyRulesAndShuffleBtn').addEventListener('click', applyRulesAndCloseModal);

  document.querySelectorAll('.default-cols-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const state = AppStore.getState();
      if (isRouletteBlockingEdit()) return;
      const prevCols = Number(state.rules.defaultCols) || 6;
      state.rules.defaultCols = Number(btn.getAttribute('data-default-cols')) || 6;
      updateRulesUI();
      applyDefaultGridAlignment(true, null, prevCols);
    });
  });

  document.getElementById('modalGenderDistinctionToggle').addEventListener('change', (e) => {
    const state = AppStore.getState();
    state.rules.useGenderDistinction = e.target.checked;
    if (!state.rules.useGenderDistinction) {
      state.rules.genderPairMode = 'any';
      if (state.printShadeMode === 'female' || state.printShadeMode === 'male') {
        state.printShadeMode = 'zebra';
      }
      if (state.printShadeMode === 'zebra') {
        state.printShadeSeatEnabled = false;
      }
    }
    AppStore.commitChange({ roster: true, classroom: true, animate: false, print: true, rules: true, dirty: true, save: true });
    showToast(
      state.rules.useGenderDistinction
        ? '남/여 구분이 활성화되어 명렬표에 성별이 표시됩니다.'
        : '남/여 구분 안 함으로 설정되어 학생 명렬표에서 성별 구분이 숨겨졌습니다.',
      'info'
    );
  });

  // 엑셀 명렬표 붙여넣기 모달 이벤트 연결
  const excelTextarea = document.getElementById('excelPasteTextarea');
  document.getElementById('openExcelPasteModalBtn').addEventListener('click', openExcelPasteModal);
  document.getElementById('closeExcelModalBtn').addEventListener('click', closeExcelPasteModal);
  document.getElementById('cancelExcelModalBtn').addEventListener('click', closeExcelPasteModal);
  excelTextarea.addEventListener('input', updateExcelLivePreview);
  document.getElementById('clearExcelTextareaBtn').addEventListener('click', () => {
    excelTextarea.value = '';
    updateExcelLivePreview();
    excelTextarea.focus();
  });
  document.getElementById('fillSampleExcelBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    excelTextarea.value = state.students.map(st => `${st.num}\t${st.name}\t${st.gender}`).join('\n');
    updateExcelLivePreview();
  });
  document.getElementById('applyExcelRosterBtn').addEventListener('click', () => applyParsedExcelRoster(false));
  const excelOverwriteModal = document.getElementById('excelOverwriteConfirmModal');
  const closeExcelOverwriteModal = () => {
    if (!excelOverwriteModal) return;
    excelOverwriteModal.classList.add('hidden');
    excelOverwriteModal.classList.remove('flex');
  };
  const excelOverwriteCancelBtn = document.getElementById('excelOverwriteCancelBtn');
  const excelOverwriteConfirmBtn = document.getElementById('excelOverwriteConfirmBtn');
  if (excelOverwriteCancelBtn) excelOverwriteCancelBtn.addEventListener('click', closeExcelOverwriteModal);
  if (excelOverwriteConfirmBtn) {
    excelOverwriteConfirmBtn.addEventListener('click', () => {
      closeExcelOverwriteModal();
      applyParsedExcelRoster(true);
    });
  }
  if (excelOverwriteModal) {
    excelOverwriteModal.addEventListener('click', (e) => {
      if (e.target === excelOverwriteModal) closeExcelOverwriteModal();
    });
  }

  document.querySelectorAll('.pair-rule-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      AppStore.getState().rules.genderPairMode = btn.getAttribute('data-pair-rule');
      AppStore.commitChange({ rules: true, dirty: true, save: true });
    });
  });

  document.getElementById('addSeparationBtn').addEventListener('click', addSeparationPairRule);
  document.getElementById('addTogetherBtn').addEventListener('click', addTogetherPairRule);
  document.getElementById('excludePrevSeatToggle').addEventListener('change', (e) => {
    AppStore.getState().rules.excludePreviousSeat = e.target.checked;
    AppStore.commitChange({ rules: true, dirty: true, save: true });
  });

  document.getElementById('openPairOptionModalBtn').addEventListener('click', openPairOptionModal);
  document.getElementById('closePairOptionModalBtn').addEventListener('click', closePairOptionModal);
  document.getElementById('donePairOptionModalBtn').addEventListener('click', closePairOptionModal);

  document.getElementById('clearAllSeparationsBtn').addEventListener('click', () => {
    AppStore.getState().rules.separatedPairs = [];
    AppStore.commitChange({ rules: true, dirty: true, save: true });
    showToast('등록된 모든 거리두기(짝꿍 분리) 조건이 비워졌습니다.', 'secret');
  });
  document.getElementById('clearAllTogethersBtn').addEventListener('click', () => {
    AppStore.getState().rules.togetherPairs = [];
    AppStore.commitChange({ rules: true, dirty: true, save: true });
    showToast('등록된 모든 친구끼리 붙이기(짝꿍) 조건이 비워졌습니다.', 'secret');
  });

  const frontRowOverflowModalEl = document.getElementById('frontRowOverflowModal');
  const closeFrontRowOverflowModal = () => {
    if (frontRowOverflowModalEl) {
      frontRowOverflowModalEl.classList.add('hidden');
      frontRowOverflowModalEl.classList.remove('flex');
    }
  };
  const overflowCloseBtn = document.getElementById('frontRowOverflowCloseBtn');
  if (overflowCloseBtn) overflowCloseBtn.addEventListener('click', closeFrontRowOverflowModal);
  if (frontRowOverflowModalEl) {
    frontRowOverflowModalEl.addEventListener('click', (e) => {
      if (e.target === frontRowOverflowModalEl) closeFrontRowOverflowModal();
    });
  }

  document.getElementById('addFrontRowBtn').addEventListener('click', addFrontRowStudentWithOverflowCheck);
  document.getElementById('clearFrontRowBtn').addEventListener('click', () => {
    AppStore.getState().rules.frontRowIds = [];
    AppStore.commitChange({ rules: true, dirty: true, save: true });
    showToast('앞줄 우선 배정 목록이 모두 비워졌습니다.', 'info');
  });
  document.getElementById('clearAllRulesBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    state.rules.genderPairMode = 'any';
    state.rules.excludePreviousSeat = false;
    state.rules.frontRowIds = [];
    AppStore.commitChange({ rules: true, dirty: true, save: true });
    showToast('배치 조건이 초기화되었습니다.', 'info');
  });

  // JSON 파일 불러오기 이벤트 연결
  const fileInput = document.getElementById('jsonFileInput');
  const jsonOverwriteModal = document.getElementById('jsonImportOverwriteConfirmModal');
  const jsonOverwriteDesc = document.getElementById('jsonImportOverwriteConfirmDesc');
  let pendingImportFile = null;

  const closeJsonOverwriteModal = (resetInput = false) => {
    if (jsonOverwriteModal) {
      jsonOverwriteModal.classList.add('hidden');
      jsonOverwriteModal.classList.remove('flex');
    }
    if (resetInput) {
      pendingImportFile = null;
      fileInput.value = '';
    }
  };

  const MAX_IMPORT_FILE_BYTES = 10 * 1024 * 1024; // 10MB 상한 가드

  const executeJsonFileImport = (file) => {
    if (!file) {
      fileInput.value = '';
      return;
    }
    if (typeof file.size === 'number' && file.size > MAX_IMPORT_FILE_BYTES) {
      showToast('파일 크기가 10MB를 초과해 불러올 수 없습니다. 올바른 자리 배치 파일인지 확인해 주세요.', 'warn');
      fileInput.value = '';
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const state = AppStore.getState();
        const parsed = parseSeatFileText(ev.target.result);
        if (AppStore.applyLoadedData(parsed, state.classTitle)) {
          const curState = AppStore.getState();
          AppStore.clearPendingCommitTimer();
          stopSequentialReveal();
          stopRouletteColumnAuto();
          AppStore.resetTransientSession();
          clearUndoHistory();
          curState.rulesModalBackup = null;
          if (curState.inSecretRoom && !curState.secretPos) {
            toggleSecretRoom(false, true);
          }
          if (curState.rouletteOpen) initRouletteSession(false);
          document.getElementById('classTitleInput').value = curState.classTitle;
          markDirty(false);
          AppStore.commitChange({ roster: true, classroom: true, animate: true, print: true, rules: true, dirty: false, save: true });
          showToast('저장된 파일에서 명렬표와 자리 배치를 불러왔습니다.', 'success');
        } else {
          showToast('올바른 자리 배치 파일 형식이 아닙니다.', 'warn');
        }
      } catch (err) {
        showToast('파일을 읽는 중 오류가 발생했습니다.', 'warn');
      }
      fileInput.value = '';
    };
    reader.onerror = () => {
      showToast('파일을 읽는 중 오류가 발생했습니다. 파일 권한이나 손상 여부를 확인해 주세요.', 'warn');
      fileInput.value = '';
    };
    reader.readAsText(file);
  };

  const jsonOverwriteCancelBtn = document.getElementById('jsonImportOverwriteCancelBtn');
  const jsonOverwriteConfirmBtn = document.getElementById('jsonImportOverwriteConfirmBtn');
  if (jsonOverwriteCancelBtn) {
    jsonOverwriteCancelBtn.addEventListener('click', () => closeJsonOverwriteModal(true));
  }
  if (jsonOverwriteConfirmBtn) {
    jsonOverwriteConfirmBtn.addEventListener('click', () => {
      const targetFile = pendingImportFile;
      pendingImportFile = null;
      closeJsonOverwriteModal(false);
      executeJsonFileImport(targetFile);
    });
  }
  if (jsonOverwriteModal) {
    jsonOverwriteModal.addEventListener('click', (e) => {
      if (e.target === jsonOverwriteModal) closeJsonOverwriteModal(true);
    });
  }

  document.getElementById('importJsonBtn').addEventListener('click', () => {
    fileInput.click();
  });
  fileInput.addEventListener('change', (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    if (typeof file.size === 'number' && file.size > MAX_IMPORT_FILE_BYTES) {
      showToast('파일 크기가 10MB를 초과해 불러올 수 없습니다. 올바른 자리 배치 파일인지 확인해 주세요.', 'warn');
      fileInput.value = '';
      return;
    }
    if (AppStore.getState().isDirty && !AppStore.isRunningSelfDiagnostics() && jsonOverwriteModal) {
      pendingImportFile = file;
      if (jsonOverwriteDesc) {
        const fname = file.name ? `"${file.name}"` : '선택한 파일';
        jsonOverwriteDesc.textContent = `현재 저장되지 않은 변경 사항이 있습니다. ${fname}을(를) 불러오면 현재 작업과 되돌리기 기록이 덮어씌워집니다. 계속 불러오시겠습니까?`;
      }
      jsonOverwriteModal.classList.remove('hidden');
      jsonOverwriteModal.classList.add('flex');
      return;
    }
    executeJsonFileImport(file);
  });

  // 학생 추가 버튼 이벤트 연결
  document.getElementById('addStudentBtn').addEventListener('click', addNewStudent);

  // 학생 게시용 / 교탁 게시용 시점 전환 버튼 이벤트 연결
  document.getElementById('viewStudentBtn').addEventListener('click', () => {
    AppStore.getState().viewOrientation = 'student';
    AppStore.commitChange({ classroom: true, animate: true, print: true, dirty: true, save: true });
  });
  document.getElementById('viewTeacherBtn').addEventListener('click', () => {
    AppStore.getState().viewOrientation = 'teacher';
    AppStore.commitChange({ classroom: true, animate: true, print: true, dirty: true, save: true });
  });

  // 좌석 성별 색상 표시 체크박스 이벤트 연결
  const genderToggle = document.getElementById('showGenderColorToggle');
  genderToggle.checked = AppStore.getState().showGenderColor;
  genderToggle.addEventListener('change', (e) => {
    AppStore.getState().showGenderColor = e.target.checked;
    AppStore.commitChange({ classroom: true, animate: false, dirty: true, save: true });
  });

  // 자리 바꾸기 및 번호순 배치 버튼 이벤트 연결
  document.getElementById('randomShuffleBtn').addEventListener('click', (e) => {
    handleShuffleButtonClick(e);
  });
  document.getElementById('numberOrderBtn').addEventListener('click', arrangeByStudentNumber);

  // A4 가로 출력 · 캡처 설정 모달 이벤트 연결
  document.getElementById('printA4Btn').addEventListener('click', openPrintOptionsModal);
  document.getElementById('closePrintOptionsModalBtn').addEventListener('click', closePrintOptionsModal);
  document.getElementById('cancelPrintOptionsModalBtn').addEventListener('click', closePrintOptionsModal);
  document.getElementById('confirmPrintActionBtn').addEventListener('click', executePrintFromModal);
  document.getElementById('capturePrintLayoutBtn').addEventListener('click', captureAndSavePrintLayout);
  const printOptionsModalEl = document.getElementById('printOptionsModal');
  if (printOptionsModalEl) {
    printOptionsModalEl.addEventListener('click', (e) => {
      if (e.target === printOptionsModalEl) closePrintOptionsModal();
    });
  }
  document.querySelectorAll('.print-orient-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      AppStore.getState().printOrientation = btn.getAttribute('data-print-orient') === 'teacher' ? 'teacher' : 'student';
      updatePrintOptionsModalUI();
      AppStore.commitChange({ print: true, dirty: false, save: true });
    });
  });
  document.querySelectorAll('.print-roster-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      AppStore.getState().printIncludeRoster = btn.getAttribute('data-print-roster') !== 'off';
      updatePrintOptionsModalUI();
      AppStore.commitChange({ print: true, dirty: false, save: true });
    });
  });
  document.querySelectorAll('.print-shade-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const state = AppStore.getState();
      const modeVal = btn.getAttribute('data-print-shade');
      if (['zebra', 'female', 'male', 'none'].includes(modeVal)) {
        const prevMode = state.printShadeMode;
        state.printShadeMode = modeVal;
        if (prevMode !== 'zebra' && modeVal === 'zebra' && state.rules && state.rules.useGenderDistinction === false) {
          state.printShadeSeatEnabled = false;
        }
        updatePrintOptionsModalUI();
        AppStore.commitChange({ print: true, dirty: false, save: true });
      }
    });
  });
  const printShadeToSeatToggleEl = document.getElementById('printShadeToSeatToggle');
  if (printShadeToSeatToggleEl) {
    printShadeToSeatToggleEl.addEventListener('change', (e) => {
      AppStore.getState().printShadeSeatEnabled = Boolean(e.target.checked);
      updatePrintOptionsModalUI();
      AppStore.commitChange({ print: true, dirty: false, save: true });
    });
  }

  document.getElementById('toggleLargeViewBtn').addEventListener('click', () => {
    toggleLargeViewMode();
  });
  document.addEventListener('fullscreenchange', () => {
    const state = AppStore.getState();
    if (!document.fullscreenElement && state.largeViewEnabled) {
      state.largeViewEnabled = false;
      toggleLeftSidebar(false);
      updateLargeViewButtonUI();
      renderClassroom(false);
    }
  });

  // 우측 화면 하단 및 설정 창 하단에 현재 버전(버전 vX.XX) 표시
  const footerVerText = document.getElementById('appVersionFooterText');
  if (footerVerText) footerVerText.textContent = '버전 v' + APP_VERSION;
  const rulesVerText = document.getElementById('rulesModalVersionText');
  if (rulesVerText) rulesVerText.textContent = '버전 v' + APP_VERSION;

  // 업데이트 모달 및 관련 버튼 이벤트 연결
  document.getElementById('openAppUpdateModalBtn').addEventListener('click', openAppUpdateModal);
  document.getElementById('closeAppUpdateModalBtn').addEventListener('click', closeAppUpdateModal);
  document.getElementById('doneAppUpdateModalBtn').addEventListener('click', closeAppUpdateModal);
  document.getElementById('appUpdateModal').addEventListener('click', (e) => {
    if (e.target && e.target.id === 'appUpdateModal') closeAppUpdateModal();
  });
  document.getElementById('updateModalBackupJsonBtn').addEventListener('click', () => {
    const fileName = sanitizeFileName(AppStore.getState().classTitle || '우리반_자리배치');
    triggerBrowserDownload(fileName);
    setUpdateModalStatus('① 현재 자리 JSON 백업 파일이 저장되었습니다. 이제 ② [최신 버전 받기]를 눌러 주세요.', 'info');
  });
  document.getElementById('downloadLatestProgramBtn').addEventListener('click', downloadAndSaveLatestProgram);
  document.getElementById('appVersionFooterBadge').addEventListener('click', () => {
    if (hasRemoteUpdateInfo()) {
      openAppUpdateModal();
    } else {
      checkForAppUpdate(true);
    }
  });

  // 좁은 화면(모바일 등 폭 768px 미만)으로 처음 열었을 때는 좌측 명렬표 사이드바를 자동으로 접어 좌석표가 화면 안에 바로 보이도록 한다.
  if (typeof window !== 'undefined' && window.innerWidth > 0 && window.innerWidth < 768 && !AppStore.getState().sidebarCollapsed) {
    toggleLeftSidebar(true);
  }

  // 초기 화면 렌더링 (가리기·성별색상·명렬표·좌석표·인쇄뷰·조건배지 일괄 동기화)
  updateSecretPresetIndicator();
  AppStore.syncViews({ animate: false });
  if (hadCorruptedStorage) {
    showToast('저장된 데이터가 손상되어 백업 키에 보관하고 기본 상태로 시작했습니다.', 'warn');
  }

  const tamperConfirmBtn = document.getElementById('tamperWarningConfirmBtn');
  if (tamperConfirmBtn) {
    tamperConfirmBtn.addEventListener('click', () => {
      closeTamperWarningModal();
      openAppUpdateModal();
    });
  }

  // 부팅 직후 __app_pkg__ 해시를 1회 계산·캐시하고 임시 참조를 정리한다.
  getRuntimePkgSha256();
  // 앱 시작 시 조용히 최신 버전 및 파일 무결성 여부를 확인한다(1시간 간격 제한, 5초 타임아웃, 실패 시 무시).
  checkForAppUpdate(false);
}
