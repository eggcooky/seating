// [L3] 로컬 저장소(localStorage) 및 파일 저장/다운로드 어댑터
import { LEGACY_STORAGE_KEYS, STORAGE_KEY } from '../core/constants.js';
import { sanitizeFileName } from '../core/utils.js';
import { encodeObfuscatedPayload, isSimpleObfuscatedText, parseSeatFileText } from '../domain/codec.js';
import { AppStore } from '../state/store.js';
import { markDirty } from '../ui/dirty-indicator.js';
import { updateSecretPresetIndicator } from '../ui/secret-indicators.js';
import { showToast } from '../ui/toast.js';

export function getObfuscatedPayload() {
  const state = AppStore.getState();
  return encodeObfuscatedPayload(AppStore.getPersistedState(state));
}

export function saveToStorage(showNotification = false) {
  const state = AppStore.getState();
  const now = new Date();
  const timeStr = now.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  state.lastSavedAt = timeStr;
  let savedOk = false;
  try {
    localStorage.setItem(STORAGE_KEY, getObfuscatedPayload());
    savedOk = true;
  } catch (e) {
    savedOk = false;
  }
  const savedTimeEl = document.getElementById('savedTimeText');
  if (savedTimeEl) {
    savedTimeEl.textContent = savedOk ? `자동저장 (${timeStr})` : '임시 세션 (파일 저장 권장)';
  }
  updateSecretPresetIndicator();
  if (showNotification && savedOk) {
    showToast('현재 상태가 브라우저에 저장되었습니다.', 'success');
  }
}

export async function saveWithFileExplorer() {
  const state = AppStore.getState();
  AppStore.flushPendingCommit();
  saveToStorage(false);
  const suggestedName = `${sanitizeFileName(state.classTitle)}.json`;
  const dataStr = getObfuscatedPayload();

  if (typeof window.showSaveFilePicker === 'function') {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName,
        types: [{
          description: '자리 배치 JSON 파일',
          accept: { 'application/json': ['.json'] }
        }]
      });
      const writable = await handle.createWritable();
      await writable.write(dataStr);
      await writable.close();
      markDirty(false);
      const saveText = document.getElementById('saveStateBtnText');
      if (saveText) {
        saveText.textContent = '✓ 저장 완료';
        setTimeout(() => {
          const latestState = AppStore.getState();
          if (saveText) saveText.textContent = latestState.isDirty ? '저장하기 ●' : '저장하기';
        }, 1500);
      }
      showToast('지정한 폴더 위치에 파일이 성공적으로 저장되었습니다!', 'success');
      return;
    } catch (err) {
      if (err && err.name === 'AbortError') {
        showToast('파일 저장이 취소되었습니다.', 'info');
        return;
      }
    }
  }

  const modal = document.getElementById('saveFileModal');
  const input = document.getElementById('saveFileNameInput');
  if (modal && input) {
    input.value = suggestedName;
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    input.focus();
    input.select();
  }
}

export function triggerBrowserDownload(fileName) {
  let cleanName = sanitizeFileName((fileName || '우리반_자리배치표.json').replace(/\.json$/i, '')) + '.json';
  const dataStr = getObfuscatedPayload();
  const blob = new Blob([dataStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = cleanName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  markDirty(false);
  showToast(`'${cleanName}' 파일이 저장되었습니다.`, 'success');
}

export function loadFromStorage() {
  const state = AppStore.getState();
  let raw = null;
  let legacyKeyUsed = null;
  try {
    raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      for (const lk of LEGACY_STORAGE_KEYS) {
        const lraw = localStorage.getItem(lk);
        if (lraw) { raw = lraw; legacyKeyUsed = lk; break; }
      }
    }
    if (!raw) return false;
    const needsReObfuscate = !isSimpleObfuscatedText(raw);
    const parsed = parseSeatFileText(raw);
    if (AppStore.applyLoadedData(parsed, '우리 반 자리 배치표', true)) {
      const curState = AppStore.getState();
      curState.lastSavedAt = parsed.lastSavedAt || null;
      // 평문 데이터나 이전 키 데이터는 현재 형식으로 다시 저장하고 구버전 키를 정리한다.
      if (needsReObfuscate || legacyKeyUsed) {
        try {
          localStorage.setItem(STORAGE_KEY, getObfuscatedPayload());
          if (legacyKeyUsed) localStorage.removeItem(legacyKeyUsed);
        } catch (e) {}
      }
      return true;
    }
  } catch (e) {
    // 파싱 오류 발생 시 아래 손상 데이터 백업 처리로 이동한다.
  }
  if (raw && String(raw).trim()) {
    try {
      localStorage.setItem(STORAGE_KEY + '_corrupted_backup', String(raw));
    } catch (e) {}
    state._corruptedStorageRecovered = true;
    showToast('저장된 데이터가 손상되어 백업 키에 보관하고 기본 상태로 시작했습니다.', 'warn');
  }
  return false;
}
