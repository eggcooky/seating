// 시스템 내장 자가 진단 오케스트레이터 (실행 · 상태 원복 · 모달 결과 렌더링)
import { setInteractionMode, toggleSecretRoom } from '../app/mode-coordinator.js';
import { STORAGE_KEY } from '../core/constants.js';
import { escapeHtml } from '../core/utils.js';
import { parseSeatFileText } from '../domain/codec.js';
import { stopSequentialReveal } from '../features/reveal-controller.js';
import {
  drawRouletteWheel,
  stopRouletteColumnAuto,
  updateRouletteStatusUI
} from '../features/roulette-controller.js';
import { AppStore, setRunningSelfDiagnostics } from '../state/store.js';
import { markDirty } from '../ui/dirty-indicator.js';
import { updateSecretPresetIndicator } from '../ui/secret-indicators.js';
import { showToast } from '../ui/toast.js';
import { updateUndoButtonState } from '../views/history-popover.js';
import { toggleLeftSidebar } from '../views/toolbar-ui.js';
import { assertGlobalInvariants, assertValidUniqueCoords, createSeededRng, setupClassRoster } from './helpers.js';
import { runAlgorithmDiagnostics } from './suite-01-algorithm.js';
import { runFeatureDiagnostics } from './suite-02-features.js';
import { runSystemDiagnostics } from './suite-03-system.js';
import { runRegressionAndMonkeyDiagnostics } from './suite-04-regression-monkey.js';

export function runAutomatedSelfDiagnostics() {
  if (AppStore.isRunningSelfDiagnostics()) return;
  AppStore.flushPendingCommit();
  setRunningSelfDiagnostics(true);
  stopSequentialReveal();

  const modal = document.getElementById('selfTestModal');
  const listEl = document.getElementById('selfTestResultList');
  const summaryBanner = document.getElementById('selfTestSummaryBanner');
  const summaryTitle = document.getElementById('selfTestSummaryTitle');
  const summarySub = document.getElementById('selfTestSummarySub');
  const elapsedBadge = document.getElementById('selfTestElapsedBadge');

  if (modal) {
    modal.classList.remove('hidden');
    modal.classList.add('flex');
  }

  const startTime = performance.now();
  const backupStateJson = JSON.stringify(AppStore.getState());
  const savedTimeElRef = document.getElementById('savedTimeText');
  const backupSavedTimeText = savedTimeElRef ? savedTimeElRef.textContent : null;
  let backupStorageRaw = null;
  let backupCorruptedRaw = null;
  try {
    backupStorageRaw = localStorage.getItem(STORAGE_KEY);
    backupCorruptedRaw = localStorage.getItem(STORAGE_KEY + '_corrupted_backup');
  } catch (e) {}

  const results = [];
  const recordTest = (name, fn) => {
    const t0 = performance.now();
    try {
      const detail = fn();
      results.push({
        name,
        passed: true,
        detail: detail || '정상 동작 확인',
        ms: Math.max(1, Math.round(performance.now() - t0))
      });
    } catch (err) {
      results.push({
        name,
        passed: false,
        detail: (err && err.message) ? err.message : String(err),
        ms: Math.max(1, Math.round(performance.now() - t0))
      });
    }
  };

  try {
    const ctx = { recordTest, setupClassRoster, assertValidUniqueCoords, assertGlobalInvariants, createSeededRng };
    runAlgorithmDiagnostics(ctx);
    runFeatureDiagnostics(ctx);
    runSystemDiagnostics(ctx);
    runRegressionAndMonkeyDiagnostics(ctx);
  } finally {
    // 원본 상태 및 로컬 스토리지 완벽 복원 (예약 타이머·보조 모달·룰렛 드로어 포함)
    try {
      AppStore.clearPendingCommitTimer();
      stopSequentialReveal();
      stopRouletteColumnAuto();
      document.querySelectorAll('[role="dialog"]').forEach(dlg => {
        if (dlg.id !== 'selfTestModal') {
          dlg.classList.add('hidden');
          dlg.classList.remove('flex');
        }
      });
      const parsedBackup = JSON.parse(backupStateJson);
      const origSelectedId = parsedBackup.selectedStudentId !== undefined ? parsedBackup.selectedStudentId : null;
      const origIsDirty = Boolean(parsedBackup.isDirty);
      const origRouletteOpen = Boolean(parsedBackup.rouletteOpen);
      parsedBackup.rouletteSpinning = false;
      parsedBackup.rouletteAutoColumnTarget = null;
      AppStore.replaceState(parsedBackup);
      toggleSecretRoom(Boolean(parsedBackup.inSecretRoom), true);
      toggleLeftSidebar(Boolean(parsedBackup.sidebarCollapsed));
      setInteractionMode(true);
      const drawerEl = document.getElementById('rouletteDrawer');
      const rBtnEl = document.getElementById('toggleRouletteBtn');
      const rLabelEl = document.getElementById('toggleRouletteBtnLabel');
      if (drawerEl && rBtnEl && rLabelEl) {
        if (origRouletteOpen) {
          drawerEl.classList.remove('hidden');
          drawerEl.classList.add('flex');
          rBtnEl.className = 'flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-extrabold text-xs bg-fuchsia-600 text-white border border-fuchsia-700 shadow-sm transition';
          rLabelEl.textContent = '룰렛 닫기';
        } else {
          drawerEl.classList.add('hidden');
          drawerEl.classList.remove('flex');
          rBtnEl.className = 'flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-extrabold text-xs bg-fuchsia-50 text-fuchsia-700 hover:bg-fuchsia-100 border border-fuchsia-200 transition';
          rLabelEl.textContent = '룰렛';
        }
      }
      const restoredState = AppStore.getState();
      restoredState.selectedStudentId = origSelectedId;
      const titleInputRef = document.getElementById('classTitleInput');
      if (titleInputRef) titleInputRef.value = restoredState.classTitle;
      markDirty(origIsDirty);
    } catch (restoreErr) {
      console.error('[selfDiagnostics] 상태 원복 중 오류 발생, 저장소 백업으로 복구를 시도합니다:', restoreErr);
      try {
        if (backupStorageRaw) {
          const fallbackParsed = parseSeatFileText(backupStorageRaw);
          if (fallbackParsed) AppStore.applyLoadedData(fallbackParsed, AppStore.getState().classTitle, true);
        }
      } catch (fallbackErr) {
        console.error('[selfDiagnostics] 저장소 백업 폴백 복구 실패:', fallbackErr);
      }
      showToast('자가 진단 종료 후 상태 복원 중 오류가 발생해 저장소 백업으로 복구를 시도했습니다.', 'warn');
    }
    AppStore.syncViews({ animate: false });
    updateUndoButtonState();
    updateSecretPresetIndicator();
    if (AppStore.getState().rouletteOpen) {
      updateRouletteStatusUI();
      drawRouletteWheel();
    }
    if (savedTimeElRef && backupSavedTimeText !== null) {
      savedTimeElRef.textContent = backupSavedTimeText;
    }

    try {
      if (backupStorageRaw !== null) {
        localStorage.setItem(STORAGE_KEY, backupStorageRaw);
      } else {
        localStorage.removeItem(STORAGE_KEY);
      }
      if (backupCorruptedRaw !== null) {
        localStorage.setItem(STORAGE_KEY + '_corrupted_backup', backupCorruptedRaw);
      } else {
        localStorage.removeItem(STORAGE_KEY + '_corrupted_backup');
      }
    } catch (e) {}
    setRunningSelfDiagnostics(false);
  }

  const totalMs = Math.max(1, Math.round(performance.now() - startTime));
  const passCount = results.filter(r => r.passed).length;
  const failCount = results.length - passCount;

  if (elapsedBadge) elapsedBadge.textContent = totalMs + 'ms 소요';
  if (summaryBanner && summaryTitle && summarySub) {
    if (failCount === 0) {
      summaryBanner.className = 'px-4 py-3 rounded-xl bg-emerald-50 border border-emerald-200 mb-3 flex items-center justify-between';
      summaryTitle.className = 'text-sm font-extrabold text-emerald-900';
      summaryTitle.textContent = `✅ 전체 ${results.length}개 항목 중 ${passCount}개 모두 통과 (오류 0건)`;
      summarySub.className = 'text-xs text-emerald-700 mt-0.5';
      summarySub.textContent = '30명 학급 · 100회 반복 · 독립 좌표 채점 · 룰렛/가리기/인쇄 검증을 모두 통과했습니다.';
    } else {
      summaryBanner.className = 'px-4 py-3 rounded-xl bg-rose-50 border border-rose-200 mb-3 flex items-center justify-between';
      summaryTitle.className = 'text-sm font-extrabold text-rose-600';
      summaryTitle.textContent = `⚠️ 전체 ${results.length}개 항목 중 ${failCount}건 점검 필요`;
      summarySub.className = 'text-xs text-slate-600 mt-0.5';
      summarySub.textContent = '아래 상세 내역에서 실패한 항목의 원인을 확인하세요.';
    }
  }

  if (listEl) {
    listEl.innerHTML = results.map(item => `
      <div class="px-3.5 py-2.5 rounded-xl border ${item.passed ? 'bg-slate-50 border-slate-200' : 'bg-rose-50 border-rose-200'} flex items-center justify-between gap-2">
        <div class="min-w-0">
          <div class="text-xs font-extrabold ${item.passed ? 'text-slate-800' : 'text-rose-600'}">${escapeHtml(item.name)}</div>
          <div class="text-[11px] ${item.passed ? 'text-slate-600 truncate' : 'text-rose-600 whitespace-normal break-words'} mt-0.5">${escapeHtml(item.detail)}</div>
        </div>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-bold shrink-0 ${item.passed ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-500 text-white'}">
          ${item.passed ? 'PASS (' + item.ms + 'ms)' : 'FAIL'}
        </span>
      </div>
    `).join('');
  }
}

export const closeSelfTestModal = () => {
  const modal = document.getElementById('selfTestModal');
  if (modal) {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
  }
};
