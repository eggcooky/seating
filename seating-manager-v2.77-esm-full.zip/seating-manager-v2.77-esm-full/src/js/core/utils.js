// [L0] 완전 순수 유틸리티 함수 (DOM·상태 비의존 리프 모듈)

export function escapeHtml(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, (ch) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[ch]));
}

export function sanitizeFileName(rawTitle) {
  const cleaned = String(rawTitle || '우리반_자리배치표')
    .trim()
    .replace(/[\\/:*?"<>|]+/g, '_')
    .replace(/\s+/g, '_');
  return cleaned || '우리반_자리배치표';
}
