// [L1] 순수 엑셀 명렬표 파서 (DOM·전역상태 비의존)
import { MAX_STUDENTS } from '../core/constants.js';

export function parseExcelRosterWithDiagnostics(rawText, useGender = true) {
  if (!rawText || !rawText.trim()) return { students: [], warnings: [] };
  const rawLines = rawText.split(/\r\n|\r|\n/);
  const parsed = [];
  const warnings = [];
  const useGenderFlag = useGender !== false;
  // 수천 줄을 실수로 붙여넣더라도 화면이 멈추지 않도록 유효 인원 탐색 상한(MAX_STUDENTS + 여유 15줄)을 적용한다.
  const MAX_SCAN_VALID = MAX_STUDENTS + 15;
  let skippedExtraLines = 0;

  for (let lineIdx = 0; lineIdx < rawLines.length; lineIdx++) {
    const rawLine = rawLines[lineIdx];
    const lineNum = lineIdx + 1;
    const line = rawLine.replace(/[\u200B-\u200D\uFEFF]/g, '').trim();
    if (!line) continue;

    if (parsed.length >= MAX_SCAN_VALID) {
      skippedExtraLines++;
      continue;
    }

    if (/^(?:(학년|반|학반|학급|번호|출석번호|연번|학번|순번|성별)[\s\t,|]+)*(이름|성명|학생명)(?:[\s\t,|]+(학년|반|학반|학급|번호|출석번호|연번|학번|순번|성별|남녀|남\/여|비고|특이사항|메모|주소|출석|결석|연락처|전화번호|생년월일).*)?$/.test(line)) continue;

    const hasTabOrDelim = /[\t,|]/.test(line);
    const tokens = (hasTabOrDelim ? line.split(/[\t,|]+/) : line.split(/\s+/))
      .map(t => t.trim())
      .filter(Boolean);

    if (tokens.length === 0) continue;
    // 모든 토큰이 표 헤더 키워드로만 구성된 줄이나, '성명/이름'과 '번호/학번/성별' 등 헤더 키워드가 함께 등장하는 헤더 줄은 건너뛴다(실명 '성명진'·'이름이' 보호).
    const HEADER_TOKEN_RE = /^(학년|반|학반|학급|번호|출석번호|연번|학번|순번|이름|성명|학생명|성별|남녀|남\/여|비고|특이사항|메모|주소|출석|결석|연락처|전화번호|생년월일)$/;
    const NAME_HEADER_RE = /^(이름|성명|학생명)$/;
    if (tokens.every(tk => HEADER_TOKEN_RE.test(tk))) {
      continue;
    }
    if (tokens.length >= 2 && tokens.some(tk => NAME_HEADER_RE.test(tk)) && tokens.filter(tk => HEADER_TOKEN_RE.test(tk)).length >= 2 && !tokens.some(tk => /^\d+$/.test(tk))) {
      continue;
    }

    let num = null;
    let name = '';
    let gender = '남';
    let genderExplicit = false;

    // 나이스(NEIS) 양식처럼 앞쪽에 '학년 / 반 / 학년-반 / 번호' 다중 숫자 컬럼이 연속으로 오는 경우 이름 직전의 마지막 숫자 토큰을 학생 번호(num)로 채택한다.
    let startIdx = 0;
    while (startIdx < tokens.length) {
      const neis3Match = tokens[startIdx].match(/^\d{1,2}-\d{1,2}-(\d{1,2})$/);
      if (neis3Match) {
        num = parseInt(neis3Match[1], 10);
        startIdx++;
        continue;
      }
      if (/^\d{1,2}-\d{1,2}$/.test(tokens[startIdx]) || /^-\d+$/.test(tokens[startIdx])) {
        startIdx++;
        continue;
      }
      const numMatch = tokens[startIdx].match(/^(\d+)\s*(?:학년|반|번|[.)])?$/);
      if (!numMatch) break;
      num = parseInt(numMatch[1], 10);
      startIdx++;
    }
    const firstNumMatch = startIdx > 0;

    if (tokens.length === 1 && firstNumMatch) {
      warnings.push(`${lineNum}번째 줄("${tokens[0]}"): 학생 성명이 누락되어 제외되었습니다.`);
      continue;
    }

    // 번호를 제외한 토큰이 성별 키워드 하나뿐이면 성명이 누락된 줄로 처리한다.
    if (tokens.length - startIdx === 1 && /^(남|여|남자|여자|남학생|여학생|M|F)$/i.test(tokens[startIdx])) {
      warnings.push(`${lineNum}번째 줄("${tokens.join(' ')}"): 학생 성명이 누락되어 제외되었습니다.`);
      continue;
    }

    // 뒤쪽 토큰부터 역방향으로 성별 키워드를 탐색하되, 영문 약어(M/F)는 중간 이니셜("John F Kennedy") 오인을 막기 위해 마지막 토큰에서만 허용한다.
    let genderTokenIdx = -1;
    for (let ti = tokens.length - 1; ti >= startIdx + 1; ti--) {
      const tk = tokens[ti];
      if (/^(남|여|남자|여자|남학생|여학생)$/.test(tk) || (ti === tokens.length - 1 && /^(M|F)$/i.test(tk))) {
        genderTokenIdx = ti;
        break;
      }
    }
    // 성별이 이름 앞에 오는 양식(번호\t성별\t성명, 1\tF\tAlice 등) 지원
    if (genderTokenIdx === -1 && tokens.length > startIdx + 1 && (/^(남자|여자|남학생|여학생)$/.test(tokens[startIdx]) || (hasTabOrDelim && /^(남|여|M|F)$/i.test(tokens[startIdx])))) {
      genderTokenIdx = startIdx;
    }

    const isMetaPhoneOrDateToken = (tk) => /^(?:\d{2,4}[-./]\d{1,4}[-./]\d{1,4}|01[016789]\d{7,8}|(?:19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01]))$/.test(tk);
    if (genderTokenIdx !== -1) {
      gender = /^(여|여자|여학생|F)$/i.test(tokens[genderTokenIdx]) ? '여' : '남';
      genderExplicit = true;
      const rawNameSlice = (genderTokenIdx === startIdx)
        ? tokens.slice(startIdx + 1)
        : tokens.slice(startIdx, genderTokenIdx);
      const nameTokensWithGender = rawNameSlice.filter(tk => tk && !isMetaPhoneOrDateToken(tk));
      name = (genderTokenIdx === startIdx && hasTabOrDelim)
        ? (nameTokensWithGender[0] || '')
        : nameTokensWithGender.join(' ');
    } else if (tokens.length === 1) {
      const singleNumMatch = tokens[0].match(/^(\d+)\s*(?:번|[.)])\s*(.+)$/);
      if (singleNumMatch) {
        num = parseInt(singleNumMatch[1], 10);
        name = singleNumMatch[2];
      } else {
        name = tokens[0].replace(/^\d+\s*(?:번|[.)])?\s*/, '');
      }
    } else {
      // 생년월일이나 전화번호(하이픈 유무 무관) 형태의 부가 정보 토큰은 이름에서 제외하고, 탭/구분자 표 형식에서는 첫 성명 열만 채택한다.
      const nameTokens = tokens.slice(startIdx).filter(tk => tk && !isMetaPhoneOrDateToken(tk));
      name = hasTabOrDelim ? (nameTokens[0] || '') : nameTokens.join(' ');
    }
    if (num === null && name) {
      const gluedNum = name.match(/^(\d+)\s*(?:번|[.)])\s*(.+)$/);
      if (gluedNum) {
        num = parseInt(gluedNum[1], 10);
        name = gluedNum[2];
      }
    }

    // 유니코드 문자와 숫자, 아포스트로피('), 가운뎃점(·), 기본 괄호·기호를 보존하고 불필요한 특수문자를 제거한다.
    let cleanedName = name.replace(/[^\p{L}\p{M}\p{N}\s()._\-'’·・]/gu, '').trim();
    if (!cleanedName) {
      warnings.push(`${lineNum}번째 줄("${line.slice(0, 18)}"): 유효한 이름을 인식할 수 없어 제외되었습니다.`);
      continue;
    }
    // 성명 입력란(maxLength=30)과 동일하게 엑셀 붙여넣기 이름도 최대 30자로 제한한다.
    if (cleanedName.length > 30) {
      cleanedName = cleanedName.slice(0, 30).trim();
      warnings.push(`${lineNum}번째 줄(${cleanedName}...): 이름이 30자를 초과하여 앞 30자까지만 반영되었습니다.`);
    }

    if (useGenderFlag && !genderExplicit) {
      warnings.push(`${lineNum}번째 줄(${cleanedName}): 성별 열이 비어있거나 형식이 달라 기본값('남')으로 임시 지정되었습니다.`);
    }

    parsed.push({
      id: 's_' + Date.now() + '_' + parsed.length,
      num: (num && num > 0 && num <= 999) ? num : (parsed.length + 1),
      name: cleanedName,
      gender
    });
  }

  if (skippedExtraLines > 0) {
    warnings.push(`최대 등록 한도(${MAX_STUDENTS}명)를 크게 초과한 나머지 ${skippedExtraLines}줄은 성능 보호를 위해 생략되었습니다.`);
  }

  // 중복 번호(예: 1, 1, 1)나 비정상 번호가 있으면 겹치지 않도록 순번으로 자동 보정한다.
  const seenNums = new Set();
  let hadDuplicateNum = false;
  parsed.forEach((st, idx) => {
    const n = Number(st.num);
    if (!Number.isInteger(n) || n <= 0 || seenNums.has(n)) {
      hadDuplicateNum = true;
      let candidateNum = idx + 1;
      while (seenNums.has(candidateNum)) candidateNum++;
      st.num = candidateNum;
      seenNums.add(candidateNum);
    } else {
      seenNums.add(n);
    }
  });
  if (hadDuplicateNum) {
    warnings.push('중복되거나 누락된 학생 번호가 감지되어 순차 번호로 자동 보정되었습니다.');
  }

  return { students: parsed, warnings };
}
