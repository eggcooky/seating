// [L1] 순수 격자 좌표 탐색 · 경계 계산 · 유효 좌표 보정 (DOM·전역상태 비의존)
import { MAX_COLS, MAX_ROWS } from '../core/constants.js';

export function findFreeCoordinate(posObj, alsoObj = null, defaultCols = 6) {
  // 대상 좌표 맵(및 보조 좌표 맵)에서 비어 있는 다음 좌석 좌표를 탐색한다.
  const coords = [...Object.values(posObj || {}), ...(alsoObj ? Object.values(alsoObj) : [])]
    .filter(p => Array.isArray(p) && p.length === 2);
  if (!coords.length) return [1, 1];
  const cols = coords.map(p => p[0]);
  const rows = coords.map(p => p[1]);
  const c0 = Math.min(...cols), c1 = Math.max(...cols);
  const r0 = Math.min(...rows), r1 = Math.max(...rows);

  // 기존 통로(비어 있는 열) 배치를 유지하기 위해 이미 책상이 존재하는 열의 마지막 행 빈자리를 우선 탐색한다.
  const occupiedColSet = new Set(cols);
  const defaultColsN = Math.min(8, Math.max(4, Number(defaultCols) || 6));
  const cEnd = Math.min(MAX_COLS - 1, (r0 === r1) ? Math.max(c1, c0 + defaultColsN - 1) : c1);
  // 1순위: 현재 격자 행 범위(r0..r1) 내에서 기존 사용 열(occupiedColSet)의 빈자리(구멍)나 마지막 행 빈칸을 먼저 채운다.
  for (let r = r0; r <= r1; r++) {
    for (let c = c0; c <= cEnd; c++) {
      if ((r0 === r1 || occupiedColSet.has(c)) && !coords.some(p => p[0] === c && p[1] === r)) {
        return [c, r];
      }
    }
  }
  // 2순위: 기존 열의 모든 행(r0..r1)이 꽉 찬 경우 다음 행(r1 + 1) 첫 번째 열에 새 좌석을 배치한다.
  if (r1 + 1 < MAX_ROWS) return [c0, r1 + 1];
  // 3순위: 마지막 행(MAX_ROWS - 1)에 도달한 경우 통로를 포함한 격자 내 잔여 빈칸을 탐색한다.
  for (let r = r0; r <= r1; r++) {
    for (let c = c0; c <= c1; c++) {
      if (!coords.some(p => p[0] === c && p[1] === r)) return [c, r];
    }
  }
  for (let r = 0; r < MAX_ROWS; r++) {
    for (let c = 0; c < MAX_COLS; c++) {
      if (!coords.some(p => p[0] === c && p[1] === r)) return [c, r];
    }
  }
  return [0, 0];
}

export function getGridBounds(students, posMap, expandForDeskMove = false) {
  const activeMap = posMap || {};
  const coords = (students || []).map(s => activeMap[s.id]).filter(Boolean);
  if (!coords.length) {
    return { c0: 0, c1: 5, r0: 0, r1: 4 };
  }
  let c0 = Math.min(...coords.map(p => p[0]));
  let c1 = Math.max(...coords.map(p => p[0]));
  let r0 = Math.min(...coords.map(p => p[1]));
  let r1 = Math.max(...coords.map(p => p[1]));

  if (expandForDeskMove) {
    // 방식 B: 기존 좌석 위치가 좌·상으로 밀리지 않도록 우측·하단 1줄만 확장해 빈칸 이동 슬롯을 제공한다.
    c1 = Math.min(MAX_COLS - 1, c1 + 1);
    r1 = Math.min(MAX_ROWS - 1, r1 + 1);
  }
  return { c0, c1, r0, r1 };
}

export function ensureAllStudentsHaveValidCoords(students, posObj, defaultCols = 6) {
  if (!posObj || typeof posObj !== 'object') return;
  const studentList = Array.isArray(students) ? students : [];
  const validStudentIdSet = new Set(studentList.map(s => String(s.id)));
  Object.keys(posObj).forEach(k => {
    if (!validStudentIdSet.has(String(k))) {
      delete posObj[k];
    }
  });
  const usedKeys = new Set();
  studentList.forEach(s => {
    const p = posObj[s.id];
    if (Array.isArray(p) && p.length === 2 && Number.isInteger(p[0]) && Number.isInteger(p[1]) &&
        p[0] >= 0 && p[0] < MAX_COLS && p[1] >= 0 && p[1] < MAX_ROWS && !usedKeys.has(`${p[0]},${p[1]}`)) {
      usedKeys.add(`${p[0]},${p[1]}`);
    } else {
      posObj[s.id] = null;
    }
  });
  studentList.forEach(s => {
    if (!Array.isArray(posObj[s.id])) {
      const free = findFreeCoordinate(posObj, null, defaultCols);
      posObj[s.id] = free;
    }
  });
}
