// [L1] 순수 데이터 난독화(XOR+Base64) 코덱 (DOM·스토리지 비의존)
import { OBFUSCATION_XOR_KEY } from '../core/constants.js';

const SIMPLE_ENC_MARK = 'simple-v1';
const SIMPLE_ENC_KEY = OBFUSCATION_XOR_KEY;
const _SIMPLE_ENC_KEY_BYTES = new TextEncoder().encode(SIMPLE_ENC_KEY);

// 바이트 배열에 대칭 XOR 스트림 연산을 수행한다 (키 바이트 배열 상수 재사용으로 직렬화 속도 최적화).
function simpleXorBytes(bytes) {
  const keyBytes = _SIMPLE_ENC_KEY_BYTES;
  const keyLen = keyBytes.length;
  const out = new Uint8Array(bytes.length);
  for (let i = 0; i < bytes.length; i++) {
    out[i] = bytes[i] ^ keyBytes[i % keyLen] ^ ((i * 31 + 7) & 255);
  }
  return out;
}

function bytesToBase64(bytes) {
  let bin = '';
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  return btoa(bin);
}

function base64ToBytes(b64) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

// 영속 상태 객체를 직렬화한 뒤 난독화된 JSON 문자열로 반환한다.
export function encodeObfuscatedPayload(persistedObj) {
  const plain = JSON.stringify(persistedObj, null, 2);
  const obfuscated = simpleXorBytes(new TextEncoder().encode(plain));
  return JSON.stringify({ _enc: SIMPLE_ENC_MARK, data: bytesToBase64(obfuscated) }, null, 2);
}

// 문자열이 난독화된 JSON 형식인지 확인한다.
export function isSimpleObfuscatedText(text) {
  try {
    const o = JSON.parse(text);
    return !!(o && o._enc === SIMPLE_ENC_MARK && typeof o.data === 'string');
  } catch (e) {
    return false;
  }
}

// 저장된 JSON 문자열을 읽어 난독화 여부에 따라 디코딩 후 파싱한다.
export function parseSeatFileText(text) {
  const outer = JSON.parse(text);
  if (outer && outer._enc === SIMPLE_ENC_MARK && typeof outer.data === 'string') {
    const plainBytes = simpleXorBytes(base64ToBytes(outer.data));
    return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(plainBytes));
  }
  return outer;
}
