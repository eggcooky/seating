// [L1] 순수 업데이트 버전 비교 · SHA-256 · 배포본 HTML 무결성 검증 (DOM 비의존)
import { APP_VERSION, MIN_VALID_HTML_LENGTH, OBFUSCATION_XOR_KEY } from '../core/constants.js';

// 문자열 사전순 비교('2.10' < '2.9') 오류를 방지하기 위해 버전을 점(.)으로 분리하여 각 자리 정수로 비교한다.
// 반환값: verA > verB 이면 1, 같으면 0, verA < verB 이면 -1
export function compareVersions(verA, verB) {
  const cleanA = String(verA || '').trim().replace(/^v/i, '');
  const cleanB = String(verB || '').trim().replace(/^v/i, '');
  if (!cleanA && !cleanB) return 0;
  if (!cleanA) return -1;
  if (!cleanB) return 1;

  const partsA = cleanA.split('.').map(n => parseInt(n, 10) || 0);
  const partsB = cleanB.split('.').map(n => parseInt(n, 10) || 0);
  const maxLen = Math.max(partsA.length, partsB.length);

  for (let i = 0; i < maxLen; i++) {
    const numA = partsA[i] || 0;
    const numB = partsB[i] || 0;
    if (numA > numB) return 1;
    if (numA < numB) return -1;
  }
  return 0;
}

// 순수 JS SHA-256 (file:// 비보안 컨텍스트에서 window.crypto.subtle이 없을 때도 100% 동작하는 폴백)
const SHA256_K = new Uint32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
]);

export function computeSha256HexSync(text) {
  const msg = new TextEncoder().encode(String(text || ''));
  const bitLen = msg.length * 8;
  const paddedLen = Math.ceil((msg.length + 9) / 64) * 64;
  const buf = new Uint8Array(paddedLen);
  buf.set(msg);
  buf[msg.length] = 0x80;
  const view = new DataView(buf.buffer);
  view.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000), false);
  view.setUint32(paddedLen - 4, bitLen >>> 0, false);

  let h0 = 0x6a09e667, h1 = 0xbb67ae85, h2 = 0x3c6ef372, h3 = 0xa54ff53a;
  let h4 = 0x510e527f, h5 = 0x9b05688c, h6 = 0x1f83d9ab, h7 = 0x5be0cd19;
  const w = new Uint32Array(64);

  for (let off = 0; off < paddedLen; off += 64) {
    for (let i = 0; i < 16; i++) w[i] = view.getUint32(off + i * 4, false);
    for (let i = 16; i < 64; i++) {
      const s0 = ((w[i - 15] >>> 7) | (w[i - 15] << 25)) ^ ((w[i - 15] >>> 18) | (w[i - 15] << 14)) ^ (w[i - 15] >>> 3);
      const s1 = ((w[i - 2] >>> 17) | (w[i - 2] << 15)) ^ ((w[i - 2] >>> 19) | (w[i - 2] << 13)) ^ (w[i - 2] >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
    }
    let a = h0, b = h1, c = h2, d = h3, e = h4, f = h5, g = h6, h = h7;
    for (let i = 0; i < 64; i++) {
      const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
      const ch = (e & f) ^ (~e & g);
      const temp1 = (h + S1 + ch + SHA256_K[i] + w[i]) >>> 0;
      const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const temp2 = (S0 + maj) >>> 0;
      h = g; g = f; f = e; e = (d + temp1) >>> 0;
      d = c; c = b; b = a; a = (temp1 + temp2) >>> 0;
    }
    h0 = (h0 + a) >>> 0; h1 = (h1 + b) >>> 0; h2 = (h2 + c) >>> 0; h3 = (h3 + d) >>> 0;
    h4 = (h4 + e) >>> 0; h5 = (h5 + f) >>> 0; h6 = (h6 + g) >>> 0; h7 = (h7 + h) >>> 0;
  }
  return [h0, h1, h2, h3, h4, h5, h6, h7].map(v => v.toString(16).padStart(8, '0')).join('');
}

export async function computeSha256Hex(text) {
  if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle && typeof window.crypto.subtle.digest === 'function') {
    try {
      const bytes = new TextEncoder().encode(String(text || ''));
      const hashBuf = await window.crypto.subtle.digest('SHA-256', bytes);
      return Array.from(new Uint8Array(hashBuf)).map(b => b.toString(16).padStart(2, '0')).join('');
    } catch (e) {
      // file:// 등 비보안 컨텍스트 오류 시 순수 JS 폴백 사용
    }
  }
  return computeSha256HexSync(text);
}

export async function verifyDownloadedHtmlSha256(htmlText, expectedSha256) {
  const expected = String(expectedSha256 || '').trim().toLowerCase();
  if (!/^[0-9a-f]{64}$/.test(expected)) return false;
  const actual = await computeSha256Hex(htmlText);
  return actual === expected;
}

export function resolveExpectedPkgSha256(remoteData, currentVer = APP_VERSION) {
  if (!remoteData || typeof remoteData !== 'object') return '';
  const cleanCur = String(currentVer || '').trim().replace(/^v/i, '');
  const known = remoteData.knownPkgHashes;
  if (known && typeof known === 'object' && !Array.isArray(known) && Object.prototype.hasOwnProperty.call(known, cleanCur)) {
    const val = typeof known[cleanCur] === 'string' ? known[cleanCur].trim().toLowerCase() : '';
    if (/^[a-f0-9]{64}$/.test(val)) return val;
  }
  const remoteVer = typeof remoteData.version === 'string' ? remoteData.version.trim().replace(/^v/i, '') : '';
  if (remoteVer && compareVersions(remoteVer, cleanCur) === 0 && typeof remoteData.pkgSha256 === 'string') {
    const val = remoteData.pkgSha256.trim().toLowerCase();
    if (/^[a-f0-9]{64}$/.test(val)) return val;
  }
  return '';
}

export function verifyRuntimePkgIntegrity(expectedPkgSha256, actualPkgSha256) {
  const expected = typeof expectedPkgSha256 === 'string' ? expectedPkgSha256.trim().toLowerCase() : '';
  if (!expected || !/^[a-f0-9]{64}$/.test(expected)) return true;
  if (!actualPkgSha256) return true;
  return actualPkgSha256.toLowerCase() === expected;
}

/**
 * 다운로드한 HTML 텍스트가 정상적인 최신 버전 프로그램 파일인지 저장 전에 검증한다.
 * 길이·종료 태그·APP_VERSION 일치 검사와 함께 난독화 패키지(__app_pkg__) 내부 스크립트 버전 디코딩 확인을 수행한다.
 * @param {string} htmlText
 * @param {string} expectedVersion
 * @param {boolean} [responseOk]
 * @returns {boolean}
 */
export function validateDownloadedHtml(htmlText, expectedVersion, responseOk = true) {
  if (!responseOk) return false;
  if (typeof htmlText !== 'string' || htmlText.length < MIN_VALID_HTML_LENGTH) return false;
  if (!htmlText.includes('</html>')) return false;

  const cleanExpected = String(expectedVersion || '').trim().replace(/^v/i, '');
  if (!cleanExpected) return false;
  const escapedVer = cleanExpected.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const versionPattern = new RegExp("APP_VERSION\\s*=\\s*['\"]" + escapedVer + "['\"]");

  let versionMatched = versionPattern.test(htmlText);
  if (!versionMatched && htmlText.includes('id="__app_pkg__"')) {
    try {
      const pkgMatch = htmlText.match(/<script[^>]*id=["']__app_pkg__["'][^>]*>([\s\S]*?)<\/script>/i);
      if (pkgMatch && pkgMatch[1]) {
        const bin = atob(pkgMatch[1].trim());
        const bytes = new Uint8Array(bin.length);
        const key = new TextEncoder().encode(OBFUSCATION_XOR_KEY);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i) ^ key[i % key.length];
        const decodedObj = JSON.parse(new TextDecoder('utf-8').decode(bytes));
        if (decodedObj && typeof decodedObj.script === 'string' && versionPattern.test(decodedObj.script)) {
          versionMatched = true;
        }
      }
    } catch (e) {
      versionMatched = false;
    }
  }
  return versionMatched;
}
