// [L1] 순수 상태 조회(Selector) 모듈 (DOM·전역상태 비의존)

export function getStudentById(state, id) {
  if (!state || !id) return null;
  const target = String(id);
  const list = state.students || [];
  for (let i = 0; i < list.length; i++) {
    if (String(list[i].id) === target) return list[i];
  }
  return null;
}

// 일반 화면 기준 해당 학생의 좌석 고정 여부를 반환한다 (불필요한 배열 재생성 없이 즉시 조회).
export function isNormalSeatLocked(state, studentId) {
  if (!state) return false;
  const target = String(studentId);
  const list = state.lockedIds;
  if (!list) return false;
  for (let i = 0; i < list.length; i++) {
    if (String(list[i]) === target) return true;
  }
  return false;
}

// 비밀의 방 기준 해당 학생의 좌석 고정 여부를 반환한다.
export function isSecretSeatLocked(state, studentId) {
  if (!state) return false;
  const target = String(studentId);
  const list = state.secretLockedIds;
  if (!list) return false;
  for (let i = 0; i < list.length; i++) {
    if (String(list[i]) === target) return true;
  }
  return false;
}

// 현재 활성화된 화면 기준 해당 학생의 좌석 고정 여부를 반환한다.
export function isSeatLocked(state, studentId) {
  if (!state) return false;
  return state.inSecretRoom ? isSecretSeatLocked(state, studentId) : isNormalSeatLocked(state, studentId);
}

export function isSeatHidden(state, studentId) {
  if (!state || state.inSecretRoom) return false;
  const target = String(studentId);
  const list = state.hiddenSeatIds;
  if (!list) return false;
  for (let i = 0; i < list.length; i++) {
    if (String(list[i]) === target) return true;
  }
  return false;
}

// 현재 활성화된 화면(일반 화면 또는 비밀의 방)의 좌석 좌표 맵을 반환한다.
export function getActivePosMap(state) {
  if (state.inSecretRoom) {
    if (!state.secretPos) {
      state.secretPos = JSON.parse(JSON.stringify(state.pos));
    }
    return state.secretPos;
  }
  return state.pos;
}

export function hasValidSecretPreset(state) {
  if (!state || !state.secretPos || typeof state.secretPos !== 'object') return false;
  return state.students.length > 0 && state.students.every(s => Array.isArray(state.secretPos[s.id]));
}

// 일반 화면에서 고정된 학생의 위치가 비밀의 방 위치와 다른 경우 해당 학생 이름 목록을 반환한다.
export function getLockedSeatConflicts(state) {
  if (!hasValidSecretPreset(state)) return [];
  const conflicts = [];
  state.students.forEach(s => {
    if (isNormalSeatLocked(state, s.id)) {
      const pubP = state.pos[s.id];
      const secP = state.secretPos[s.id];
      if (!pubP || !secP || pubP[0] !== secP[0] || pubP[1] !== secP[1]) {
        conflicts.push(s.name);
      }
    }
  });
  return conflicts;
}

// 일반 화면과 비밀의 방의 책상 좌표 집합이 일치하고 고정석 위치 충돌이 없는지 확인한다.
export function doesSecretLayoutMatchCurrent(state) {
  if (!hasValidSecretPreset(state)) return false;
  const normalCoords = state.students
    .map(s => state.pos[s.id])
    .filter(Boolean)
    .map(p => `${p[0]},${p[1]}`)
    .sort();
  const secretCoords = state.students
    .map(s => state.secretPos[s.id])
    .filter(Boolean)
    .map(p => `${p[0]},${p[1]}`)
    .sort();
  if (normalCoords.length !== secretCoords.length) return false;
  for (let i = 0; i < normalCoords.length; i++) {
    if (normalCoords[i] !== secretCoords[i]) return false;
  }
  if (getLockedSeatConflicts(state).length > 0) return false;
  return true;
}
