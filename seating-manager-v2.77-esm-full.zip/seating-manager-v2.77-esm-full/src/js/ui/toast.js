// [L3] 상단 상태 표시줄 토스트 알림 및 기본 필 스타일 복원
import { AppStore } from '../state/store.js';

let statusPillRevertTimer = null;

export function applyDefaultModeStatusPillStyle() {
  if (statusPillRevertTimer) {
    clearTimeout(statusPillRevertTimer);
    statusPillRevertTimer = null;
  }
  const modeStatusPill = document.getElementById('modeStatusPill');
  const modeStatusDot = document.getElementById('modeStatusDot');
  const modeStatusText = document.getElementById('modeStatusText');
  if (!modeStatusPill || !modeStatusDot || !modeStatusText) return;

  const state = AppStore.getState();
  const stack = state.inSecretRoom ? state.undoStackSecret : state.undoStackNormal;
  const latestEntry = (stack && stack.length > 0) ? stack[stack.length - 1] : null;

  if (state.inSecretRoom) {
    modeStatusPill.className = 'px-3.5 py-1.5 rounded-full text-xs font-bold bg-slate-900 text-amber-300 border border-amber-500/40 hover:bg-slate-800 transition-all flex items-center gap-2 cursor-pointer shadow-sm';
    modeStatusDot.className = 'w-2 h-2 rounded-full bg-amber-400 animate-ping shrink-0';
    modeStatusText.textContent = latestEntry
      ? `[비밀의 방] 최근: ${latestEntry.actionLabel}`
      : '비밀의 방: 학생들 몰래 배정할 목표 자리를 클릭해 맞추세요';
  } else {
    modeStatusPill.className = 'px-3.5 py-1.5 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 hover:bg-indigo-100/80 transition-all flex items-center gap-2 cursor-pointer shadow-sm';
    modeStatusDot.className = 'w-2 h-2 rounded-full bg-indigo-600 shrink-0';
    modeStatusText.textContent = latestEntry
      ? `최근 변화: ${latestEntry.actionLabel}`
      : '상태창';
  }
}

// 상단 상태 표시줄에 알림 메시지를 표시하고 일정 시간 후 기본 상태로 복원한다.
export function showToast(message, type = 'info') {
  if (AppStore.isRunningSelfDiagnostics()) return;
  const modeStatusPill = document.getElementById('modeStatusPill');
  const modeStatusDot = document.getElementById('modeStatusDot');
  const modeStatusText = document.getElementById('modeStatusText');
  if (!modeStatusPill || !modeStatusDot || !modeStatusText) return;

  if (statusPillRevertTimer) {
    clearTimeout(statusPillRevertTimer);
    statusPillRevertTimer = null;
  }

  const pillStyles = {
    success: 'px-3.5 py-1.5 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-300 hover:bg-emerald-100 transition-all flex items-center gap-2 cursor-pointer shadow-sm',
    info: 'px-3.5 py-1.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-800 border border-indigo-300 hover:bg-indigo-100 transition-all flex items-center gap-2 cursor-pointer shadow-sm',
    warn: 'px-3.5 py-1.5 rounded-full text-xs font-bold bg-amber-50 text-amber-900 border border-amber-400 hover:bg-amber-100 transition-all flex items-center gap-2 cursor-pointer shadow-sm',
    secret: 'px-3.5 py-1.5 rounded-full text-xs font-bold bg-slate-900 text-amber-300 border border-amber-500/50 hover:bg-slate-800 transition-all flex items-center gap-2 cursor-pointer shadow-sm'
  };
  const dotStyles = {
    success: 'w-2 h-2 rounded-full bg-emerald-500 animate-ping shrink-0',
    info: 'w-2 h-2 rounded-full bg-indigo-600 animate-ping shrink-0',
    warn: 'w-2 h-2 rounded-full bg-amber-500 animate-ping shrink-0',
    secret: 'w-2 h-2 rounded-full bg-amber-400 animate-ping shrink-0'
  };

  modeStatusPill.className = pillStyles[type] || pillStyles.info;
  modeStatusDot.className = dotStyles[type] || dotStyles.info;
  modeStatusText.textContent = message;

  statusPillRevertTimer = setTimeout(() => {
    applyDefaultModeStatusPillStyle();
  }, 3600);
}
