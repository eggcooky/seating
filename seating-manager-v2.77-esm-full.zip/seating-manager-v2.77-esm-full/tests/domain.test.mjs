/**
 * 순수 도메인 계층(L0·L1) Node.js 단독 단위 테스트 (DOM·브라우저 불필요)
 * 실행: npm run test:unit  (또는 node --test tests/domain.test.mjs)
 */
import assert from 'node:assert/strict';
import test from 'node:test';

import { APP_VERSION, MAX_COLS, MAX_ROWS, MIN_VALID_HTML_LENGTH, OBFUSCATION_XOR_KEY } from '../src/js/core/constants.js';
import { escapeHtml, sanitizeFileName } from '../src/js/core/utils.js';
import { canRegisterPairRule, generateOptimalSeatAssignment } from '../src/js/domain/algorithm-engine.js';
import { encodeObfuscatedPayload, isSimpleObfuscatedText, parseSeatFileText } from '../src/js/domain/codec.js';
import { parseExcelRosterWithDiagnostics } from '../src/js/domain/excel-parser.js';
import { ensureAllStudentsHaveValidCoords, findFreeCoordinate, getGridBounds } from '../src/js/domain/grid.js';
import { applyLoadedDataToState, createInitialState, migratePayloadSchema, sanitizeLoadedStudents } from '../src/js/domain/schema.js';
import { doesSecretLayoutMatchCurrent, getLockedSeatConflicts, isSeatLocked } from '../src/js/domain/seat-queries.js';
import {
  compareVersions,
  computeSha256HexSync,
  resolveExpectedPkgSha256,
  validateDownloadedHtml,
  verifyRuntimePkgIntegrity
} from '../src/js/domain/updater-core.js';

function makeSeededRng(seed = 20261121) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function makeRoster(count = 30, cols = 6) {
  const students = [];
  const pos = {};
  for (let i = 1; i <= count; i++) {
    const id = 's' + i;
    students.push({ id, num: i, name: '학생' + i, gender: i % 2 === 1 ? '남' : '여' });
    pos[id] = [((i - 1) % cols) + 1, Math.floor((i - 1) / cols) + 1];
  }
  return { students, pos };
}

test('L0 core/utils: escapeHtml 및 sanitizeFileName 동작 검증', () => {
  assert.equal(escapeHtml('<script>"a&b\'</script>'), '&lt;script&gt;&quot;a&amp;b&#39;&lt;/script&gt;');
  assert.equal(sanitizeFileName(' 3학년/2반:자리*배치? '), '3학년_2반_자리_배치_');
});

test('L1 domain/codec: simple-v1 XOR+Base64 난독화 왕복 및 평문 호환', () => {
  const payload = { classTitle: '3학년 2반', students: [{ id: 's1', num: 1, name: '홍길동', gender: '남' }] };
  const enc = encodeObfuscatedPayload(payload);
  assert.equal(isSimpleObfuscatedText(enc), true);
  assert.equal(isSimpleObfuscatedText(JSON.stringify(payload)), false);
  assert.deepEqual(parseSeatFileText(enc), payload);
  assert.deepEqual(parseSeatFileText(JSON.stringify(payload)), payload);
});

test('L1 domain/schema: v1→v2 마이그레이션, 미래 버전 거부, 프로토타입 오염 차단', () => {
  const v2 = migratePayloadSchema({ classTitle: '구버전반', students: [], pos: {}, rules: { genderPairMode: 'mixed' } });
  assert.equal(v2.schemaVersion, 2);
  assert.equal(v2.rules.defaultCols, 6);
  assert.equal(migratePayloadSchema({ schemaVersion: 99, students: [], pos: {} }), null);

  const sanitized = sanitizeLoadedStudents([
    { id: '__proto__', num: 1, name: '차단1', gender: '남' },
    { id: 'toString', num: 2, name: '차단2', gender: '여' },
    { id: 's1', num: 12345, name: '정상학생', gender: '여' }
  ]);
  assert.equal(sanitized.length, 1);
  assert.equal(sanitized[0].id, 's1');
  assert.equal(sanitized[0].num, 1);

  const st = createInitialState();
  assert.equal(applyLoadedDataToState(st, { classTitle: '빈명단', students: [], pos: {} }, '기본', false), false);
  assert.equal(applyLoadedDataToState(st, { classTitle: '빈명단허용', students: [], pos: {} }, '기본', true), true);
  assert.equal(st.classTitle, '빈명단허용');
});

test('L1 domain/grid & seat-queries: 빈 좌표 탐색 · 중복 좌표 보정 · 고정석 충돌 감지', () => {
  const { students, pos } = makeRoster(6, 6);
  const free = findFreeCoordinate(pos, null, 6);
  assert.deepEqual(free, [1, 2]);

  pos.s2 = [...pos.s1]; // 의도적 중복
  ensureAllStudentsHaveValidCoords(students, pos, 6);
  const keys = new Set(students.map((s) => pos[s.id].join(',')));
  assert.equal(keys.size, 6);

  const bounds = getGridBounds(students, pos, false);
  assert.ok(bounds.c0 >= 0 && bounds.c1 < MAX_COLS && bounds.r0 >= 0 && bounds.r1 < MAX_ROWS);

  const st = createInitialState();
  st.secretPos = JSON.parse(JSON.stringify(st.pos));
  assert.equal(doesSecretLayoutMatchCurrent(st), true);
  st.lockedIds = ['s1'];
  assert.equal(isSeatLocked(st, 's1'), true);
  const tmp = st.secretPos.s1;
  st.secretPos.s1 = st.secretPos.s2;
  st.secretPos.s2 = tmp;
  assert.deepEqual(getLockedSeatConflicts(st), ['고길동']);
  assert.equal(doesSecretLayoutMatchCurrent(st), false);
});

test('L1 domain/excel-parser: 나이스·성별선행·붙은번호·전화번호제외·실명보호 파싱', () => {
  const raw = [
    '번호\t이름\t성별',
    '1\t고길동\t010-1234-5678\t남',
    '2.김영희\t여',
    '3\t여\t또치',
    '성명진\t남',
    '-5\t음수학생\t여'
  ].join('\n');
  const { students } = parseExcelRosterWithDiagnostics(raw, true);
  assert.equal(students.length, 5);
  assert.equal(students[0].name, '고길동');
  assert.equal(students[1].name, '김영희');
  assert.equal(students[2].name, '또치');
  assert.equal(students[3].name, '성명진');
  const neis3 = parseExcelRosterWithDiagnostics('3-2-15\t홍길동\t남\n3-2-16\t김영희\t여', true).students;
  assert.equal(neis3.length, 2);
  assert.equal(neis3[0].num, 15);
  assert.equal(neis3[0].name, '홍길동');
  assert.equal(neis3[1].num, 16);
  assert.equal(neis3[1].name, '김영희');
  assert.equal(students[4].name, '음수학생');
});

test('L1 domain/algorithm-engine: 상호배타 규칙 검증 및 결정론적 시드 재현성', () => {
  const rules = {
    defaultCols: 6,
    useGenderDistinction: true,
    genderPairMode: 'mixed',
    excludePreviousSeat: true,
    frontRowIds: ['s11', 's12'],
    separatedPairs: [['s1', 's2']],
    togetherPairs: [['s3', 's4']]
  };
  assert.equal(canRegisterPairRule('s1', 's2', 'tog', rules).ok, false);
  assert.equal(canRegisterPairRule('s3', 's4', 'sep', rules).ok, false);
  assert.equal(canRegisterPairRule('s3', 's5', 'tog', rules).ok, false);
  assert.equal(canRegisterPairRule('s5', 's6', 'sep', rules).ok, true);

  const { students, pos } = makeRoster(30, 6);
  const res1 = generateOptimalSeatAssignment({ students, pos, rules, lockedIds: ['s15'], rng: makeSeededRng(42) });
  const res2 = generateOptimalSeatAssignment({ students, pos, rules, lockedIds: ['s15'], rng: makeSeededRng(42) });
  assert.deepEqual(res1.map, res2.map);
  assert.deepEqual(res1.map.s15, pos.s15);
  assert.equal(res1.conflicts.length, 0);
});

test('L1 domain/updater-core: 버전 비교 · SHA-256 표준 벡터 · HTML 무결성 검증', () => {
  assert.ok(compareVersions('2.10', '2.9') > 0);
  assert.equal(compareVersions('v' + APP_VERSION, APP_VERSION), 0);
  assert.equal(
    computeSha256HexSync('abc'),
    'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'
  );
  const pad = '<!-- ' + 'A'.repeat(MIN_VALID_HTML_LENGTH) + ' -->';
  const html = `<!DOCTYPE html><html><body>${pad}<script>const APP_VERSION = '9.99';</script></body></html>`;
  assert.equal(validateDownloadedHtml(html, '9.99', true), true);
  assert.equal(validateDownloadedHtml(html, '9.99', false), false);
  assert.equal(validateDownloadedHtml(html, APP_VERSION, true), false);

  const hash = computeSha256HexSync(OBFUSCATION_XOR_KEY);
  assert.equal(verifyRuntimePkgIntegrity(hash, hash), true);
  assert.equal(verifyRuntimePkgIntegrity('0'.repeat(64), hash), false);
  assert.equal(resolveExpectedPkgSha256({ version: '9.99', knownPkgHashes: { [APP_VERSION]: hash } }, APP_VERSION), hash);
});
