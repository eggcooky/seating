// 자가 진단 스위트 3: 업데이트 무결성 · 배치 조건 모달 · 다중 탭 동기화 · CSS/심볼은닉/접근성 (항목 13~16)
import { toggleSecretRoom } from '../app/mode-coordinator.js';
import { applyRulesAndCloseModal, cancelRulesModal, openRulesModal } from '../app/rules-coordinator.js';
import { APP_VERSION, MIN_VALID_HTML_LENGTH, OBFUSCATION_XOR_KEY } from '../core/constants.js';
import { createInitialState } from '../domain/schema.js';
import {
  compareVersions,
  computeSha256HexSync,
  resolveExpectedPkgSha256,
  validateDownloadedHtml
} from '../domain/updater-core.js';
import { handleStudentPick } from '../features/seat-actions.js';
import { verifyRuntimePkgIntegrity } from '../features/updater-ui.js';
import { getActiveStorageKey, getObfuscatedPayload } from '../infra/storage-io.js';
import { AppStore, setRunningSelfDiagnostics } from '../state/store.js';

export function runSystemDiagnostics({ recordTest, setupClassRoster }) {
  // 13. 업데이트 버전 비교(동적 APP_VERSION 호환) 및 다운로드 파일 무결성 검증 테스트
  recordTest('13. 업데이트 버전 비교 및 다운로드 파일 검증 함수 테스트', () => {
    if (compareVersions('2.10', '2.9') <= 0) {
      throw new Error('버전 비교 오류: 2.10이 2.9보다 커야 함');
    }
    if (compareVersions(APP_VERSION, APP_VERSION) !== 0 || compareVersions('v' + APP_VERSION, APP_VERSION) !== 0) {
      throw new Error('현재 버전(' + APP_VERSION + ') 동일 비교 오류');
    }
    if (compareVersions('9.99', APP_VERSION) <= 0 || compareVersions('1.00', APP_VERSION) >= 0) {
      throw new Error('상위(9.99)·하위(1.00) 버전 대소 비교 오류');
    }

    const dummyPadding = '<!-- ' + 'A'.repeat(MIN_VALID_HTML_LENGTH) + ' -->';
    const nextVer = '9.99';
    const validNewHtml = "<!DOCTYPE html><html><body>" + dummyPadding + "<script>const APP_VERSION = '" + nextVer + "';</" + "script></body></html>";
    const shortErrorHtml = "<html><body>404 Not Found const APP_VERSION = '" + nextVer + "';</body></html>";
    const truncatedHtml = "<!DOCTYPE html><html><body>" + dummyPadding + "<script>const APP_VERSION = '" + nextVer + "';</" + "script></body>";
    const oldVersionHtml = "<!DOCTYPE html><html><body>" + dummyPadding + "<script>const APP_VERSION = '" + APP_VERSION + "';</" + "script></body></html>";

    if (!validateDownloadedHtml(validNewHtml, nextVer, true)) {
      throw new Error('정상 최신 HTML 파일이 검증에서 거부됨');
    }
    if (validateDownloadedHtml(validNewHtml, nextVer, false)) {
      throw new Error('응답 실패(responseOk=false) 파일이 검증을 통과함');
    }
    if (validateDownloadedHtml(shortErrorHtml, nextVer, true)) {
      throw new Error('길이가 짧은 오류 페이지가 검증을 통과함');
    }
    if (validateDownloadedHtml(truncatedHtml, nextVer, true)) {
      throw new Error('</html> 태그가 누락된 손상 파일이 검증을 통과함');
    }
    if (validateDownloadedHtml(oldVersionHtml, nextVer, true)) {
      throw new Error('요청 버전(' + nextVer + ')과 다른 구버전(' + APP_VERSION + ') 파일이 검증을 통과함');
    }
    const encodePkg = (obj) => {
      const rawBytes = new TextEncoder().encode(JSON.stringify(obj));
      const keyBytes = new TextEncoder().encode(OBFUSCATION_XOR_KEY);
      let bin = '';
      for (let i = 0; i < rawBytes.length; i++) {
        bin += String.fromCharCode(rawBytes[i] ^ keyBytes[i % keyBytes.length]);
      }
      return btoa(bin);
    };
    const validPkgHtml = '<!DOCTYPE html><html><body>' + dummyPadding + '<script id="__app_pkg__" type="application/octet-stream">' + encodePkg({ script: "const APP_VERSION = '" + nextVer + "';" }) + '</' + 'script></body></html>';
    const wrongVerPkgHtml = '<!DOCTYPE html><html><body>' + dummyPadding + '<script id="__app_pkg__" type="application/octet-stream">' + encodePkg({ script: "const APP_VERSION = '" + APP_VERSION + "';" }) + '</' + 'script></body></html>';
    const corruptPkgHtml = '<!DOCTYPE html><html><body>' + dummyPadding + '<script id="__app_pkg__" type="application/octet-stream">NOT_VALID_BASE64!!!</' + 'script></body></html>';
    if (!validateDownloadedHtml(validPkgHtml, nextVer, true)) {
      throw new Error('정상 난독화(__app_pkg__) HTML 파일이 검증에서 거부됨');
    }
    if (validateDownloadedHtml(wrongVerPkgHtml, nextVer, true)) {
      throw new Error('구버전 난독화(__app_pkg__) HTML 파일이 검증을 통과함');
    }
    if (validateDownloadedHtml(corruptPkgHtml, nextVer, true)) {
      throw new Error('손상된 난독화(__app_pkg__) HTML 파일이 검증을 통과함');
    }
    const nistHash = computeSha256HexSync('abc');
    if (nistHash !== 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad') {
      throw new Error('SHA-256 표준 벡터 불일치: ' + nistHash);
    }
    const pkgHash1 = computeSha256HexSync(validPkgHtml);
    const pkgHash2 = computeSha256HexSync(validPkgHtml + ' ');
    if (pkgHash1.length !== 64 || pkgHash1 === pkgHash2) {
      throw new Error('SHA-256 무결성 1바이트 변조 감지 실패');
    }
    if (!verifyRuntimePkgIntegrity(pkgHash1, pkgHash1) || verifyRuntimePkgIntegrity('0'.repeat(64), pkgHash1)) {
      throw new Error('실행 파일 pkgSha256 변조 감지 함수 오류');
    }
    const mockHistory = { version: nextVer, pkgSha256: '1'.repeat(64), knownPkgHashes: { [nextVer]: '1'.repeat(64), [APP_VERSION]: pkgHash1 } };
    if (resolveExpectedPkgSha256(mockHistory, APP_VERSION) !== pkgHash1 || resolveExpectedPkgSha256(mockHistory, '1.00') !== '') {
      throw new Error('knownPkgHashes 구버전 이력 조회 오류');
    }
    return '동적 버전(' + APP_VERSION + ') · 평문/난독화(__app_pkg__) · SHA-256·이력변조감지 100% 통과';
  });

  // 14. 배치 조건 모달 [취소] 원복 vs [조건 적용] 확정 및 성별 OFF 드롭다운·칩 연동 검증
  recordTest('14. 조건 모달 [취소] 원복 · [적용] 확정 및 성별 OFF UI 연동 검증', () => {
    const state = setupClassRoster(12, 6);
    state.hasDeleteGapNotice = true;
    state.printShadeMode = 'female';
    state.printShadeSeatEnabled = true;
    state.rules.frontRowIds = ['s1'];
    const posBeforeModal = JSON.stringify(state.pos);
    const rulesBeforeModal = JSON.stringify(state.rules);
    openRulesModal();
    document.querySelector('.default-cols-btn[data-default-cols="5"]').click();
    const modalGenderEl = document.getElementById('modalGenderDistinctionToggle');
    if (modalGenderEl) {
      modalGenderEl.checked = false;
      modalGenderEl.dispatchEvent(new Event('change'));
    }
    const frontSelText = (document.getElementById('frontRowStudentSelect') || {}).textContent || '';
    const frontListText = (document.getElementById('frontRowListContainer') || {}).textContent || '';
    const sepSelText = (document.getElementById('sepStudentA') || {}).textContent || '';
    if (frontSelText.includes('(남)') || frontListText.includes('(남)') || sepSelText.includes('(남)')) {
      throw new Error('성별 구분 OFF 상태에서 배치 조건 드롭다운 또는 앞줄 목록에 (남)/(여)가 노출됨');
    }
    cancelRulesModal();
    if (JSON.stringify(state.pos) !== posBeforeModal || JSON.stringify(state.rules) !== rulesBeforeModal ||
        state.printShadeMode !== 'female' || state.printShadeSeatEnabled !== true || state.hasDeleteGapNotice !== true) {
      throw new Error('조건 모달 [취소] 후 규칙·좌석·인쇄음영·빈자리알림 원복 실패');
    }
    openRulesModal();
    state.rules.excludePreviousSeat = true;
    applyRulesAndCloseModal();
    if (state.rules.excludePreviousSeat !== true || state.rulesModalBackup !== null) {
      throw new Error('조건 모달 [조건 적용] 확정 실패');
    }
    return '조건 모달 취소 100% 원복(규칙·좌석·음영·알림점) · 적용 확정 · 성별 OFF 숨김 통과';
  });

  // 15. 다중 탭 storage 이벤트 실시간 동기화 및 비밀의 방 secretPos:null 보호 검증
  recordTest('15. 다중 탭 storage 실시간 동기화 및 비밀방 상태 보호 검증', () => {
    const prevRef = setupClassRoster(8, 6);
    const otherState = createInitialState();
    otherState.classTitle = '다중탭동기화반';
    otherState.students = otherState.students.slice(0, 4);
    otherState.secretPos = null;
    AppStore.replaceState(otherState);
    const syncPayload = getObfuscatedPayload();
    AppStore.replaceState(prevRef);

    toggleSecretRoom(true);
    try {
      setRunningSelfDiagnostics(false);
      window.dispatchEvent(new StorageEvent('storage', { key: getActiveStorageKey(), newValue: syncPayload }));
    } finally {
      setRunningSelfDiagnostics(true);
    }
    const curState = AppStore.getState();
    if (curState.classTitle !== '다중탭동기화반' || curState.students.length !== 4 || curState.inSecretRoom !== false || curState.secretPos !== null) {
      throw new Error('다중 탭 storage 동기화 실패 또는 비밀의 방 secretPos:null 부활 발생');
    }
    return '타 탭 storage 이벤트 실시간 동기화 및 비밀방 secretPos:null 무부활 확인';
  });

  // 16. 오프라인 내장 CSS 무결성 및 내부 전용 심볼 window 미노출 검증
  recordTest('16. 오프라인 내장 CSS 무결성 및 28종 내부 심볼 은닉 검증', () => {
    const hidden28 = [
      'INITIAL_STUDENTS', 'INITIAL_SEAT_IDS_BY_COL',
      'statusPillRevertTimer', 'renderStatusHistoryPopover',
      'SIMPLE_ENC_MARK', 'SIMPLE_ENC_KEY', '_SIMPLE_ENC_KEY_BYTES',
      'simpleXorBytes', 'bytesToBase64', 'base64ToBytes', 'getSerializedPayload',
      'sequentialRevealTimer', '_sharedAudioCtx', 'isSecretSeatLocked',
      'updateStudentNameOnBoard',
      '_genderGridBuf', 'shuffleArrayInPlace', 'extractActualRowPairs',
      'computeEffectiveMaxFrontRow', 'scoreCandidateAssignment',
      'WHEEL_PALETTE', 'rouletteColumnTimer', 'formatVisualSeatLabel', 'animateWheel',
      'latestRemoteVersionInfo', 'lastUpdateCheckTimestamp', 'isCheckingOrDownloadingUpdate',
      'closeSelfTestModal'
    ];
    const leaked = hidden28.filter(sym => sym in window);
    if (leaked.length > 0) {
      throw new Error('내부 전용 심볼 window 노출 감지: ' + leaked.join(', '));
    }
    const state = setupClassRoster(8, 6);
    handleStudentPick('s1');
    const expBtn = document.getElementById('expandGridRowBtn');
    const skipBtn = document.getElementById('syncConflictSkipBtn');
    const confList = document.getElementById('syncLockConflictList');
    if (typeof getComputedStyle === 'function') {
      if (expBtn && getComputedStyle(expBtn).backgroundColor === 'rgba(0, 0, 0, 0)') {
        throw new Error('오프라인 CSS 누락: #expandGridRowBtn(bg-amber-50/95) 미정의');
      }
      if (skipBtn && getComputedStyle(skipBtn).backgroundColor === 'rgba(0, 0, 0, 0)') {
        throw new Error('오프라인 CSS 누락: #syncConflictSkipBtn(bg-slate-700) 미정의');
      }
      if (confList && getComputedStyle(confList).maxHeight === 'none') {
        throw new Error('오프라인 CSS 누락: #syncLockConflictList(max-h-40) 미정의');
      }
    }
    state.selectedStudentId = null;
    const dialogCount = document.querySelectorAll('[role="dialog"][aria-modal="true"]').length;
    if (dialogCount < 12) {
      throw new Error('접근성 모달(role="dialog", aria-modal="true") 누락: ' + dialogCount + '/12');
    }
    const reqAriaIds = [
      'closeRulesModalBtn', 'closeExcelModalBtn', 'closeSelfTestModalBtn', 'closePrintOptionsModalBtn',
      'closeAppUpdateModalBtn', 'closePairOptionModalBtn', 'collapseSidebarBtn', 'closeRouletteDrawerBtn',
      'saveFileNameInput', 'sepStudentA', 'sepStudentB', 'togStudentA', 'togStudentB', 'showGenderColorToggle'
    ];
    const missingAria = reqAriaIds.filter(id => !(document.getElementById(id) && document.getElementById(id).getAttribute('aria-label')));
    if (missingAria.length > 0) {
      throw new Error('접근성 aria-label 누락 요소: ' + missingAria.join(', '));
    }
    const trigEl = document.getElementById('secretRoomTriggerBtn');
    if (!trigEl || trigEl.getAttribute('tabindex') !== '-1' || trigEl.getAttribute('aria-hidden') !== 'true' || trigEl.getAttribute('aria-label')) {
      throw new Error('진입 아이콘 스텔스 속성(tabindex="-1", aria-hidden="true", aria-label 미부여) 위반');
    }
    const hasFocusCss = Array.from(document.querySelectorAll('style')).some(st => st.textContent.includes(':focus-visible'));
    if (!hasFocusCss) {
      throw new Error('오프라인 내장 CSS :focus-visible 규칙 누락');
    }
    return '28종 내부 심볼 은닉 · 오프라인 CSS · 접근성(모달12·라벨14·포커스·스텔스) 확인';
  });
}
