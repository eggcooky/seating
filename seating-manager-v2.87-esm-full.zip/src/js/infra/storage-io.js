// [L3] 로컬 저장소(localStorage) · 5+1 슬롯 라우팅 · 파일 저장/다운로드 어댑터
import {
  CURRENT_SCHEMA_VERSION,
  DIAG_SANDBOX_STORAGE_KEY,
  LEGACY_STORAGE_KEYS,
  MULTI_CLASS_META_KEY,
  MULTI_CLASS_SLOT_COUNT,
  STORAGE_KEY
} from '../core/constants.js';
import { sanitizeFileName } from '../core/utils.js';
import {
  encodeMultiClassBundle,
  encodeObfuscatedPayload,
  isSimpleObfuscatedText,
  parseSeatFileText
} from '../domain/codec.js';
import { AppStore } from '../state/store.js';
import { markDirty } from '../ui/dirty-indicator.js';
import { updateSecretPresetIndicator } from '../ui/secret-indicators.js';
import { showToast } from '../ui/toast.js';

let _activeClassSlot = 1;
let _diagStorageSandboxActive = false;

export function setDiagStorageSandboxActive(active) {
  _diagStorageSandboxActive = Boolean(active);
}

export function isDiagStorageSandboxActive() {
  return _diagStorageSandboxActive;
}
const _memoryStorageFallback = Object.create(null);

function safeStorageGet(key) {
  try {
    return localStorage.getItem(key);
  } catch (e) {
    return Object.prototype.hasOwnProperty.call(_memoryStorageFallback, key) ? _memoryStorageFallback[key] : null;
  }
}

function safeStorageSet(key, val) {
  try {
    localStorage.setItem(key, val);
    return true;
  } catch (e) {
    _memoryStorageFallback[key] = String(val);
    return false;
  }
}

function safeStorageRemove(key) {
  delete _memoryStorageFallback[key];
  try {
    localStorage.removeItem(key);
  } catch (e) {}
}

export function normalizeSlotIndex(slot) {
  const n = Math.round(Number(slot));
  if (!Number.isFinite(n) || n < 1 || n > MULTI_CLASS_SLOT_COUNT) return 1;
  return n;
}

export function getActiveClassSlot() {
  return _activeClassSlot;
}

export function setActiveClassSlot(slot) {
  _activeClassSlot = normalizeSlotIndex(slot);
  return _activeClassSlot;
}

export function getSlotStorageKey(slot) {
  const s = normalizeSlotIndex(slot);
  return s === 1 ? STORAGE_KEY : `${STORAGE_KEY}_slot_${s}`;
}

// 자가진단 실행 중에는 6번 전용 샌드박스 키로 자동 라우팅해 사용자 1~5번 학급 쓰기를 원천 차단한다.
export function getActiveStorageKey() {
  if (_diagStorageSandboxActive || AppStore.isRunningSelfDiagnostics()) {
    return DIAG_SANDBOX_STORAGE_KEY;
  }
  return getSlotStorageKey(_activeClassSlot);
}

// 자가진단 종료 시 6번 전용 샌드박스 키와 파생 손상 백업 키를 함께 삭제한다.
export function cleanupDiagSandboxStorage() {
  safeStorageRemove(DIAG_SANDBOX_STORAGE_KEY);
  safeStorageRemove(`${DIAG_SANDBOX_STORAGE_KEY}_corrupted_backup`);
}

export function getDefaultMultiClassMeta() {
  return {
    enabled: false,
    activeSlot: 1,
    titles: Array.from({ length: MULTI_CLASS_SLOT_COUNT }, (_, idx) => `학급 ${idx + 1}`)
  };
}

export function loadMultiClassMeta() {
  const fallback = getDefaultMultiClassMeta();
  try {
    const raw = safeStorageGet(MULTI_CLASS_META_KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return fallback;
    const titles = Array.from({ length: MULTI_CLASS_SLOT_COUNT }, (_, idx) => {
      const candidate = Array.isArray(parsed.titles) ? parsed.titles[idx] : '';
      const clean = typeof candidate === 'string' ? candidate.trim().slice(0, 40) : '';
      return clean || `학급 ${idx + 1}`;
    });
    return {
      enabled: Boolean(parsed.enabled),
      activeSlot: normalizeSlotIndex(parsed.activeSlot),
      titles
    };
  } catch (e) {
    return fallback;
  }
}

export function saveMultiClassMeta(meta) {
  if (_diagStorageSandboxActive || AppStore.isRunningSelfDiagnostics()) return false;
  const base = getDefaultMultiClassMeta();
  const safeMeta = {
    enabled: Boolean(meta && meta.enabled),
    activeSlot: normalizeSlotIndex(meta && meta.activeSlot),
    titles: Array.from({ length: MULTI_CLASS_SLOT_COUNT }, (_, idx) => {
      const candidate = meta && Array.isArray(meta.titles) ? meta.titles[idx] : '';
      const clean = typeof candidate === 'string' ? candidate.trim().slice(0, 40) : '';
      return clean || base.titles[idx];
    })
  };
  try {
    return safeStorageSet(MULTI_CLASS_META_KEY, JSON.stringify(safeMeta));
  } catch (e) {
    return false;
  }
}

export function readSlotRawText(slot) {
  try {
    return safeStorageGet(getSlotStorageKey(slot));
  } catch (e) {
    return null;
  }
}

export function writeSlotRawText(slot, rawText) {
  if (_diagStorageSandboxActive || AppStore.isRunningSelfDiagnostics()) return false;
  try {
    if (rawText === null || rawText === undefined) {
      safeStorageRemove(getSlotStorageKey(slot));
      return true;
    }
    return safeStorageSet(getSlotStorageKey(slot), String(rawText));
  } catch (e) {
    return false;
  }
}

export function getObfuscatedPayload() {
  const state = AppStore.getState();
  return encodeObfuscatedPayload(AppStore.getPersistedState(state));
}

export function saveToStorage(showNotification = false) {
  const state = AppStore.getState();
  const now = new Date();
  const timeStr = now.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  state.lastSavedAt = timeStr;
  const targetKey = getActiveStorageKey();
  const payloadStr = getObfuscatedPayload();
  const savedOk = safeStorageSet(targetKey, payloadStr);
  const savedTimeEl = document.getElementById('savedTimeText');
  if (savedTimeEl) {
    savedTimeEl.textContent = savedOk ? `자동저장 (${timeStr})` : '임시 세션 (파일 저장 권장)';
  }
  updateSecretPresetIndicator();
  if (showNotification && savedOk) {
    showToast('현재 상태가 브라우저에 저장되었습니다.', 'success');
  }
}

// 1~5번 전체 학급 데이터를 기존 난독화 포맷으로 묶어 직렬화한다.
export function getMultiClassBundlePayload() {
  const state = AppStore.getState();
  const meta = loadMultiClassMeta();
  const activeSlot = getActiveClassSlot();
  const slots = {};
  for (let slot = 1; slot <= MULTI_CLASS_SLOT_COUNT; slot++) {
    if (slot === activeSlot) {
      slots[String(slot)] = AppStore.getPersistedState(state);
      meta.titles[slot - 1] = String(state.classTitle || `학급 ${slot}`).trim().slice(0, 40) || `학급 ${slot}`;
    } else {
      const raw = readSlotRawText(slot);
      if (raw) {
        try {
          const parsed = parseSeatFileText(raw);
          if (parsed && typeof parsed === 'object') {
            slots[String(slot)] = parsed;
            if (typeof parsed.classTitle === 'string' && parsed.classTitle.trim()) {
              meta.titles[slot - 1] = parsed.classTitle.trim().slice(0, 40);
            }
          }
        } catch (e) {}
      }
    }
  }
  return encodeMultiClassBundle({
    _multiClassBundle: true,
    schemaVersion: CURRENT_SCHEMA_VERSION,
    exportedAt: new Date().toISOString(),
    multiClassEnabled: Boolean(meta.enabled),
    activeSlot,
    titles: meta.titles,
    slots
  });
}

export async function saveWithFileExplorer() {
  const state = AppStore.getState();
  AppStore.flushPendingCommit();
  saveToStorage(false);
  const meta = loadMultiClassMeta();
  const suggestedName = meta.enabled
    ? `${sanitizeFileName(state.classTitle || '학급자리배치')}_전체백업.json`
    : `${sanitizeFileName(state.classTitle || '우리반_자리배치표')}.json`;
  const dataStr = getMultiClassBundlePayload();

  if (typeof window.showSaveFilePicker === 'function') {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName,
        types: [{
          description: '자리 배치 백업 JSON 파일 (전체 학급)',
          accept: { 'application/json': ['.json'] }
        }]
      });
      const writable = await handle.createWritable();
      await writable.write(dataStr);
      await writable.close();
      markDirty(false);
      const saveText = document.getElementById('saveStateBtnText');
      if (saveText) {
        saveText.textContent = '✓ 저장 완료';
        setTimeout(() => {
          const latestState = AppStore.getState();
          if (saveText) saveText.textContent = latestState.isDirty ? '저장하기 ●' : '저장하기';
        }, 1500);
      }
      showToast('지정한 폴더 위치에 전체 학급 백업 파일이 성공적으로 저장되었습니다!', 'success');
      return;
    } catch (err) {
      if (err && err.name === 'AbortError') {
        showToast('파일 저장이 취소되었습니다.', 'info');
        return;
      }
    }
  }

  const modal = document.getElementById('saveFileModal');
  const input = document.getElementById('saveFileNameInput');
  if (modal && input) {
    input.value = suggestedName;
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    input.focus();
    input.select();
  }
}

export function triggerBrowserDownload(fileName) {
  let cleanName = sanitizeFileName((fileName || '우리반_자리배치표.json').replace(/\.json$/i, '')) + '.json';
  const dataStr = getMultiClassBundlePayload();
  const blob = new Blob([dataStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = cleanName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  markDirty(false);
  showToast(`'${cleanName}' 파일(전체 학급 백업)이 저장되었습니다.`, 'success');
}

export function loadFromStorage(fallbackTitle = '우리 반 자리 배치표') {
  const state = AppStore.getState();
  const activeKey = getActiveStorageKey();
  let raw = null;
  let legacyKeyUsed = null;
  try {
    raw = safeStorageGet(activeKey);
    if (!raw && activeKey === STORAGE_KEY) {
      for (const lk of LEGACY_STORAGE_KEYS) {
        const lraw = safeStorageGet(lk);
        if (lraw) { raw = lraw; legacyKeyUsed = lk; break; }
      }
    }
    if (!raw) return false;
    const needsReObfuscate = !isSimpleObfuscatedText(raw);
    const parsed = parseSeatFileText(raw);
    if (AppStore.applyLoadedData(parsed, fallbackTitle, true)) {
      const curState = AppStore.getState();
      curState.lastSavedAt = parsed.lastSavedAt || null;
      // 평문 데이터나 이전 키 데이터는 현재 형식으로 다시 저장하고 구버전 키를 정리한다.
      if (needsReObfuscate || legacyKeyUsed) {
        try {
          localStorage.setItem(activeKey, getObfuscatedPayload());
          if (legacyKeyUsed) localStorage.removeItem(legacyKeyUsed);
        } catch (e) {}
      }
      return true;
    }
  } catch (e) {
    // 파싱 오류 발생 시 아래 손상 데이터 백업 처리로 이동한다.
  }
  if (raw && String(raw).trim()) {
    try {
      localStorage.setItem(`${activeKey}_corrupted_backup`, String(raw));
    } catch (e) {}
    state._corruptedStorageRecovered = true;
    showToast('저장된 데이터가 손상되어 백업 키에 보관하고 기본 상태로 시작했습니다.', 'warn');
  }
  return false;
}
