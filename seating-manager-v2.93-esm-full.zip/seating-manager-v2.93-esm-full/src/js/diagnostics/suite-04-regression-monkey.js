// 자가 진단 스위트 4 (항목 17~18): 핵심 회귀(BUG-01~06·11·12·REG-01~03) · isDirty 전이 · 극단 입력 · 200스텝 시드 몽키
import { restoreHistoryAtIndex } from '../app/history-coordinator.js';
import { toggleSecretRoom } from '../app/mode-coordinator.js';
import { applyMultiClassBundleData } from '../app/multiclass-coordinator.js';
import { cancelRulesModal, openRulesModal } from '../app/rules-coordinator.js';
import { DIAG_SANDBOX_STORAGE_KEY, MAX_COLS, MAX_ROWS, MAX_STUDENT_NUM } from '../core/constants.js';
import { compareStudentsByNumber, formatStudentNumCompact, formatStudentNumLabel, parseInlineStudentNumInput } from '../core/utils.js';
import { generateOptimalSeatAssignment } from '../domain/algorithm-engine.js';
import { encodeMultiClassBundle, isMultiClassBundlePayload, parseSeatFileText } from '../domain/codec.js';
import { parseExcelRosterWithDiagnostics } from '../domain/excel-parser.js';
import { createEmptyClassState, sanitizeLoadedStudents } from '../domain/schema.js';
import { buildSeatingTsvText } from '../domain/seat-queries.js';
import { addNewStudent, applyParsedExcelRoster, deleteStudentById, sortRosterListByNumber, toggleRosterNumEditMode, updateStudentNumInline } from '../features/roster-actions.js';
import { initRouletteSession, syncRouletteWithCurrentLocks } from '../features/roulette-controller.js';
import { toggleSeatLock } from '../features/seat-actions.js';
import { getActiveStorageKey, getSlotStorageKey, isDiagStorageSandboxActive, markHelpGuideSeen, markSecretHelpGuideSeen, normalizeSlotIndex } from '../infra/storage-io.js';
import { closeHelpGuideModal, openHelpGuideModal, openSecretHelpGuideModal } from '../views/help-guide-view.js';
import { pushUndoSnapshot } from '../state/history-store.js';
import { AppStore, setRunningSelfDiagnostics } from '../state/store.js';
import { markDirty } from '../ui/dirty-indicator.js';

export function runRegressionAndMonkeyDiagnostics({
  recordTest,
  setupClassRoster,
  assertValidUniqueCoords,
  assertGlobalInvariants,
  createSeededRng
}) {
  // 17. 핵심 회귀(BUG-01~06·11·12·REG-01~03) · isDirty 전이 · 극단 입력 검증
  recordTest('17. 핵심 회귀 · 미저장 표시 전이 · 극단 입력 매트릭스 검증', () => {
    const rng = createSeededRng(26901);
    let state = AppStore.getState();

    // (A) BUG-01 독립 단언: 반고정석 존재 시 앞줄 배려석(frontRowIds) 전원이 실제 row <= 2에 배치되는지 검증
    for (const pairMode of ['mixed', 'same']) {
      state = setupClassRoster(30, 6);
      state.lockedIds = ['s2', 's4', 's8', 's10'];
      state.rules.useGenderDistinction = true;
      state.rules.genderPairMode = pairMode;
      state.rules.frontRowIds = ['s13', 's15', 's17', 's19'];
      for (let t = 0; t < 15; t++) {
        const res = generateOptimalSeatAssignment({
          students: state.students,
          pos: state.pos,
          rules: state.rules,
          lockedIds: state.lockedIds,
          rng
        });
        assertValidUniqueCoords(res.map, 30);
        for (const fid of state.rules.frontRowIds) {
          const row = res.map[fid][1];
          if (row > 2) {
            throw new Error(`BUG-01 회귀(${pairMode}): 앞줄 학생 ${fid}이 ${row}행으로 밀려남`);
          }
        }
      }
    }

    // (B) BUG-05 실전 충돌 케이스: mixed + 동성 붙이기 과확장 & same + 남녀 혼성 붙이기 충돌 검증
    for (const [mode, pairs, fIds] of [
      ['mixed', [['s1', 's3'], ['s5', 's7']], ['s1', 's3', 's5', 's7', 's2', 's4']],
      ['same', [['s1', 's2'], ['s3', 's4']], ['s1', 's2', 's3', 's4', 's5', 's6']]
    ]) {
      state = setupClassRoster(24, 6);
      state.rules.useGenderDistinction = true;
      state.rules.genderPairMode = mode;
      state.rules.frontRowIds = fIds;
      state.rules.togetherPairs = pairs;
      for (let t = 0; t < 10; t++) {
        const res5 = generateOptimalSeatAssignment({
          students: state.students,
          pos: state.pos,
          rules: state.rules,
          lockedIds: [],
          rng
        });
        assertValidUniqueCoords(res5.map, 24);
        if (res5.conflicts.length > 0) {
          throw new Error(`BUG-05 회귀(${mode} togetherPairs 충돌): ` + res5.conflicts.join(', '));
        }
      }
    }

    // (C) BUG-02 & BUG-06: 다단계 Undo 고스트 잠금 차단 + 비밀방 명단 Undo 시 일반방 스왑 보존
    state = setupClassRoster(10, 4);
    toggleSeatLock('s10');
    pushUndoSnapshot('스텝1', { locks: { lockedIds: [...state.lockedIds], secretLockedIds: [...state.secretLockedIds] } });
    // 학생 삭제(rosterBackup 포함)
    pushUndoSnapshot('학생 삭제', {
      locks: { lockedIds: [...state.lockedIds], secretLockedIds: [...state.secretLockedIds] },
      rosterBackup: {
        students: JSON.parse(JSON.stringify(state.students)),
        pos: JSON.parse(JSON.stringify(state.pos)),
        secretPos: state.secretPos ? JSON.parse(JSON.stringify(state.secretPos)) : null,
        lockedIds: [...state.lockedIds],
        secretLockedIds: [...state.secretLockedIds],
        hiddenSeatIds: [...state.hiddenSeatIds],
        rules: JSON.parse(JSON.stringify(state.rules))
      }
    });
    state.students = state.students.filter(s => s.id !== 's10');
    delete state.pos.s10;
    state.lockedIds = state.lockedIds.filter(id => id !== 's10');
    restoreHistoryAtIndex(0);
    assertGlobalInvariants('BUG-02-다단계Undo');

    // BUG-06: 비밀방 진입 -> 학생 추가(명단 변경) -> 일반방 복귀 후 s1↔s2 수동 스왑 -> 비밀방 복귀 후 명단 Undo -> 일반방 s1 위치 보존 확인
    state = setupClassRoster(10, 4);
    toggleSecretRoom(true, true);
    addNewStudent();
    toggleSecretRoom(false, true);
    const origS1 = [...state.pos.s1];
    const origS2 = [...state.pos.s2];
    state.pos.s1 = [...origS2];
    state.pos.s2 = [...origS1];
    toggleSecretRoom(true, true);
    if (state.undoStackSecret.length > 0) {
      restoreHistoryAtIndex(state.undoStackSecret.length - 1);
    }
    toggleSecretRoom(false, true);
    if (state.pos.s1[0] !== origS2[0] || state.pos.s1[1] !== origS2[1]) {
      throw new Error('BUG-06 회귀: 비밀방 명단 Undo 후 일반방 s1 수동 스왑 위치가 원복됨');
    }
    assertGlobalInvariants('BUG-06-비밀방명단Undo');

    // (D) REG-01: isDirty 전이 매트릭스 (true -> commitChange(dirty:false) 유지 -> 조건 모달 취소 유지 -> 명시 해제 false)
    state = setupClassRoster(12, 4);
    markDirty(false);
    AppStore.commitChange({ classroom: true, dirty: true, save: false });
    if (!state.isDirty) throw new Error('REG-01: 변경 커밋 후 isDirty가 true가 아님');
    AppStore.commitChange({ print: true, dirty: false, save: false });
    if (!state.isDirty) throw new Error('REG-01 회귀: commitChange({ dirty: false })가 isDirty를 초기화함');
    openRulesModal();
    cancelRulesModal();
    if (!state.isDirty) throw new Error('REG-01 회귀: 배치 조건 모달 취소 후 isDirty가 초기화됨');
    markDirty(false);
    if (state.isDirty) throw new Error('REG-01: markDirty(false) 명시 호출 후 해제 실패');

    // (E) REG-02: 룰렛 회전 중(rouletteSpinning=true) openRulesModal 차단 검증
    state.inSecretRoom = false;
    state.rouletteSpinning = true;
    const rulesModalEl = document.getElementById('rulesModal');
    if (rulesModalEl) {
      rulesModalEl.classList.add('hidden');
      rulesModalEl.classList.remove('flex');
    }
    openRulesModal();
    const openedDuringSpin = rulesModalEl && !rulesModalEl.classList.contains('hidden');
    state.rouletteSpinning = false;
    if (openedDuringSpin) {
      cancelRulesModal();
      throw new Error('REG-02 회귀: 룰렛 회전 중 배치 조건 모달이 열림');
    }

    // (F) BUG-11 (정화 + 2-opt toString 직접 호출) & BUG-12/REG-03 (엑셀 엣지)
    const sanitized = sanitizeLoadedStudents([
      { id: 'toString', num: 1, name: '예약어1', gender: '남' },
      { id: 'valueOf', num: 2, name: '예약어2', gender: '여' },
      { id: 'constructor', num: 3, name: '예약어3', gender: '남' },
      { id: 's_big', num: 123456, name: '초과번호', gender: '남' }
    ]);
    if (sanitized.some(s => ['toString', 'valueOf', 'constructor'].includes(String(s.id)))) {
      throw new Error('BUG-11 회귀: Object.prototype 키 ID가 차단되지 않음');
    }
    if (sanitized.length !== 1 || sanitized[0].num > MAX_STUDENT_NUM) {
      throw new Error(`BUG-11 회귀: 학번 상한 ${MAX_STUDENT_NUM} 보정 실패`);
    }
    const sanitizedV291 = sanitizeLoadedStudents([
      { id: 's_id5', num: 30103, name: '오자리학번', gender: '남' },
      { id: 's_cls', num: 3, name: '합반학생', gender: '여', classLabel: '2반' }
    ]);
    if (sanitizedV291.length !== 2 || sanitizedV291[0].num !== 30103 || sanitizedV291[0].classLabel !== undefined || sanitizedV291[1].classLabel !== '2반') {
      throw new Error('v2.91 회귀: 5자리 학번 또는 선택적 classLabel 정화 실패');
    }
    // BUG-11 2-opt 직접 API 호출 (hasTog=false, id='toString' 포함 + separatedPairs)
    state = setupClassRoster(8, 4);
    state.students[0].id = 'toString';
    state.pos.toString = state.pos.s1;
    delete state.pos.s1;
    state.rules.separatedPairs = [['toString', 's2']];
    state.rules.togetherPairs = [];
    const resProto = generateOptimalSeatAssignment({
      students: state.students,
      pos: state.pos,
      rules: state.rules,
      lockedIds: [],
      rng
    });
    assertValidUniqueCoords(resProto.map, 8);

    const ex1 = parseExcelRosterWithDiagnostics('1 남 주혁\n2 여 진구').students;
    if (ex1.length !== 2 || ex1[0].name !== '남 주혁' || ex1[1].name !== '여 진구') {
      throw new Error('BUG-12 회귀: 공백 구분 성씨(남/여) 파싱 실패');
    }
    const ex2 = parseExcelRosterWithDiagnostics('1.홍길동\t010-1234-5678\n2.김영희\t반장\n-5\t음수학생\t여').students;
    if (ex2.length !== 3 || ex2[0].num !== 1 || ex2[0].name !== '홍길동' || ex2[1].num !== 2 || ex2[1].name !== '김영희' || ex2[2].num !== 3 || ex2[2].name !== '음수학생') {
      throw new Error('BUG-12/REG-03 회귀: 붙은 번호·음수 번호 엑셀 파싱 실패');
    }

    // (G) 극단 입력 매트릭스: 0·1·2·45명, 단일 성별(남100%/여100%), 1열 세로, 경계 좌표 (0,0)·(11,15)
    for (const cnt of [0, 1, 2, 45]) {
      state = setupClassRoster(cnt, cnt <= 1 ? 1 : 6);
      const resE = generateOptimalSeatAssignment({ students: state.students, pos: state.pos, rules: state.rules, lockedIds: [], rng });
      state.pos = resE.map;
      assertGlobalInvariants(`극단인원-${cnt}`);
    }
    for (const singleGender of ['남', '여']) {
      state = setupClassRoster(12, 4);
      state.students.forEach(s => { s.gender = singleGender; });
      state.rules.useGenderDistinction = true;
      state.rules.genderPairMode = 'mixed';
      const resG = generateOptimalSeatAssignment({ students: state.students, pos: state.pos, rules: state.rules, lockedIds: [], rng });
      state.pos = resG.map;
      assertGlobalInvariants(`단일성별-${singleGender}`);
    }
    state = setupClassRoster(2, 1);
    state.pos.s1 = [0, 0];
    state.pos.s2 = [MAX_COLS - 1, MAX_ROWS - 1];
    const resB = generateOptimalSeatAssignment({ students: state.students, pos: state.pos, rules: state.rules, lockedIds: [], rng });
    state.pos = resB.map;
    assertGlobalInvariants('경계좌표-0,0-11,15');

    // (H) v2.74~2.75 회귀 2건: 비밀방 엑셀 적용+Undo 및 일반방 Undo 시 비밀방 잠금·스택 동시 정리
    state = setupClassRoster(8, 4);
    toggleSecretRoom(true, true);
    const taSec = document.getElementById('excelPasteTextarea');
    if (taSec) {
      taSec.value = '1\t비밀신규1\t남\n2\t비밀신규2\t여\n3\t비밀신규3\t남';
      applyParsedExcelRoster(true);
      if (state.students.length !== 3 || state.undoStackSecret.length !== 1 || !state.secretPos) {
        throw new Error('비밀방 엑셀 적용 후 undoStackSecret/secretPos 정합성 오류');
      }
      restoreHistoryAtIndex(0);
      if (state.students.length !== 8) {
        throw new Error('비밀방 엑셀 적용 Undo 복원 실패');
      }
      assertGlobalInvariants('비밀방엑셀Undo');
    }
    toggleSecretRoom(false, true);

    state = setupClassRoster(8, 4);
    deleteStudentById(state.students[7]); // secretPos === null 시점 삭제 백업
    toggleSecretRoom(true, true);
    toggleSeatLock(state.students[0].id);
    pushUndoSnapshot('비밀방 임시 변경');
    toggleSecretRoom(false, true);
    restoreHistoryAtIndex(state.undoStackNormal.length - 1);
    if (state.secretPos !== null || state.secretLockedIds.length !== 0 || state.undoStackSecret.length !== 0) {
      throw new Error('일반 모드 Undo 시 비밀방 좌표·잠금·스택 동시 정리 실패');
    }
    assertGlobalInvariants('일반방Undo비밀방정리');

    // (K) v2.78~v2.87: 자가진단 전용 샌드박스 락 유지([C-01]) · 손상 묶음 거부([H-01]) · 비밀방 명단변경 후 일반방 Undo 가리기 보존([H-02]) · 표(TSV) 검증
    let sandboxLockedEvenWhenDiagOff = false;
    try {
      setRunningSelfDiagnostics(false);
      sandboxLockedEvenWhenDiagOff = isDiagStorageSandboxActive() && getActiveStorageKey() === DIAG_SANDBOX_STORAGE_KEY;
    } finally {
      setRunningSelfDiagnostics(true);
    }
    if (!sandboxLockedEvenWhenDiagOff) {
      throw new Error('자가진단 플래그 일시 해제 시 자가진단 전용 샌드박스 스토리지 락 유지 실패');
    }

    // [H-01] 손상된 다중학급 묶음 및 미래 스키마 번들 거부 검증
    state = setupClassRoster(8, 4);
    const badBundleEmpty = applyMultiClassBundleData({ _multiClassBundle: true, slots: {} });
    const badBundleFuture = applyMultiClassBundleData({ _multiClassBundle: true, slots: { '1': { schemaVersion: 999, students: [], pos: {} } } });
    if (badBundleEmpty !== false || badBundleFuture !== false || state.students.length !== 8) {
      throw new Error('손상/미래버전 다중학급 묶음 백업 사전 차단 실패');
    }

    // [H-02] 가리기 활성 상태에서 비밀방 학생 추가 후 일반방 Undo 시 가리기 좌석 보존 검증
    state = setupClassRoster(8, 4);
    state.maskModeEnabled = true;
    state.hiddenSeatIds = state.students.map(s => String(s.id));
    toggleSecretRoom(true, true);
    addNewStudent();
    toggleSecretRoom(false, true);
    restoreHistoryAtIndex(state.undoStackNormal.length - 1);
    if (state.students.length !== 8 || state.hiddenSeatIds.length !== 8) {
      throw new Error(`비밀방 명단 추가 후 일반방 Undo 가리기 보존 실패 (인원=${state.students.length}, 가림=${state.hiddenSeatIds.length})`);
    }
    state.maskModeEnabled = false;
    state.hiddenSeatIds = [];
    state = setupClassRoster(8, 4);
    const emptySlot = createEmptyClassState('테스트 2반');
    if (emptySlot.students.length !== 0 || Object.keys(emptySlot.pos).length !== 0) {
      throw new Error('미사용 다중학급 빈 슬롯(0명) 생성 실패');
    }
    if (normalizeSlotIndex(7) !== 7 || normalizeSlotIndex(8) !== 1 || getSlotStorageKey(6) === DIAG_SANDBOX_STORAGE_KEY) {
      throw new Error('7학급 슬롯 정규화 또는 6번 학급·자가진단 샌드박스 키 분리 검증 실패');
    }
    const bundleRaw = encodeMultiClassBundle({
      _multiClassBundle: true,
      schemaVersion: 2,
      activeSlot: 1,
      titles: ['테스트 1반', '테스트 2반', '학급 3', '학급 4', '학급 5', '학급 6', '테스트 7반'],
      slots: { '1': AppStore.getPersistedState(state), '2': emptySlot, '7': createEmptyClassState('테스트 7반') }
    });
    const bundleParsed = parseSeatFileText(bundleRaw);
    if (!isMultiClassBundlePayload(bundleParsed) || bundleParsed.slots['2'].students.length !== 0 || bundleParsed.slots['7'].students.length !== 0) {
      throw new Error('7학급 통합 백업 코덱 왕복 검증 실패');
    }
    const stuTsv = buildSeatingTsvText(state, 'student');
    const teaTsv = buildSeatingTsvText(state, 'teacher');
    if (!stuTsv.includes('\t') || !stuTsv.split('\n')[1].includes('[교탁]') || !teaTsv.split('\n').at(-1).includes('[교탁]')) {
      throw new Error('출력 모달 표(TSV) 시점 반전 직렬화 실패');
    }

    // [v2.90·v2.91 보강] 도움말 모달 수동 열기/닫기 · 스텔스·6단계+무번호4팁 구조 · HELP_GUIDE_SEEN_KEY 쓰기 차단 검증
    const helpOpened = openHelpGuideModal({ isAutoFirstRun: false });
    const helpModalEl = document.getElementById('helpGuideModal');
    if (!helpOpened || !helpModalEl || helpModalEl.classList.contains('hidden')) {
      throw new Error('도움말 모달 수동 열기 검증 실패');
    }
    const helpText = helpModalEl.textContent || '';
    if (['비밀의 방', '거리두기', '붙이기'].some(w => helpText.includes(w))) {
      throw new Error('도움말 모달에 스텔스 금지어가 노출됨');
    }
    const helpStepCount = helpModalEl.querySelectorAll('#helpGuideStepList > li[data-help-step]').length;
    const helpTipCount = helpModalEl.querySelectorAll('.help-guide-tips > div').length;
    if (helpStepCount !== 6 || helpTipCount !== 4) {
      throw new Error(`도움말 모달 구조 불일치 (단계=${helpStepCount}/6, 무번호 팁=${helpTipCount}/4)`);
    }
    if (markHelpGuideSeen() !== false) {
      throw new Error('자가진단 실행 중 HELP_GUIDE_SEEN_KEY 쓰기 차단 실패');
    }
    closeHelpGuideModal({ persistSeen: true });
    if (!helpModalEl.classList.contains('hidden')) {
      throw new Error('도움말 모달 닫기 검증 실패');
    }

    // [v2.93 보강] 비밀의 방 전용 도움말 일반화면 차단 · 5단계 구조 · 쓰기 차단 · 퇴장 시 즉시 닫힘 검증
    const secretHelpModalEl = document.getElementById('secretHelpGuideModal');
    if (openSecretHelpGuideModal({ isAutoFirstRun: false }) !== false || (secretHelpModalEl && !secretHelpModalEl.classList.contains('hidden'))) {
      throw new Error('일반 화면에서 비밀의 방 전용 도움말 열기 차단 실패');
    }
    toggleSecretRoom(true, true);
    const secHelpOpened = openSecretHelpGuideModal({ isAutoFirstRun: false });
    if (!secHelpOpened || !secretHelpModalEl || secretHelpModalEl.classList.contains('hidden')) {
      throw new Error('비밀의 방 전용 도움말 수동 열기 검증 실패');
    }
    const secHelpSteps = secretHelpModalEl.querySelectorAll('#secretHelpGuideStepList > li[data-secret-help-step]').length;
    const secStartBtn = document.getElementById('startSecretHelpGuideBtn');
    const secCheckWrap = document.getElementById('secretHelpDontShowAgainWrap');
    if (secHelpSteps !== 5 || !secStartBtn || secStartBtn.textContent !== '닫기' || !secCheckWrap || !secCheckWrap.classList.contains('hidden')) {
      throw new Error(`비밀의 방 도움말 구조 또는 수동 열람 UI 불일치 (단계=${secHelpSteps}/5)`);
    }
    if (markSecretHelpGuideSeen() !== false) {
      throw new Error('자가진단 실행 중 SECRET_HELP_GUIDE_SEEN_KEY 쓰기 차단 실패');
    }
    toggleSecretRoom(false, true);
    if (!secretHelpModalEl.classList.contains('hidden')) {
      throw new Error('비밀의 방 퇴장 시 비밀 도움말 자동 닫기 실패');
    }

    // [v2.91 보강] 합반 학반 자동 감지 · (classLabel, num) 중복 공존 · 연번 오탐 방어 · 5자리 학번 포맷/자연정렬 검증
    const mixedParsed = parseExcelRosterWithDiagnostics('1반\t3\t홍길동\t남\n2반\t3\t김영희\t여\n10반\t1\t박민수\t남\n3-1-15\t이철수\t남', true).students;
    if (mixedParsed.length !== 4 || mixedParsed[0].classLabel !== '1반' || mixedParsed[0].num !== 3 || mixedParsed[1].classLabel !== '2반' || mixedParsed[1].num !== 3 || mixedParsed[3].classLabel !== '3-1' || mixedParsed[3].num !== 15) {
      throw new Error('v2.91 회귀: 합반 학반 자동 추출 또는 반별 동일 번호 공존 검증 실패');
    }
    const serialNotClass = parseExcelRosterWithDiagnostics('1\t15\t홍길동\t남\n2\t16\t김영희\t여\n3\t17\t박민수\t남', true).students;
    if (serialNotClass.length !== 3 || serialNotClass.some(s => Boolean(s.classLabel)) || serialNotClass[0].num !== 15) {
      throw new Error('v2.91 회귀: [연번/번호/성명] 양식이 학반으로 오탐됨');
    }
    const id5Parsed = parseExcelRosterWithDiagnostics('30103\t김학번\t남', true).students;
    if (id5Parsed.length !== 1 || id5Parsed[0].num !== 30103 || formatStudentNumLabel(id5Parsed[0]) !== '30103' || formatStudentNumCompact(mixedParsed[0]) !== '1-3' || formatStudentNumLabel(mixedParsed[0]) !== '1반 3번') {
      throw new Error('v2.91 회귀: 5자리 학번 또는 학반 포맷터 출력 오류');
    }
    const sortedCls = [mixedParsed[2], mixedParsed[1], mixedParsed[0]].sort(compareStudentsByNumber);
    if (sortedCls[0].classLabel !== '1반' || sortedCls[1].classLabel !== '2반' || sortedCls[2].classLabel !== '10반') {
      throw new Error('v2.91 회귀: 합반 학반 자연정렬(1반→2반→10반) 실패');
    }
    const inlineOk = parseInlineStudentNumInput('2-5');
    const inlineBad = parseInlineStudentNumInput('123456');
    if (!inlineOk.ok || inlineOk.classLabel !== '2반' || inlineOk.num !== 5 || inlineBad.ok) {
      throw new Error('v2.91 회귀: 명렬표 1칸 반·번호 파서 오류');
    }
    state = setupClassRoster(4, 4);
    toggleRosterNumEditMode(true);
    const editRes = updateStudentNumInline(state.students[0], '10반 2');
    const editRes2 = updateStudentNumInline(state.students[1], '2-1');
    if (!state.rosterNumEditMode || !editRes.ok || state.students[0].classLabel !== '10반' || state.students[0].num !== 2 || !editRes2.ok || state.students[1].classLabel !== '2반' || state.students[1].num !== 1) {
      throw new Error('v2.91 회귀: 명렬표 반·번호 직접 편집 모드 반영 실패');
    }
    // 중복 반·번호(2반 1번) 경고 스타일 및 포커스 입력칸 재렌더(blur 재진입) 방어 + 번호순 정리 Undo 복원 검증
    updateStudentNumInline(state.students[2], '2-1');
    AppStore.syncViews({ roster: true, classroom: false, animate: false, print: false, rules: false });
    const numInputs = document.querySelectorAll('#rosterListContainer [data-roster-num-input]');
    const amberDupCount = Array.from(numInputs).filter(el => el.className.includes('border-amber-400')).length;
    if (amberDupCount < 2) {
      throw new Error(`v2.91 회귀: 중복 반·번호 경고 스타일(border-amber-400) 미표시 (${amberDupCount}/2)`);
    }
    const orderBeforeSort = state.students.map(s => String(s.id));
    if (numInputs[0]) {
      numInputs[0].focus();
      numInputs[0].value = '잘못된값!!!';
    }
    const sortedOk = sortRosterListByNumber();
    const lastAfterSort = state.students[state.students.length - 1];
    if (!sortedOk || !lastAfterSort || lastAfterSort.classLabel !== '10반' || lastAfterSort.num !== 2) {
      throw new Error('v2.91 회귀: 명렬표 번호순 정리(10반 자연정렬) 또는 재렌더 blur 방어 실패');
    }
    restoreHistoryAtIndex(state.undoStackNormal.length - 1);
    const orderAfterSortUndo = state.students.map(s => String(s.id));
    if (orderAfterSortUndo.join(',') !== orderBeforeSort.join(',')) {
      throw new Error('v2.91 회귀: 명렬표 번호순 정리 후 되돌리기(Undo) 순서 복원 실패');
    }
    // 합반 상태에서 학생 추가 시 마지막 학생의 classLabel 자동 상속 및 다음 번호 부여 검증
    updateStudentNumInline(state.students[state.students.length - 1], '2반 3');
    addNewStudent();
    const addedMixed = state.students[state.students.length - 1];
    if (!addedMixed || addedMixed.classLabel !== '2반' || addedMixed.num !== 4) {
      throw new Error('v2.91 회귀: 합반 명단에서 학생 추가 시 학반 자동 상속 또는 다음 번호 계산 실패');
    }
    toggleRosterNumEditMode(false);
    if (state.rosterNumEditMode) {
      throw new Error('v2.91 회귀: 명렬표 반·번호 편집 모드 해제 실패');
    }

    return '핵심 회귀·Undo·미저장·보안·극단(0~45명)·7학급·도움말·합반학번·표(TSV) 통과';
  });

  // 18. 고정 시드 200스텝 교차 조작 몽키 불변식 검증 (rosterBackup 삭제 + 임의 인덱스 다단계 Undo)
  recordTest('18. 고정 시드 200스텝 교차 조작 몽키 불변식 검증', () => {
    const rng = createSeededRng(20261120);
    const pickInt = (max) => Math.floor(rng() * max);

    const state = setupClassRoster(16, 4);
    assertGlobalInvariants('몽키-초기');

    let stepCount = 0;
    for (let step = 1; step <= 200; step++) {
      stepCount = step;
      const action = pickInt(9);

      if (action === 0 && state.students.length < 30) {
        addNewStudent();
      } else if (action === 1 && state.students.length > 4 && !state.rouletteActiveSession) {
        const victim = state.students[pickInt(state.students.length)];
        deleteStudentById(victim);
      } else if (action === 2 && state.students.length > 0) {
        const target = state.students[pickInt(state.students.length)];
        toggleSeatLock(target.id);
      } else if (action === 3 && state.students.length >= 2) {
        const activePos = state.inSecretRoom && state.secretPos ? state.secretPos : state.pos;
        const activeLocks = state.inSecretRoom ? state.secretLockedIds : state.lockedIds;
        const res = generateOptimalSeatAssignment({
          students: state.students,
          pos: activePos,
          rules: state.rules,
          lockedIds: activeLocks,
          rng
        });
        if (state.inSecretRoom && state.secretPos) {
          state.secretPos = res.map;
        } else {
          state.pos = res.map;
          if (state.rouletteActiveSession) syncRouletteWithCurrentLocks();
        }
      } else if (action === 4) {
        toggleSecretRoom(!state.inSecretRoom, true);
      } else if (action === 5) {
        openRulesModal();
        if (state.students.length >= 2) {
          state.rules.frontRowIds = [String(state.students[0].id)];
          state.rules.separatedPairs = [[String(state.students[0].id), String(state.students[1].id)]];
        }
        cancelRulesModal();
      } else if (action === 6) {
        // 임의 인덱스 점프 다단계 Undo
        const curStack = state.inSecretRoom ? state.undoStackSecret : state.undoStackNormal;
        if (curStack.length > 0) {
          restoreHistoryAtIndex(pickInt(curStack.length));
        }
      } else if (action === 7 && !state.inSecretRoom) {
        if (!state.rouletteActiveSession) {
          state.rouletteOpen = true;
          initRouletteSession(false);
        } else {
          syncRouletteWithCurrentLocks();
        }
      } else if (action === 8 && !state.rouletteActiveSession) {
        const n = 6 + pickInt(10);
        const lines = [];
        for (let i = 1; i <= n; i++) {
          lines.push(`${i}\t몽키학생${step}_${i}\t${i % 2 === 0 ? '여' : '남'}`);
        }
        const ta = document.getElementById('excelPasteTextarea');
        if (ta) {
          ta.value = lines.join('\n');
          applyParsedExcelRoster(true);
          if (!state.inSecretRoom && state.undoStackSecret.length !== 0) {
            throw new Error(`스텝 ${step}: 일반 모드 엑셀 교체 후 undoStackSecret 미초기화`);
          }
        }
      }

      assertGlobalInvariants(`몽키-step-${step}(act=${action})`);
    }

    toggleSecretRoom(false, true);
    state.rouletteOpen = false;
    state.rouletteActiveSession = false;
    return `고정 시드 ${stepCount}스텝 교차 조작(실제 학생 삭제·다단계 Undo 포함) 전역 불변식 위반 0건`;
  });
}
