// [L1] 순수 조건 기반 자리 배정 알고리즘 엔진 (DOM·전역상태 비의존)
import { MAX_COLS, MAX_ROWS } from '../core/constants.js';

// [10] 조건 기반 자리 배정 알고리즘 및 자리 바꾸기 실행 (SeatingAlgorithmModule)
/**
 * @typedef {import('../core/constants.js').Student} Student
 * @typedef {import('../core/constants.js').SeatCoord} SeatCoord
 * @typedef {import('../core/constants.js').SeatingRules} SeatingRules
 * @typedef {import('../core/constants.js').AlgorithmInput} AlgorithmInput
 */

// 정수 비트 키((col << 5) | row) 및 Uint8Array(384) 버퍼 인덱싱 안전성 상한 검증
if (MAX_COLS > 12 || MAX_ROWS > 31) {
  throw new Error('SeatingAlgorithmModule bit-key bounds exceeded (requires MAX_COLS <= 12, MAX_ROWS <= 31)');
}

/**
 * 배열을 시드 가능한 난수 함수(rng)로 제자리 셔플한다.
 * @template T
 * @param {T[]} arr
 * @param {() => number} [rng]
 * @returns {T[]}
 */
function shuffleArrayInPlace(arr, rng = Math.random) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
  }
  return arr;
}

/**
 * 전달받은 학생 목록과 좌표 맵만으로 격자 경계(c0, c1, r0, r1)를 계산하는 순수 헬퍼
 * @param {Student[]} students
 * @param {Record<string, SeatCoord>} posMap
 * @returns {{ c0: number, c1: number, r0: number, r1: number }}
 */
function computePureGridBounds(students, posMap) {
  const coords = (students || []).map(s => posMap && posMap[s.id]).filter(Boolean);
  if (!coords.length) {
    return { c0: 0, c1: 5, r0: 0, r1: 4 };
  }
  let c0 = coords[0][0], c1 = coords[0][0], r0 = coords[0][1], r1 = coords[0][1];
  for (let i = 1; i < coords.length; i++) {
    const [c, r] = coords[i];
    if (c < c0) c0 = c;
    if (c > c1) c1 = c;
    if (r < r0) r0 = r;
    if (r > r1) r1 = r;
  }
  return { c0, c1, r0, r1 };
}

/**
 * 각 행의 실제 책상 배치를 기준으로 2인 짝 슬롯, 단독 슬롯, 반쪽 고정 슬롯을 분류한다. (전역 참조 없는 순수 함수)
 * @param {SeatCoord[]} unlockedCoordsList
 * @param {Record<string, SeatCoord>} fullMap
 * @param {Student[]} studentsList
 */
function extractActualRowPairs(unlockedCoordsList, fullMap, studentsList) {
  if (!fullMap || !Array.isArray(studentsList)) {
    throw new Error('extractActualRowPairs requires explicit fullMap and studentsList');
  }
  const allOccupiedCoords = studentsList.map(s => fullMap[s.id]).filter(Boolean);
  const unlockedKeySet = new Set((unlockedCoordsList || []).map(p => `${p[0]},${p[1]}`));

  const byRowAll = {};
  allOccupiedCoords.forEach(p => {
    const r = p[1];
    if (!byRowAll[r]) byRowAll[r] = [];
    byRowAll[r].push(p);
  });

  const fullPairSlots = [];
  const singleSlots = [];
  const halfLocked = []; // 한쪽만 고정된 2인 짝 정보

  Object.keys(byRowAll).map(Number).sort((a, b) => a - b).forEach(r => {
    const rowCoords = byRowAll[r].sort((a, b) => a[0] - b[0]);
    let i = 0;
    while (i < rowCoords.length) {
      if (i + 1 < rowCoords.length && rowCoords[i + 1][0] - rowCoords[i][0] === 1) {
        const leftP = rowCoords[i];
        const rightP = rowCoords[i + 1];
        const leftUnlocked = unlockedKeySet.has(`${leftP[0]},${leftP[1]}`);
        const rightUnlocked = unlockedKeySet.has(`${rightP[0]},${rightP[1]}`);
        if (leftUnlocked && rightUnlocked) {
          fullPairSlots.push([leftP, rightP]);
        } else {
          if (leftUnlocked) singleSlots.push(leftP);
          if (rightUnlocked) singleSlots.push(rightP);
          if (leftUnlocked && !rightUnlocked) halfLocked.push({ c: leftP, mate: rightP });
          if (rightUnlocked && !leftUnlocked) halfLocked.push({ c: rightP, mate: leftP });
        }
        i += 2;
      } else {
        const p = rowCoords[i];
        if (unlockedKeySet.has(`${p[0]},${p[1]}`)) {
          singleSlots.push(p);
        }
        i += 1;
      }
    }
  });

  return { fullPairSlots, singleSlots, halfLocked };
}

/**
 * 거리두기(separatedPairs)와 친구끼리 붙이기(togetherPairs) 등록 가능 여부를 검증한다(동시 등록 및 중복 짝 원천 차단).
 * @param {string} idA
 * @param {string} idB
 * @param {'sep'|'tog'} [targetType]
 * @param {SeatingRules} [rulesObj]
 * @returns {{ ok: boolean, reason: string }}
 */
function canRegisterPairRule(idA, idB, targetType = 'sep', rulesObj = null) {
  const activeRules = rulesObj || {};
  const a = String(idA || '');
  const b = String(idB || '');
  if (!a || !b || a === b) {
    return { ok: false, reason: '서로 다른 두 학생을 선택해 주세요.' };
  }
  const sepList = activeRules.separatedPairs || [];
  const togList = activeRules.togetherPairs || [];
  const inSep = sepList.some(p => (String(p[0]) === a && String(p[1]) === b) || (String(p[0]) === b && String(p[1]) === a));
  const inTog = togList.some(p => (String(p[0]) === a && String(p[1]) === b) || (String(p[0]) === b && String(p[1]) === a));

  if (targetType === 'sep') {
    if (inSep) return { ok: false, reason: '이미 거리두기 목록에 등록된 학생 조합입니다.' };
    if (inTog) return { ok: false, reason: '이미 친구끼리 붙이기 목록에 등록된 학생 조합입니다. 거리두기와 붙이기는 동시에 설정할 수 없습니다.' };
    return { ok: true, reason: '' };
  } else {
    if (inTog) return { ok: false, reason: '이미 친구끼리 붙이기 목록에 등록된 학생 조합입니다.' };
    if (inSep) return { ok: false, reason: '이미 거리두기 목록에 등록된 학생 조합입니다. 거리두기와 붙이기는 동시에 설정할 수 없습니다.' };
    const alreadyPairedOther = togList.some(p => String(p[0]) === a || String(p[1]) === a || String(p[0]) === b || String(p[1]) === b);
    if (alreadyPairedOther) {
      return { ok: false, reason: '선택한 학생 중 이미 다른 친구와 붙이기(짝꿍)로 설정된 학생이 있습니다.' };
    }
    return { ok: true, reason: '' };
  }
}

/**
 * 앞줄 배려석(frontRowIds) 학생과 그 짝꿍(togetherPairs), 그리고 앞줄 학생 간 상호 거리두기(separatedPairs) 제약을 고려해 허용 앞줄 행 상한(maxFrontRow)을 계산한다. (전역 참조 없는 순수 함수)
 * @param {Record<string, SeatCoord>} candidateMap
 * @param {Student[]} unlockedStudents
 * @param {number} r0
 * @param {SeatingRules} rulesObj
 * @returns {number}
 */
function computeEffectiveMaxFrontRow(candidateMap, unlockedStudents, r0, rulesObj, allStudents = null) {
  if (!rulesObj) {
    throw new Error('computeEffectiveMaxFrontRow requires explicit rulesObj');
  }
  const unlockedIdSet = new Set(unlockedStudents.map(s => String(s.id)));
  const rawFrontIds = (rulesObj.frontRowIds || []).map(String).filter(id => unlockedIdSet.has(id));
  if (rawFrontIds.length === 0) return r0 + 1;

  const effectiveFrontSet = new Set(rawFrontIds);
  (rulesObj.togetherPairs || []).forEach(pair => {
    if (!Array.isArray(pair) || pair.length !== 2) return;
    const a = String(pair[0]), b = String(pair[1]);
    if (effectiveFrontSet.has(a) && unlockedIdSet.has(b)) effectiveFrontSet.add(b);
    if (effectiveFrontSet.has(b) && unlockedIdSet.has(a)) effectiveFrontSet.add(a);
  });

  const unlockedCoords = unlockedStudents.map(s => candidateMap[s.id]).filter(Boolean);
  const sortedRows = unlockedCoords.map(p => p[1]).sort((a, b) => a - b);
  const targetIdx = Math.min(sortedRows.length - 1, Math.max(0, effectiveFrontSet.size - 1));
  let maxFR = Math.max(r0 + 1, sortedRows[targetIdx] || (r0 + 1));

  const mode = (rulesObj.useGenderDistinction === false) ? 'any' : rulesObj.genderPairMode;
  const seatsPerRow = {};
  unlockedCoords.forEach(p => { seatsPerRow[p[1]] = (seatsPerRow[p[1]] || 0) + 1; });
  const distinctRows = Object.keys(seatsPerRow).map(Number).sort((a, b) => a - b);

  // BUG-01(ST-18) 방어: 행별 실제 완전 미고정 2인 짝 슬롯과 반쪽 고정석(남/여 옆자리) 수를 정밀 집계한다.
  const studentsForPairs = Array.isArray(allStudents) && allStudents.length > 0 ? allStudents : unlockedStudents;
  const pairBreakdown = extractActualRowPairs(unlockedCoords, candidateMap, studentsForPairs);
  const fullPairsPerRow = {};
  const halfBoyMatePerRow = {};
  const halfGirlMatePerRow = {};
  const singleSlotsPerRow = {};
  (pairBreakdown.fullPairSlots || []).forEach(([sL]) => {
    fullPairsPerRow[sL[1]] = (fullPairsPerRow[sL[1]] || 0) + 1;
  });
  const coordToGenderForHalf = {};
  studentsForPairs.forEach(s => {
    const p = candidateMap[s.id];
    if (Array.isArray(p)) coordToGenderForHalf[`${p[0]},${p[1]}`] = s.gender;
  });
  const halfCoordKeySet = new Set();
  (pairBreakdown.halfLocked || []).forEach(h => {
    const rNum = h.c[1];
    halfCoordKeySet.add(`${h.c[0]},${h.c[1]}`);
    const mateGender = h.mateGender || (Array.isArray(h.mate) ? coordToGenderForHalf[`${h.mate[0]},${h.mate[1]}`] : null);
    if (mateGender === '남') halfBoyMatePerRow[rNum] = (halfBoyMatePerRow[rNum] || 0) + 1;
    else if (mateGender === '여') halfGirlMatePerRow[rNum] = (halfGirlMatePerRow[rNum] || 0) + 1;
  });
  (pairBreakdown.singleSlots || []).forEach(sc => {
    if (!halfCoordKeySet.has(`${sc[0]},${sc[1]}`)) {
      singleSlotsPerRow[sc[1]] = (singleSlotsPerRow[sc[1]] || 0) + 1;
    }
  });

  let frontBoys = 0, frontGirls = 0;
  const idToGenderLocal = {};
  unlockedStudents.forEach(s => {
    idToGenderLocal[String(s.id)] = s.gender;
    if (effectiveFrontSet.has(String(s.id))) {
      if (s.gender === '남') frontBoys++; else frontGirls++;
    }
  });

  if (mode === 'mixed' || mode === 'mixed_random') {
    const totalBoyCount = unlockedStudents.filter(s => s.gender === '남').length;
    const totalGirlCount = unlockedStudents.filter(s => s.gender === '여').length;
    let frontSameBoyPairs = 0, frontSameGirlPairs = 0;
    (rulesObj.togetherPairs || []).forEach(pair => {
      if (!Array.isArray(pair) || pair.length !== 2) return;
      const a = String(pair[0]), b = String(pair[1]);
      if (effectiveFrontSet.has(a) && effectiveFrontSet.has(b) && idToGenderLocal[a] && idToGenderLocal[a] === idToGenderLocal[b]) {
        if (idToGenderLocal[a] === '남') frontSameBoyPairs++; else frontSameGirlPairs++;
      }
    });
    const remFrontBoys = Math.max(0, frontBoys - frontSameBoyPairs * 2);
    const remFrontGirls = Math.max(0, frontGirls - frontSameGirlPairs * 2);
    const remTotalBoys = Math.max(0, totalBoyCount - frontSameBoyPairs * 2);
    const remTotalGirls = Math.max(0, totalGirlCount - frontSameGirlPairs * 2);
    const mixableFrontBoys = Math.min(remFrontBoys, remTotalGirls);
    const excessFrontBoys = Math.max(0, remFrontBoys - mixableFrontBoys);
    const mixableFrontGirls = Math.min(remFrontGirls, remTotalBoys);
    const excessFrontGirls = Math.max(0, remFrontGirls - mixableFrontGirls);

    if (effectiveFrontSet.size > 0) {
      let cumFull = 0, cumHalfNeedBoy = 0, cumHalfNeedGirl = 0, cumFree = 0, cumSeats = 0, satisfied = false;
      for (let ri = 0; ri < distinctRows.length; ri++) {
        const rowNum = distinctRows[ri];
        cumFull += (fullPairsPerRow[rowNum] || 0);
        cumHalfNeedBoy += (halfGirlMatePerRow[rowNum] || 0);
        cumHalfNeedGirl += (halfBoyMatePerRow[rowNum] || 0);
        cumFree += (singleSlotsPerRow[rowNum] || 0);
        cumSeats += (seatsPerRow[rowNum] || 0);
        const availFull = cumFull - frontSameBoyPairs - frontSameGirlPairs;
        if (availFull >= 0 && cumSeats >= effectiveFrontSet.size) {
          const needBoyFull = Math.max(0, mixableFrontBoys - cumHalfNeedBoy - cumFree) + Math.ceil(excessFrontBoys / 2);
          const needGirlFull = Math.max(0, mixableFrontGirls - cumHalfNeedGirl - cumFree) + Math.ceil(excessFrontGirls / 2);
          if (availFull >= Math.max(needBoyFull, needGirlFull)) {
            if (rowNum > maxFR) maxFR = rowNum;
            satisfied = true;
            break;
          }
        }
      }
      // BUG-01(ST-13) 방어: 전체 행 용량을 초과한 경우 마지막 행까지 확장해 성별 짝 파괴를 방지한다.
      if (!satisfied && distinctRows.length > 0) {
        const lastRow = distinctRows[distinctRows.length - 1];
        if (lastRow > maxFR) maxFR = lastRow;
      }
    }
  } else if (mode === 'same' || mode === 'same_random') {
    let frontMixedTogPairs = 0;
    (rulesObj.togetherPairs || []).forEach(pair => {
      if (!Array.isArray(pair) || pair.length !== 2) return;
      const a = String(pair[0]), b = String(pair[1]);
      if (effectiveFrontSet.has(a) && effectiveFrontSet.has(b) && idToGenderLocal[a] && idToGenderLocal[b] && idToGenderLocal[a] !== idToGenderLocal[b]) {
        frontMixedTogPairs++;
      }
    });
    const baseFrontBoys = Math.max(0, frontBoys - frontMixedTogPairs);
    const baseFrontGirls = Math.max(0, frontGirls - frontMixedTogPairs);

    if (frontBoys > 0 || frontGirls > 0) {
      let cumFullPairs = 0, cumHalfBoy = 0, cumHalfGirl = 0, cumSingle = 0, cumSeats = 0, satisfied = false;
      for (let ri = 0; ri < distinctRows.length; ri++) {
        const rowNum = distinctRows[ri];
        cumFullPairs += fullPairsPerRow[rowNum] || 0;
        cumHalfBoy += halfBoyMatePerRow[rowNum] || 0;
        cumHalfGirl += halfGirlMatePerRow[rowNum] || 0;
        cumSingle += singleSlotsPerRow[rowNum] || 0;
        cumSeats += seatsPerRow[rowNum] || 0;
        const availFull = cumFullPairs - frontMixedTogPairs;
        if (availFull >= 0 && cumSeats >= effectiveFrontSet.size) {
          let remB = Math.max(0, baseFrontBoys - cumHalfBoy);
          let remG = Math.max(0, baseFrontGirls - cumHalfGirl);
          let remFree = cumSingle;
          if ((remB % 2 === 1) && remFree > 0) { remB--; remFree--; }
          if ((remG % 2 === 1) && remFree > 0) { remG--; remFree--; }
          const neededFullPairs = Math.ceil(remB / 2) + Math.ceil(remG / 2);
          if (availFull + Math.floor(remFree / 2) >= neededFullPairs) {
            if (rowNum > maxFR) maxFR = rowNum;
            satisfied = true;
            break;
          }
        }
      }
      if (!satisfied && distinctRows.length > 0) {
        const lastRow = distinctRows[distinctRows.length - 1];
        if (lastRow > maxFR) maxFR = lastRow;
      }
    }
  }

  const sepList = rulesObj.separatedPairs || [];
  let frontInternalSepCount = 0;
  sepList.forEach(pair => {
    if (!Array.isArray(pair) || pair.length !== 2) return;
    if (effectiveFrontSet.has(String(pair[0])) && effectiveFrontSet.has(String(pair[1]))) {
      frontInternalSepCount++;
    }
  });
  if (frontInternalSepCount >= 3) {
    maxFR = Math.min(MAX_ROWS - 1, maxFR + 1);
  }
  return maxFR;
}

// 후보 좌석 배치의 제약 위반 벌점(score)과 사후 충돌 감사(audit)를 단일 evaluate(candidateMap, prevMap, parityFlip, ctx) 메서드로 통합한다.
// 임시 문자열("col,row") 반복 할당 대신 정수 비트 키((col << 5) | row)와 Uint8Array(384) 고정 버퍼를 재사용해 연산 속도를 약 13~16% 개선한다.
const _genderGridBuf = new Uint8Array(384);

const SEATING_RULES = [
  // [규칙 1: 거리두기 (separatedPairs)] 직교 인접 +1300점 / 대각선 인접 +1100점
  {
    id: 'separate',
    evaluate(candidateMap, prevMap, parityFlip, ctx) {
      const sepPairs = ctx.rules.separatedPairs || [];
      let penalty = 0;
      let violations = 0;
      for (let i = 0; i < sepPairs.length; i++) {
        const pair = sepPairs[i];
        const posA = candidateMap[pair[0]];
        const posB = candidateMap[pair[1]];
        if (posA && posB) {
          const dc = Math.abs(posA[0] - posB[0]);
          const dr = Math.abs(posA[1] - posB[1]);
          if (dc <= 1 && dr <= 1) {
            violations++;
            penalty += (dc + dr === 1) ? 1300 : 1100;
          }
        }
      }
      return {
        penalty,
        violations,
        label: violations > 0 ? `거리두기(${violations}쌍)` : null
      };
    }
  },
  // [규칙 2: 친구끼리 붙이기 (togetherPairs)] 같은 2인 짝꿍 슬롯 미배정 시 +1500점
  {
    id: 'together',
    evaluate(candidateMap, prevMap, parityFlip, ctx) {
      const togPairs = ctx.rules.togetherPairs || [];
      if (togPairs.length === 0) return { penalty: 0, violations: 0, label: null };
      let pairIntKeySet = ctx.structuralPairIntKeySet;
      if (!pairIntKeySet) {
        const allCoords = ctx.students.map(s => candidateMap[s.id]).filter(Boolean);
        const allPairs = extractActualRowPairs(allCoords, candidateMap, ctx.students).fullPairSlots;
        pairIntKeySet = new Set();
        for (let i = 0; i < allPairs.length; i++) {
          const l = allPairs[i][0], r = allPairs[i][1];
          const kL = (l[0] << 5) | l[1], kR = (r[0] << 5) | r[1];
          pairIntKeySet.add((kL << 10) | kR);
          pairIntKeySet.add((kR << 10) | kL);
        }
        ctx.structuralPairIntKeySet = pairIntKeySet;
      }
      let violations = 0;
      for (let i = 0; i < togPairs.length; i++) {
        const pair = togPairs[i];
        const pA = candidateMap[pair[0]], pB = candidateMap[pair[1]];
        if (!pA || !pB) {
          violations++;
        } else {
          const keyAB = (((pA[0] << 5) | pA[1]) << 10) | ((pB[0] << 5) | pB[1]);
          if (!pairIntKeySet.has(keyAB)) violations++;
        }
      }
      return {
        penalty: violations * 1500,
        violations,
        label: violations > 0 ? `친구 붙이기(${violations}쌍)` : null
      };
    }
  },
  // [규칙 3: 시력 보호 · 배려석 (frontRowIds)] 허용 앞줄 초과 시 +720 + (row - maxFR) * 120점
  {
    id: 'frontRow',
    evaluate(candidateMap, prevMap, parityFlip, ctx) {
      const rawFrontIds = (ctx.rules.frontRowIds || []).map(String);
      if (rawFrontIds.length === 0) return { penalty: 0, violations: 0, label: null };
      if (ctx.r0 === undefined) {
        ctx.r0 = computePureGridBounds(ctx.students, candidateMap).r0;
      }
      if (ctx.maxFrontRow === undefined) {
        const unlockedList = ctx.unlockedStudents || ctx.students.filter(s => !(ctx.lockedIdSet && ctx.lockedIdSet.has(String(s.id))));
        ctx.maxFrontRow = computeEffectiveMaxFrontRow(candidateMap, unlockedList, ctx.r0, ctx.rules, ctx.students);
      }
      const maxFR = ctx.maxFrontRow;
      const scoreFrontList = ctx.frontRowIds || rawFrontIds.filter(id => !(ctx.lockedIdSet && ctx.lockedIdSet.has(id)));
      let penalty = 0;
      for (let i = 0; i < scoreFrontList.length; i++) {
        const p = candidateMap[scoreFrontList[i]];
        if (p && p[1] > maxFR) {
          penalty += 720 + (p[1] - maxFR) * 120;
        }
      }
      let violations = 0;
      for (let i = 0; i < rawFrontIds.length; i++) {
        const id = rawFrontIds[i];
        if (ctx.lockedIdSet && ctx.lockedIdSet.has(id)) continue;
        const p = candidateMap[id];
        if (p && p[1] > maxFR) violations++;
      }
      return {
        penalty,
        violations,
        label: violations > 0 ? `앞줄 배려석(${violations}명)` : null
      };
    }
  },
  // [규칙 4: 이전 자리 제외 (excludePreviousSeat)] 직전 좌표와 동일 시 +620점
  {
    id: 'excludePrev',
    evaluate(candidateMap, prevMap, parityFlip, ctx) {
      if (!ctx.rules.excludePreviousSeat || !prevMap) {
        return { penalty: 0, violations: 0, label: null };
      }
      let violations = 0;
      const studentsList = ctx.students;
      for (let i = 0; i < studentsList.length; i++) {
        const stId = String(studentsList[i].id);
        if (ctx.lockedIdSet && ctx.lockedIdSet.has(stId)) continue;
        const curP = candidateMap[stId], oldP = prevMap[stId];
        if (curP && oldP && curP[0] === oldP[0] && curP[1] === oldP[1]) {
          violations++;
        }
      }
      return {
        penalty: violations * 620,
        violations,
        label: violations > 0 ? `이전 자리 제외(${violations}명)` : null
      };
    }
  },
  // [규칙 5: 5종 성별 짝 배정 (genderPairMode)] 짝 성별 불일치 +250점(+잠금가중 15점), 교차 패턴 불일치 +30~45점
  {
    id: 'genderPair',
    scorePairs(candidateMap, parityFlip, ctx, mode, isMixedMode, isSameMode) {
      const studentsList = ctx.students;
      if (ctx.r0 === undefined) {
        ctx.r0 = computePureGridBounds(studentsList, candidateMap).r0;
      }
      const r0 = ctx.r0;
      let penalty = 0;

      _genderGridBuf.fill(0);
      for (let i = 0; i < studentsList.length; i++) {
        const st = studentsList[i];
        const p = candidateMap[st.id];
        if (p) _genderGridBuf[(p[0] << 5) | p[1]] = (st.gender === '남') ? 1 : 2;
      }

      let allStructuralPairs = ctx.pairs;
      if (!allStructuralPairs) {
        const allCoords = studentsList.map(s => candidateMap[s.id]).filter(Boolean);
        allStructuralPairs = extractActualRowPairs(allCoords, candidateMap, studentsList).fullPairSlots;
        ctx.pairs = allStructuralPairs;
      }
      let lockedPairIntKeys = ctx.lockedPairIntKeys;
      if (!lockedPairIntKeys) {
        lockedPairIntKeys = new Set();
        const lockedCoordIntKeys = new Set(
          studentsList
            .filter(st => ctx.lockedIdSet && ctx.lockedIdSet.has(String(st.id)) && candidateMap[st.id])
            .map(st => (candidateMap[st.id][0] << 5) | candidateMap[st.id][1])
        );
        allStructuralPairs.forEach(([l, r]) => {
          const kL = (l[0] << 5) | l[1], kR = (r[0] << 5) | r[1];
          if (lockedCoordIntKeys.has(kL) || lockedCoordIntKeys.has(kR)) lockedPairIntKeys.add(kL);
        });
        ctx.lockedPairIntKeys = lockedPairIntKeys;
      }

      for (let i = 0; i < allStructuralPairs.length; i++) {
        const leftP = allStructuralPairs[i][0], rightP = allStructuralPairs[i][1];
        const kL = (leftP[0] << 5) | leftP[1], kR = (rightP[0] << 5) | rightP[1];
        const gLeft = _genderGridBuf[kL], gRight = _genderGridBuf[kR];
        if (!gLeft || !gRight) continue;
        const lockTie = lockedPairIntKeys.has(kL) ? 15 : 0;

        if (isMixedMode) {
          if (gLeft === gRight) {
            penalty += 250 + lockTie;
          } else if (mode === 'mixed') {
            const expectedLeftCode = ((leftP[1] - r0 + parityFlip) % 2 === 0) ? 1 : 2;
            if (gLeft !== expectedLeftCode) penalty += 30;
          }
        } else if (isSameMode) {
          if (gLeft !== gRight) {
            penalty += 250 + lockTie;
          } else if (mode === 'same') {
            const nextLeft = _genderGridBuf[(leftP[0] << 5) | (leftP[1] + 1)];
            const nextRight = _genderGridBuf[(rightP[0] << 5) | (rightP[1] + 1)];
            if (nextLeft && nextRight && nextLeft === nextRight && gLeft === nextLeft) penalty += 45;
            if (rightP[0] + 2 < 12) {
              const sideLeft = _genderGridBuf[((rightP[0] + 1) << 5) | rightP[1]];
              const sideRight = _genderGridBuf[((rightP[0] + 2) << 5) | rightP[1]];
              if (sideLeft && sideRight && sideLeft === sideRight && gLeft === sideLeft) penalty += 45;
            }
          }
        }
      }

      if (mode === 'mixed') {
        let pairLeftIntKeys = ctx.pairLeftIntKeys;
        if (!pairLeftIntKeys) {
          pairLeftIntKeys = new Set(allStructuralPairs.map(([l]) => (l[0] << 5) | l[1]));
          ctx.pairLeftIntKeys = pairLeftIntKeys;
        }
        for (let i = 0; i < studentsList.length; i++) {
          const st = studentsList[i];
          const p = candidateMap[st.id];
          if (!p) continue;
          const gCode = (st.gender === '남') ? 1 : 2;
          const down = _genderGridBuf[(p[0] << 5) | (p[1] + 1)];
          if (down === gCode) penalty += 8;
          const kCur = (p[0] << 5) | p[1];
          if (!pairLeftIntKeys.has(kCur) && p[0] + 1 < 12) {
            const right = _genderGridBuf[((p[0] + 1) << 5) | p[1]];
            if (right === gCode) penalty += 8;
          }
        }
      }
      return penalty;
    },
    auditPairs(candidateMap, ctx, isMixedMode) {
      const studentsList = ctx.students;
      const unlockedStudents = ctx.unlockedStudents;
      const unlockedIdSet = ctx.unlockedIdSet;
      const unlockedCoords = unlockedStudents.map(s => candidateMap[s.id]).filter(Boolean);
      const { fullPairSlots, halfLocked } = extractActualRowPairs(unlockedCoords, candidateMap, studentsList);
      let remBoys = unlockedStudents.filter(s => s.gender === '남').length;
      let remGirls = unlockedStudents.filter(s => s.gender === '여').length;

      const coordToGender = {};
      const coordToStudent = {};
      studentsList.forEach(s => {
        const p = candidateMap[s.id];
        if (p) {
          const key = `${p[0]},${p[1]}`;
          coordToGender[key] = s.gender;
          coordToStudent[key] = s;
        }
      });

      const isTargetPair = (g1, g2) => (isMixedMode ? g1 !== g2 : g1 === g2);
      const consumedHalfKeys = new Set();
      let forcedTargetPairs = 0;
      let remPairSlots = fullPairSlots.length;

      const seenTogIds = new Set();
      (ctx.rules.togetherPairs || []).forEach(pair => {
        if (!Array.isArray(pair) || pair.length !== 2) return;
        const sA = ctx.studentById[String(pair[0])];
        const sB = ctx.studentById[String(pair[1])];
        if (!sA || !sB) return;
        const idA = String(sA.id), idB = String(sB.id);
        if (idA === idB || seenTogIds.has(idA) || seenTogIds.has(idB)) return;
        seenTogIds.add(idA);
        seenTogIds.add(idB);

        const aUn = unlockedIdSet.has(idA), bUn = unlockedIdSet.has(idB);
        if (aUn && bUn) {
          if (remPairSlots > 0) {
            remPairSlots--;
            if (sA.gender === '남') remBoys = Math.max(0, remBoys - 1); else remGirls = Math.max(0, remGirls - 1);
            if (sB.gender === '남') remBoys = Math.max(0, remBoys - 1); else remGirls = Math.max(0, remGirls - 1);
            if (isTargetPair(sA.gender, sB.gender)) forcedTargetPairs++;
          }
        } else if (aUn !== bUn) {
          const unStu = aUn ? sA : sB, lockStu = aUn ? sB : sA;
          const hMatch = (halfLocked || []).find(h => {
            const hKey = `${h.c[0]},${h.c[1]}`;
            if (consumedHalfKeys.has(hKey)) return false;
            const mateStu = coordToStudent[`${h.mate[0]},${h.mate[1]}`];
            return mateStu && String(mateStu.id) === String(lockStu.id);
          });
          if (hMatch) {
            consumedHalfKeys.add(`${hMatch.c[0]},${hMatch.c[1]}`);
            if (unStu.gender === '남') remBoys = Math.max(0, remBoys - 1); else remGirls = Math.max(0, remGirls - 1);
            if (isTargetPair(unStu.gender, lockStu.gender)) forcedTargetPairs++;
          }
        }
      });

      let halfNeedBoy = 0, halfNeedGirl = 0;
      (halfLocked || []).forEach(h => {
        const hKey = `${h.c[0]},${h.c[1]}`;
        if (consumedHalfKeys.has(hKey)) return;
        const mateG = coordToGender[`${h.mate[0]},${h.mate[1]}`];
        if (!mateG) return;
        const needBoy = isMixedMode ? (mateG === '여') : (mateG === '남');
        if (needBoy) halfNeedBoy++; else halfNeedGirl++;
      });
      const halfBoyOk = Math.min(halfNeedBoy, remBoys);
      const halfGirlOk = Math.min(halfNeedGirl, remGirls);
      remBoys -= halfBoyOk;
      remGirls -= halfGirlOk;

      const maxPossibleTargetPairs = forcedTargetPairs + halfBoyOk + halfGirlOk + (isMixedMode
        ? Math.min(remPairSlots, remBoys, remGirls)
        : Math.min(remPairSlots, Math.floor(remBoys / 2) + Math.floor(remGirls / 2)));

      let achievedTargetPairs = 0;
      fullPairSlots.forEach(([leftP, rightP]) => {
        const g1 = coordToGender[`${leftP[0]},${leftP[1]}`], g2 = coordToGender[`${rightP[0]},${rightP[1]}`];
        if (g1 && g2 && isTargetPair(g1, g2)) achievedTargetPairs++;
      });
      (halfLocked || []).forEach(h => {
        const g1 = coordToGender[`${h.c[0]},${h.c[1]}`], g2 = coordToGender[`${h.mate[0]},${h.mate[1]}`];
        if (g1 && g2 && isTargetPair(g1, g2)) achievedTargetPairs++;
      });

      const violated = achievedTargetPairs < maxPossibleTargetPairs;
      return {
        penalty: 0,
        violations: violated ? (maxPossibleTargetPairs - achievedTargetPairs) : 0,
        label: violated ? (isMixedMode ? '남녀 짝꿍' : '동성 짝꿍') : null
      };
    },
    evaluate(candidateMap, prevMap, parityFlip, ctx, isAuditOnly = false) {
      const mode = (ctx.rules.useGenderDistinction === false) ? 'any' : ctx.rules.genderPairMode;
      const isMixedMode = (mode === 'mixed' || mode === 'mixed_random');
      const isSameMode = (mode === 'same' || mode === 'same_random');
      if (!isMixedMode && !isSameMode) {
        return { penalty: 0, violations: 0, label: null };
      }
      if (isAuditOnly) {
        return this.auditPairs(candidateMap, ctx, isMixedMode);
      }
      return {
        penalty: this.scorePairs(candidateMap, parityFlip, ctx, mode, isMixedMode, isSameMode),
        violations: 0,
        label: null
      };
    }
  }
];

/**
 * 후보 배치의 총 벌점을 SEATING_RULES 단일 레지스트리를 통해 계산한다.
 * @param {Record<string, SeatCoord>} candidateMap
 * @param {Record<string, SeatCoord> | null} prevMap
 * @param {[SeatCoord, SeatCoord][]} fullPairSlots
 * @param {number} parityFlip
 * @param {Record<string, any>} ctx
 * @returns {number}
 */
function scoreCandidateAssignment(candidateMap, prevMap, fullPairSlots, parityFlip, ctx) {
  if (!ctx || !Array.isArray(ctx.students) || !ctx.rules) {
    throw new Error('scoreCandidateAssignment requires explicit ctx.students and ctx.rules');
  }
  let totalPenalty = 0;
  for (let i = 0; i < SEATING_RULES.length; i++) {
    totalPenalty += SEATING_RULES[i].evaluate(candidateMap, prevMap, parityFlip, ctx, false).penalty;
  }
  return totalPenalty;
}

/**
 * 후보 배치의 미충족 제약 조건 목록을 SEATING_RULES 단일 레지스트리를 통해 점검한다.
 * @param {Record<string, SeatCoord>} candidateMap
 * @param {Record<string, SeatCoord> | null} prevMap
 * @param {{ students: Student[], rules: SeatingRules, lockedIds?: string[], lockedIdSet?: Set<string> }} auditCtx
 * @returns {string[]}
 */
function auditAssignmentConflicts(candidateMap, prevMap, auditCtx) {
  if (!auditCtx || !Array.isArray(auditCtx.students) || !auditCtx.rules) {
    throw new Error('auditAssignmentConflicts requires explicit auditCtx ({ students, rules, lockedIds })');
  }
  const students = auditCtx.students;
  const rules = auditCtx.rules;
  const lockedIdSet = (auditCtx.lockedIdSet instanceof Set)
    ? auditCtx.lockedIdSet
    : new Set((auditCtx.lockedIds || []).map(String));

  const studentById = {};
  students.forEach(s => { studentById[String(s.id)] = s; });
  const unlockedStudents = students.filter(s => !lockedIdSet.has(String(s.id)));
  const unlockedIdSet = new Set(unlockedStudents.map(s => String(s.id)));
  const { r0 } = computePureGridBounds(students, candidateMap);
  const maxFrontRow = (rules.frontRowIds && rules.frontRowIds.length > 0)
    ? computeEffectiveMaxFrontRow(candidateMap, unlockedStudents, r0, rules, students)
    : (r0 + 1);

  const sharedCtx = {
    students,
    rules,
    lockedIdSet,
    studentById,
    unlockedStudents,
    unlockedIdSet,
    r0,
    maxFrontRow
  };

  const conflicts = [];
  for (let i = 0; i < SEATING_RULES.length; i++) {
    const res = SEATING_RULES[i].evaluate(candidateMap, prevMap, 0, sharedCtx, true);
    if (res.label) conflicts.push(res.label);
  }
  return conflicts;
}

// [단계 0] 친구끼리 붙이기(togetherPairs) 최우선 슬롯 배정 서브 함수
function assignTogetherPairsStep(stepCtx) {
  const {
    togPairs, sepPairs, frontRowSet, unlockedIdSet, halfLockedInfo, usedHalfCoords,
    candidateMap, trialFullPairs, removeStudentFromPools, hasFront, maxFrontRow,
    excludePrev, prevMap, hasSep, mode, idToGender, r0, parityFlip, rng
  } = stepCtx;
  let { trialSingles } = stepCtx;
  const activeTogPartnerMap = Object.create(null);
  const actuallyPairedTogetherIds = new Set();
  const seenTogetherIds = new Set();
  const sepIdSetForTog = new Set();
  sepPairs.forEach(([a, b]) => { sepIdSetForTog.add(String(a)); sepIdSetForTog.add(String(b)); });

  const shuffledTog = shuffleArrayInPlace([...togPairs], rng).sort((p1, p2) => {
    const p1Front = (frontRowSet.has(String(p1[0])) || frontRowSet.has(String(p1[1]))) ? 2 : 0;
    const p2Front = (frontRowSet.has(String(p2[0])) || frontRowSet.has(String(p2[1]))) ? 2 : 0;
    const p1Sep = (sepIdSetForTog.has(String(p1[0])) || sepIdSetForTog.has(String(p1[1]))) ? 1 : 0;
    const p2Sep = (sepIdSetForTog.has(String(p2[0])) || sepIdSetForTog.has(String(p2[1]))) ? 1 : 0;
    return (p2Front + p2Sep) - (p1Front + p1Sep);
  });

  shuffledTog.forEach(([rawA, rawB]) => {
    const idA = String(rawA);
    const idB = String(rawB);
    if (idA === idB || seenTogetherIds.has(idA) || seenTogetherIds.has(idB)) return;
    seenTogetherIds.add(idA);
    seenTogetherIds.add(idB);
    const aUnlocked = unlockedIdSet.has(idA);
    const bUnlocked = unlockedIdSet.has(idB);
    if (!aUnlocked && !bUnlocked) return;

    if (aUnlocked && !bUnlocked) {
      const hMatch = halfLockedInfo.find(h => h.mateId === idB && !usedHalfCoords.has(`${h.c[0]},${h.c[1]}`));
      if (hMatch) {
        candidateMap[idA] = hMatch.c;
        usedHalfCoords.add(`${hMatch.c[0]},${hMatch.c[1]}`);
        trialSingles = trialSingles.filter(sc => !(sc[0] === hMatch.c[0] && sc[1] === hMatch.c[1]));
        removeStudentFromPools(idA);
        actuallyPairedTogetherIds.add(idA);
        actuallyPairedTogetherIds.add(idB);
        activeTogPartnerMap[idA] = idB;
        activeTogPartnerMap[idB] = idA;
      }
    } else if (!aUnlocked && bUnlocked) {
      const hMatch = halfLockedInfo.find(h => h.mateId === idA && !usedHalfCoords.has(`${h.c[0]},${h.c[1]}`));
      if (hMatch) {
        candidateMap[idB] = hMatch.c;
        usedHalfCoords.add(`${hMatch.c[0]},${hMatch.c[1]}`);
        trialSingles = trialSingles.filter(sc => !(sc[0] === hMatch.c[0] && sc[1] === hMatch.c[1]));
        removeStudentFromPools(idB);
        actuallyPairedTogetherIds.add(idA);
        actuallyPairedTogetherIds.add(idB);
        activeTogPartnerMap[idA] = idB;
        activeTogPartnerMap[idB] = idA;
      }
    } else if (trialFullPairs.length > 0) {
      const isFrontTogPair = hasFront && (frontRowSet.has(idA) || frontRowSet.has(idB));
      const evalOrderScore = (posA, posB) => {
        let ordPen = 0;
        if (excludePrev) {
          const pA = prevMap[idA], pB = prevMap[idB];
          if (pA && pA[0] === posA[0] && pA[1] === posA[1]) ordPen += 500;
          if (pB && pB[0] === posB[0] && pB[1] === posB[1]) ordPen += 500;
        }
        if (hasSep) {
          for (let k = 0; k < sepPairs.length; k++) {
            const sp1 = String(sepPairs[k][0]), sp2 = String(sepPairs[k][1]);
            let targetPos = null, otherId = null;
            if (sp1 === idA) { targetPos = posA; otherId = sp2; }
            else if (sp2 === idA) { targetPos = posA; otherId = sp1; }
            else if (sp1 === idB) { targetPos = posB; otherId = sp2; }
            else if (sp2 === idB) { targetPos = posB; otherId = sp1; }
            if (targetPos && otherId && candidateMap[otherId] && (!unlockedIdSet.has(otherId) || actuallyPairedTogetherIds.has(otherId))) {
              const op = candidateMap[otherId];
              if (Math.abs(targetPos[0] - op[0]) <= 1 && Math.abs(targetPos[1] - op[1]) <= 1) {
                ordPen += 1200;
              }
            }
          }
        }
        return ordPen;
      };

      let bestSlotIdx = trialFullPairs.length - 1;
      let bestSlotScore = Infinity;
      for (let si = 0; si < trialFullPairs.length; si++) {
        const [sL, sR] = trialFullPairs[si];
        let sScore = 0;
        if (isFrontTogPair && sL[1] > maxFrontRow) {
          sScore += 900 + (sL[1] - maxFrontRow) * 120;
        } else if (!isFrontTogPair && hasFront && sL[1] <= maxFrontRow) {
          // BUG-04A 방어: 앞줄 대상이 아닌 붙이기 쌍이 앞줄 슬롯을 선점해 앞줄 배려석 학생을 밀어내지 않도록 후순위 비용을 부여한다.
          sScore += 50;
        }
        const penOrderAB = evalOrderScore(sL, sR);
        const penOrderBA = evalOrderScore(sR, sL);
        sScore += Math.min(penOrderAB, penOrderBA);
        if (sScore < bestSlotScore) {
          bestSlotScore = sScore;
          bestSlotIdx = si;
          if (sScore === 0) break;
        }
      }
      const slot = trialFullPairs.splice(bestSlotIdx, 1)[0];
      const [sL, sR] = slot;
      let placeALeft = rng() < 0.5;
      if (mode === 'mixed' && idToGender[idA] !== idToGender[idB]) {
        const wantLeftGender = ((sL[1] - r0 + parityFlip) % 2 === 0) ? '남' : '여';
        placeALeft = (idToGender[idA] === wantLeftGender);
      }
      const penAB = evalOrderScore(sL, sR);
      const penBA = evalOrderScore(sR, sL);
      if (penAB < penBA) placeALeft = true;
      else if (penBA < penAB) placeALeft = false;
      if (placeALeft) {
        candidateMap[idA] = sL;
        candidateMap[idB] = sR;
      } else {
        candidateMap[idA] = sR;
        candidateMap[idB] = sL;
      }
      removeStudentFromPools(idA);
      removeStudentFromPools(idB);
      actuallyPairedTogetherIds.add(idA);
      actuallyPairedTogetherIds.add(idB);
      activeTogPartnerMap[idA] = idB;
      activeTogPartnerMap[idB] = idA;
    }
  });
  return { trialSingles, activeTogPartnerMap, actuallyPairedTogetherIds };
}

// [단계 1] 반쪽 고정석(halfLocked) 옆자리 성별 맞춤 배정 서브 함수
function assignHalfLockedStep(halfLockedInfo, usedHalfCoords, isSameMode, boys, girls, candidateMap, trialSingles) {
  let nextSingles = trialSingles;
  halfLockedInfo.forEach(h => {
    const hKey = `${h.c[0]},${h.c[1]}`;
    if (usedHalfCoords.has(hKey)) return;
    const want = isSameMode ? h.mateGender : (h.mateGender === '남' ? '여' : '남');
    const pool = want === '남' ? boys : girls;
    if (pool.length > 0) {
      candidateMap[pool.pop()] = h.c;
      usedHalfCoords.add(hKey);
      nextSingles = nextSingles.filter(sc => !(sc[0] === h.c[0] && sc[1] === h.c[1]));
    }
  });
  return nextSingles;
}

// [단계 2] 5종 성별 짝 모드(same, same_random, mixed, mixed_random, any) 초기 배정 서브 함수
function assignGenderModeStep(modeCtx) {
  const { mode, boys, girls, trialFullPairs, trialSingles, leftOverCoords, remainderStudents, candidateMap, idToGender, c0, r0, rng } = modeCtx;
  let { parityFlip } = modeCtx;

  if (mode === 'same') {
    const boyPairs = [];
    const girlPairs = [];
    while (boys.length >= 2) boyPairs.push([boys.pop(), boys.pop()]);
    while (girls.length >= 2) girlPairs.push([girls.pop(), girls.pop()]);
    while (boys.length > 0) remainderStudents.push(boys.pop());
    while (girls.length > 0) remainderStudents.push(girls.pop());
    shuffleArrayInPlace(boyPairs, rng);
    shuffleArrayInPlace(girlPairs, rng);

    const slotsS = [...trialFullPairs];
    const colorOf = (xy, flip) => ((((xy[1] - r0) + Math.floor((xy[0] - c0) / 2) + flip) % 2) === 0) ? '여' : '남';
    const gp = girlPairs.length;
    const evalFlip = (flip) => {
      const tg = slotsS.filter(sl => colorOf(sl[0], flip) === '여').length;
      const freeColors = trialSingles.map(c => colorOf(c, flip));
      let matched = 0;
      remainderStudents.forEach(id => {
        const k = freeColors.indexOf(idToGender[id]);
        if (k >= 0) { freeColors.splice(k, 1); matched++; }
      });
      return Math.abs(tg - gp) * 10 - matched;
    };
    const e0 = evalFlip(0);
    const e1 = evalFlip(1);
    const flipS = e0 < e1 ? 0 : (e1 < e0 ? 1 : Math.floor(rng() * 2));
    parityFlip = flipS;
    const slotColor = slotsS.map(sl => colorOf(sl[0], flipS));
    const cG = slotColor.filter(c => c === '여').length;
    const cB = slotsS.length - cG;

    const spreadConvert = (fromC, toC, count) => {
      const done = [];
      for (let k = 0; k < count; k++) {
        const cands = [];
        slotColor.forEach((c, i) => { if (c === fromC) cands.push(i); });
        if (cands.length === 0) break;
        shuffleArrayInPlace(cands, rng);
        let best = cands[0];
        let bestVal = Infinity;
        cands.forEach(i => {
          const [x, y] = slotsS[i][0];
          let nbSame = 0;
          slotsS.forEach((o, j) => {
            if (j === i || slotColor[j] !== toC) return;
            const dx = Math.abs(o[0][0] - x);
            const dy = Math.abs(o[0][1] - y);
            if ((dx === 0 && dy === 1) || (dy === 0 && dx === 2)) nbSame++;
          });
          const d = done.length
            ? Math.min(...done.map(j => Math.abs(slotsS[j][0][0] - x) + Math.abs(slotsS[j][0][1] - y)))
            : 99;
          const val = nbSame * 100 - d;
          if (val < bestVal) { bestVal = val; best = i; }
        });
        slotColor[best] = toC;
        done.push(best);
      }
    };
    if (gp > cG) spreadConvert('남', '여', Math.min(gp - cG, Math.max(0, cB - boyPairs.length)));
    else if (boyPairs.length > cB) spreadConvert('여', '남', Math.min(boyPairs.length - cB, Math.max(0, cG - gp)));

    const freeSeats = [];
    trialSingles.forEach(c => freeSeats.push({ c, color: colorOf(c, flipS) }));
    slotsS.forEach((sl, i) => {
      const pool = slotColor[i] === '여' ? girlPairs : boyPairs;
      if (pool.length > 0) {
        const pr = pool.pop();
        candidateMap[pr[0]] = sl[0];
        candidateMap[pr[1]] = sl[1];
      } else {
        freeSeats.push({ c: sl[0], color: slotColor[i] }, { c: sl[1], color: slotColor[i] });
      }
    });
    while (girlPairs.length > 0) remainderStudents.push(...girlPairs.pop());
    while (boyPairs.length > 0) remainderStudents.push(...boyPairs.pop());
    shuffleArrayInPlace(remainderStudents, rng);
    shuffleArrayInPlace(freeSeats, rng);
    remainderStudents.forEach(id => {
      if (freeSeats.length === 0) return;
      let k = freeSeats.findIndex(f => f.color === idToGender[id]);
      if (k < 0) k = 0;
      candidateMap[id] = freeSeats.splice(k, 1)[0].c;
    });
    remainderStudents.length = 0;
    leftOverCoords.length = 0;

  } else if (mode === 'same_random') {
    const samePairsPool = [];
    while (boys.length >= 2) samePairsPool.push([boys.pop(), boys.pop()]);
    while (girls.length >= 2) samePairsPool.push([girls.pop(), girls.pop()]);
    while (boys.length > 0) remainderStudents.push(boys.pop());
    while (girls.length > 0) remainderStudents.push(girls.pop());
    shuffleArrayInPlace(samePairsPool, rng);

    const slotsSR = shuffleArrayInPlace([...trialFullPairs], rng);
    slotsSR.forEach(sl => {
      if (samePairsPool.length > 0) {
        const pr = samePairsPool.pop();
        candidateMap[pr[0]] = sl[0];
        candidateMap[pr[1]] = sl[1];
      } else {
        leftOverCoords.push(sl[0], sl[1]);
      }
    });
    while (samePairsPool.length > 0) {
      const leftoverPair = samePairsPool.pop();
      remainderStudents.push(leftoverPair[0], leftoverPair[1]);
    }

  } else if (mode === 'mixed') {
    const pairSlotsM = shuffleArrayInPlace([...trialFullPairs], rng);
    const singlesM = [...trialSingles];
    const buildSeats = (flip) => {
      const seats = [];
      pairSlotsM.forEach(([L, R], i) => {
        const lg = ((L[1] - r0 + flip) % 2 === 0) ? '남' : '여';
        seats.push({ c: L, g: lg, pair: i });
        seats.push({ c: R, g: lg === '남' ? '여' : '남', pair: i });
      });
      singlesM.forEach(c => {
        seats.push({ c, g: ((c[0] - c0 + c[1] - r0 + flip) % 2 === 0) ? '남' : '여', pair: -1 });
      });
      return seats;
    };
    const boyN = boys.length;
    const countBoySeats = (seats) => seats.filter(s => s.g === '남').length;
    const seats0 = buildSeats(0);
    const seats1 = buildSeats(1);
    const miss0 = Math.abs(countBoySeats(seats0) - boyN);
    const miss1 = Math.abs(countBoySeats(seats1) - boyN);
    const flipM = miss0 < miss1 ? 0 : (miss1 < miss0 ? 1 : Math.floor(rng() * 2));
    parityFlip = flipM;
    const seatsM = flipM === 0 ? seats0 : seats1;

    const diffM = countBoySeats(seatsM) - boyN;
    const fromG = diffM > 0 ? '남' : '여';
    const toG = diffM > 0 ? '여' : '남';
    const changed = [];
    const changedPairs = new Set();
    for (let k = 0; k < Math.abs(diffM); k++) {
      let cands = seatsM.filter(s => s.g === fromG && s.pair < 0);
      if (cands.length === 0) cands = seatsM.filter(s => s.g === fromG && s.pair >= 0 && !changedPairs.has(s.pair));
      if (cands.length === 0) break;
      shuffleArrayInPlace(cands, rng);
      let best = cands[0];
      let bestD = -1;
      cands.forEach(s => {
        const d = changed.length
          ? Math.min(...changed.map(o => Math.abs(o.c[0] - s.c[0]) + Math.abs(o.c[1] - s.c[1])))
          : 99;
        if (d > bestD) { bestD = d; best = s; }
      });
      best.g = toG;
      changed.push(best);
      if (best.pair >= 0) changedPairs.add(best.pair);
    }

    leftOverCoords.length = 0;
    seatsM.forEach(s => {
      const pool = s.g === '남' ? boys : girls;
      if (pool.length > 0) candidateMap[pool.pop()] = s.c;
      else leftOverCoords.push(s.c);
    });
    while (boys.length > 0) remainderStudents.push(boys.pop());
    while (girls.length > 0) remainderStudents.push(girls.pop());

  } else if (mode === 'mixed_random') {
    const slotsMR = shuffleArrayInPlace([...trialFullPairs], rng);
    slotsMR.forEach(([L, R]) => {
      if (boys.length > 0 && girls.length > 0) {
        const bId = boys.pop();
        const gId = girls.pop();
        if (rng() < 0.5) {
          candidateMap[bId] = L;
          candidateMap[gId] = R;
        } else {
          candidateMap[gId] = L;
          candidateMap[bId] = R;
        }
      } else {
        leftOverCoords.push(L, R);
      }
    });
    while (boys.length > 0) remainderStudents.push(boys.pop());
    while (girls.length > 0) remainderStudents.push(girls.pop());

  } else {
    const allPool = shuffleArrayInPlace([...boys, ...girls], rng);
    const remainingSlots = [...leftOverCoords];
    trialFullPairs.forEach(([L, R]) => remainingSlots.push(L, R));
    shuffleArrayInPlace(remainingSlots, rng);
    leftOverCoords.length = 0;
    allPool.forEach((stId, idx) => {
      if (remainingSlots[idx]) candidateMap[stId] = remainingSlots[idx];
    });
  }

  if (mode !== 'any') {
    shuffleArrayInPlace(remainderStudents, rng);
    shuffleArrayInPlace(leftOverCoords, rng);
    remainderStudents.forEach((stId, idx) => {
      if (leftOverCoords[idx]) {
        candidateMap[stId] = leftOverCoords[idx];
      }
    });
  }
  return parityFlip;
}

// [단계 3] 시력 보호·배려석(frontRowIds) 동일 성별 O(N) 앞줄 선교환 서브 함수
function preSwapFrontRowStep(frontRowSet, candidateMap, maxFrontRow, actuallyPairedTogetherIds, idToGender, unlockedIds, mode, rng) {
  for (const fId of frontRowSet) {
    const fp = candidateMap[fId];
    if (!fp || fp[1] <= maxFrontRow || actuallyPairedTogetherIds.has(fId)) continue;
    const fGender = idToGender[fId];
    const shuffledSwapCands = shuffleArrayInPlace([...unlockedIds], rng);
    for (let ui = 0; ui < shuffledSwapCands.length; ui++) {
      const candId = String(shuffledSwapCands[ui]);
      if (frontRowSet.has(candId) || actuallyPairedTogetherIds.has(candId)) continue;
      const cp = candidateMap[candId];
      if (!cp || cp[1] > maxFrontRow) continue;
      if (mode === 'any' || idToGender[candId] === fGender) {
        candidateMap[fId] = cp;
        candidateMap[candId] = fp;
        break;
      }
    }
  }
}

// [단계 4] 제약 참여 학생 사전 인덱싱 가속 2-opt 지역 탐색 서브 함수
function runTwoOptLocalSearch(twoOptCtx) {
  const {
    candidateMap, prevMap, fullPairSlots, parityFlip, scoreCtx,
    unlockedIds, idToGender, activeTogPartnerMap, excludePrev,
    hasSep, sepPairs, hasTog, togPairs, hasFront, frontRowSet
  } = twoOptCtx;
  let { currentPenalty } = twoOptCtx;

  if (!scoreCtx.constrainedIdSet) {
    const cSet = new Set();
    if (hasSep) sepPairs.forEach(([a, b]) => { cSet.add(String(a)); cSet.add(String(b)); });
    if (hasTog) togPairs.forEach(([a, b]) => { cSet.add(String(a)); cSet.add(String(b)); });
    if (hasFront) frontRowSet.forEach(id => cSet.add(String(id)));
    scoreCtx.constrainedIdSet = cSet;
  }
  const cSet = scoreCtx.constrainedIdSet;
  const tPartnerMap = activeTogPartnerMap;

  let improved = true;
  let pass = 0;
  while (improved && pass < 10) {
    improved = false;
    pass++;
    for (let i = 0; i < unlockedIds.length && currentPenalty > 0; i++) {
      const idA = String(unlockedIds[i]);
      const gA = idToGender[idA];
      const aConstrained = cSet.has(idA);
      const aPartner = tPartnerMap[idA];
      for (let j = i + 1; j < unlockedIds.length && currentPenalty > 0; j++) {
        const idB = String(unlockedIds[j]);
        if ((aPartner && aPartner !== idB) || (tPartnerMap[idB] && tPartnerMap[idB] !== idA)) continue;
        if (!aConstrained && !cSet.has(idB) && gA === idToGender[idB]) {
          if (!excludePrev) continue;
          const curA = candidateMap[idA], curB = candidateMap[idB];
          const oldA = prevMap[idA], oldB = prevMap[idB];
          const aInPrev = (curA && oldA && curA[0] === oldA[0] && curA[1] === oldA[1]) || (curB && oldA && curB[0] === oldA[0] && curB[1] === oldA[1]);
          const bInPrev = (curB && oldB && curB[0] === oldB[0] && curB[1] === oldB[1]) || (curA && oldB && curA[0] === oldB[0] && curA[1] === oldB[1]);
          if (!aInPrev && !bInPrev) continue;
        }
        const tmp = candidateMap[idA];
        candidateMap[idA] = candidateMap[idB];
        candidateMap[idB] = tmp;

        const newPenalty = scoreCandidateAssignment(candidateMap, prevMap, fullPairSlots, parityFlip, scoreCtx);
        if (newPenalty < currentPenalty) {
          currentPenalty = newPenalty;
          improved = true;
        } else {
          candidateMap[idB] = candidateMap[idA];
          candidateMap[idA] = tmp;
        }
      }
    }
  }
  return currentPenalty;
}

/**
 * 설정된 배치 조건(짝 성별, 거리두기, 친구끼리 붙이기, 앞줄 배려석, 이전 자리 제외)에 맞춰 최적 좌석 배치를 탐색한다.
 * 전역 state 참조가 전혀 없는 순수 함수로, { students, pos, rules, lockedIds, rng } 객체를 입력받는다.
 * @param {AlgorithmInput} input
 * @returns {{ map: Record<string, SeatCoord>, conflicts: string[] }}
 */
function generateOptimalSeatAssignment(input) {
  if (!input || typeof input !== 'object' || !Array.isArray(input.students) || !input.pos || typeof input.pos !== 'object') {
    throw new Error('generateOptimalSeatAssignment requires { students, pos, rules, lockedIds, rng }');
  }
  const students = input.students;
  const activeMap = input.pos;
  const rules = input.rules || {};
  const rawLocks = Array.isArray(input.lockedIds) ? input.lockedIds : [];
  const lockedIdSet = new Set(rawLocks.map(String));
  const unlockedStudents = students.filter(s => !lockedIdSet.has(String(s.id)));
  const rng = typeof input.rng === 'function' ? input.rng : Math.random;

  const unlockedIds = unlockedStudents.map(s => s.id).filter(id => Array.isArray(activeMap[id]) && activeMap[id].length === 2);
  const unlockedIdSet = new Set(unlockedIds.map(String));
  const availableCoords = unlockedIds.map(id => [...activeMap[id]]);
  const mode = (rules.useGenderDistinction === false) ? 'any' : rules.genderPairMode;
  const isMixedMode = (mode === 'mixed' || mode === 'mixed_random');
  const isSameMode = (mode === 'same' || mode === 'same_random');
  const excludePrev = Boolean(rules.excludePreviousSeat);
  const sepPairs = rules.separatedPairs || [];
  const hasSep = sepPairs.length > 0;
  const togPairs = (rules.togetherPairs || []).filter(p => Array.isArray(p) && p.length === 2);
  const hasTog = togPairs.length > 0;
  const frontRowSet = new Set((rules.frontRowIds || []).map(String).filter(id => unlockedIdSet.has(id)));
  const hasFront = frontRowSet.size > 0;

  const prevMap = {};
  unlockedIds.forEach(id => {
    if (activeMap[id]) prevMap[id] = [activeMap[id][0], activeMap[id][1]];
  });

  if (mode === 'any' && !hasSep && !hasTog && !hasFront && !excludePrev) {
    const shuffledCoords = shuffleArrayInPlace([...availableCoords], rng);
    const result = {};
    students.forEach(s => { result[s.id] = activeMap[s.id]; });
    unlockedIds.forEach((id, idx) => { result[id] = shuffledCoords[idx]; });
    return { map: result, conflicts: [] };
  }

  const { c0, r0 } = computePureGridBounds(students, activeMap);
  const { fullPairSlots, singleSlots, halfLocked } = extractActualRowPairs(availableCoords, activeMap, students);

  const idToGender = {};
  students.forEach(s => { idToGender[s.id] = s.gender; });
  const halfLockedInfo = (halfLocked || []).map(h => {
    const mateStu = students.find(s => { const p = activeMap[s.id]; return p && p[0] === h.mate[0] && p[1] === h.mate[1]; });
    return { c: h.c, mateId: mateStu ? String(mateStu.id) : null, mateGender: mateStu ? mateStu.gender : null };
  }).filter(h => h.mateGender);

  if (hasFront && hasTog) {
    togPairs.forEach(([rawA, rawB]) => {
      const a = String(rawA), b = String(rawB);
      if (frontRowSet.has(a) && unlockedIdSet.has(b)) frontRowSet.add(b);
      if (frontRowSet.has(b) && unlockedIdSet.has(a)) frontRowSet.add(a);
    });
  }
  const maxFrontRow = hasFront ? computeEffectiveMaxFrontRow(activeMap, unlockedStudents, r0, rules, students) : (r0 + 1);
  const scoreCtx = { r0, maxFrontRow, frontRowIds: [...frontRowSet], students, rules, lockedIdSet, unlockedStudents };
  const trials = (hasSep || hasTog || hasFront || excludePrev) ? 75 : ((isMixedMode || isSameMode) ? 12 : 25);

  let globalBestMap = null;
  let globalBestPenalty = Infinity;
  let stallTrials = 0;

  for (let t = 0; t < trials; t++) {
    let boys = shuffleArrayInPlace(unlockedStudents.filter(s => s.gender === '남').map(s => s.id), rng);
    let girls = shuffleArrayInPlace(unlockedStudents.filter(s => s.gender === '여').map(s => s.id), rng);
    let parityFlip = t % 2;

    const candidateMap = {};
    students.forEach(s => { candidateMap[s.id] = activeMap[s.id]; });

    const remainderStudents = [];
    const trialFullPairs = shuffleArrayInPlace([...fullPairSlots], rng);
    let trialSingles = [...singleSlots];
    const usedHalfCoords = new Set();

    const removeStudentFromPools = (targetId) => {
      boys = boys.filter(id => String(id) !== String(targetId));
      girls = girls.filter(id => String(id) !== String(targetId));
    };

    // 0순위: 친구끼리 붙이기(togetherPairs) 슬롯 배정
    let activeTogPartnerMap = Object.create(null);
    let actuallyPairedTogetherIds = new Set();
    if (hasTog) {
      const togRes = assignTogetherPairsStep({
        togPairs, sepPairs, frontRowSet, unlockedIdSet, halfLockedInfo, usedHalfCoords,
        candidateMap, trialFullPairs, trialSingles, removeStudentFromPools,
        hasFront, maxFrontRow, excludePrev, prevMap, hasSep, mode, idToGender, r0, parityFlip, rng
      });
      trialSingles = togRes.trialSingles;
      activeTogPartnerMap = togRes.activeTogPartnerMap;
      actuallyPairedTogetherIds = togRes.actuallyPairedTogetherIds;
    }

    // 1순위: 반쪽 고정석 옆자리 성별 맞춤 배정
    if (isSameMode || isMixedMode) {
      trialSingles = assignHalfLockedStep(halfLockedInfo, usedHalfCoords, isSameMode, boys, girls, candidateMap, trialSingles);
    }

    // 2순위: 5종 성별 짝 모드별 배정
    const leftOverCoords = shuffleArrayInPlace([...trialSingles], rng);
    parityFlip = assignGenderModeStep({
      mode, boys, girls, trialFullPairs, trialSingles, leftOverCoords,
      remainderStudents, candidateMap, idToGender, c0, r0, parityFlip, rng
    });

    // 3순위: 앞줄 우선 배정(frontRowIds) 동일 성별 선교환
    if (hasFront) {
      preSwapFrontRowStep(frontRowSet, candidateMap, maxFrontRow, actuallyPairedTogetherIds, idToGender, unlockedIds, mode, rng);
    }

    // 4순위: 벌점 계산 및 2-opt 지역 탐색
    let currentPenalty = scoreCandidateAssignment(candidateMap, prevMap, fullPairSlots, parityFlip, scoreCtx);
    if (currentPenalty > 0) {
      currentPenalty = runTwoOptLocalSearch({
        candidateMap, prevMap, fullPairSlots, parityFlip, scoreCtx,
        unlockedIds, idToGender, activeTogPartnerMap, excludePrev,
        hasSep, sepPairs, hasTog, togPairs, hasFront, frontRowSet, currentPenalty
      });
    }

    if (currentPenalty < globalBestPenalty) {
      globalBestPenalty = currentPenalty;
      globalBestMap = candidateMap;
      stallTrials = 0;
      if (globalBestPenalty === 0) break;
    } else if (++stallTrials >= ((hasSep || hasTog || hasFront || excludePrev) ? 15 : 2)) {
      break;
    }
  }

  const conflicts = globalBestMap
    ? auditAssignmentConflicts(globalBestMap, prevMap, { students, rules, lockedIdSet })
    : [];
  return { map: globalBestMap, conflicts };
}

export {
  canRegisterPairRule,
  generateOptimalSeatAssignment
};
