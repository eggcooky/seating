// [L5] 상호 배타 모드 전환(비밀의 방 ↔ 룰렛 드로어) 및 조작 모드 통합 코디네이터
import { doesSecretLayoutMatchCurrent, hasValidSecretPreset } from '../domain/seat-queries.js';
import { initRouletteSession, stopRouletteColumnAuto } from '../features/roulette-controller.js';
import { stopSequentialReveal } from '../features/reveal-controller.js';
import { hasSeenSecretHelpGuide, saveToStorage } from '../infra/storage-io.js';
import { AppStore } from '../state/store.js';
import {
  checkSecretRoomLayoutMismatch,
  showSecretNoticePopup,
  updateSecretPresetIndicator
} from '../ui/secret-indicators.js';
import { applyDefaultModeStatusPillStyle, showToast, syncHeaderStatusLayout } from '../ui/toast.js';
import { renderClassroom } from '../views/classroom-view.js';
import {
  closeHelpGuideModal,
  closeSecretHelpGuideModal,
  openSecretHelpGuideModal
} from '../views/help-guide-view.js';
import { updateUndoButtonState } from '../views/history-popover.js';
import { renderRoster } from '../views/roster-view.js';

// 화면 조작 모드 초기화 (v2.50 학생 클릭 통합 방식)
export function setInteractionMode(skipRender = false) {
  const state = AppStore.getState();
  state.interactionMode = 'seat';
  state.selectedStudentId = null;
  const paperHelpHint = document.getElementById('paperHelpHint');
  if (paperHelpHint) {
    paperHelpHint.textContent = '• 학생을 클릭한 뒤 다른 학생을 누르면 자리 교환, 점선 빈칸(＋)을 누르면 책상 이동이 됩니다.';
  }
  applyDefaultModeStatusPillStyle();
  if (!skipRender) {
    renderRoster();
    renderClassroom(false);
  }
}

export function toggleRouletteDrawer(forceOpen, useSecret = false) {
  const state = AppStore.getState();
  const drawer = document.getElementById('rouletteDrawer');
  const btn = document.getElementById('toggleRouletteBtn');
  const label = document.getElementById('toggleRouletteBtnLabel');
  if (!drawer || !btn || !label) return;

  const nextOpen = typeof forceOpen === 'boolean' ? forceOpen : !state.rouletteOpen;
  state.rouletteOpen = nextOpen;

  if (nextOpen) {
    if (state.inSecretRoom) toggleSecretRoom(false);
    drawer.classList.remove('hidden');
    drawer.classList.add('flex');
    btn.className = 'flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-extrabold text-xs bg-fuchsia-600 text-white border border-fuchsia-700 shadow-sm transition';
    label.textContent = '룰렛 닫기';
    initRouletteSession(useSecret);
    showToast('오른쪽에 원형 룰렛이 열렸습니다! 원판을 클릭할 때마다 한 명씩 배정됩니다.', 'info');
  } else {
    drawer.classList.add('hidden');
    drawer.classList.remove('flex');
    btn.className = 'flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-extrabold text-xs bg-fuchsia-50 text-fuchsia-700 hover:bg-fuchsia-100 border border-fuchsia-200 transition';
    label.textContent = '룰렛';
    stopRouletteColumnAuto();
    state.rouletteSessionToken = (state.rouletteSessionToken || 0) + 1;
    state.rouletteSpinning = false;
    state.rouletteActiveSession = false;
    state.rouletteDrawnIds = [];
    state.rouletteUseSecretPreset = false;
    renderClassroom(false);
  }
}

export function toggleSecretRoom(forceState, skipSave = false) {
  const state = AppStore.getState();
  stopSequentialReveal();
  const wasInSecretRoom = Boolean(state.inSecretRoom);
  const hadExistingSecretPreset = hasValidSecretPreset(state);
  const nextState = typeof forceState === 'boolean' ? forceState : !state.inSecretRoom;
  if (nextState && state.rouletteOpen) {
    toggleRouletteDrawer(false);
  }
  state.inSecretRoom = nextState;
  state.selectedStudentId = null;

  const brandHeader = document.getElementById('sidebarBrandHeader');
  const headerTitle = document.getElementById('appHeaderTitle');
  const secretBanner = document.getElementById('secretRoomBanner');
  const paperCard = document.getElementById('seatingPaperCard');
  const modeStatusPill = document.getElementById('modeStatusPill');
  const modeStatusDot = document.getElementById('modeStatusDot');
  const modeStatusText = document.getElementById('modeStatusText');
  const shuffleBtnText = document.getElementById('randomShuffleBtnText');
  const row2 = document.getElementById('controlMenuRow2');
  const pairOptionBtn = document.getElementById('openPairOptionModalBtn');
  const rulesBtnLabel = document.getElementById('openRulesBtnLabel');

  let shouldAutoOpenSecretHelp = false;

  if (state.inSecretRoom) {
    closeHelpGuideModal({ persistSeen: false });
    // 비밀의 방 좌석 데이터가 없으면 현재 일반 배치를 복사해 초기화한다.
    if (!hadExistingSecretPreset) {
      state.secretPos = JSON.parse(JSON.stringify(state.pos));
      state.pendingSecretNotices = [];
    }
    brandHeader.className = 'px-3.5 py-3.5 border-b border-slate-800 flex items-center justify-between gap-2 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-amber-300 transition-colors duration-300';
    headerTitle.textContent = '비밀의 방 (사전 지정)';
    secretBanner.classList.remove('hidden');
    paperCard.classList.add('ring-2', 'ring-amber-400/80');
    modeStatusPill.className = 'px-3.5 py-1.5 rounded-full text-xs font-bold bg-slate-900 text-amber-300 border border-amber-500/40 hover:bg-slate-800 transition-all flex items-center gap-2 cursor-pointer shadow-sm max-w-full';
    modeStatusDot.className = 'w-2 h-2 rounded-full bg-amber-400 animate-ping shrink-0';
    modeStatusText.textContent = '비밀의 방: 학생들 몰래 배정할 목표 자리를 클릭해 맞추세요';
    modeStatusText.title = modeStatusText.textContent;
    syncHeaderStatusLayout();
    shuffleBtnText.textContent = '비밀 자리 랜덤 섞기';

    // 비밀의 방 진입 시 배치 조건 + 거리두기 2열 메뉴 구성을 표시하고 다중학급 UI는 숨긴다.
    if (row2 && pairOptionBtn) {
      row2.className = 'grid grid-cols-2 gap-2';
      pairOptionBtn.classList.remove('hidden');
      pairOptionBtn.classList.add('flex');
      if (rulesBtnLabel) rulesBtnLabel.textContent = '배치 조건';
    }
    const multiWrapEnter = document.getElementById('multiClassToggleWrapper');
    const multiBarEnter = document.getElementById('multiClassControlBar');
    if (multiWrapEnter) { multiWrapEnter.classList.add('hidden'); multiWrapEnter.classList.remove('flex'); }
    if (multiBarEnter) { multiBarEnter.classList.add('hidden'); multiBarEnter.classList.remove('flex'); }

    let showedNoticePopup = false;
    if (!doesSecretLayoutMatchCurrent(state)) {
      checkSecretRoomLayoutMismatch(true);
    } else {
      checkSecretRoomLayoutMismatch(false);
      showToast('🕵️ 비밀의 방에 접속했습니다. 원하는 자리로 학생들을 배치하세요.', 'secret');
    }
    if (Array.isArray(state.pendingSecretNotices) && state.pendingSecretNotices.length > 0) {
      const notices = state.pendingSecretNotices;
      state.pendingSecretNotices = [];
      showSecretNoticePopup(notices);
      showedNoticePopup = true;
    }
    shouldAutoOpenSecretHelp = Boolean(
      !wasInSecretRoom &&
      !skipSave &&
      !AppStore.isRunningSelfDiagnostics() &&
      !hadExistingSecretPreset &&
      !hasSeenSecretHelpGuide() &&
      !showedNoticePopup
    );
  } else {
    closeSecretHelpGuideModal({ persistSeen: false });
    brandHeader.className = 'px-3.5 py-3.5 border-b border-slate-100 flex items-center justify-between gap-2 bg-gradient-to-r from-indigo-600 to-violet-600 text-white transition-colors duration-300';
    headerTitle.textContent = '학급 자리 배치 매니저';
    secretBanner.classList.add('hidden');
    paperCard.classList.remove('ring-2', 'ring-amber-400/80');
    shuffleBtnText.textContent = '자리 바꾸기 (랜덤 배정)';

    // 일반 화면 복귀 시 배치 조건 + 다중학급 토글 구성으로 되돌린다.
    if (row2 && pairOptionBtn) {
      row2.className = 'flex items-center gap-2';
      pairOptionBtn.classList.add('hidden');
      pairOptionBtn.classList.remove('flex');
      if (rulesBtnLabel) rulesBtnLabel.textContent = '배치 조건 설정';
    }
    const multiWrapExit = document.getElementById('multiClassToggleWrapper');
    const multiBarExit = document.getElementById('multiClassControlBar');
    const multiToggleExit = document.getElementById('multiClassModeToggle');
    if (multiWrapExit) { multiWrapExit.classList.remove('hidden'); multiWrapExit.classList.add('flex'); }
    if (multiBarExit && multiToggleExit && multiToggleExit.checked) {
      multiBarExit.classList.remove('hidden');
      multiBarExit.classList.add('flex');
    }
    const pairModal = document.getElementById('pairOptionModal');
    if (pairModal) {
      pairModal.classList.add('hidden');
      pairModal.classList.remove('flex');
    }

    setInteractionMode(true);
    if (!skipSave) {
      saveToStorage(false);
    }
  }

  updateUndoButtonState();
  updateSecretPresetIndicator();
  AppStore.setPrintViewDirty(true);
  renderRoster();
  renderClassroom(true);

  if (shouldAutoOpenSecretHelp) {
    requestAnimationFrame(() => {
      if (AppStore.getState().inSecretRoom && !AppStore.isRunningSelfDiagnostics()) {
        openSecretHelpGuideModal({ isAutoFirstRun: true });
      }
    });
  }
}
