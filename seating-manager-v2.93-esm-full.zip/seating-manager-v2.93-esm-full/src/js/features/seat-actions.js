// [L4] 좌석 잠금 토글 · 기본 대형 정렬 · 좌석 맞바꾸기 · 빈칸 책상 이동 액션
import { MAX_COLS, MAX_ROWS } from '../core/constants.js';
import { compareStudentsByNumber } from '../core/utils.js';
import { getGridBounds } from '../domain/grid.js';
import {
  getActivePosMap,
  getStudentById,
  isNormalSeatLocked,
  isSeatHidden,
  isSeatLocked,
  isSecretSeatLocked
} from '../domain/seat-queries.js';
import { playSoundEffect } from '../infra/audio.js';
import { pushUndoSnapshot } from '../state/history-store.js';
import { AppStore } from '../state/store.js';
import { isRouletteBlockingEdit } from '../ui/guards.js';
import { checkSecretRoomLayoutMismatch, updateSecretPresetIndicator } from '../ui/secret-indicators.js';
import { showToast } from '../ui/toast.js';
import { syncRouletteWithCurrentLocks } from './roulette-controller.js';

// 현재 활성화된 화면의 좌석 고정 상태를 토글한다.
export function toggleSeatLock(studentId) {
  const state = AppStore.getState();
  if (!state.inSecretRoom && state.rouletteSpinning) {
    showToast('룰렛이 돌아가는 중에는 자리 고정을 변경할 수 없습니다.', 'warn');
    return;
  }
  const id = String(studentId);
  let nowLocked = false;
  if (state.inSecretRoom) {
    if (isSecretSeatLocked(state, id)) {
      state.secretLockedIds = state.secretLockedIds.filter(x => String(x) !== id);
      nowLocked = false;
    } else {
      state.secretLockedIds.push(id);
      nowLocked = true;
    }
  } else {
    if (isNormalSeatLocked(state, id)) {
      state.lockedIds = state.lockedIds.filter(x => String(x) !== id);
      nowLocked = false;
    } else {
      state.lockedIds.push(id);
      nowLocked = true;
    }
    checkSecretRoomLayoutMismatch(false);
    if (state.rouletteOpen || state.rouletteActiveSession) {
      syncRouletteWithCurrentLocks();
    }
  }
  playSoundEffect(nowLocked ? 'lock' : 'unlock');
  AppStore.commitChange({ classroom: Boolean(state.rouletteOpen), roulette: Boolean(state.rouletteOpen), dirty: true, save: true });
}

// 현재 좌석 순서를 유지한 채 설정된 기본 열 수(4~8열)에 맞춰 책상 격자를 정렬한다.
export function applyDefaultGridAlignment(showNotice = true, locksBefore = null, prevDefaultCols = null) {
  const state = AppStore.getState();
  if (isRouletteBlockingEdit()) return;
  if (state.students.length === 0) return;
  const colsCount = Math.min(8, Math.max(4, Number(state.rules.defaultCols) || 6));
  const snapExtra = {};
  if (locksBefore) snapExtra.locks = locksBefore;
  if (prevDefaultCols !== null && Number.isInteger(Number(prevDefaultCols))) {
    snapExtra.prevDefaultCols = Number(prevDefaultCols);
  }
  pushUndoSnapshot(`기본 대형 정렬 (${colsCount}열)`, Object.keys(snapExtra).length > 0 ? snapExtra : null);
  const activeMap = getActivePosMap(state);
  const totalStudents = state.students.length;
  const rowsPerCol = Math.max(1, Math.ceil(totalStudents / colsCount));

  // 현재 화면의 행·열 순서대로 학생을 정렬하여 순서 섞임 없이 열 폭만 재조정한다.
  const orderedStudents = [...state.students].sort((a, b) => {
    const pA = activeMap[a.id] || [99, 99];
    const pB = activeMap[b.id] || [99, 99];
    if (pA[1] !== pB[1]) return pA[1] - pB[1];
    if (pA[0] !== pB[0]) return pA[0] - pB[0];
    return compareStudentsByNumber(a, b);
  });

  // 잠겨 있는 학생(🔒)은 원래 좌표를 그대로 유지하고, 잠기지 않은 학생만 빈 격자 칸에 순서대로 배치한다.
  const lockedOccupiedKeys = new Set();
  orderedStudents.forEach(st => {
    if (isSeatLocked(state, st.id) && Array.isArray(activeMap[st.id])) {
      const [lc, lr] = activeMap[st.id];
      lockedOccupiedKeys.add(`${lc},${lr}`);
    }
  });

  let slotCursor = 0;
  orderedStudents.forEach(st => {
    if (isSeatLocked(state, st.id) && Array.isArray(activeMap[st.id])) {
      return;
    }
    while (slotCursor < MAX_COLS * MAX_ROWS * 2) {
      const col = Math.min(MAX_COLS - 1, (slotCursor % colsCount) + 1);
      const row = Math.min(MAX_ROWS - 1, Math.floor(slotCursor / colsCount) + 1);
      slotCursor++;
      const key = `${col},${row}`;
      if (!lockedOccupiedKeys.has(key)) {
        lockedOccupiedKeys.add(key);
        activeMap[st.id] = [col, row];
        break;
      }
    }
  });
  state.selectedStudentId = null;
  state.hasDeleteGapNotice = false;
  updateSecretPresetIndicator();
  AppStore.commitChange({ classroom: true, animate: true, print: true, dirty: true, save: true });
  if (showNotice) {
    showToast(`현재 자리 순서를 유지한 채 ${colsCount}열(${rowsPerCol}행) 대형으로 즉시 반영되었습니다.`, 'info');
  }
  if (state.inSecretRoom) checkSecretRoomLayoutMismatch(true);
}

export function handleStudentPick(studentId) {
  const state = AppStore.getState();
  if (isRouletteBlockingEdit()) return;
  const id = String(studentId);
  if (!state.inSecretRoom && isSeatHidden(state, id)) {
    showToast('현재 자리가 가려져 있습니다. 책상을 직접 클릭해 이름을 먼저 공개해 주세요.', 'info');
    return;
  }
  const activeMap = getActivePosMap(state);

  if (state.selectedStudentId === null) {
    state.selectedStudentId = id;
    playSoundEffect('select');
  } else if (String(state.selectedStudentId) === id) {
    state.selectedStudentId = null;
    playSoundEffect('unlock');
  } else {
    const firstId = String(state.selectedStudentId);
    const firstSt = getStudentById(state, firstId);
    const secondSt = getStudentById(state, id);

    pushUndoSnapshot(`${firstSt ? firstSt.name : '학생'} ↔ ${secondSt ? secondSt.name : '학생'} 자리 맞바꾸기`);
    const tempCoord = activeMap[firstId];
    activeMap[firstId] = activeMap[id];
    activeMap[id] = tempCoord;

    state.selectedStudentId = null;
    playSoundEffect('swap');
    AppStore.commitChange({ roster: true, classroom: true, animate: true, print: true, dirty: true, save: true });

    if (firstSt && secondSt) {
      showToast(
        state.inSecretRoom
          ? `[비밀의 방] ${firstSt.name} ↔ ${secondSt.name} 목표 자리가 설정되었습니다.`
          : `${firstSt.name} ↔ ${secondSt.name} 자리가 변경되었습니다.`,
        state.inSecretRoom ? 'secret' : 'info'
      );
    }
    if (state.inSecretRoom) checkSecretRoomLayoutMismatch(true);
    return;
  }
  AppStore.requestRosterAndClassroomRender(false);
}

export function handleEmptySlotClick(col, row) {
  const state = AppStore.getState();
  if (isRouletteBlockingEdit()) return;
  if (state.selectedStudentId === null) {
    showToast('먼저 이동할 학생의 책상(또는 왼쪽 번호)을 클릭해 선택하세요.', 'info');
    return;
  }
  const activeMap = getActivePosMap(state);
  const targetCol = Math.min(MAX_COLS - 1, Math.max(0, Math.round(Number(col) || 0)));
  const targetRow = Math.min(MAX_ROWS - 1, Math.max(0, Math.round(Number(row) || 0)));
  const alreadyOccupied = state.students.some(s => {
    const p = activeMap[s.id];
    return Array.isArray(p) && p[0] === targetCol && p[1] === targetRow;
  });
  if (alreadyOccupied) return;
  col = targetCol;
  row = targetRow;
  const st = getStudentById(state, state.selectedStudentId);
  const { c0, r0 } = getGridBounds(state.students, activeMap, false);
  const visCol = Math.max(1, col - c0 + 1);
  const visRow = Math.max(1, row - r0 + 1);
  pushUndoSnapshot(`${st ? st.name : '학생'} 책상 위치 이동 (${visCol}열 ${visRow}행)`);
  activeMap[state.selectedStudentId] = [col, row];
  state.selectedStudentId = null;
  playSoundEffect('swap');
  AppStore.commitChange({ roster: true, classroom: true, animate: true, print: true, dirty: true, save: true });
  showToast(`${st ? st.name : '선택한'} 책상이 새 위치로 이동되었습니다.`, 'success');
  if (state.inSecretRoom) checkSecretRoomLayoutMismatch(true);
}
