import { createEmptyClassState } from '../src/js/domain/schema.js';
import { encodeMultiClassBundle, isMultiClassBundlePayload } from '../src/js/domain/codec.js';
import { buildSeatingHtmlTable, buildSeatingTsvText } from '../src/js/domain/seat-queries.js';
/**
 * 순수 도메인 계층(L0·L1) Node.js 단독 단위 테스트 (DOM·브라우저 불필요)
 * 실행: npm run test:unit  (또는 node --test tests/domain.test.mjs)
 */
import assert from 'node:assert/strict';
import test from 'node:test';

import { APP_VERSION, MAX_COLS, MAX_ROWS, MIN_VALID_HTML_LENGTH, OBFUSCATION_XOR_KEY } from '../src/js/core/constants.js';
import {
  compareStudentsByNumber,
  escapeHtml,
  formatStudentNumCompact,
  formatStudentNumLabel,
  hasWideStudentNum,
  parseInlineStudentNumInput,
  sanitizeClassLabel,
  sanitizeFileName
} from '../src/js/core/utils.js';
import {
  canRegisterPairRule,
  diagnoseAssignmentConflicts,
  generateOptimalSeatAssignment
} from '../src/js/domain/algorithm-engine.js';
import { encodeObfuscatedPayload, isSimpleObfuscatedText, parseSeatFileText } from '../src/js/domain/codec.js';
import {
  computeCustomLayoutAssignments,
  extractCanonicalCoordsFromPos,
  getLayoutMiniGridGeometry,
  getNextDefaultLayoutName,
  sanitizeCustomLayoutName,
  sanitizeCustomLayoutsList
} from '../src/js/domain/custom-layouts.js';
import { parseExcelRosterWithDiagnostics } from '../src/js/domain/excel-parser.js';
import {
  ensureAllStudentsHaveValidCoords,
  findFreeCoordinate,
  getGridBounds,
  insertGridColAisle,
  insertGridRowAisle,
  removeEmptyGridColAisle,
  removeEmptyGridRowAisle,
  resolveLockedSafePositions
} from '../src/js/domain/grid.js';
import {
  applyLoadedDataToState,
  createInitialState,
  isUnsupportedFutureSchemaPayload,
  migratePayloadSchema,
  sanitizeLoadedStudents,
  validateBundleSlotPayload
} from '../src/js/domain/schema.js';
import { doesSecretLayoutMatchCurrent, getLockedSeatConflicts, isSeatLocked } from '../src/js/domain/seat-queries.js';
import {
  compareVersions,
  computeSha256HexSync,
  resolveExpectedPkgSha256,
  validateDownloadedHtml,
  verifyRuntimePkgIntegrity
} from '../src/js/domain/updater-core.js';

function makeSeededRng(seed = 20261121) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function makeRoster(count = 30, cols = 6) {
  const students = [];
  const pos = {};
  for (let i = 1; i <= count; i++) {
    const id = 's' + i;
    students.push({ id, num: i, name: '학생' + i, gender: i % 2 === 1 ? '남' : '여' });
    pos[id] = [((i - 1) % cols) + 1, Math.floor((i - 1) / cols) + 1];
  }
  return { students, pos };
}

test('L0 core/utils: escapeHtml 및 sanitizeFileName 동작 검증', () => {
  assert.equal(escapeHtml('<script>"a&b\'</script>'), '&lt;script&gt;&quot;a&amp;b&#39;&lt;/script&gt;');
  assert.equal(sanitizeFileName(' 3학년/2반:자리*배치? '), '3학년_2반_자리_배치_');
});

test('L1 domain/codec: simple-v1 XOR+Base64 난독화 왕복 및 평문 호환', () => {
  const payload = { classTitle: '3학년 2반', students: [{ id: 's1', num: 1, name: '홍길동', gender: '남' }] };
  const enc = encodeObfuscatedPayload(payload);
  assert.equal(isSimpleObfuscatedText(enc), true);
  assert.equal(isSimpleObfuscatedText(JSON.stringify(payload)), false);
  assert.deepEqual(parseSeatFileText(enc), payload);
  assert.deepEqual(parseSeatFileText(JSON.stringify(payload)), payload);
});

test('L1 domain/schema: v1→v2 마이그레이션, 미래 버전 거부, 프로토타입 오염 차단', () => {
  const v2 = migratePayloadSchema({ classTitle: '구버전반', students: [], pos: {}, rules: { genderPairMode: 'mixed' } });
  assert.equal(v2.schemaVersion, 2);
  assert.equal(v2.rules.defaultCols, 6);
  assert.equal(migratePayloadSchema({ schemaVersion: 99, students: [], pos: {} }), null);

  const sanitized = sanitizeLoadedStudents([
    { id: '__proto__', num: 1, name: '차단1', gender: '남' },
    { id: 'toString', num: 2, name: '차단2', gender: '여' },
    { id: 's1', num: 123456, name: '정상학생', gender: '여' },
    { id: 's2', num: 30103, name: '학번학생', gender: '남' },
    { id: 's3', num: 3, name: '합반학생', gender: '여', classLabel: '2반' }
  ]);
  assert.equal(sanitized.length, 3);
  assert.equal(sanitized[0].id, 's1');
  assert.equal(sanitized[0].num, 1);
  assert.equal(sanitized[1].num, 30103);
  assert.equal(sanitized[1].classLabel, undefined);
  assert.equal(sanitized[2].classLabel, '2반');

  const st = createInitialState();
  assert.equal(applyLoadedDataToState(st, { classTitle: '빈명단', students: [], pos: {} }, '기본', false), false);
  assert.equal(applyLoadedDataToState(st, { classTitle: '빈명단허용', students: [], pos: {} }, '기본', true), true);
  assert.equal(st.classTitle, '빈명단허용');
});

test('L1 domain/grid & seat-queries: 빈 좌표 탐색 · 중복 좌표 보정 · 고정석 충돌 감지', () => {
  const { students, pos } = makeRoster(6, 6);
  const free = findFreeCoordinate(pos, null, 6);
  assert.deepEqual(free, [1, 2]);

  pos.s2 = [...pos.s1]; // 의도적 중복
  ensureAllStudentsHaveValidCoords(students, pos, 6);
  const keys = new Set(students.map((s) => pos[s.id].join(',')));
  assert.equal(keys.size, 6);

  const bounds = getGridBounds(students, pos, false);
  assert.ok(bounds.c0 >= 0 && bounds.c1 < MAX_COLS && bounds.r0 >= 0 && bounds.r1 < MAX_ROWS);

  const st = createInitialState();
  st.secretPos = JSON.parse(JSON.stringify(st.pos));
  assert.equal(doesSecretLayoutMatchCurrent(st), true);
  st.lockedIds = ['s1'];
  assert.equal(isSeatLocked(st, 's1'), true);
  const tmp = st.secretPos.s1;
  st.secretPos.s1 = st.secretPos.s2;
  st.secretPos.s2 = tmp;
  assert.deepEqual(getLockedSeatConflicts(st), ['고길동']);
  assert.equal(doesSecretLayoutMatchCurrent(st), false);
});

test('L1 domain/excel-parser: 나이스·성별선행·붙은번호·전화번호제외·실명보호 파싱', () => {
  const raw = [
    '번호\t이름\t성별',
    '1\t고길동\t010-1234-5678\t남',
    '2.김영희\t여',
    '3\t여\t또치',
    '성명진\t남',
    '-5\t음수학생\t여'
  ].join('\n');
  const { students } = parseExcelRosterWithDiagnostics(raw, true);
  assert.equal(students.length, 5);
  assert.equal(students[0].name, '고길동');
  assert.equal(students[1].name, '김영희');
  assert.equal(students[2].name, '또치');
  assert.equal(students[3].name, '성명진');
  const neis3 = parseExcelRosterWithDiagnostics('3-2-15\t홍길동\t남\n3-2-16\t김영희\t여', true).students;
  assert.equal(neis3.length, 2);
  assert.equal(neis3[0].num, 15);
  assert.equal(neis3[0].name, '홍길동');
  assert.equal(neis3[1].num, 16);
  assert.equal(neis3[1].name, '김영희');
  assert.equal(students[4].name, '음수학생');
});

test('L1 domain/algorithm-engine: 상호배타 규칙 검증 및 결정론적 시드 재현성', () => {
  const rules = {
    defaultCols: 6,
    useGenderDistinction: true,
    genderPairMode: 'mixed',
    excludePreviousSeat: true,
    frontRowIds: ['s11', 's12'],
    separatedPairs: [['s1', 's2']],
    togetherPairs: [['s3', 's4']]
  };
  assert.equal(canRegisterPairRule('s1', 's2', 'tog', rules).ok, false);
  assert.equal(canRegisterPairRule('s3', 's4', 'sep', rules).ok, false);
  assert.equal(canRegisterPairRule('s3', 's5', 'tog', rules).ok, false);
  assert.equal(canRegisterPairRule('s5', 's6', 'sep', rules).ok, true);

  const { students, pos } = makeRoster(30, 6);
  const res1 = generateOptimalSeatAssignment({ students, pos, rules, lockedIds: ['s15'], rng: makeSeededRng(42) });
  const res2 = generateOptimalSeatAssignment({ students, pos, rules, lockedIds: ['s15'], rng: makeSeededRng(42) });
  assert.deepEqual(res1.map, res2.map);
  assert.deepEqual(res1.map.s15, pos.s15);
  assert.equal(res1.conflicts.length, 0);
});

test('L1 domain/updater-core: 버전 비교 · SHA-256 표준 벡터 · HTML 무결성 검증', () => {
  assert.ok(compareVersions('2.10', '2.9') > 0);
  assert.equal(compareVersions('v' + APP_VERSION, APP_VERSION), 0);
  assert.equal(
    computeSha256HexSync('abc'),
    'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'
  );
  const pad = '<!-- ' + 'A'.repeat(MIN_VALID_HTML_LENGTH) + ' -->';
  const html = `<!DOCTYPE html><html><body>${pad}<script>const APP_VERSION = '9.99';</script></body></html>`;
  assert.equal(validateDownloadedHtml(html, '9.99', true), true);
  assert.equal(validateDownloadedHtml(html, '9.99', false), false);
  assert.equal(validateDownloadedHtml(html, APP_VERSION, true), false);

  const hash = computeSha256HexSync(OBFUSCATION_XOR_KEY);
  assert.equal(verifyRuntimePkgIntegrity(hash, hash), true);
  assert.equal(verifyRuntimePkgIntegrity('0'.repeat(64), hash), false);
  assert.equal(resolveExpectedPkgSha256({ version: '9.99', knownPkgHashes: { [APP_VERSION]: hash } }, APP_VERSION), hash);
});

test('v2.78: createEmptyClassState creates 0-student empty class slot', () => {
  const empty = createEmptyClassState('3학년 2반');
  assert.equal(empty.classTitle, '3학년 2반');
  assert.equal(empty.students.length, 0);
  assert.deepEqual(empty.pos, {});
});

test('v2.78: buildSeatingTsvText flips coordinates cleanly between student and teacher orientations', () => {
  const st = createInitialState();
  const stuTsv = buildSeatingTsvText(st, 'student');
  const teaTsv = buildSeatingTsvText(st, 'teacher');
  assert.ok(stuTsv.includes('[교탁]'));
  assert.ok(stuTsv.includes('\t'));
  assert.ok(stuTsv.split('\n')[1].includes('[교탁]'));
  assert.ok(teaTsv.split('\n').at(-1).includes('[교탁]'));
  assert.equal(buildSeatingTsvText(createEmptyClassState('빈반'), 'student'), '');
});

test('v2.89: encodeMultiClassBundle round-trips obfuscated 7-class bundle', () => {
  const bundle = {
    _multiClassBundle: true,
    schemaVersion: 2,
    activeSlot: 7,
    titles: ['1반', '2반', '3반', '4반', '5반', '6반', '7반'],
    slots: { '1': createInitialState(), '2': createEmptyClassState('2반'), '7': createEmptyClassState('7반') }
  };
  const encoded = encodeMultiClassBundle(bundle);
  assert.ok(!encoded.includes('3학년') && encoded.includes('simple-v1'));
  const decoded = parseSeatFileText(encoded);
  assert.equal(isMultiClassBundlePayload(decoded), true);
  assert.equal(decoded.activeSlot, 7);
  assert.equal(decoded.slots['2'].students.length, 0);
  assert.equal(decoded.slots['7'].students.length, 0);
});

test('v2.80: sanitizeFileName caps overly long filenames at 80 characters', () => {
  const longName = '가'.repeat(200);
  const safe = sanitizeFileName(longName);
  assert.equal(safe.length, 80);
});

test('v2.81: resolveLockedSafePositions keeps locked student fixed and relocates displaced student without collision', () => {
  const students = [
    { id: 's1', num: 1, name: 'A', gender: '남' },
    { id: 's2', num: 2, name: 'B', gender: '여' },
    { id: 's3', num: 3, name: 'C', gender: '남' }
  ];
  const snapshotPos = { s1: [1, 1], s2: [2, 1], s3: [3, 1] };
  const currentMap = { s1: [2, 1], s2: [1, 1], s3: [3, 1] };
  const resolved = resolveLockedSafePositions(students, snapshotPos, currentMap, (id) => id === 's1');
  assert.deepEqual(resolved.s1, [2, 1]); // locked s1 stays at current [2, 1]
  assert.deepEqual(resolved.s2, [1, 1]); // displaced s2 takes s1's old snapshot coord [1, 1]
  assert.deepEqual(resolved.s3, [3, 1]); // unaffected s3 restores snapshot [3, 1]
});

test('v2.81: resolveLockedSafePositions handles multiple locked students with zero overlapping coordinates', () => {
  const students = [
    { id: 's1', num: 1, name: 'A', gender: '남' },
    { id: 's2', num: 2, name: 'B', gender: '여' },
    { id: 's3', num: 3, name: 'C', gender: '남' },
    { id: 's4', num: 4, name: 'D', gender: '여' }
  ];
  const snapshotPos = { s1: [1, 1], s2: [2, 1], s3: [3, 1], s4: [4, 1] };
  const currentMap = { s1: [3, 1], s2: [4, 1], s3: [1, 1], s4: [2, 1] };
  const resolved = resolveLockedSafePositions(students, snapshotPos, currentMap, (id) => id === 's1' || id === 's2');
  assert.deepEqual(resolved.s1, [3, 1]);
  assert.deepEqual(resolved.s2, [4, 1]);
  const coords = Object.values(resolved).map(c => `${c[0]},${c[1]}`);
  assert.equal(new Set(coords).size, 4);
});

test('v2.83: buildSeatingHtmlTable outputs borderless-gap card table with shading, centered podium, and XSS escaping', () => {
  const st = createInitialState();
  st.printShadeMode = 'female';
  st.printShadeSeatEnabled = true;
  st.students[0].name = '<img src=x onerror=alert(1)>';
  const htmlStu = buildSeatingHtmlTable(st, 'student');
  const htmlTea = buildSeatingHtmlTable(st, 'teacher');
  assert.ok(!htmlStu.includes('border="0"') && !htmlStu.includes('border:none'));
  assert.ok(htmlStu.includes('border:1pt solid #000000'));
  assert.ok(htmlStu.includes('font-size:8pt') && htmlStu.includes('width:76px'));
  assert.ok(htmlStu.includes('background:#e5e7eb'));
  assert.ok(htmlStu.includes('1번'));
  assert.ok(!htmlStu.includes('<img src=x') && htmlStu.includes('&lt;img src=x'));
  assert.ok(htmlStu.indexOf('교&nbsp;&nbsp;탁') < htmlStu.lastIndexOf('고영희'));
  assert.ok(htmlTea.indexOf('교&nbsp;&nbsp;탁') > htmlTea.lastIndexOf('고영희'));
  assert.equal(buildSeatingHtmlTable(createEmptyClassState('빈반'), 'student'), '');
});

test('v2.84: printIncludeRoster=false disables HTML table shading and applyLoadedDataToState resets lastSavedAt', () => {
  const st = createInitialState();
  st.printIncludeRoster = false;
  st.printShadeMode = 'female';
  st.printShadeSeatEnabled = true;
  const htmlNoRoster = buildSeatingHtmlTable(st, 'student');
  assert.ok(!htmlNoRoster.includes('background:#e5e7eb'));

  st.lastSavedAt = '오후 11:22:42';
  const empty = createEmptyClassState('2반');
  assert.equal(applyLoadedDataToState(st, empty, '2반', true), true);
  assert.equal(st.lastSavedAt, null);
});

test('v2.86: buildSeatingHtmlTable outputs side-by-side roster + seating table when printIncludeRoster=true and seat-only when false', () => {
  const st = createInitialState();
  st.printIncludeRoster = true;
  st.printShadeMode = 'female';
  st.printShadeSeatEnabled = false;
  const htmlSideBySide = buildSeatingHtmlTable(st, 'student');
  assert.equal((htmlSideBySide.match(/<table /g) || []).length, 3);
  assert.ok(htmlSideBySide.includes('성명') && htmlSideBySide.includes('교&nbsp;&nbsp;탁'));
  assert.ok(htmlSideBySide.indexOf('성명') < htmlSideBySide.indexOf('교&nbsp;&nbsp;탁'));
  assert.ok(htmlSideBySide.includes('background:#e5e7eb'));

  st.printIncludeRoster = false;
  const htmlSeatOnly = buildSeatingHtmlTable(st, 'student');
  assert.equal((htmlSeatOnly.match(/<table /g) || []).length, 1);
  assert.ok(!htmlSeatOnly.includes('성명'));
});

test('v2.91: 합반 classLabel 자동 인식 · (classLabel, num) 중복 허용 · 연번 오탐 방어 · 5자리 학번 포맷/자연정렬', () => {
  assert.equal(sanitizeClassLabel(' 3-1반 '), '3-1반');
  assert.equal(formatStudentNumLabel({ num: 3 }), '3번');
  assert.equal(formatStudentNumLabel({ num: 30103 }), '30103');
  assert.equal(formatStudentNumLabel({ num: 3, classLabel: '1반' }), '1반 3번');
  assert.equal(formatStudentNumCompact({ num: 3, classLabel: '1반' }), '1-3');
  assert.equal(formatStudentNumCompact({ num: 15, classLabel: '3-1' }), '3-1-15');
  assert.equal(hasWideStudentNum([{ num: 1 }, { num: 30 }]), false);
  assert.equal(hasWideStudentNum([{ num: 30103 }]), true);
  assert.equal(hasWideStudentNum([{ num: 3, classLabel: '1반' }]), true);

  // 1) 명시적 학반·NEIS·반-번호 하이픈 + 반별 동일 번호 공존
  const explicit = parseExcelRosterWithDiagnostics(
    '1반\t3\t홍길동\t남\n2반\t3\t김영희\t여\n10반\t1\t박민수\t남\n3-1-15\t이철수\t남\n4-3\t최유리\t여',
    true
  );
  assert.equal(explicit.students.length, 5);
  assert.equal(explicit.students[0].classLabel, '1반');
  assert.equal(explicit.students[0].num, 3);
  assert.equal(explicit.students[1].classLabel, '2반');
  assert.equal(explicit.students[1].num, 3);
  assert.equal(explicit.students[3].classLabel, '3-1');
  assert.equal(explicit.students[3].num, 15);
  assert.equal(explicit.students[4].classLabel, '4반');
  assert.equal(explicit.students[4].num, 3);

  // 2) 순수 숫자 [반/번호/성명] (헤더 유무) vs [연번/번호/성명] 오탐 차단
  const pureWithHeader = parseExcelRosterWithDiagnostics('반\t번호\t성명\t성별\n1\t3\t홍길동\t남\n2\t3\t김영희\t여', true).students;
  assert.equal(pureWithHeader[0].classLabel, '1반');
  assert.equal(pureWithHeader[1].classLabel, '2반');
  assert.equal(pureWithHeader[1].num, 3);

  const pureMultiClass = parseExcelRosterWithDiagnostics('1\t3\t홍길동\t남\n1\t4\t이철수\t남\n2\t3\t김영희\t여\n2\t4\t박민수\t남', true).students;
  assert.equal(pureMultiClass[0].classLabel, '1반');
  assert.equal(pureMultiClass[2].classLabel, '2반');
  assert.equal(pureMultiClass[2].num, 3);

  const serialFalsePos = parseExcelRosterWithDiagnostics('1\t15\t홍길동\t남\n2\t16\t김영희\t여\n3\t17\t박민수\t남', true).students;
  assert.equal(serialFalsePos.every((s) => !s.classLabel), true);
  assert.equal(serialFalsePos[0].num, 15);

  // 3) 5자리 학번 + 자연정렬 + HTML/TSV 표 출력
  const id5 = parseExcelRosterWithDiagnostics('30103\t김학번\t남\n30201\t이학번\t여', true).students;
  assert.equal(id5[0].num, 30103);
  assert.equal(id5[1].num, 30201);

  const sorted = [explicit.students[2], explicit.students[1], explicit.students[0]].sort(compareStudentsByNumber);
  assert.deepEqual(sorted.map((s) => `${s.classLabel}:${s.num}`), ['1반:3', '2반:3', '10반:1']);

  const st = createEmptyClassState('선택과목 A반');
  st.students = [
    { id: 's1', num: 3, name: '홍길동', gender: '남', classLabel: '1반' },
    { id: 's2', num: 30103, name: '김학번', gender: '여' }
  ];
  st.pos = { s1: [1, 1], s2: [2, 1] };
  const html = buildSeatingHtmlTable(st, 'student');
  assert.ok(html.includes('1반 3번'));
  assert.ok(html.includes('>1-3<'));
  assert.ok(html.includes('>30103<'));
  assert.ok(html.includes('width:54px'));
  const tsv = buildSeatingTsvText(st, 'student');
  assert.ok(tsv.includes('1-3 홍길동') && tsv.includes('30103 김학번'));

  // 4) 명렬표 1칸 스마트 반·번호 입력 파서 검증
  assert.deepEqual(parseInlineStudentNumInput('3'), { ok: true, num: 3, classLabel: '' });
  assert.deepEqual(parseInlineStudentNumInput('3번'), { ok: true, num: 3, classLabel: '' });
  assert.deepEqual(parseInlineStudentNumInput('1-3'), { ok: true, num: 3, classLabel: '1반' });
  assert.deepEqual(parseInlineStudentNumInput('1반 3'), { ok: true, num: 3, classLabel: '1반' });
  assert.deepEqual(parseInlineStudentNumInput('3-1-15'), { ok: true, num: 15, classLabel: '3-1' });
  assert.deepEqual(parseInlineStudentNumInput('3-1 15번'), { ok: true, num: 15, classLabel: '3-1' });
  assert.deepEqual(parseInlineStudentNumInput('A반 2'), { ok: true, num: 2, classLabel: 'A반' });
  assert.deepEqual(parseInlineStudentNumInput('30103'), { ok: true, num: 30103, classLabel: '' });
  assert.equal(parseInlineStudentNumInput('').ok, false);
  assert.equal(parseInlineStudentNumInput('0').ok, false);
  assert.equal(parseInlineStudentNumInput('123456').ok, false);
  assert.equal(parseInlineStudentNumInput('홍길동').ok, false);
});

test('v2.95: diagnoseAssignmentConflicts 및 conflictDetails 정원 부족·구조 제약·규칙 충돌 분류 검증', () => {
  // 1) 충돌 0건 정상 배정 시 conflictDetails는 빈 배열
  const okClass = makeRoster(12, 6);
  const okRes = generateOptimalSeatAssignment({
    students: okClass.students,
    pos: okClass.pos,
    rules: {
      defaultCols: 6,
      useGenderDistinction: true,
      genderPairMode: 'mixed',
      excludePreviousSeat: false,
      frontRowIds: ['s1', 's2'],
      separatedPairs: [['s1', 's3']],
      togetherPairs: [['s5', 's6']]
    },
    lockedIds: [],
    rng: makeSeededRng(20261124)
  });
  assert.equal(okRes.conflicts.length, 0);
  assert.deepEqual(okRes.conflictDetails, []);

  // 2) 4명 2x2 격자 전쌍 거리두기 → [정원 부족] 거리두기 공간 부족 + 학생명 명시
  const tiny = makeRoster(4, 2);
  const tinyRes = generateOptimalSeatAssignment({
    students: tiny.students,
    pos: tiny.pos,
    rules: {
      defaultCols: 2,
      useGenderDistinction: false,
      genderPairMode: 'any',
      excludePreviousSeat: false,
      frontRowIds: [],
      separatedPairs: [['s1', 's2'], ['s1', 's3'], ['s1', 's4'], ['s2', 's3'], ['s2', 's4'], ['s3', 's4']],
      togetherPairs: []
    },
    lockedIds: [],
    rng: makeSeededRng(20261124)
  });
  assert.ok(tinyRes.conflicts.length > 0);
  assert.ok(tinyRes.conflictDetails.some(d => d.includes('[정원 부족]') && d.includes('거리두기 공간 부족')));

  // 3) 인접 고정석 거리두기 + 떨어진 고정석 붙이기 → [구조 제약] 분류
  const structClass = makeRoster(6, 6);
  const structDetails = diagnoseAssignmentConflicts(
    structClass.pos,
    null,
    {
      students: structClass.students,
      rules: {
        defaultCols: 6,
        useGenderDistinction: false,
        genderPairMode: 'any',
        excludePreviousSeat: false,
        frontRowIds: [],
        separatedPairs: [['s1', 's2']],
        togetherPairs: [['s3', 's6']]
      },
      lockedIds: ['s1', 's2', 's3', 's6']
    }
  );
  assert.ok(structDetails.some(d => d.includes('[구조 제약]') && d.includes('거리두기 불가') && d.includes('학생1')));
  assert.ok(structDetails.some(d => d.includes('[구조 제약]') && d.includes('친구 붙이기 불가') && d.includes('학생3')));

  // 4) 단독석 격자(짝 슬롯 0쌍)에서 친구 붙이기 + 앞줄(1~2행) 좌석 수 초과 → [정원 부족] 진단
  const soloStudents = [
    { id: 's1', num: 1, name: '민수', gender: '남' },
    { id: 's2', num: 2, name: '영희', gender: '여' },
    { id: 's3', num: 3, name: '철수', gender: '남' },
    { id: 's4', num: 4, name: '유리', gender: '여' }
  ];
  const soloPos = { s1: [1, 1], s2: [3, 1], s3: [1, 3], s4: [3, 3] };
  const capDetails = diagnoseAssignmentConflicts(
    soloPos,
    null,
    {
      students: soloStudents,
      rules: {
        defaultCols: 4,
        useGenderDistinction: false,
        genderPairMode: 'any',
        excludePreviousSeat: false,
        frontRowIds: ['s1', 's2', 's3'],
        separatedPairs: [],
        togetherPairs: [['s1', 's2']]
      },
      lockedIds: []
    }
  );
  assert.ok(capDetails.some(d => d.includes('[정원 부족]') && d.includes('앞줄(1~2행) 좌석 부족')));
  assert.ok(capDetails.some(d => d.includes('[정원 부족]') && d.includes('친구 붙이기 슬롯 부족') && d.includes('민수')));
});

test('v2.96: generateOptimalSeatAssignment 좌표 누락 학생 포함 직접 호출 시 유효 학생 좌표 중첩 0건 방어', () => {
  const students = [
    { id: 's1', num: 1, name: '남1', gender: '남' },
    { id: 's2', num: 2, name: '여1', gender: '여' },
    { id: 's3', num: 3, name: '남2', gender: '남' },
    { id: 's4', num: 4, name: '여2', gender: '여' },
    { id: 's5', num: 5, name: '좌표누락학생', gender: '남' }
  ];
  const pos = { s1: [1, 1], s2: [2, 1], s3: [1, 2], s4: [2, 2] };
  const res = generateOptimalSeatAssignment({
    students,
    pos,
    rules: {
      defaultCols: 2,
      useGenderDistinction: true,
      genderPairMode: 'mixed',
      excludePreviousSeat: false,
      frontRowIds: [],
      separatedPairs: [],
      togetherPairs: []
    },
    lockedIds: [],
    rng: makeSeededRng(20261124)
  });
  const assignedCoords = ['s1', 's2', 's3', 's4'].map(id => res.map[id]);
  assert.equal(assignedCoords.every(c => Array.isArray(c) && c.length === 2), true);
  const uniqueKeys = new Set(assignedCoords.map(c => `${c[0]},${c[1]}`));
  assert.equal(uniqueKeys.size, 4);
  assert.equal(res.map.s5, undefined);
});

test('20. [domain/custom-layouts] 사용자 책상 대형 좌표 정규화·상한·미니 격자 기하 검증', () => {
  const students = [
    { id: 's1', num: 1, name: '가', gender: '남' },
    { id: 's2', num: 2, name: '나', gender: '여' },
    { id: 's3', num: 3, name: '다', gender: '남' },
    { id: 's4', num: 4, name: '라', gender: '여' },
    { id: 's5', num: 5, name: '마', gender: '남' }
  ];
  // 통로가 있는 모둠 + 단독 1석 형상 (시작 좌표가 (3, 4)로 치우쳐 있어도 (1, 1) 기준으로 상대 간격 보존)
  const pos = {
    s1: [3, 4],
    s2: [4, 4],
    s3: [6, 4],
    s4: [7, 4],
    s5: [6, 6]
  };
  const coords = extractCanonicalCoordsFromPos(students, pos);
  assert.deepEqual(coords, [
    [1, 1],
    [2, 1],
    [4, 1],
    [5, 1],
    [4, 3]
  ]);

  const mini = getLayoutMiniGridGeometry(coords);
  assert.equal(mini.cols, 5);
  assert.equal(mini.rows, 3);
  assert.equal(mini.cells.length, 5);

  // 최대 6개 상한 · 중복 ID 정화 · 유효하지 않은 항목 필터링
  const many = Array.from({ length: 10 }, (_, idx) => ({
    id: idx < 2 ? 'dup' : `id_${idx}`,
    name: `  대형\n${idx + 1}  `,
    coords: [[1, 1], [2, 1]]
  }));
  many.push({ id: 'bad', name: '빈좌표', coords: [] });
  const cleaned = sanitizeCustomLayoutsList(many);
  assert.equal(cleaned.length, 6);
  assert.notEqual(cleaned[0].id, cleaned[1].id);
  assert.equal(cleaned[0].name, '대형 1');
  assert.equal(getNextDefaultLayoutName([{ name: '내 대형 1' }, { name: '내 대형 3' }]), '내 대형 2');

  // 48자 최대 길이 중복 ID 무한 루프 방어 (P1-H1)
  const id48 = 'a'.repeat(48);
  const dup48 = sanitizeCustomLayoutsList([
    { id: id48, name: '긴ID 1', coords: [[1, 1], [2, 1]] },
    { id: id48, name: '긴ID 2', coords: [[1, 1], [3, 1]] }
  ]);
  assert.equal(dup48.length, 2);
  assert.notEqual(dup48[0].id, dup48[1].id);
  assert.ok(dup48[0].id.length <= 48 && dup48[1].id.length <= 48);
  assert.ok(dup48[1].id.endsWith('_2'));
});

test('21. [domain/custom-layouts] 대형 적용 시 고정석 유지 · 인원 감소 · 초과 인원 빈칸 보정 검증', () => {
  const targetCoords = [[1, 1], [2, 1], [4, 1], [5, 1]];
  const baseStudents = [
    { id: 's1', num: 1, name: '가', gender: '남' },
    { id: 's2', num: 2, name: '나', gender: '여' },
    { id: 's3', num: 3, name: '다', gender: '남' },
    { id: 's4', num: 4, name: '라', gender: '여' },
    { id: 's5', num: 5, name: '마', gender: '남' }
  ];
  const curPos = {
    s1: [0, 0],
    s2: [1, 2],
    s3: [2, 2],
    s4: [3, 2],
    s5: [4, 2]
  };
  // s1 고정(0,0) + 5명 적용(4석 대형) → s1은 (0,0) 유지, 나머지 4명 중 4명이 targetCoords 4칸을 모두 채워 초과 0명
  const withLock = computeCustomLayoutAssignments(baseStudents, curPos, targetCoords, (id) => id === 's1', 6);
  assert.deepEqual(withLock.posMap.s1, [0, 0]);
  assert.equal(withLock.overflowCount, 0);
  assert.equal(withLock.unusedSlotCount, 0);

  // 고정 없이 5명 적용(4석 대형) → 4명은 targetCoords, 초과 1명은 겹치지 않는 인접 빈칸 자동 배치
  const overflow = computeCustomLayoutAssignments(baseStudents, curPos, targetCoords, () => false, 6);
  assert.equal(overflow.overflowCount, 1);
  const uniq = new Set(Object.values(overflow.posMap).map(([c, r]) => `${c},${r}`));
  assert.equal(uniq.size, 5);

  // 인원 3명(4석 대형) → 3명 배치 + 미사용 1석 집계
  const fewer = computeCustomLayoutAssignments(baseStudents.slice(0, 3), curPos, targetCoords, () => false, 6);
  assert.equal(fewer.overflowCount, 0);
  assert.equal(fewer.unusedSlotCount, 1);
});

test('22. [domain/custom-layouts] 책상 대형 이름 정화·공백 거부·24자 제한 검증', () => {
  assert.equal(sanitizeCustomLayoutName('   ', ''), '');
  assert.equal(sanitizeCustomLayoutName('  4인\t\n모둠  대형  ', ''), '4인 모둠 대형');
  assert.equal(sanitizeCustomLayoutName('가나다라마바사아자차카타파하거너더러머버서어저처커터', '').length, 24);
  assert.equal(sanitizeCustomLayoutName('\u200B  ', '기본이름'), '기본이름');
});

test('23. [domain/grid v3.00] 책상 사이 세로·가로 통로 벌리기/좁히기 · 좌상단 시프트 폴백 · 12x16 상한 검증', () => {
  const students = [
    { id: 's1', num: 1, name: '가', gender: '남' },
    { id: 's2', num: 2, name: '나', gender: '여' },
    { id: 's3', num: 3, name: '다', gender: '남' },
    { id: 's4', num: 4, name: '라', gender: '여' }
  ];
  const basePos = { s1: [1, 1], s2: [2, 1], s3: [1, 2], s4: [2, 2] };

  // 1) 세로 통로 벌리기 (splitCol=2 -> 2열 이상이 +1 이동, 빈 2열 생성) 및 좁히기 왕복
  const colSplit = insertGridColAisle(students, basePos, 2);
  assert.equal(colSplit.ok, true);
  assert.deepEqual(colSplit.nextPos.s1, [1, 1]);
  assert.deepEqual(colSplit.nextPos.s2, [3, 1]);
  assert.deepEqual(colSplit.nextPos.s4, [3, 2]);
  assert.deepEqual(colSplit.movedIds.sort(), ['s2', 's4']);
  assert.deepEqual(basePos.s2, [2, 1]); // 원본 불변 확인

  // 학생이 있는 열(1열·3열)은 좁히기 거부, 빈 내부 열(2열)만 좁히기 허용
  assert.equal(removeEmptyGridColAisle(students, colSplit.nextPos, 1).ok, false);
  assert.equal(removeEmptyGridColAisle(students, colSplit.nextPos, 3).reason, 'range');
  const colOccupiedMid = { s1: [1, 1], s2: [2, 1], s3: [3, 1], s4: [3, 2] };
  assert.equal(removeEmptyGridColAisle(students, colOccupiedMid, 2).reason, 'occupied');

  const colMerged = removeEmptyGridColAisle(students, colSplit.nextPos, 2);
  assert.equal(colMerged.ok, true);
  assert.deepEqual(colMerged.nextPos, basePos);

  // 2) 우측 끝(c1 = MAX_COLS - 1 = 11)에 닿았으나 좌측 여유(c0 > 0)가 있을 때 왼쪽으로 -1 당김 폴백
  const rightEdgePos = { s1: [10, 1], s2: [11, 1], s3: [10, 2], s4: [11, 2] };
  const leftFallback = insertGridColAisle(students, rightEdgePos, 11);
  assert.equal(leftFallback.ok, true);
  assert.deepEqual(leftFallback.nextPos.s1, [9, 1]);
  assert.deepEqual(leftFallback.nextPos.s2, [11, 1]);

  // 전체 12열 폭(0..11) 포화 상태에서는 max_cols 거부
  const fullSpanCols = { s1: [0, 1], s2: [5, 1], s3: [6, 1], s4: [MAX_COLS - 1, 1] };
  assert.equal(insertGridColAisle(students, fullSpanCols, 6).reason, 'max_cols');

  // 3) 가로 통로 벌리기 · 하단 끝(r1 = MAX_ROWS - 1 = 15) 상단 폴백 · 빈 가로 통로 좁히기 · 16행 포화 거부
  const rowSplit = insertGridRowAisle(students, basePos, 2);
  assert.equal(rowSplit.ok, true);
  assert.deepEqual(rowSplit.nextPos.s3, [1, 3]);
  assert.deepEqual(rowSplit.nextPos.s4, [2, 3]);
  const rowMerged = removeEmptyGridRowAisle(students, rowSplit.nextPos, 2);
  assert.equal(rowMerged.ok, true);
  assert.deepEqual(rowMerged.nextPos, basePos);

  const bottomEdgePos = { s1: [1, 14], s2: [2, 14], s3: [1, 15], s4: [2, 15] };
  const upFallback = insertGridRowAisle(students, bottomEdgePos, 15);
  assert.equal(upFallback.ok, true);
  assert.deepEqual(upFallback.nextPos.s1, [1, 13]);
  assert.deepEqual(upFallback.nextPos.s3, [1, 15]);

  const fullSpanRows = { s1: [1, 0], s2: [1, 7], s3: [1, 8], s4: [1, MAX_ROWS - 1] };
  assert.equal(insertGridRowAisle(students, fullSpanRows, 8).reason, 'max_rows');
});

test('24. [domain/schema v3.01] 상위 스키마 버전 판별 및 다중학급 번들 슬롯 단일 계약 검증', () => {
  assert.equal(isUnsupportedFutureSchemaPayload({ schemaVersion: 3 }), true);
  assert.equal(isUnsupportedFutureSchemaPayload({ schemaVersion: 999 }), true);
  assert.equal(isUnsupportedFutureSchemaPayload({ schemaVersion: 2 }), false);
  assert.equal(isUnsupportedFutureSchemaPayload({ schemaVersion: 1 }), false);
  assert.equal(isUnsupportedFutureSchemaPayload({ schemaVersion: 0 }), false);
  assert.equal(isUnsupportedFutureSchemaPayload({ schemaVersion: -1 }), false);
  assert.equal(isUnsupportedFutureSchemaPayload({ schemaVersion: 2.5 }), false);
  assert.equal(isUnsupportedFutureSchemaPayload({ schemaVersion: 'future' }), false);
  assert.equal(isUnsupportedFutureSchemaPayload({}), false);
  assert.equal(isUnsupportedFutureSchemaPayload(null), false);
  assert.equal(isUnsupportedFutureSchemaPayload([]), false);

  const validV1 = validateBundleSlotPayload({
    classTitle: '구버전1반',
    students: [{ id: 's1', num: 1, name: '홍길동', gender: '남' }],
    pos: { s1: [1, 1] }
  });
  assert.ok(validV1);
  assert.equal(validV1.schemaVersion, 2);

  const validEmptyV2 = validateBundleSlotPayload({
    schemaVersion: 2,
    classTitle: '빈학급',
    students: [],
    pos: {}
  });
  assert.ok(validEmptyV2);

  assert.equal(validateBundleSlotPayload({ schemaVersion: 3, students: [], pos: {} }), null);
  assert.equal(validateBundleSlotPayload({ schemaVersion: 2, students: 'not-array', pos: {} }), null);
  assert.equal(validateBundleSlotPayload({ schemaVersion: 2, students: [], pos: null }), null);
  assert.equal(validateBundleSlotPayload({ schemaVersion: 2, students: [], pos: [] }), null);
  assert.equal(validateBundleSlotPayload(['bad']), null);
  assert.equal(validateBundleSlotPayload(null), null);
});
