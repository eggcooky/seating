// [L1] 순수 사용자 책상 대형 좌표 정규화 · 검증 · 배치 계산 · 미니 썸네일 기하 (DOM·스토리지 비의존)
import { MAX_COLS, MAX_CUSTOM_LAYOUTS, MAX_ROWS, MAX_STUDENTS } from '../core/constants.js';
import { compareStudentsByNumber } from '../core/utils.js';
import { findFreeCoordinate } from './grid.js';

// 사용자 책상 대형 이름을 공백·개행 정화 후 최대 24자로 제한한다.
export function sanitizeCustomLayoutName(rawName, fallbackName = '') {
  const cleaned = String(rawName == null ? '' : rawName)
    .replace(/[\t\r\n\u200B-\u200D\uFEFF]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 24);
  return cleaned || String(fallbackName || '').trim().slice(0, 24);
}

// 이름이 비어 있을 때 겹치지 않는 기본 이름('내 대형 1', '내 대형 2' ...)을 생성한다.
export function getNextDefaultLayoutName(existingLayouts = []) {
  const used = new Set(
    (Array.isArray(existingLayouts) ? existingLayouts : [])
      .map(item => sanitizeCustomLayoutName(item && item.name))
      .filter(Boolean)
  );
  for (let i = 1; i <= MAX_CUSTOM_LAYOUTS + 20; i++) {
    const candidate = `내 대형 ${i}`;
    if (!used.has(candidate)) return candidate;
  }
  return '내 대형';
}

// 좌표 배열에서 유효·고유 정수 좌표만 추출하고, 상대 형상(통로·간격)을 그대로 보존한 채 기준 원점으로 정규화한다.
function normalizeLayoutCoords(rawCoords) {
  if (!Array.isArray(rawCoords)) return [];
  const valid = [];
  const seen = new Set();
  for (const item of rawCoords) {
    if (!Array.isArray(item) || item.length !== 2) continue;
    const c = Number(item[0]);
    const r = Number(item[1]);
    if (!Number.isInteger(c) || !Number.isInteger(r)) continue;
    if (c < 0 || c >= MAX_COLS || r < 0 || r >= MAX_ROWS) continue;
    const key = `${c},${r}`;
    if (seen.has(key)) continue;
    seen.add(key);
    valid.push([c, r]);
    if (valid.length >= MAX_STUDENTS) break;
  }
  if (valid.length === 0) return [];

  const cols = valid.map(p => p[0]);
  const rows = valid.map(p => p[1]);
  const c0 = Math.min(...cols);
  const c1 = Math.max(...cols);
  const r0 = Math.min(...rows);
  const r1 = Math.max(...rows);
  const baseCol = (c1 - c0 + 1 < MAX_COLS) ? 1 : 0;
  const baseRow = (r1 - r0 + 1 < MAX_ROWS) ? 1 : 0;

  return valid
    .map(([c, r]) => [c - c0 + baseCol, r - r0 + baseRow])
    .sort((a, b) => (a[1] !== b[1] ? a[1] - b[1] : a[0] - b[0]));
}

// 현재 학급의 활성 좌표 맵에서 학생들의 책상 좌표만 추출해 정규화된 대형 좌표 목록으로 반환한다.
export function extractCanonicalCoordsFromPos(students, posMap) {
  const list = Array.isArray(students) ? students : [];
  const map = posMap && typeof posMap === 'object' ? posMap : {};
  const raw = [];
  for (const st of list) {
    if (!st) continue;
    const p = map[st.id];
    if (Array.isArray(p) && p.length === 2) {
      raw.push([p[0], p[1]]);
    }
  }
  return normalizeLayoutCoords(raw);
}

// 단일 사용자 대형 레코드를 검증·정화한다. 유효 좌표가 없으면 null을 반환한다.
function sanitizeCustomLayoutEntry(raw, idx = 0) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const coords = normalizeLayoutCoords(raw.coords);
  if (coords.length === 0) return null;
  const fallbackName = `내 대형 ${idx + 1}`;
  const name = sanitizeCustomLayoutName(raw.name, fallbackName) || fallbackName;
  const rawId = typeof raw.id === 'string' ? raw.id.trim().replace(/[^A-Za-z0-9_-]/g, '').slice(0, 48) : '';
  const id = rawId || `cl_${idx + 1}`;
  const createdAt = Number.isFinite(Number(raw.createdAt)) && Number(raw.createdAt) > 0 ? Math.round(Number(raw.createdAt)) : 0;
  return { id, name, coords, createdAt };
}

// 저장된 사용자 대형 목록 전체를 검증·중복 제거·최대 개수 상한 적용한다.
export function sanitizeCustomLayoutsList(rawList) {
  if (!Array.isArray(rawList)) return [];
  const out = [];
  const usedIds = new Set();
  for (let i = 0; i < rawList.length; i++) {
    const clean = sanitizeCustomLayoutEntry(rawList[i], out.length);
    if (!clean) continue;
    let uniqueId = clean.id;
    let suffix = 2;
    while (usedIds.has(uniqueId)) {
      const tag = `_${suffix++}`;
      uniqueId = `${clean.id.slice(0, Math.max(0, 48 - tag.length))}${tag}`;
    }
    clean.id = uniqueId;
    usedIds.add(uniqueId);
    out.push(clean);
    if (out.length >= MAX_CUSTOM_LAYOUTS) break;
  }
  return out;
}

// 팝오버 미리보기용 미니 도트 격자 기하(0-based 상대 좌표 + 전체 열/행 수)를 계산한다.
export function getLayoutMiniGridGeometry(coords) {
  const normalized = normalizeLayoutCoords(coords);
  if (normalized.length === 0) {
    return { cols: 1, rows: 1, cells: [] };
  }
  const c0 = Math.min(...normalized.map(p => p[0]));
  const c1 = Math.max(...normalized.map(p => p[0]));
  const r0 = Math.min(...normalized.map(p => p[1]));
  const r1 = Math.max(...normalized.map(p => p[1]));
  return {
    cols: Math.max(1, c1 - c0 + 1),
    rows: Math.max(1, r1 - r0 + 1),
    cells: normalized.map(([c, r]) => [c - c0, r - r0])
  };
}

// 저장된 대형 좌표 틀을 현재 학급 학생들에게 적용한 새 좌표 맵을 순수 계산한다.
// - 현재 좌석 읽기 순서(행→열)를 보존해 순서 섞임을 방지한다.
// - 고정석(🔒) 학생은 원래 좌표를 그대로 유지한다.
// - 학생 수가 저장된 석 수보다 적으면 앞쪽 좌표부터 채우고, 많으면 초과 인원은 인접 빈칸에 자동 배치한다.
export function computeCustomLayoutAssignments(students, currentPosMap, targetCoords, isLockedFn, defaultCols = 6) {
  const list = Array.isArray(students) ? students : [];
  const curMap = currentPosMap && typeof currentPosMap === 'object' ? currentPosMap : {};
  const coords = normalizeLayoutCoords(targetCoords);
  const checkLocked = typeof isLockedFn === 'function' ? isLockedFn : () => false;

  const nextPos = {};
  if (list.length === 0) {
    return { posMap: nextPos, appliedCount: 0, overflowCount: 0, unusedSlotCount: coords.length };
  }

  const orderedStudents = [...list].sort((a, b) => {
    const pA = curMap[a.id] || [99, 99];
    const pB = curMap[b.id] || [99, 99];
    if (pA[1] !== pB[1]) return pA[1] - pB[1];
    if (pA[0] !== pB[0]) return pA[0] - pB[0];
    return compareStudentsByNumber(a, b);
  });

  const occupiedKeys = new Set();
  orderedStudents.forEach(st => {
    if (checkLocked(st.id) && Array.isArray(curMap[st.id]) && curMap[st.id].length === 2) {
      const lc = curMap[st.id][0];
      const lr = curMap[st.id][1];
      const key = `${lc},${lr}`;
      if (!occupiedKeys.has(key)) {
        nextPos[st.id] = [lc, lr];
        occupiedKeys.add(key);
      }
    }
  });

  let slotCursor = 0;
  let usedTargetSlots = 0;
  let appliedCount = 0;
  let overflowCount = 0;

  orderedStudents.forEach(st => {
    if (nextPos[st.id]) return;
    let placed = false;
    while (slotCursor < coords.length) {
      const [tc, tr] = coords[slotCursor++];
      const key = `${tc},${tr}`;
      if (!occupiedKeys.has(key)) {
        nextPos[st.id] = [tc, tr];
        occupiedKeys.add(key);
        usedTargetSlots++;
        appliedCount++;
        placed = true;
        break;
      }
    }
    if (!placed) {
      const free = findFreeCoordinate(nextPos, null, defaultCols);
      nextPos[st.id] = [free[0], free[1]];
      occupiedKeys.add(`${free[0]},${free[1]}`);
      overflowCount++;
    }
  });

  // 고정석이 targetCoords 좌표를 이미 점유한 경우도 사용된 슬롯으로 집계한다.
  const targetKeySet = new Set(coords.map(([c, r]) => `${c},${r}`));
  let lockedOnTargetCount = 0;
  orderedStudents.forEach(st => {
    if (checkLocked(st.id) && Array.isArray(nextPos[st.id])) {
      const k = `${nextPos[st.id][0]},${nextPos[st.id][1]}`;
      if (targetKeySet.has(k)) lockedOnTargetCount++;
    }
  });
  const unusedSlotCount = Math.max(0, coords.length - (usedTargetSlots + lockedOnTargetCount));

  return { posMap: nextPos, appliedCount, overflowCount, unusedSlotCount };
}
