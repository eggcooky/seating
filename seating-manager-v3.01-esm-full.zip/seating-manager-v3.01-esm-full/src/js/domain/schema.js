// [L1] 상태 스키마 · 4분할 키 · 마이그레이션 · 정화 · 초기 상태 생성 (DOM·스토리지 비의존)
import { CURRENT_SCHEMA_VERSION, MAX_STUDENT_NUM, MAX_STUDENTS } from '../core/constants.js';
import { sanitizeClassLabel } from '../core/utils.js';
import { ensureAllStudentsHaveValidCoords } from './grid.js';

// [상태 4분할 키 정의]
// 1) DOMAIN_STATE_KEYS: 저장 및 실행 취소(Undo) 대상이 되는 학급 핵심 도메인 데이터
// 2) PREFS_STATE_KEYS: 로컬 저장소·백업 파일에 함께 영속 저장되는 사용자 환경설정
// 3) UI_STATE_KEYS: 저장하지 않는 순수 화면 레이아웃·모드 상태
// 4) SESSION_STATE_KEYS: 룰렛 회전·선택 대기·히스토리 스택 등 일회성 런타임 세션 상태
export const DOMAIN_STATE_KEYS = [
  'schemaVersion', 'classTitle', 'teacherMessage', 'students', 'pos', 'secretPos',
  'lockedIds', 'secretLockedIds', 'rules', 'hiddenSeatIds'
];
export const PREFS_STATE_KEYS = [
  'viewOrientation', 'showGenderColor', 'maskModeEnabled', 'soundEnabled',
  'printOrientation', 'printIncludeRoster', 'printShadeMode', 'printShadeSeatEnabled'
];
export const PERSISTED_STATE_KEYS = [...DOMAIN_STATE_KEYS, ...PREFS_STATE_KEYS, 'lastSavedAt'];
export const UI_STATE_KEYS = [
  'interactionMode', 'sidebarCollapsed', 'largeViewEnabled', 'inSecretRoom', 'hasDeleteGapNotice', 'rosterNumEditMode'
];
export const SESSION_STATE_KEYS = [
  'selectedStudentId', 'manualExpandCol', 'manualExpandRow',
  'rouletteOpen', 'rouletteActiveSession', 'rouletteUseSecretPreset',
  'rouletteSpinning', 'rouletteWheelAngle', 'rouletteRemainingStudents', 'rouletteTargetCoords',
  'rouletteAssignedMap', 'rouletteDrawnIds', 'rouletteAutoColumnTarget', 'rouletteSessionToken',
  'undoStackNormal', 'undoStackSecret', 'rulesModalBackup', 'isDirty', 'pendingSecretNotices'
];

// 스키마 버전별 순차 마이그레이션 테이블 (구버전 저장 데이터를 현재 스키마 구조로 안전하게 변환)
const SCHEMA_MIGRATIONS = {
  1: (v1Data) => {
    const next = { ...v1Data, schemaVersion: 2 };
    if (next.rules && typeof next.rules === 'object') {
      next.rules = {
        defaultCols: 6,
        useGenderDistinction: true,
        genderPairMode: 'any',
        excludePreviousSeat: false,
        frontRowIds: [],
        separatedPairs: [],
        togetherPairs: [],
        ...next.rules
      };
    }
    return next;
  }
};

/**
 * 입력 페이로드가 현재 프로그램이 지원하는 스키마 버전(CURRENT_SCHEMA_VERSION)보다 높은
 * 미래 버전인지 판별한다 (정수 스키마 버전이 현재보다 큰 경우만 true).
 * @param {any} rawPayload
 * @returns {boolean}
 */
export function isUnsupportedFutureSchemaPayload(rawPayload) {
  if (!rawPayload || typeof rawPayload !== 'object' || Array.isArray(rawPayload)) return false;
  if (rawPayload.schemaVersion === undefined || rawPayload.schemaVersion === null) return false;
  const rawVerNum = Number(rawPayload.schemaVersion);
  return Number.isInteger(rawVerNum) && rawVerNum > CURRENT_SCHEMA_VERSION;
}

/**
 * 입력 페이로드의 스키마 버전을 확인하고 현재 버전(CURRENT_SCHEMA_VERSION)으로 마이그레이션한다.
 * 현재 프로그램보다 높은 미래 버전(schemaVersion > CURRENT_SCHEMA_VERSION) 데이터는 필드 유실 방지를 위해 null을 반환해 거부한다.
 * @param {Record<string, any>} rawPayload
 * @returns {Record<string, any> | null}
 */
export function migratePayloadSchema(rawPayload) {
  if (!rawPayload || typeof rawPayload !== 'object' || Array.isArray(rawPayload)) return null;
  if (rawPayload.schemaVersion !== undefined && rawPayload.schemaVersion !== null) {
    const rawVerNum = Number(rawPayload.schemaVersion);
    if (!Number.isInteger(rawVerNum) || rawVerNum < 1 || rawVerNum > CURRENT_SCHEMA_VERSION) {
      return null;
    }
  }
  let cur = { ...rawPayload };
  let ver = Number.isInteger(Number(cur.schemaVersion)) && Number(cur.schemaVersion) >= 1
    ? Number(cur.schemaVersion)
    : 1;
  while (ver < CURRENT_SCHEMA_VERSION && typeof SCHEMA_MIGRATIONS[ver] === 'function') {
    cur = SCHEMA_MIGRATIONS[ver](cur);
    const nextVer = Number(cur.schemaVersion) || (ver + 1);
    if (!(nextVer > ver)) break;
    ver = nextVer;
  }
  cur.schemaVersion = CURRENT_SCHEMA_VERSION;
  return cur;
}

/**
 * 단일 학급 슬롯 객체가 다중학급 번들에 포함·복원 가능한 유효 스키마인지 검증하고
 * 현재 스키마 버전으로 마이그레이션된 사본을 반환한다. 유효하지 않으면 null을 반환한다.
 * (저장 측과 복원 측의 검증 계약을 단일 진실 원천으로 통일한다.)
 * @param {any} rawSlot
 * @returns {Record<string, any> | null}
 */
export function validateBundleSlotPayload(rawSlot) {
  if (!rawSlot || typeof rawSlot !== 'object' || Array.isArray(rawSlot)) return null;
  const migrated = migratePayloadSchema(rawSlot);
  if (!migrated || !Array.isArray(migrated.students) || !migrated.pos || typeof migrated.pos !== 'object' || Array.isArray(migrated.pos)) {
    return null;
  }
  return migrated;
}

const INITIAL_STUDENTS = [
  { id: 's1', num: 1, name: '고길동', gender: '남' },
  { id: 's2', num: 2, name: '희동이', gender: '남' },
  { id: 's3', num: 3, name: '또치',   gender: '여' },
  { id: 's4', num: 4, name: '둘리',   gender: '남' },
  { id: 's5', num: 5, name: '마이콜', gender: '남' },
  { id: 's6', num: 6, name: '공실이', gender: '여' },
  { id: 's7', num: 7, name: '고철수', gender: '남' },
  { id: 's8', num: 8, name: '고영희', gender: '여' }
];

const INITIAL_SEAT_IDS_BY_COL = [
  's1', 's2', 's3', 's4', 's5', 's6', 's7', 's8'
];

export function createInitialState() {
  const students = JSON.parse(JSON.stringify(INITIAL_STUDENTS));
  const pos = {};
  INITIAL_SEAT_IDS_BY_COL.forEach((id, i) => {
    const col = (i % 6) + 1;
    const row = Math.floor(i / 6) + 1;
    pos[id] = [col, row];
  });

  return {
    // [도메인 1: 학급 기본 정보 및 화면 표시 설정]
    schemaVersion: CURRENT_SCHEMA_VERSION,
    classTitle: '우리 반 자리 배치표',
    teacherMessage: '',         // 교탁 하단 안내 문구
    viewOrientation: 'student', // 화면 시점 ('student': 교탁 위, 'teacher': 교탁 아래)
    printOrientation: 'student', // 출력·캡처 시점 ('student' | 'teacher')
    printIncludeRoster: true,    // 출력·캡처 시 좌측 명렬표 포함 여부
    printShadeMode: 'female',    // 출력·캡처 시 음영 기준 ('zebra' | 'female' | 'male' | 'none')
    printShadeSeatEnabled: true, // 명렬표에서 선택한 음영을 우측 책상 칸에 반영할지 여부
    interactionMode: 'seat',    // 조작 모드 ('seat': 자리 교환, 'desk': 책상 이동)
    sidebarCollapsed: false,
    largeViewEnabled: false,
    rosterNumEditMode: false,
    hasDeleteGapNotice: false,
    manualExpandCol: 0,
    manualExpandRow: 0,
    showGenderColor: false,
    // [도메인 2: 학생 명렬표 및 일반·비밀의 방 좌석 좌표·고정석]
    students,
    pos,                        // 일반 화면 좌석 좌표 맵 (studentId -> [col, row])
    secretPos: null,            // 비밀의 방 좌석 좌표 맵 (studentId -> [col, row])
    inSecretRoom: false,        // 비밀의 방 활성화 여부
    lockedIds: [],
    secretLockedIds: [],
    // [도메인 3: 자리 배정 제약 규칙]
    rules: {
      defaultCols: 6,           // 기본 대형 열 수 (4~8열)
      useGenderDistinction: true, // 성별 구분 사용 여부
      genderPairMode: 'any',    // 짝 배정 기준 ('any' | 'mixed' | 'mixed_random' | 'same' | 'same_random')
      excludePreviousSeat: false,
      frontRowIds: [],
      separatedPairs: [],
      togetherPairs: []
    },
    // [도메인 4: 이름 가리기 및 원형 룰렛 세션 상태]
    maskModeEnabled: false,
    soundEnabled: true,
    hiddenSeatIds: [],
    rouletteOpen: false,
    rouletteActiveSession: false,
    rouletteUseSecretPreset: false,
    rouletteSpinning: false,
    rouletteWheelAngle: 0,
    rouletteRemainingStudents: [],
    rouletteTargetCoords: [],
    rouletteAssignedMap: {},
    rouletteDrawnIds: [],
    rouletteAutoColumnTarget: null,
    rouletteSessionToken: 0,
    // [도메인 5: 선택 상태, 실행 취소(Undo) 스택 및 저장 메타데이터]
    selectedStudentId: null,
    undoStackNormal: [],
    undoStackSecret: [],
    rulesModalBackup: null,
    pendingSecretNotices: [],
    isDirty: false,
    lastSavedAt: null
  };
}

// 미사용 다중학급 슬롯(학급 2~7)용 0명 빈 학급 초기 상태를 생성한다.
export function createEmptyClassState(title = '새 학급') {
  const base = createInitialState();
  base.classTitle = String(title || '새 학급').trim().slice(0, 40) || '새 학급';
  base.students = [];
  base.pos = {};
  base.secretPos = null;
  base.lockedIds = [];
  base.secretLockedIds = [];
  base.hiddenSeatIds = [];
  base.rules.frontRowIds = [];
  base.rules.separatedPairs = [];
  base.rules.togetherPairs = [];
  base.lastSavedAt = null;
  return base;
}

export function sanitizeLoadedStudents(list) {
  // 불러온 학생 목록에서 누락·중복 ID를 제거하고 최대 인원(MAX_STUDENTS)과 이름·성별 값을 보정한다.
  const seen = new Set();
  return (Array.isArray(list) ? list : []).filter(st => {
    if (!st || st.id === undefined || st.id === null) return false;
    const rawId = String(st.id).trim();
    if (!rawId || (rawId in Object.prototype) || rawId === '__proto__' || rawId === 'constructor' || rawId === 'prototype' || seen.has(rawId)) return false;
    seen.add(rawId);
    return true;
  }).slice(0, MAX_STUDENTS).map((st, idx) => {
    const cleanId = String(st.id).trim();
    const parsedNum = Number(st.num);
    const cleanNum = Number.isInteger(parsedNum) && parsedNum > 0 && parsedNum <= MAX_STUDENT_NUM ? parsedNum : (idx + 1);
    const cleanName = String(st.name || ('학생' + (idx + 1))).trim().slice(0, 30).trim() || ('학생' + (idx + 1));
    const cleanGender = (st.gender === '남' || st.gender === '여') ? st.gender : '남';
    const cleanClassLabel = sanitizeClassLabel(st.classLabel);
    return cleanClassLabel
      ? { id: cleanId, num: cleanNum, name: cleanName, gender: cleanGender, classLabel: cleanClassLabel }
      : { id: cleanId, num: cleanNum, name: cleanName, gender: cleanGender };
  });
}

// 로컬 저장소(loadFromStorage)와 외부 JSON 파일 불러오기(importJson)의 데이터 검증·정화를 단일 경로로 통합한다.
// 외부 JSON 파일 불러오기 시에는 빈 명단(0명)을 거부하고, 로컬 저장소 복원(allowEmptyRoster=true) 시에는 전원 삭제 후 새로고침해도 학급 제목과 설정이 유지되도록 허용한다.
export function applyLoadedDataToState(targetState, rawParsed, fallbackTitle = '우리 반 자리 배치표', allowEmptyRoster = false) {
  if (!targetState || !rawParsed || typeof rawParsed !== 'object' || Array.isArray(rawParsed)) {
    return false;
  }
  const parsed = migratePayloadSchema(rawParsed);
  if (!parsed || !Array.isArray(parsed.students) || !parsed.pos || typeof parsed.pos !== 'object' || Array.isArray(parsed.pos)) {
    return false;
  }
  const cleanedStudents = sanitizeLoadedStudents(parsed.students);
  if (!allowEmptyRoster && cleanedStudents.length === 0) {
    return false;
  }
  targetState.schemaVersion = CURRENT_SCHEMA_VERSION;
  targetState.classTitle = String(parsed.classTitle || fallbackTitle).trim().slice(0, 40).trim() || fallbackTitle;
  targetState.teacherMessage = typeof parsed.teacherMessage === 'string' ? parsed.teacherMessage.slice(0, 80) : '';
  targetState.viewOrientation = parsed.viewOrientation === 'teacher' ? 'teacher' : 'student';
  targetState.printOrientation = (parsed.printOrientation === 'teacher' || parsed.printOrientation === 'student')
    ? parsed.printOrientation
    : targetState.viewOrientation;
  targetState.hasDeleteGapNotice = false;
  targetState.printIncludeRoster = parsed.printIncludeRoster !== false;
  targetState.printShadeMode = ['zebra', 'female', 'male', 'none'].includes(parsed.printShadeMode) ? parsed.printShadeMode : 'female';
  targetState.showGenderColor = Boolean(parsed.showGenderColor);
  targetState.maskModeEnabled = Boolean(parsed.maskModeEnabled);
  targetState.soundEnabled = parsed.soundEnabled !== false;
  targetState.students = cleanedStudents;

  const validIdSet = new Set(targetState.students.map(s => String(s.id)));
  const cleanPosObj = {};
  Object.keys(parsed.pos).forEach(k => {
    if (validIdSet.has(String(k))) cleanPosObj[String(k)] = parsed.pos[k];
  });
  targetState.pos = cleanPosObj;

  if (parsed.secretPos && typeof parsed.secretPos === 'object' && !Array.isArray(parsed.secretPos)) {
    const cleanSecObj = {};
    Object.keys(parsed.secretPos).forEach(k => {
      if (validIdSet.has(String(k))) cleanSecObj[String(k)] = parsed.secretPos[k];
    });
    targetState.secretPos = cleanSecObj;
  } else {
    targetState.secretPos = null;
  }

  const dedupValidIds = (arr) => [...new Set((Array.isArray(arr) ? arr : []).map(String).filter(id => validIdSet.has(id)))];
  targetState.lockedIds = dedupValidIds(parsed.lockedIds);
  targetState.secretLockedIds = dedupValidIds(parsed.secretLockedIds);

  const rawRules = (parsed.rules && typeof parsed.rules === 'object' && !Array.isArray(parsed.rules)) ? parsed.rules : {};
  const allowedModes = ['any', 'mixed', 'mixed_random', 'same', 'same_random'];
  const safeCols = Math.min(8, Math.max(4, Math.round(Number(rawRules.defaultCols) || 6)));
  const safeMode = allowedModes.includes(rawRules.genderPairMode) ? rawRules.genderPairMode : 'any';

  // 거리두기 쌍 중복 제거 및 유효 ID 검증
  const seenSepKeys = new Set();
  const cleanSeparatedPairs = [];
  (Array.isArray(rawRules.separatedPairs) ? rawRules.separatedPairs : []).forEach(pair => {
    if (!Array.isArray(pair) || pair.length !== 2) return;
    const a = String(pair[0]), b = String(pair[1]);
    if (a === b || !validIdSet.has(a) || !validIdSet.has(b)) return;
    const pairKey = a < b ? `${a}|${b}` : `${b}|${a}`;
    if (seenSepKeys.has(pairKey)) return;
    seenSepKeys.add(pairKey);
    cleanSeparatedPairs.push([a, b]);
  });

  // 친구끼리 붙이기 쌍 정화: 거리두기와 겹치는 쌍을 제외하고, 한 학생이 두 쌍에 중복 참여(체인·스타)하지 않도록 1인 1짝꿍만 허용한다.
  const usedInTogetherIds = new Set();
  const cleanTogetherPairs = [];
  (Array.isArray(rawRules.togetherPairs) ? rawRules.togetherPairs : []).forEach(pair => {
    if (!Array.isArray(pair) || pair.length !== 2) return;
    const a = String(pair[0]), b = String(pair[1]);
    if (a === b || !validIdSet.has(a) || !validIdSet.has(b)) return;
    const pairKey = a < b ? `${a}|${b}` : `${b}|${a}`;
    if (seenSepKeys.has(pairKey)) return;
    if (usedInTogetherIds.has(a) || usedInTogetherIds.has(b)) return;
    usedInTogetherIds.add(a);
    usedInTogetherIds.add(b);
    cleanTogetherPairs.push([a, b]);
  });

  const cleanFrontRowIds = dedupValidIds(rawRules.frontRowIds);
  targetState.rules = {
    defaultCols: safeCols,
    useGenderDistinction: rawRules.useGenderDistinction !== false,
    genderPairMode: safeMode,
    excludePreviousSeat: Boolean(rawRules.excludePreviousSeat),
    frontRowIds: cleanFrontRowIds,
    separatedPairs: cleanSeparatedPairs,
    togetherPairs: cleanTogetherPairs
  };
  if (!targetState.rules.useGenderDistinction && (targetState.printShadeMode === 'female' || targetState.printShadeMode === 'male')) {
    targetState.printShadeMode = 'zebra';
  }
  targetState.printShadeSeatEnabled = parsed.printShadeSeatEnabled !== undefined
    ? Boolean(parsed.printShadeSeatEnabled)
    : !(targetState.rules.useGenderDistinction === false && targetState.printShadeMode === 'zebra');

  if (targetState.maskModeEnabled && Array.isArray(parsed.hiddenSeatIds)) {
    targetState.hiddenSeatIds = dedupValidIds(parsed.hiddenSeatIds);
  } else {
    targetState.hiddenSeatIds = [];
  }
  ensureAllStudentsHaveValidCoords(targetState.students, targetState.pos, safeCols);
  if (targetState.secretPos) {
    ensureAllStudentsHaveValidCoords(targetState.students, targetState.secretPos, safeCols);
  }
  targetState.lastSavedAt = (typeof parsed.lastSavedAt === 'string' && parsed.lastSavedAt.trim()) ? parsed.lastSavedAt.trim() : null;
  return true;
}
