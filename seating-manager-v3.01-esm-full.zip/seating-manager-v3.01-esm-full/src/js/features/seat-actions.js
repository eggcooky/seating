// [L4] 좌석 잠금 토글 · 기본 대형 정렬 · 내 책상 대형 저장/적용/삭제 · 좌석 맞바꾸기 · 빈칸 책상 이동 액션
import { MAX_COLS, MAX_CUSTOM_LAYOUTS, MAX_ROWS } from '../core/constants.js';
import { compareStudentsByNumber } from '../core/utils.js';
import {
  computeCustomLayoutAssignments,
  extractCanonicalCoordsFromPos,
  getNextDefaultLayoutName,
  sanitizeCustomLayoutName
} from '../domain/custom-layouts.js';
import {
  getGridBounds,
  insertGridColAisle,
  insertGridRowAisle,
  removeEmptyGridColAisle,
  removeEmptyGridRowAisle
} from '../domain/grid.js';
import {
  getActivePosMap,
  getStudentById,
  isNormalSeatLocked,
  isSeatHidden,
  isSeatLocked,
  isSecretSeatLocked
} from '../domain/seat-queries.js';
import { playSoundEffect } from '../infra/audio.js';
import { loadCustomLayouts, saveCustomLayouts } from '../infra/storage-io.js';
import { pushUndoSnapshot } from '../state/history-store.js';
import { AppStore } from '../state/store.js';
import { isRouletteBlockingEdit } from '../ui/guards.js';
import { checkSecretRoomLayoutMismatch, updateSecretPresetIndicator } from '../ui/secret-indicators.js';
import { showToast } from '../ui/toast.js';
import { syncRouletteWithCurrentLocks } from './roulette-controller.js';

// 현재 활성화된 화면의 좌석 고정 상태를 토글한다.
export function toggleSeatLock(studentId) {
  const state = AppStore.getState();
  if (!state.inSecretRoom && state.rouletteSpinning) {
    showToast('룰렛이 돌아가는 중에는 자리 고정을 변경할 수 없습니다.', 'warn');
    return;
  }
  const id = String(studentId);
  let nowLocked = false;
  if (state.inSecretRoom) {
    if (isSecretSeatLocked(state, id)) {
      state.secretLockedIds = state.secretLockedIds.filter(x => String(x) !== id);
      nowLocked = false;
    } else {
      state.secretLockedIds.push(id);
      nowLocked = true;
    }
  } else {
    if (isNormalSeatLocked(state, id)) {
      state.lockedIds = state.lockedIds.filter(x => String(x) !== id);
      nowLocked = false;
    } else {
      state.lockedIds.push(id);
      nowLocked = true;
    }
    checkSecretRoomLayoutMismatch(false);
    if (state.rouletteOpen || state.rouletteActiveSession) {
      syncRouletteWithCurrentLocks();
    }
  }
  playSoundEffect(nowLocked ? 'lock' : 'unlock');
  AppStore.commitChange({ classroom: Boolean(state.rouletteOpen), roulette: Boolean(state.rouletteOpen), dirty: true, save: true });
}

// 현재 좌석 순서를 유지한 채 설정된 기본 열 수(4~8열)에 맞춰 책상 격자를 정렬한다.
export function applyDefaultGridAlignment(showNotice = true, locksBefore = null, prevDefaultCols = null) {
  const state = AppStore.getState();
  if (isRouletteBlockingEdit()) return;
  if (state.students.length === 0) return;
  const colsCount = Math.min(8, Math.max(4, Number(state.rules.defaultCols) || 6));
  const snapExtra = {};
  if (locksBefore) snapExtra.locks = locksBefore;
  if (prevDefaultCols !== null && Number.isInteger(Number(prevDefaultCols))) {
    snapExtra.prevDefaultCols = Number(prevDefaultCols);
  }
  pushUndoSnapshot(`기본 대형 정렬 (${colsCount}열)`, Object.keys(snapExtra).length > 0 ? snapExtra : null);
  const activeMap = getActivePosMap(state);
  const totalStudents = state.students.length;
  const rowsPerCol = Math.max(1, Math.ceil(totalStudents / colsCount));

  // 현재 화면의 행·열 순서대로 학생을 정렬하여 순서 섞임 없이 열 폭만 재조정한다.
  const orderedStudents = [...state.students].sort((a, b) => {
    const pA = activeMap[a.id] || [99, 99];
    const pB = activeMap[b.id] || [99, 99];
    if (pA[1] !== pB[1]) return pA[1] - pB[1];
    if (pA[0] !== pB[0]) return pA[0] - pB[0];
    return compareStudentsByNumber(a, b);
  });

  // 잠겨 있는 학생(🔒)은 원래 좌표를 그대로 유지하고, 잠기지 않은 학생만 빈 격자 칸에 순서대로 배치한다.
  const lockedOccupiedKeys = new Set();
  orderedStudents.forEach(st => {
    if (isSeatLocked(state, st.id) && Array.isArray(activeMap[st.id])) {
      const [lc, lr] = activeMap[st.id];
      lockedOccupiedKeys.add(`${lc},${lr}`);
    }
  });

  let slotCursor = 0;
  orderedStudents.forEach(st => {
    if (isSeatLocked(state, st.id) && Array.isArray(activeMap[st.id])) {
      return;
    }
    while (slotCursor < MAX_COLS * MAX_ROWS * 2) {
      const col = Math.min(MAX_COLS - 1, (slotCursor % colsCount) + 1);
      const row = Math.min(MAX_ROWS - 1, Math.floor(slotCursor / colsCount) + 1);
      slotCursor++;
      const key = `${col},${row}`;
      if (!lockedOccupiedKeys.has(key)) {
        lockedOccupiedKeys.add(key);
        activeMap[st.id] = [col, row];
        break;
      }
    }
  });
  state.selectedStudentId = null;
  state.hasDeleteGapNotice = false;
  updateSecretPresetIndicator();
  if (!state.inSecretRoom && state.rouletteOpen) {
    syncRouletteWithCurrentLocks();
  }
  AppStore.commitChange({ classroom: true, animate: true, print: true, roulette: Boolean(!state.inSecretRoom && state.rouletteOpen), dirty: true, save: true });
  if (showNotice) {
    showToast(`현재 자리 순서를 유지한 채 ${colsCount}열(${rowsPerCol}행) 대형으로 즉시 반영되었습니다.`, 'info');
  }
  if (state.inSecretRoom) checkSecretRoomLayoutMismatch(true);
}

// 현재 화면에 배치된 책상들의 좌표 형상만 추출해 사용자 책상 대형 목록(최대 6개, 1~7반 공용)에 저장한다.
export function saveCurrentCustomLayout(rawName = '', showNotice = true) {
  const state = AppStore.getState();
  if (isRouletteBlockingEdit()) return { ok: false, reason: 'roulette' };
  if (state.students.length === 0) {
    if (showNotice) showToast('저장할 책상이 없습니다. 먼저 학생 명단을 등록해 주세요.', 'warn');
    return { ok: false, reason: 'empty' };
  }
  const activeMap = getActivePosMap(state);
  const coords = extractCanonicalCoordsFromPos(state.students, activeMap);
  if (coords.length === 0) {
    if (showNotice) showToast('저장할 유효한 책상 좌표를 찾지 못했습니다.', 'warn');
    return { ok: false, reason: 'no_coords' };
  }
  const existing = loadCustomLayouts();
  if (existing.length >= MAX_CUSTOM_LAYOUTS) {
    if (showNotice) {
      showToast(`내 책상 대형은 최대 ${MAX_CUSTOM_LAYOUTS}개까지 저장할 수 있습니다. 기존 대형을 삭제한 뒤 저장해 주세요.`, 'warn');
    }
    return { ok: false, reason: 'limit', layouts: existing };
  }
  const fallbackName = getNextDefaultLayoutName(existing);
  const cleanName = sanitizeCustomLayoutName(rawName, fallbackName) || fallbackName;
  const entry = {
    id: `cl_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
    name: cleanName,
    coords,
    createdAt: Date.now()
  };
  const saved = saveCustomLayouts([...existing, entry]);
  if (showNotice) {
    if (saved.ok) {
      showToast(`'${cleanName}' 책상 대형(${coords.length}석)이 저장되었습니다.`, 'success');
    } else {
      showToast(`'${cleanName}' 책상 대형이 임시 세션에 저장되었습니다. (파일 저장으로 백업을 권장합니다)`, 'warn');
    }
  }
  return { ok: true, entry, layouts: saved.layouts };
}

// 저장된 사용자 책상 대형의 이름을 변경한다 (좌표·순서·ID는 그대로 보존).
export function renameCustomLayoutById(layoutId, rawNewName, showNotice = true) {
  const targetId = String(layoutId || '');
  const existing = loadCustomLayouts();
  const idx = existing.findIndex(item => item.id === targetId);
  if (idx === -1) return { ok: false, reason: 'not_found', layouts: existing };
  const cleanName = sanitizeCustomLayoutName(rawNewName, '');
  if (!cleanName) {
    if (showNotice) showToast('변경할 책상 대형 이름을 입력해 주세요.', 'warn');
    return { ok: false, reason: 'empty', layouts: existing };
  }
  const prevName = existing[idx].name;
  if (cleanName === prevName) {
    return { ok: true, unchanged: true, entry: existing[idx], layouts: existing };
  }
  const nextList = existing.map((item, i) => (i === idx ? { ...item, name: cleanName } : item));
  const saved = saveCustomLayouts(nextList);
  if (showNotice) {
    showToast(`'${prevName}' → '${cleanName}'(으)로 이름이 변경되었습니다.`, 'success');
  }
  return { ok: true, entry: saved.layouts[idx] || nextList[idx], layouts: saved.layouts };
}

// 저장된 사용자 책상 대형을 ID 기준으로 삭제한다.
export function deleteCustomLayoutById(layoutId, showNotice = true) {
  const targetId = String(layoutId || '');
  const existing = loadCustomLayouts();
  const target = existing.find(item => item.id === targetId);
  if (!target) return { ok: false, layouts: existing };
  const nextList = existing.filter(item => item.id !== targetId);
  const saved = saveCustomLayouts(nextList);
  if (showNotice) {
    showToast(`'${target.name}' 책상 대형이 삭제되었습니다.`, 'info');
  }
  return { ok: true, deleted: target, layouts: saved.layouts };
}

// 저장해 둔 사용자 책상 대형 좌표 틀을 현재 학급에 적용한다 (고정석 유지 · Ctrl+Z 되돌리기 · 인원 변동 보정).
export function applyCustomLayoutById(layoutId, showNotice = true, locksBefore = null) {
  const state = AppStore.getState();
  if (isRouletteBlockingEdit()) return false;
  if (state.students.length === 0) {
    if (showNotice) showToast('대형을 적용할 학생이 없습니다.', 'warn');
    return false;
  }
  const existing = loadCustomLayouts();
  const target = existing.find(item => item.id === String(layoutId || ''));
  if (!target) {
    if (showNotice) showToast('선택한 책상 대형을 찾을 수 없습니다.', 'warn');
    return false;
  }

  const snapExtra = locksBefore ? { locks: locksBefore } : null;
  pushUndoSnapshot(`내 책상 대형 적용 (${target.name})`, snapExtra);

  const activeMap = getActivePosMap(state);
  const { posMap, overflowCount, unusedSlotCount } = computeCustomLayoutAssignments(
    state.students,
    activeMap,
    target.coords,
    (sid) => isSeatLocked(state, sid),
    state.rules.defaultCols
  );

  state.students.forEach(st => {
    if (Array.isArray(posMap[st.id])) {
      activeMap[st.id] = [posMap[st.id][0], posMap[st.id][1]];
    }
  });

  state.selectedStudentId = null;
  state.hasDeleteGapNotice = false;
  updateSecretPresetIndicator();
  if (!state.inSecretRoom && state.rouletteOpen) {
    syncRouletteWithCurrentLocks();
  }
  AppStore.commitChange({
    classroom: true,
    animate: true,
    print: true,
    roulette: Boolean(!state.inSecretRoom && state.rouletteOpen),
    dirty: true,
    save: true
  });

  if (showNotice) {
    if (overflowCount > 0) {
      showToast(`'${target.name}' 대형을 적용했습니다. (초과 ${overflowCount}명은 인접 빈칸에 자동 배치됨)`, 'info');
    } else if (unusedSlotCount > 0) {
      showToast(`'${target.name}' 대형을 적용했습니다. (현재 ${state.students.length}명 배치)`, 'info');
    } else {
      showToast(`'${target.name}' 책상 대형(${state.students.length}석)이 즉시 적용되었습니다.`, 'success');
    }
  }
  if (state.inSecretRoom) checkSecretRoomLayoutMismatch(true);
  return true;
}

export function handleStudentPick(studentId) {
  const state = AppStore.getState();
  if (isRouletteBlockingEdit()) return;
  const id = String(studentId);
  if (!state.inSecretRoom && isSeatHidden(state, id)) {
    showToast('현재 자리가 가려져 있습니다. 책상을 직접 클릭해 이름을 먼저 공개해 주세요.', 'info');
    return;
  }
  const activeMap = getActivePosMap(state);

  if (state.selectedStudentId === null) {
    if (!getStudentById(state, id) || !Array.isArray(activeMap[id])) return;
    state.selectedStudentId = id;
    playSoundEffect('select');
  } else if (String(state.selectedStudentId) === id) {
    state.selectedStudentId = null;
    playSoundEffect('unlock');
  } else {
    const firstId = String(state.selectedStudentId);
    const firstSt = getStudentById(state, firstId);
    const secondSt = getStudentById(state, id);
    if (!firstSt || !secondSt || !Array.isArray(activeMap[firstId]) || !Array.isArray(activeMap[id])) {
      state.selectedStudentId = null;
      AppStore.requestRosterAndClassroomRender(false);
      return;
    }

    const swappedLockedIds = [firstId, id].filter(sid => isSeatLocked(state, sid));
    pushUndoSnapshot(
      `${firstSt.name} ↔ ${secondSt.name} 자리 맞바꾸기`,
      swappedLockedIds.length > 0 ? { overwrittenLockIds: swappedLockedIds } : null
    );
    const tempCoord = activeMap[firstId];
    activeMap[firstId] = activeMap[id];
    activeMap[id] = tempCoord;

    state.selectedStudentId = null;
    playSoundEffect('swap');
    AppStore.commitChange({ roster: true, classroom: true, animate: true, print: true, dirty: true, save: true });

    if (firstSt && secondSt) {
      showToast(
        state.inSecretRoom
          ? `[비밀의 방] ${firstSt.name} ↔ ${secondSt.name} 목표 자리가 설정되었습니다.`
          : `${firstSt.name} ↔ ${secondSt.name} 자리가 변경되었습니다.`,
        state.inSecretRoom ? 'secret' : 'info'
      );
    }
    if (state.inSecretRoom) checkSecretRoomLayoutMismatch(true);
    return;
  }
  AppStore.requestRosterAndClassroomRender(false);
}

export function handleEmptySlotClick(col, row) {
  const state = AppStore.getState();
  if (isRouletteBlockingEdit()) return;
  if (state.selectedStudentId === null) {
    showToast('먼저 이동할 학생의 책상(또는 왼쪽 번호)을 클릭해 선택하세요.', 'info');
    return;
  }
  const activeMap = getActivePosMap(state);
  const targetCol = Math.min(MAX_COLS - 1, Math.max(0, Math.round(Number(col) || 0)));
  const targetRow = Math.min(MAX_ROWS - 1, Math.max(0, Math.round(Number(row) || 0)));
  const alreadyOccupied = state.students.some(s => {
    const p = activeMap[s.id];
    return Array.isArray(p) && p[0] === targetCol && p[1] === targetRow;
  });
  if (alreadyOccupied) return;
  col = targetCol;
  row = targetRow;
  const st = getStudentById(state, state.selectedStudentId);
  if (!st) {
    state.selectedStudentId = null;
    AppStore.requestRosterAndClassroomRender(false);
    return;
  }
  const { c0, r0 } = getGridBounds(state.students, activeMap, false);
  const visCol = Math.max(1, col - c0 + 1);
  const visRow = Math.max(1, row - r0 + 1);
  const pickedIdStr = String(state.selectedStudentId);
  const movedLockedIds = isSeatLocked(state, pickedIdStr) ? [pickedIdStr] : [];
  pushUndoSnapshot(
    `${st ? st.name : '학생'} 책상 위치 이동 (${visCol}열 ${visRow}행)`,
    movedLockedIds.length > 0 ? { overwrittenLockIds: movedLockedIds } : null
  );
  activeMap[state.selectedStudentId] = [col, row];
  state.selectedStudentId = null;
  playSoundEffect('swap');
  AppStore.commitChange({ roster: true, classroom: true, animate: true, print: true, dirty: true, save: true });
  showToast(`${st ? st.name : '선택한'} 책상이 새 위치로 이동되었습니다.`, 'success');
  if (state.inSecretRoom) checkSecretRoomLayoutMismatch(true);
}

// 통로 벌리기(＋) · 빈 통로 좁히기(−) 공통 적용 헬퍼 (고정석 동반 이동 시 overwrittenLockIds를 기록해 Ctrl+Z 원복을 보장)
function commitAisleAdjustment(res, undoLabel, toastMessage, toastTone = 'info') {
  const state = AppStore.getState();
  if (!res || !res.ok) {
    if (res && res.reason === 'max_cols') {
      showToast(`최대 ${MAX_COLS}열까지 확장할 수 있습니다.`, 'warn');
    } else if (res && res.reason === 'max_rows') {
      showToast(`최대 ${MAX_ROWS}행까지 확장할 수 있습니다.`, 'warn');
    } else if (res && res.reason === 'occupied') {
      showToast('학생이 앉아 있는 줄은 좁힐 수 없습니다.', 'warn');
    }
    return false;
  }

  const activeMap = getActivePosMap(state);
  const movedLockedIds = (res.movedIds || []).filter(id => isSeatLocked(state, id));
  pushUndoSnapshot(
    undoLabel,
    movedLockedIds.length > 0 ? { overwrittenLockIds: movedLockedIds } : null
  );

  state.students.forEach(st => {
    if (Array.isArray(res.nextPos[st.id])) {
      activeMap[st.id] = [res.nextPos[st.id][0], res.nextPos[st.id][1]];
    }
  });

  checkSecretRoomLayoutMismatch(Boolean(state.inSecretRoom));
  if (!state.inSecretRoom && state.rouletteOpen) {
    syncRouletteWithCurrentLocks();
  }
  playSoundEffect('swap');
  AppStore.commitChange({
    classroom: true,
    animate: false,
    print: true,
    roulette: Boolean(!state.inSecretRoom && state.rouletteOpen),
    dirty: true,
    save: true
  });
  showToast(toastMessage, toastTone);
  return true;
}

export function handleInsertColAisle(splitCol) {
  const state = AppStore.getState();
  if (isRouletteBlockingEdit() || state.students.length === 0) return false;
  const activeMap = getActivePosMap(state);
  const res = insertGridColAisle(state.students, activeMap, splitCol);
  return commitAisleAdjustment(res, '세로 통로 벌리기', '세로 통로를 한 칸 벌렸습니다.', 'success');
}

export function handleRemoveEmptyColAisle(emptyCol) {
  const state = AppStore.getState();
  if (isRouletteBlockingEdit() || state.students.length === 0) return false;
  const activeMap = getActivePosMap(state);
  const res = removeEmptyGridColAisle(state.students, activeMap, emptyCol);
  return commitAisleAdjustment(res, '빈 세로 통로 좁히기', '빈 세로 통로를 좁혔습니다.', 'info');
}

export function handleInsertRowAisle(splitRow) {
  const state = AppStore.getState();
  if (isRouletteBlockingEdit() || state.students.length === 0) return false;
  const activeMap = getActivePosMap(state);
  const res = insertGridRowAisle(state.students, activeMap, splitRow);
  return commitAisleAdjustment(res, '가로 통로 벌리기', '가로 통로를 한 줄 벌렸습니다.', 'success');
}

export function handleRemoveEmptyRowAisle(emptyRow) {
  const state = AppStore.getState();
  if (isRouletteBlockingEdit() || state.students.length === 0) return false;
  const activeMap = getActivePosMap(state);
  const res = removeEmptyGridRowAisle(state.students, activeMap, emptyRow);
  return commitAisleAdjustment(res, '빈 가로 통로 좁히기', '빈 가로 통로를 좁혔습니다.', 'info');
}
