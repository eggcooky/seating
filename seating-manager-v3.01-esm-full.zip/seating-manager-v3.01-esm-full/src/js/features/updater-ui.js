// [L4] 프로그램 업데이트 확인, 파일 손상 경고 모달 및 복구 다운로드 UI 컨트롤러
import {
  APP_VERSION,
  PROGRAM_URL,
  UPDATE_CHECK_INTERVAL_MS,
  VERSION_URL
} from '../core/constants.js';
import {
  compareVersions,
  computeSha256HexSync,
  resolveExpectedPkgSha256,
  validateDownloadedHtml,
  verifyDownloadedHtmlSha256,
  verifyRuntimePkgIntegrity as verifyRuntimePkgIntegrityPure
} from '../domain/updater-core.js';
import { showToast } from '../ui/toast.js';

let latestRemoteVersionInfo = null;
let lastUpdateCheckTimestamp = 0;
let isCheckingUpdate = false;
let isCheckingOrDownloadingUpdate = false;
let cachedRuntimePkgSha256 = '';

// 업데이트 모달 하단 상태 안내 상자에 평문(textContent)으로만 메시지를 표시한다.
export function setUpdateModalStatus(message, tone = 'info') {
  const box = document.getElementById('updateModalStatusBox');
  if (!box) return;
  if (!message) {
    box.className = 'hidden mt-3 px-3.5 py-2.5 rounded-xl text-xs font-bold border';
    box.textContent = '';
    return;
  }
  const toneClassMap = {
    info: 'mt-3 px-3.5 py-2.5 rounded-xl text-xs font-bold border bg-indigo-50 text-indigo-800 border-indigo-200',
    success: 'mt-3 px-3.5 py-2.5 rounded-xl text-xs font-bold border bg-emerald-50 text-emerald-800 border-emerald-200',
    warn: 'mt-3 px-3.5 py-2.5 rounded-xl text-xs font-bold border bg-amber-50 text-amber-900 border-amber-300',
    error: 'mt-3 px-3.5 py-2.5 rounded-xl text-xs font-bold border bg-rose-50 text-rose-600 border-rose-200'
  };
  box.className = toneClassMap[tone] || toneClassMap.info;
  box.textContent = message;
}

// 새 버전 정보를 업데이트 모달에 채우고 모달을 연다.
// 외부 JSON 데이터에 의한 XSS(스크립트 삽입)를 원천 차단하기 위해 모든 항목은 textContent로만 주입한다.
export function openAppUpdateModal() {
  if (!latestRemoteVersionInfo) return;
  const modal = document.getElementById('appUpdateModal');
  const curVerEl = document.getElementById('updateCurrentVerText');
  const latestVerEl = document.getElementById('updateLatestVerText');
  const dateEl = document.getElementById('updateReleaseDateText');
  const notesListEl = document.getElementById('updateNotesList');

  if (curVerEl) curVerEl.textContent = 'v' + APP_VERSION;
  if (latestVerEl) latestVerEl.textContent = 'v' + String(latestRemoteVersionInfo.version || '').replace(/^v/i, '');
  if (dateEl) {
    dateEl.textContent = latestRemoteVersionInfo.date ? ('배포일: ' + String(latestRemoteVersionInfo.date)) : '';
  }
  if (notesListEl) {
    while (notesListEl.firstChild) {
      notesListEl.removeChild(notesListEl.firstChild);
    }
    const notes = Array.isArray(latestRemoteVersionInfo.notes) ? latestRemoteVersionInfo.notes : [];
    if (notes.length === 0) {
      const li = document.createElement('li');
      li.textContent = '최신 안정화 및 기능 개선 업데이트가 포함되었습니다.';
      notesListEl.appendChild(li);
    } else {
      notes.forEach(noteItem => {
        const li = document.createElement('li');
        li.textContent = String(noteItem);
        notesListEl.appendChild(li);
      });
    }
  }

  const downloadBtn = document.getElementById('downloadLatestProgramBtn');
  if (downloadBtn && !isCheckingOrDownloadingUpdate) {
    downloadBtn.disabled = false;
  }
  if (latestRemoteVersionInfo.isTampered) {
    setUpdateModalStatus('파일이 손상되었습니다. 아래 버튼으로 정상 배포본을 저장한 뒤 다시 실행해 주세요.', 'warn');
  } else {
    setUpdateModalStatus('');
  }
  if (modal) {
    modal.classList.remove('hidden');
    modal.classList.add('flex');
  }
}

export function getRuntimePkgSha256() {
  if (cachedRuntimePkgSha256) return cachedRuntimePkgSha256;
  if (typeof document !== 'undefined' && document.documentElement && typeof document.documentElement.__pkgB64 === 'string') {
    const rawB64 = document.documentElement.__pkgB64.trim();
    try { delete document.documentElement.__pkgB64; } catch (_) {}
    if (rawB64) {
      cachedRuntimePkgSha256 = computeSha256HexSync(rawB64);
    }
  }
  return cachedRuntimePkgSha256;
}

export function verifyRuntimePkgIntegrity(expectedPkgSha256, actualPkgSha256 = getRuntimePkgSha256()) {
  return verifyRuntimePkgIntegrityPure(expectedPkgSha256, actualPkgSha256);
}

function showTamperWarningModal() {
  const modal = document.getElementById('tamperWarningModal');
  if (modal) {
    modal.classList.remove('hidden');
    modal.classList.add('flex');
  }
}

export function closeTamperWarningModal() {
  const modal = document.getElementById('tamperWarningModal');
  if (modal) {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
  }
}

function activateTamperRecoveryUI(remoteInfo, showWarningModal = true) {
  latestRemoteVersionInfo = {
    version: remoteInfo.version || APP_VERSION,
    date: remoteInfo.date || '',
    notes: Array.isArray(remoteInfo.notes) && remoteInfo.notes.length > 0
      ? remoteInfo.notes
      : ['파일 손상이 감지되어 정상 배포본으로 복구 업데이트가 필요합니다.'],
    sha256: remoteInfo.sha256 || '',
    pkgSha256: remoteInfo.pkgSha256 || '',
    isTampered: true
  };
  const updateBtn = document.getElementById('openAppUpdateModalBtn');
  const updateBtnText = document.getElementById('openAppUpdateBtnText');
  const footerDot = document.getElementById('appVersionUpdateDot');
  const downloadBtn = document.getElementById('downloadLatestProgramBtn');
  if (updateBtn) {
    updateBtn.disabled = false;
    updateBtn.classList.remove('hidden');
    updateBtn.classList.add('flex');
  }
  if (updateBtnText) {
    updateBtnText.textContent = '파일 복구 업데이트 (v' + latestRemoteVersionInfo.version + ')';
  }
  if (footerDot) {
    footerDot.classList.remove('hidden');
  }
  if (downloadBtn) {
    downloadBtn.disabled = false;
  }
  if (showWarningModal) {
    showTamperWarningModal();
  }
}

export function closeAppUpdateModal() {
  const modal = document.getElementById('appUpdateModal');
  if (modal) {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
  }
}

// 원격 version.json을 조회하여 현재 버전(APP_VERSION)보다 높은 신규 버전이 있는지 확인한다.
export async function checkForAppUpdate(isManual = false) {
  if (typeof fetch === 'undefined' || isCheckingUpdate || isCheckingOrDownloadingUpdate) return;
  const now = Date.now();
  if (!isManual && lastUpdateCheckTimestamp > 0 && (now - lastUpdateCheckTimestamp) < UPDATE_CHECK_INTERVAL_MS) {
    return;
  }
  isCheckingUpdate = true;

  const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timeoutId = controller ? setTimeout(() => controller.abort(), 5000) : null;

  try {
    const url = VERSION_URL + '?t=' + now;
    const response = await fetch(url, {
      method: 'GET',
      cache: 'no-store',
      signal: controller ? controller.signal : undefined
    });
    if (!response.ok) {
      if (timeoutId) clearTimeout(timeoutId);
      throw new Error('HTTP ' + response.status);
    }
    const data = await response.json();
    if (timeoutId) clearTimeout(timeoutId);
    if (!data || typeof data.version !== 'string') {
      throw new Error('Invalid version.json');
    }
    lastUpdateCheckTimestamp = now;

    const remoteVer = data.version.trim().replace(/^v/i, '');
    const verCmp = compareVersions(remoteVer, APP_VERSION);
    const isNewer = verCmp > 0;
    const remoteDate = typeof data.date === 'string'
      ? data.date
      : (typeof data.releaseDate === 'string' ? data.releaseDate : (typeof data.releasedAt === 'string' ? data.releasedAt : ''));
    const remoteNotes = Array.isArray(data.notes)
      ? data.notes
      : (typeof data.notes === 'string' && data.notes.trim() ? [data.notes.trim()] : []);
    const remoteSha256 = typeof data.sha256 === 'string' ? data.sha256.trim().toLowerCase() : '';
    const remotePkgSha256 = typeof data.pkgSha256 === 'string' ? data.pkgSha256.trim().toLowerCase() : '';
    const expectedCurrentPkgSha = resolveExpectedPkgSha256(data, APP_VERSION);
    const isRuntimeTampered = Boolean(expectedCurrentPkgSha) && !verifyRuntimePkgIntegrity(expectedCurrentPkgSha);

    const updateBtn = document.getElementById('openAppUpdateModalBtn');
    const updateBtnText = document.getElementById('openAppUpdateBtnText');
    const footerDot = document.getElementById('appVersionUpdateDot');

    if (isRuntimeTampered) {
      activateTamperRecoveryUI({
        version: remoteVer,
        date: remoteDate,
        notes: remoteNotes,
        sha256: remoteSha256,
        pkgSha256: remotePkgSha256
      }, true);
    } else if (isNewer) {
      latestRemoteVersionInfo = {
        version: remoteVer,
        date: remoteDate,
        notes: remoteNotes,
        sha256: remoteSha256,
        pkgSha256: remotePkgSha256,
        isTampered: false
      };
      if (updateBtn) {
        updateBtn.disabled = false;
        updateBtn.classList.remove('hidden');
        updateBtn.classList.add('flex');
      }
      if (updateBtnText) {
        updateBtnText.textContent = '새버전 업데이트 (v' + remoteVer + ')';
      }
      if (footerDot) {
        footerDot.classList.remove('hidden');
      }
      if (isManual) {
        openAppUpdateModal();
      }
    } else {
      latestRemoteVersionInfo = null;
      if (updateBtn) {
        updateBtn.classList.add('hidden');
        updateBtn.classList.remove('flex');
      }
      if (footerDot) {
        footerDot.classList.add('hidden');
      }
      if (isManual) {
        showToast('현재 최신 버전(v' + APP_VERSION + ')을 사용 중입니다.', 'success');
      }
    }
  } catch (err) {
    if (timeoutId) clearTimeout(timeoutId);
    if (isManual) {
      showToast('확인하지 못했어요(오프라인일 수 있어요)', 'warn');
    }
  } finally {
    isCheckingUpdate = false;
  }
}

export async function downloadAndSaveLatestProgram() {
  if (isCheckingOrDownloadingUpdate || !latestRemoteVersionInfo) return;
  const targetInfo = { ...latestRemoteVersionInfo };
  isCheckingOrDownloadingUpdate = true;
  const downloadBtn = document.getElementById('downloadLatestProgramBtn');
  if (downloadBtn) downloadBtn.disabled = true;
  setUpdateModalStatus('최신 버전 파일을 내려받아 검증하고 있습니다...', 'info');

  const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timeoutId = controller ? setTimeout(() => controller.abort(), 15000) : null;

  try {
    const url = PROGRAM_URL + '?t=' + Date.now();
    const response = await fetch(url, {
      method: 'GET',
      cache: 'no-store',
      signal: controller ? controller.signal : undefined
    });
    const htmlText = response.ok ? await response.text() : '';
    if (timeoutId) clearTimeout(timeoutId);
    const isValid = validateDownloadedHtml(htmlText, targetInfo.version, response.ok);
    if (!isValid) {
      setUpdateModalStatus('받은 파일이 올바르지 않아요', 'error');
      showToast('받은 파일이 올바르지 않아요', 'warn');
      return;
    }
    const shaOk = await verifyDownloadedHtmlSha256(htmlText, targetInfo.sha256);
    if (!shaOk) {
      setUpdateModalStatus('받은 파일의 무결성(SHA-256) 검증에 실패했어요', 'error');
      showToast('받은 파일의 무결성(SHA-256) 검증에 실패했어요', 'warn');
      return;
    }

    const rawCleanVer = String(targetInfo.version || APP_VERSION).trim().replace(/^v/i, '').replace(/[^0-9A-Za-z._-]/g, '');
    const cleanVer = rawCleanVer || APP_VERSION;
    const targetFileName = `자리바꾸기(v${cleanVer}).html`;

    let savedViaPicker = false;
    if (typeof window.showSaveFilePicker === 'function') {
      try {
        const fileHandle = await window.showSaveFilePicker({
          suggestedName: targetFileName,
          types: [{
            description: 'HTML',
            accept: { 'text/html': ['.html'] }
          }]
        });
        const writable = await fileHandle.createWritable();
        await writable.write(htmlText);
        await writable.close();
        savedViaPicker = true;
        const savedName = (fileHandle && fileHandle.name) ? fileHandle.name : targetFileName;
        setUpdateModalStatus(`저장 완료! 방금 저장한 파일(${savedName})을 열어 실행해 주세요.`, 'success');
        showToast(`저장 완료! 방금 저장한 파일(${savedName})을 열어 실행해 주세요.`, 'success');
      } catch (pickerErr) {
        if (pickerErr && pickerErr.name === 'AbortError') {
          setUpdateModalStatus('파일 저장이 취소되었습니다. 다시 받으려면 [최신 버전 받기]를 눌러 주세요.', 'warn');
          return;
        }
        savedViaPicker = false;
      }
    }
    if (!savedViaPicker) {
      const blob = new Blob([htmlText], { type: 'text/html;charset=utf-8' });
      const blobUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = targetFileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(blobUrl), 1500);
      setUpdateModalStatus('이름 뒤에 (1)이 붙으면 기존 파일을 지우고 이름을 바꿔 주세요', 'warn');
      showToast('이름 뒤에 (1)이 붙으면 기존 파일을 지우고 이름을 바꿔 주세요', 'info');
    }
  } catch (err) {
    if (timeoutId) clearTimeout(timeoutId);
    setUpdateModalStatus('확인하지 못했어요(오프라인일 수 있어요)', 'error');
    showToast('확인하지 못했어요(오프라인일 수 있어요)', 'warn');
  } finally {
    isCheckingOrDownloadingUpdate = false;
    if (downloadBtn) downloadBtn.disabled = false;
  }
}

export function hasRemoteUpdateInfo() {
  return Boolean(latestRemoteVersionInfo);
}
