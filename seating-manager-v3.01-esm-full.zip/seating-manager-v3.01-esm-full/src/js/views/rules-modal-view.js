// [L4] 배치 조건 및 거리두기·짝꿍 모달 UI 렌더링 및 규칙 추가 (모달 열기/취소/적용 트랜잭션은 L5 rules-coordinator.js)
import { escapeHtml, formatStudentNumLabel } from '../core/utils.js';
import { canRegisterPairRule } from '../domain/algorithm-engine.js';
import { getGridBounds } from '../domain/grid.js';
import { getActivePosMap, getStudentById, isSeatLocked } from '../domain/seat-queries.js';
import { AppStore } from '../state/store.js';
import { showSecretNoticePopup } from '../ui/secret-indicators.js';
import { showToast } from '../ui/toast.js';

export function updateRulesUI() {
  const state = AppStore.getState();
  const useGender = state.rules.useGenderDistinction !== false;
  const pairBtns = document.querySelectorAll('.pair-rule-btn');
  pairBtns.forEach(btn => {
    const ruleVal = btn.getAttribute('data-pair-rule');
    const spanClass = ruleVal === 'any' ? 'row-span-2 py-2.5 gap-1' : 'py-2 gap-0.5';
    btn.disabled = !useGender;
    btn.setAttribute('aria-disabled', String(!useGender));
    if (ruleVal === state.rules.genderPairMode) {
      btn.className = `pair-rule-btn ${spanClass} px-3 rounded-xl text-xs font-bold border transition flex flex-col items-center justify-center bg-indigo-600 text-white border-indigo-600 shadow-sm`;
    } else {
      btn.className = `pair-rule-btn ${spanClass} px-3 rounded-xl text-xs font-bold border transition flex flex-col items-center justify-center bg-white text-slate-700 border-slate-200 hover:bg-slate-100`;
    }
  });

  const formatGenderSuffix = (g) => useGender ? ` (${escapeHtml(g)})` : '';

  const selA = document.getElementById('sepStudentA');
  const selB = document.getElementById('sepStudentB');
  if (selA && selB) {
    const prevA = selA.value;
    const prevB = selB.value;
    const optionsHtml = state.students
      .map(s => `<option value="${escapeHtml(s.id)}">${escapeHtml(formatStudentNumLabel(s))} ${escapeHtml(s.name)}${formatGenderSuffix(s.gender)}</option>`)
      .join('');
    selA.innerHTML = optionsHtml;
    selB.innerHTML = optionsHtml;
    if (prevA && state.students.some(s => String(s.id) === String(prevA))) {
      selA.value = prevA;
    }
    if (prevB && state.students.some(s => String(s.id) === String(prevB))) {
      selB.value = prevB;
    } else if (state.students.length > 1) {
      selB.value = String(state.students[1].id);
    }
  }

  const listContainer = document.getElementById('separationListContainer');
  if (listContainer) {
    listContainer.innerHTML = '';
    if (!state.rules.separatedPairs.length) {
      listContainer.innerHTML = `<div class="text-[11px] text-slate-400 py-2 text-center">등록된 거리두기 학생 쌍이 없습니다.</div>`;
    } else {
      state.rules.separatedPairs.forEach((pair, idx) => {
        const stA = getStudentById(state, pair[0]);
        const stB = getStudentById(state, pair[1]);
        if (!stA || !stB) return;
        const item = document.createElement('div');
        item.className = 'flex items-center justify-between bg-white px-3 py-2 rounded-xl border border-slate-200 text-xs';
        item.innerHTML = `
          <div class="flex items-center gap-2 font-semibold text-slate-700">
            <span class="px-2 py-0.5 rounded bg-rose-50 text-rose-600 text-[10px] font-bold">분리 ${idx + 1}</span>
            <span>${escapeHtml(formatStudentNumLabel(stA))} ${escapeHtml(stA.name)}</span>
            <span class="text-slate-400">↔</span>
            <span>${escapeHtml(formatStudentNumLabel(stB))} ${escapeHtml(stB.name)}</span>
          </div>
          <button type="button" data-remove-sep="${idx}" class="text-slate-400 hover:text-rose-600 font-bold px-1.5">삭제</button>
        `;
        item.querySelector('[data-remove-sep]').addEventListener('click', () => {
          AppStore.getState().rules.separatedPairs.splice(idx, 1);
          AppStore.commitChange({ rules: true, dirty: true, save: true });
        });
        listContainer.appendChild(item);
      });
    }
  }

  const modalGenderToggle = document.getElementById('modalGenderDistinctionToggle');
  if (modalGenderToggle) {
    modalGenderToggle.checked = useGender;
  }
  const pairSection = document.getElementById('genderPairRuleSection');
  if (pairSection) {
    if (useGender) {
      pairSection.classList.remove('opacity-40', 'pointer-events-none');
    } else {
      pairSection.classList.add('opacity-40', 'pointer-events-none');
    }
  }

  const excludeToggle = document.getElementById('excludePrevSeatToggle');
  if (excludeToggle) {
    excludeToggle.checked = Boolean(state.rules.excludePreviousSeat);
  }

  if (!Array.isArray(state.rules.frontRowIds)) state.rules.frontRowIds = [];
  const frontSelectedSet = new Set(state.rules.frontRowIds.map(String));
  const frontSelect = document.getElementById('frontRowStudentSelect');
  if (frontSelect) {
    const prevFrontVal = frontSelect.value;
    frontSelect.innerHTML = state.students
      .map(s => {
        const isAlreadyFront = frontSelectedSet.has(String(s.id));
        if (isAlreadyFront) {
          return `<option value="${escapeHtml(s.id)}" data-front-selected="true" class="bg-amber-100 text-amber-900 font-bold" style="background-color: #fef3c7; color: #92400e; font-weight: 700;">✓ [지정됨] ${escapeHtml(formatStudentNumLabel(s))} ${escapeHtml(s.name)}${formatGenderSuffix(s.gender)}</option>`;
        }
        return `<option value="${escapeHtml(s.id)}">${escapeHtml(formatStudentNumLabel(s))} ${escapeHtml(s.name)}${formatGenderSuffix(s.gender)}</option>`;
      })
      .join('');
    if (prevFrontVal && state.students.some(s => String(s.id) === String(prevFrontVal))) {
      frontSelect.value = prevFrontVal;
    }
  }

  const frontListContainer = document.getElementById('frontRowListContainer');
  if (frontListContainer) {
    frontListContainer.innerHTML = '';
    if (!state.rules.frontRowIds.length) {
      frontListContainer.innerHTML = `<div class="text-[11px] text-slate-400 py-1.5 text-center">등록된 앞줄 우선 배정 학생이 없습니다.</div>`;
    } else {
      state.rules.frontRowIds.forEach((fId, idx) => {
        const st = getStudentById(state, fId);
        if (!st) return;
        const item = document.createElement('div');
        item.className = 'flex items-center justify-between bg-white px-3 py-1.5 rounded-xl border border-slate-200 text-xs';
        item.innerHTML = `
          <div class="flex items-center gap-2 font-semibold text-slate-700">
            <span class="px-2 py-0.5 rounded bg-amber-100 text-amber-800 text-[10px] font-bold">👓 앞줄 ${idx + 1}</span>
            <span>${escapeHtml(formatStudentNumLabel(st))} ${escapeHtml(st.name)}${formatGenderSuffix(st.gender)}</span>
          </div>
          <button type="button" data-remove-front="${idx}" class="text-slate-400 hover:text-rose-600 font-bold px-1.5">삭제</button>
        `;
        item.querySelector('[data-remove-front]').addEventListener('click', () => {
          AppStore.getState().rules.frontRowIds.splice(idx, 1);
          AppStore.commitChange({ rules: true, dirty: true, save: true });
        });
        frontListContainer.appendChild(item);
      });
    }
  }

  const hasActiveGeneralRule = (useGender && state.rules.genderPairMode !== 'any') || Boolean(state.rules.excludePreviousSeat) || (state.rules.frontRowIds && state.rules.frontRowIds.length > 0);
  const activeBadge = document.getElementById('activeRulesBadge');
  if (activeBadge) {
    if (hasActiveGeneralRule) {
      activeBadge.classList.remove('hidden');
    } else {
      activeBadge.classList.add('hidden');
    }
  }

  const togA = document.getElementById('togStudentA');
  const togB = document.getElementById('togStudentB');
  if (togA && togB) {
    const prevTA = togA.value;
    const prevTB = togB.value;
    const optionsHtml = state.students
      .map(s => `<option value="${escapeHtml(s.id)}">${escapeHtml(formatStudentNumLabel(s))} ${escapeHtml(s.name)}${formatGenderSuffix(s.gender)}</option>`)
      .join('');
    togA.innerHTML = optionsHtml;
    togB.innerHTML = optionsHtml;
    if (prevTA && state.students.some(s => String(s.id) === String(prevTA))) {
      togA.value = prevTA;
    }
    if (prevTB && state.students.some(s => String(s.id) === String(prevTB))) {
      togB.value = prevTB;
    } else if (state.students.length > 1) {
      togB.value = String(state.students[1].id);
    }
  }

  if (!Array.isArray(state.rules.togetherPairs)) state.rules.togetherPairs = [];
  const togListContainer = document.getElementById('togetherListContainer');
  if (togListContainer) {
    togListContainer.innerHTML = '';
    if (!state.rules.togetherPairs.length) {
      togListContainer.innerHTML = `<div class="text-[11px] text-slate-400 py-2 text-center">등록된 붙이기 학생 쌍이 없습니다.</div>`;
    } else {
      state.rules.togetherPairs.forEach((pair, idx) => {
        const stA = getStudentById(state, pair[0]);
        const stB = getStudentById(state, pair[1]);
        if (!stA || !stB) return;
        const item = document.createElement('div');
        item.className = 'flex items-center justify-between bg-white px-3 py-2 rounded-xl border border-slate-200 text-xs';
        item.innerHTML = `
          <div class="flex items-center gap-2 font-semibold text-slate-700">
            <span class="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 text-[10px] font-bold">짝꿍 ${idx + 1}</span>
            <span>${escapeHtml(formatStudentNumLabel(stA))} ${escapeHtml(stA.name)}</span>
            <span class="text-emerald-600">♥</span>
            <span>${escapeHtml(formatStudentNumLabel(stB))} ${escapeHtml(stB.name)}</span>
          </div>
          <button type="button" data-remove-tog="${idx}" class="text-slate-400 hover:text-rose-600 font-bold px-1.5">삭제</button>
        `;
        item.querySelector('[data-remove-tog]').addEventListener('click', () => {
          AppStore.getState().rules.togetherPairs.splice(idx, 1);
          AppStore.commitChange({ rules: true, dirty: true, save: true });
        });
        togListContainer.appendChild(item);
      });
    }
  }

  const pairOptionBadge = document.getElementById('activePairOptionBadge');
  if (pairOptionBadge) {
    const hasAnyPairOption = (state.rules.separatedPairs && state.rules.separatedPairs.length > 0) ||
                             (state.rules.togetherPairs && state.rules.togetherPairs.length > 0);
    if (hasAnyPairOption) {
      pairOptionBadge.classList.remove('hidden');
    } else {
      pairOptionBadge.classList.add('hidden');
    }
  }
}

export function openPairOptionModal() {
  const state = AppStore.getState();
  if (!state.inSecretRoom) return;
  const pairOptionModal = document.getElementById('pairOptionModal');
  if (!pairOptionModal) return;
  updateRulesUI();
  pairOptionModal.classList.remove('hidden');
  pairOptionModal.classList.add('flex');
}

export function closePairOptionModal() {
  const pairOptionModal = document.getElementById('pairOptionModal');
  if (!pairOptionModal) return;
  pairOptionModal.classList.add('hidden');
  pairOptionModal.classList.remove('flex');
}

export function addSeparationPairRule() {
  const state = AppStore.getState();
  const idA = String(document.getElementById('sepStudentA').value);
  const idB = String(document.getElementById('sepStudentB').value);
  const check = canRegisterPairRule(idA, idB, 'sep', state.rules);
  if (!check.ok) {
    showToast(check.reason, 'warn');
    showSecretNoticePopup([check.reason]);
    return;
  }
  state.rules.separatedPairs.push([idA, idB]);
  AppStore.commitChange({ rules: true, dirty: true, save: true });
  const listEl = document.getElementById('separationListContainer');
  if (listEl) listEl.scrollTop = listEl.scrollHeight;
  showToast('거리두기 조건이 추가되었습니다.', 'success');
}

export function addTogetherPairRule() {
  const state = AppStore.getState();
  const idA = String(document.getElementById('togStudentA').value);
  const idB = String(document.getElementById('togStudentB').value);
  const check = canRegisterPairRule(idA, idB, 'tog', state.rules);
  if (!check.ok) {
    showToast(check.reason, 'warn');
    showSecretNoticePopup([check.reason]);
    return;
  }
  if (!Array.isArray(state.rules.togetherPairs)) state.rules.togetherPairs = [];
  state.rules.togetherPairs.push([idA, idB]);
  AppStore.commitChange({ rules: true, dirty: true, save: true });
  const listEl = document.getElementById('togetherListContainer');
  if (listEl) listEl.scrollTop = listEl.scrollHeight;
  showToast('친구끼리 붙이기(짝꿍) 조건이 추가되었습니다.', 'success');
}

export function addFrontRowStudentWithOverflowCheck() {
  const state = AppStore.getState();
  const sel = document.getElementById('frontRowStudentSelect');
  const targetId = sel ? String(sel.value || '') : '';
  if (!targetId) return;
  if (!Array.isArray(state.rules.frontRowIds)) state.rules.frontRowIds = [];
  if (state.rules.frontRowIds.some(id => String(id) === targetId)) {
    showToast('이미 앞줄 우선 배정 목록에 등록된 학생입니다.', 'warn');
    return;
  }
  state.rules.frontRowIds.push(targetId);
  AppStore.commitChange({ rules: true, dirty: true, save: true });
  const frontListEl = document.getElementById('frontRowListContainer');
  if (frontListEl) {
    frontListEl.scrollTop = frontListEl.scrollHeight;
  }
  const st = getStudentById(state, targetId);

  // 현재 교실 앞줄(1~2행) 미잠금 좌석 정원을 기준으로 초과 여부를 계산해 안내 팝업을 표시한다.
  const activeMap = getActivePosMap(state);
  const { r0 } = getGridBounds(state.students, activeMap, false);
  const totalFrontTwoRowSeats = state.students.filter(s => {
    const p = activeMap[s.id];
    return p && p[1] <= r0 + 1;
  }).length;
  const unlockedFrontTwoRowSeats = state.students.filter(s => {
    const p = activeMap[s.id];
    return p && p[1] <= r0 + 1 && !isSeatLocked(state, s.id);
  }).length;
  const frontTwoRowSeats = totalFrontTwoRowSeats > 0
    ? unlockedFrontTwoRowSeats
    : Math.min(state.students.length, (Number(state.rules.defaultCols) || 6) * 2);

  const unlockedFrontSelectedCount = state.rules.frontRowIds.filter(id => !isSeatLocked(state, id)).length;
  const frontRowOverflowModalEl = document.getElementById('frontRowOverflowModal');
  if (unlockedFrontSelectedCount > frontTwoRowSeats) {
    const unlockedRows = state.students
      .filter(s => !isSeatLocked(state, s.id) && Array.isArray(activeMap[s.id]))
      .map(s => activeMap[s.id][1])
      .sort((a, b) => a - b);
    const targetRowAbs = unlockedRows[Math.min(unlockedRows.length - 1, Math.max(0, unlockedFrontSelectedCount - 1))] || (r0 + 2);
    const expandedMaxRow = Math.max(3, targetRowAbs - r0 + 1);
    const overflowTextEl = document.getElementById('frontRowOverflowModalText');
    if (overflowTextEl && frontRowOverflowModalEl) {
      overflowTextEl.textContent = `현재 교실 앞줄(1~2행) 배정 가능 좌석 정원은 ${frontTwoRowSeats}석입니다. 방금 '${st ? st.name : '학생'}' 추가로 총 ${unlockedFrontSelectedCount}명이 시력 보호·배려석으로 지정되어, [자리 바꾸기] 실행 시 앞쪽 1~${expandedMaxRow}행 범위로 자동 확장되어 배정됩니다.`;
      frontRowOverflowModalEl.classList.remove('hidden');
      frontRowOverflowModalEl.classList.add('flex');
    }
  }
  showToast(`${st ? st.name + ' 학생이 ' : ''}앞줄(1~2행) 우선 배정 목록에 추가되었습니다.`, 'success');
}
