// [L4] 좌측 학생 명렬표 뷰 렌더러 (선택/삭제/번호편집/룰렛재초기화 액션은 L5에서 주입받아 순환참조 차단)
import { formatStudentNumCompact, sanitizeClassLabel } from '../core/utils.js';
import { isSeatHidden } from '../domain/seat-queries.js';
import { AppStore } from '../state/store.js';

const _handlers = {
  onStudentPick: null,
  onDeleteStudent: null,
  onRouletteRedraw: null,
  onUpdateStudentNum: null,
  onExitNumEdit: null
};

export function bindRosterHandlers(nextHandlers = {}) {
  if (!nextHandlers || typeof nextHandlers !== 'object') return;
  Object.keys(_handlers).forEach((k) => {
    if (typeof nextHandlers[k] === 'function' || nextHandlers[k] === null) {
      _handlers[k] = nextHandlers[k];
    }
  });
}

function updateStudentNameOnBoard(studentId, newName) {
  const safeId = (typeof CSS !== "undefined" && CSS.escape) ? CSS.escape(String(studentId)) : String(studentId).replace(/["\\]/g, "\\$&");
  const nameEls = document.querySelectorAll(`[data-student-name-id="${safeId}"]`);
  const trimmedLen = String(newName || '').trim().length;
  nameEls.forEach(el => {
    el.textContent = newName || '·';
    el.classList.toggle('seat-name-len-4', trimmedLen === 4);
    el.classList.toggle('seat-name-len-5', trimmedLen >= 5);
  });
}

function buildDuplicateNumKeySet(students) {
  const counts = new Map();
  (students || []).forEach((st, idx) => {
    const key = `${sanitizeClassLabel(st && st.classLabel)}::${Number(st && st.num) || (idx + 1)}`;
    counts.set(key, (counts.get(key) || 0) + 1);
  });
  const dups = new Set();
  counts.forEach((cnt, key) => {
    if (cnt > 1) dups.add(key);
  });
  return dups;
}

function getNumInputClassName(isDuplicate) {
  return isDuplicate
    ? 'w-full h-7 px-1 text-center font-bold text-[11px] rounded-lg border border-amber-400 bg-amber-50 text-amber-800 focus:bg-white focus:border-indigo-500 focus:outline-none transition'
    : 'w-full h-7 px-1 text-center font-bold text-[11px] rounded-lg border border-indigo-200 bg-white text-indigo-800 hover:border-indigo-300 focus:border-indigo-500 focus:outline-none transition';
}

function refreshDuplicateNumInputStyles(container, students) {
  if (!container) return;
  const dupSet = buildDuplicateNumKeySet(students);
  const byId = new Map((students || []).map((st, idx) => [String(st.id), { st, idx }]));
  container.querySelectorAll('[data-roster-num-input]').forEach((inp) => {
    const sid = inp.getAttribute('data-student-id');
    const info = byId.get(String(sid));
    if (!info) return;
    const key = `${sanitizeClassLabel(info.st.classLabel)}::${Number(info.st.num) || (info.idx + 1)}`;
    const isDup = dupSet.has(key);
    inp.className = getNumInputClassName(isDup);
    inp.title = isDup
      ? '동일한 반·번호가 중복되어 있습니다 (예: 3, 1-3, 1반 3, 30103)'
      : '반·번호 수정 후 Enter/Tab으로 이동 (예: 3, 1-3, 1반 3, 3-1-15, 30103)';
  });
}

let _isRenderingRoster = false;

export function renderRoster() {
  const state = AppStore.getState();
  const container = document.getElementById('rosterListContainer');
  const badge = document.getElementById('studentCountBadge');
  if (!container) return;

  const useGender = state.rules.useGenderDistinction !== false;
  const isNumEditMode = Boolean(state.rosterNumEditMode);
  const boyCount = state.students.filter(s => s.gender === '남').length;
  const girlCount = state.students.length - boyCount;

  if (useGender) {
    badge.textContent = `총 ${state.students.length}명 (남${boyCount}·여${girlCount})`;
  } else {
    badge.textContent = `총 ${state.students.length}명`;
  }

  const hdNameCol = document.getElementById('rosterHeaderNameCol');
  const hdGenderCol = document.getElementById('rosterHeaderGenderCol');
  if (hdNameCol && hdGenderCol) {
    if (useGender) {
      hdNameCol.className = 'col-span-6 text-left pl-2';
      hdGenderCol.className = 'col-span-2';
    } else {
      hdNameCol.className = 'col-span-8 text-left pl-2';
      hdGenderCol.className = 'hidden';
    }
  }

  // 번호 편집 토글 버튼 및 보조 안내 바 동기화
  const toggleNumEditBtn = document.getElementById('toggleRosterNumEditBtn');
  if (toggleNumEditBtn) {
    if (isNumEditMode) {
      toggleNumEditBtn.textContent = '편집 중';
      toggleNumEditBtn.className = 'px-1.5 py-0.5 rounded-md text-[11px] font-extrabold bg-indigo-600 text-white hover:bg-indigo-700 transition whitespace-nowrap';
    } else {
      toggleNumEditBtn.textContent = '번호 ✎';
      toggleNumEditBtn.className = 'px-1.5 py-0.5 rounded-md text-[11px] font-bold text-slate-600 hover:bg-indigo-100 hover:text-indigo-700 transition whitespace-nowrap';
    }
  }
  const numEditBar = document.getElementById('rosterNumEditBar');
  if (numEditBar) {
    if (isNumEditMode) {
      numEditBar.classList.remove('hidden');
      numEditBar.classList.add('flex');
    } else {
      numEditBar.classList.add('hidden');
      numEditBar.classList.remove('flex');
    }
  }

  const paperGenderLabel = document.getElementById('paperGenderColorLabel');
  if (paperGenderLabel) {
    if (useGender) {
      paperGenderLabel.classList.remove('hidden');
      paperGenderLabel.classList.add('flex');
    } else {
      paperGenderLabel.classList.add('hidden');
      paperGenderLabel.classList.remove('flex');
    }
  }

  _isRenderingRoster = true;
  try {
    container.innerHTML = '';
  } finally {
    _isRenderingRoster = false;
  }
  const dupSet = isNumEditMode ? buildDuplicateNumKeySet(state.students) : null;

  state.students.forEach((student, idx) => {
    const isSelected = String(state.selectedStudentId) === String(student.id);
    const row = document.createElement('div');
    row.className = `grid grid-cols-12 items-center px-3 py-1.5 transition group text-xs ${
      isSelected ? 'bg-amber-50/90 ring-1 ring-amber-400' : 'hover:bg-indigo-50/40'
    }`;

    // 번호 칸: 평소엔 자리 선택 버튼, [번호 ✎] 편집 모드에서는 한 칸 스마트 입력란
    const numCol = document.createElement('div');
    numCol.className = 'col-span-2 flex justify-center pr-1';
    const compactNumText = formatStudentNumCompact(student, idx + 1);

    if (isNumEditMode) {
      const numKey = `${sanitizeClassLabel(student.classLabel)}::${Number(student.num) || (idx + 1)}`;
      const isDup = dupSet.has(numKey);
      const numInput = document.createElement('input');
      numInput.type = 'text';
      numInput.maxLength = 15;
      numInput.value = compactNumText;
      numInput.setAttribute('data-roster-num-input', '1');
      numInput.setAttribute('data-student-id', String(student.id));
      numInput.setAttribute('aria-label', `${student.name || '학생'} 반 및 번호 입력`);
      numInput.className = getNumInputClassName(isDup);
      numInput.title = isDup
        ? '동일한 반·번호가 중복되어 있습니다 (예: 3, 1-3, 1반 3, 30103)'
        : '반·번호 수정 후 Enter/Tab으로 이동 (예: 3, 1-3, 1반 3, 3-1-15, 30103)';

      let skipNextBlur = false;
      const commitCurrentInput = () => {
        if (typeof _handlers.onUpdateStudentNum !== 'function') return true;
        const res = _handlers.onUpdateStudentNum(student, numInput.value);
        const normalizedText = formatStudentNumCompact(student, idx + 1);
        numInput.value = normalizedText;
        refreshDuplicateNumInputStyles(container, AppStore.getState().students);
        return Boolean(res && res.ok);
      };

      numInput.addEventListener('focus', () => numInput.select());
      numInput.addEventListener('blur', () => {
        if (_isRenderingRoster || !numInput.isConnected) return;
        if (skipNextBlur) {
          skipNextBlur = false;
          return;
        }
        commitCurrentInput();
      });
      numInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          if (e.isComposing || e.keyCode === 229) return;
          e.preventDefault();
          const ok = commitCurrentInput();
          if (ok) {
            const allInputs = Array.from(container.querySelectorAll('[data-roster-num-input]'));
            const curPos = allInputs.indexOf(numInput);
            const nextPos = e.shiftKey ? curPos - 1 : curPos + 1;
            if (nextPos >= 0 && nextPos < allInputs.length) {
              skipNextBlur = true;
              allInputs[nextPos].focus();
              allInputs[nextPos].select();
            } else {
              skipNextBlur = true;
              numInput.blur();
            }
          } else {
            numInput.select();
          }
        } else if (e.key === 'Escape') {
          e.preventDefault();
          e.stopPropagation();
          skipNextBlur = true;
          numInput.value = formatStudentNumCompact(student, idx + 1);
          if (typeof _handlers.onExitNumEdit === 'function') {
            _handlers.onExitNumEdit();
          }
        }
      });
      numCol.appendChild(numInput);
    } else {
      const numBtn = document.createElement('button');
      numBtn.type = 'button';
      numBtn.title = '클릭하여 자리 선택/맞바꾸기 (반·번호 수정은 상단 [번호 ✎] 클릭)';
      const numSizeClass = compactNumText.length >= 4 ? 'text-[10px]' : 'text-xs';
      numBtn.className = `min-w-7 h-7 px-1 rounded-lg font-bold ${numSizeClass} whitespace-nowrap transition flex items-center justify-center ${
        isSelected
          ? 'bg-indigo-600 text-white shadow-sm'
          : 'bg-slate-100 text-slate-600 hover:bg-indigo-100 hover:text-indigo-700'
      }`;
      numBtn.textContent = compactNumText;
      numBtn.addEventListener('click', () => {
        if (typeof _handlers.onStudentPick === 'function') {
          _handlers.onStudentPick(student.id);
        }
      });
      numCol.appendChild(numBtn);
    }

    // 성명 입력란 (부분 DOM 패치로 한글 입력 포커스 보존)
    const nameCol = document.createElement('div');
    nameCol.className = useGender ? 'col-span-6 pl-1 pr-1' : 'col-span-8 pl-1 pr-1';
    const nameInput = document.createElement('input');
    nameInput.type = 'text';
    nameInput.maxLength = 30;
    nameInput.value = student.name;
    nameInput.placeholder = '이름 입력';
    nameInput.className = 'w-full font-bold text-slate-800 bg-slate-50/70 border border-transparent hover:border-slate-200 focus:border-indigo-500 focus:bg-white rounded-lg px-2 py-1 focus:outline-none transition';
    nameInput.addEventListener('input', (e) => {
      const curState = AppStore.getState();
      student.name = e.target.value;
      if (!isSeatHidden(curState, student.id) || curState.inSecretRoom) {
        updateStudentNameOnBoard(student.id, student.name);
      }
      if (curState.rouletteOpen && typeof _handlers.onRouletteRedraw === 'function') {
        _handlers.onRouletteRedraw();
      }
      AppStore.scheduleDebouncedCommit(200);
    });
    nameCol.appendChild(nameInput);

    // 성별 전환 버튼
    const genderCol = document.createElement('div');
    genderCol.className = useGender ? 'col-span-2 flex justify-center' : 'hidden';
    const genderBtn = document.createElement('button');
    genderBtn.type = 'button';
    const isFemale = student.gender === '여';
    genderBtn.className = `px-2 py-0.5 rounded-md text-[11px] font-bold transition ${
      isFemale
        ? 'bg-rose-50 text-rose-600 border border-rose-200 hover:bg-rose-100'
        : 'bg-sky-50 text-sky-600 border border-sky-200 hover:bg-sky-100'
    }`;
    genderBtn.textContent = student.gender;
    genderBtn.addEventListener('click', () => {
      student.gender = student.gender === '여' ? '남' : '여';
      AppStore.commitChange({ roster: true, classroom: true, animate: false, print: true, dirty: true, save: true });
    });
    genderCol.appendChild(genderBtn);

    // 삭제 버튼
    const actionCol = document.createElement('div');
    actionCol.className = 'col-span-2 flex items-center justify-center';

    const delBtn = document.createElement('button');
    delBtn.type = 'button';
    delBtn.title = '학생 삭제';
    delBtn.className = 'p-1 rounded hover:bg-rose-100 text-slate-400 hover:text-rose-600 transition';
    delBtn.innerHTML = `
      <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
      </svg>
    `;
    delBtn.addEventListener('click', () => {
      if (typeof _handlers.onDeleteStudent === 'function') {
        _handlers.onDeleteStudent(student);
      }
    });

    actionCol.appendChild(delBtn);

    row.appendChild(numCol);
    row.appendChild(nameCol);
    row.appendChild(genderCol);
    row.appendChild(actionCol);
    container.appendChild(row);
  });
}
