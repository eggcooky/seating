// [L4] 중앙 교실 좌석 배치표 뷰 렌더러 (액션 핸들러는 L5에서 주입받아 순환참조 차단)
import { MAX_COLS, MAX_ROWS } from '../core/constants.js';
import { formatStudentNumLabel } from '../core/utils.js';
import { getGridBounds } from '../domain/grid.js';
import { getActivePosMap, getStudentById, isSeatHidden, isSeatLocked } from '../domain/seat-queries.js';
import { AppStore } from '../state/store.js';
import { createPodiumAndMessageElement } from '../ui/podium.js';
import { checkSecretRoomLayoutMismatch } from '../ui/secret-indicators.js';
import { showToast } from '../ui/toast.js';
import { updateRevealAllButton } from './toolbar-ui.js';

const _handlers = {
  onStudentPick: null,
  onEmptySlotClick: null,
  onToggleLock: null,
  onRevealSeat: null,
  onAnimateDesk: null,
  onRouletteTargetPicked: null,
  onInsertColAisle: null,
  onRemoveEmptyColAisle: null,
  onInsertRowAisle: null,
  onRemoveEmptyRowAisle: null
};

export function bindClassroomHandlers(nextHandlers = {}) {
  if (!nextHandlers || typeof nextHandlers !== 'object') return;
  Object.keys(_handlers).forEach((k) => {
    if (typeof nextHandlers[k] === 'function' || nextHandlers[k] === null) {
      _handlers[k] = nextHandlers[k];
    }
  });
}

function getSeatNameLenClass(rawName) {
  const len = String(rawName || '').trim().length;
  if (len >= 5) return 'seat-name-len-5';
  if (len === 4) return 'seat-name-len-4';
  return '';
}

export function renderClassroom(animate = false) {
  const stage = document.getElementById('classroomStage');
  if (!stage) return;
  stage.innerHTML = '';

  const state = AppStore.getState();
  const activeMap = getActivePosMap(state);
  const isStudentView = state.viewOrientation === 'student';
  const isDeskMode = Boolean(state.selectedStudentId !== null && !(!state.inSecretRoom && state.rouletteActiveSession));

  const viewStudentBtn = document.getElementById('viewStudentBtn');
  const viewTeacherBtn = document.getElementById('viewTeacherBtn');
  const paperViewBadge = document.getElementById('paperViewBadge');
  const selectionIndicator = document.getElementById('selectionIndicator');

  if (isStudentView) {
    viewStudentBtn.className = 'px-3 py-1.5 rounded-lg text-xs font-bold transition-all bg-white text-indigo-700 shadow-sm whitespace-nowrap';
    viewTeacherBtn.className = 'px-3 py-1.5 rounded-lg text-xs font-bold transition-all text-slate-600 hover:text-slate-900 whitespace-nowrap';
    paperViewBadge.textContent = state.inSecretRoom
      ? '🕵️ 비밀의 방 — 학생 게시용'
      : '학생 게시용';
    paperViewBadge.className = state.inSecretRoom
      ? 'paper-header-badge px-2.5 py-0.5 rounded-md text-xs font-bold bg-slate-900 text-amber-300 border border-amber-500/40 whitespace-nowrap shrink-0'
      : 'paper-header-badge px-2.5 py-0.5 rounded-md text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 whitespace-nowrap shrink-0';
  } else {
    viewTeacherBtn.className = 'px-3 py-1.5 rounded-lg text-xs font-bold transition-all bg-white text-violet-700 shadow-sm whitespace-nowrap';
    viewStudentBtn.className = 'px-3 py-1.5 rounded-lg text-xs font-bold transition-all text-slate-600 hover:text-slate-900 whitespace-nowrap';
    paperViewBadge.textContent = state.inSecretRoom
      ? '🕵️ 비밀의 방 — 교탁 게시용'
      : '교탁 게시용';
    paperViewBadge.className = state.inSecretRoom
      ? 'paper-header-badge px-2.5 py-0.5 rounded-md text-xs font-bold bg-slate-900 text-amber-300 border border-amber-500/40 whitespace-nowrap shrink-0'
      : 'paper-header-badge px-2.5 py-0.5 rounded-md text-xs font-bold bg-violet-50 text-violet-700 border border-violet-200 whitespace-nowrap shrink-0';
  }

  if (state.selectedStudentId !== null) {
    const st = getStudentById(state, state.selectedStudentId);
    if (isDeskMode) {
      selectionIndicator.textContent = `선택된 책상: ${st ? st.name : ''} — 빈칸(＋) 이동 · 책상 교환 · 테두리 ＋/− 통로 조절 (취소: ESC)`;
    } else {
      selectionIndicator.textContent = `선택됨: ${st ? st.name : ''} — 맞바꿀 다른 학생의 자리를 클릭하세요 (취소: ESC)`;
    }
  } else {
    selectionIndicator.textContent = '';
  }

  updateRevealAllButton();

  if (isStudentView) {
    stage.appendChild(createPodiumAndMessageElement(false));
  }

  const posMap = {};
  state.students.forEach((s, idx) => {
    const coord = activeMap[s.id];
    if (coord) {
      posMap[`${coord[0]},${coord[1]}`] = { student: s, num: s.num || (idx + 1) };
    }
  });

  const nextTargetCoord = (state.rouletteActiveSession && !state.inSecretRoom && state.rouletteTargetCoords.length > 0)
    ? state.rouletteTargetCoords[0]
    : null;

  if (!isDeskMode) {
    state.manualExpandCol = 0;
    state.manualExpandRow = 0;
  }
  const bounds = getGridBounds(state.students, activeMap, false);
  const { c0, r0 } = bounds;
  let { c1, r1 } = bounds;
  const extraCols = isDeskMode ? Math.max(0, Number(state.manualExpandCol) || 0) : 0;
  const extraRows = isDeskMode ? Math.max(0, Number(state.manualExpandRow) || 0) : 0;
  c1 = Math.min(MAX_COLS - 1, c1 + extraCols);
  r1 = Math.min(MAX_ROWS - 1, r1 + extraRows);

  // 시점 대칭 연속 확장: 최대 열(12열)·최대 행(16행)에 도달하기 전까지 버튼을 누를 때마다 1줄씩 계속 확장 가능
  const canExpandMoreCol = isDeskMode && (c1 < MAX_COLS - 1);
  const canExpandMoreRow = isDeskMode && (r1 < MAX_ROWS - 1);

  const baseCols = Math.max(1, (bounds.c1 - c0) + 1);
  const numCols = c1 - c0 + 1;

  // 전체화면(크게 보기) 전환 시 배치표 카드와 그리드 최대 폭을 함께 확장해 책상과 글씨가 여유롭게 커지도록 한다.
  const paperCard = document.getElementById('seatingPaperCard');
  if (paperCard) {
    paperCard.classList.toggle('paper-card-large', Boolean(state.largeViewEnabled));
  }

  // 상·하·좌·우 고정 여백(28px / 34px)을 미리 확보해 두어 학생 클릭 시 확장·통로 버튼이 떠도 책상 위치가 1px도 울컥이지 않도록 함
  const gridOuterWrapper = document.createElement('div');
  gridOuterWrapper.className = state.largeViewEnabled
    ? 'relative w-full seat-grid-large mx-auto'
    : 'relative w-full max-w-4xl mx-auto';
  gridOuterWrapper.style.padding = '28px 34px';
  // 가로 1열 확장 시 화면 여유 폭 범위 내에서 max-width를 비례 확장해 기존 책상 폭과 글씨 크기의 울렁임을 최소화한다.
  if (extraCols > 0) {
    const baseMaxW = state.largeViewEnabled ? 1560 : 896;
    const expandedMaxW = Math.round(68 + ((baseMaxW - 68) * numCols) / baseCols);
    gridOuterWrapper.style.maxWidth = `${expandedMaxW}px`;
  }

  if (canExpandMoreRow) {
    const rowExpandBtn = document.createElement('button');
    rowExpandBtn.id = 'expandGridRowBtn';
    rowExpandBtn.type = 'button';
    rowExpandBtn.title = isStudentView ? '아래쪽으로 1줄(빈칸) 더 확장' : '위쪽으로 1줄(빈칸) 더 확장';
    rowExpandBtn.className = 'rounded-md border border-dashed border-amber-400 bg-amber-50/95 hover:bg-amber-100 text-amber-700 font-extrabold text-xs flex items-center justify-center transition shadow-sm z-10';
    rowExpandBtn.style.position = 'absolute';
    rowExpandBtn.style.left = '34px';
    rowExpandBtn.style.right = '34px';
    rowExpandBtn.style.height = '22px';
    if (isStudentView) {
      rowExpandBtn.style.bottom = '1px';
      rowExpandBtn.textContent = '＋ 아래쪽 1줄 확장';
    } else {
      rowExpandBtn.style.top = '1px';
      rowExpandBtn.textContent = '＋ 위쪽 1줄 확장';
    }
    rowExpandBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const curState = AppStore.getState();
      curState.manualExpandRow = (Number(curState.manualExpandRow) || 0) + 1;
      renderClassroom(false);
    });
    gridOuterWrapper.appendChild(rowExpandBtn);
  }

  if (canExpandMoreCol) {
    const colExpandBtn = document.createElement('button');
    colExpandBtn.id = 'expandGridColBtn';
    colExpandBtn.type = 'button';
    colExpandBtn.title = isStudentView ? '오른쪽으로 1열(빈칸) 더 확장' : '왼쪽으로 1열(빈칸) 더 확장';
    colExpandBtn.className = 'rounded-md border border-dashed border-amber-400 bg-amber-50/95 hover:bg-amber-100 text-amber-700 font-extrabold text-sm flex items-center justify-center transition shadow-sm z-10';
    colExpandBtn.style.position = 'absolute';
    colExpandBtn.style.top = '28px';
    colExpandBtn.style.bottom = '28px';
    colExpandBtn.style.width = '26px';
    if (isStudentView) {
      colExpandBtn.style.right = '2px';
    } else {
      colExpandBtn.style.left = '2px';
    }
    colExpandBtn.textContent = '＋';
    colExpandBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const curState = AppStore.getState();
      curState.manualExpandCol = (Number(curState.manualExpandCol) || 0) + 1;
      renderClassroom(false);
    });
    gridOuterWrapper.appendChild(colExpandBtn);
  }

  const colGridGapCls = (!state.largeViewEnabled && baseCols >= 7)
    ? 'aisle-col-grid-tight'
    : 'aisle-col-grid-normal';
  const gridBodyWrap = document.createElement('div');
  gridBodyWrap.className = 'relative w-full';

  const columnsContainer = document.createElement('div');
  // 일반 모드 7열 이상은 열 간격을 살짝 줄여 책상 폭을 확보하되, 임시 1열 확장(extraCols)으로 간격이 변하지 않게 baseCols 기준으로 고정한다.
  columnsContainer.className = `w-full grid ${colGridGapCls}`;
  columnsContainer.style.gridTemplateColumns = `repeat(${numCols}, minmax(0, 1fr))`;

  const colOrder = [];
  for (let c = c0; c <= c1; c++) colOrder.push(c);
  if (!isStudentView) colOrder.reverse();

  const rowOrder = [];
  for (let r = r0; r <= r1; r++) rowOrder.push(r);
  if (!isStudentView) rowOrder.reverse();

  colOrder.forEach(c => {
    const colStack = document.createElement('div');
    colStack.className = 'flex flex-col';

    rowOrder.forEach((r, visualRowIdx) => {
      const coordKey = `${c},${r}`;
      const entry = posMap[coordKey];
      const borderOverlap = visualRowIdx > 0 ? '-mt-[1.5px]' : '';
      const deskEl = document.createElement('div');

      if (entry) {
        const { student, num } = entry;
        const isSelected = String(state.selectedStudentId) === String(student.id);
        const locked = isSeatLocked(state, student.id);
        // 비밀의 방에서는 가리기 모드와 무관하게 모든 학생 이름을 표시한다.
        const isMasked = !state.inSecretRoom && isSeatHidden(state, student.id);

        const isRoulettePending = !state.inSecretRoom && state.rouletteActiveSession && !state.rouletteAssignedMap[coordKey];
        const isNextRouletteTarget = nextTargetCoord && nextTargetCoord[0] === c && nextTargetCoord[1] === r;

        let bgClass = 'bg-white hover:bg-indigo-50/50';
        if (isNextRouletteTarget) {
          bgClass = 'bg-fuchsia-50/90 border-fuchsia-600 z-10 roulette-target-seat';
        } else if (isRoulettePending) {
          bgClass = 'bg-slate-50/80 text-slate-400';
        } else if (isMasked) {
          bgClass = 'bg-indigo-950 hover:bg-indigo-900 text-white';
        } else if (locked) {
          bgClass = 'bg-amber-50/80 hover:bg-amber-100/70';
        } else if (state.showGenderColor && state.rules.useGenderDistinction !== false) {
          bgClass = student.gender === '여'
            ? 'bg-rose-50/70 hover:bg-rose-100/60'
            : 'bg-sky-50/70 hover:bg-sky-100/60';
        }

        const selectedRing = isSelected
          ? 'z-20 ring-2 ring-amber-500 selected-seat'
          : '';

        deskEl.className = `relative ${state.largeViewEnabled ? 'seat-box-large' : 'seat-box-responsive'} border-[1.5px] border-slate-800 ${borderOverlap} ${bgClass} ${selectedRing} cursor-pointer flex flex-col items-center justify-center transition-all group ${animate ? 'animate-pop' : ''}`;

        if (isRoulettePending) {
          const badge = document.createElement('div');
          badge.className = `text-xs font-extrabold truncate max-w-full px-1 ${isNextRouletteTarget ? 'text-fuchsia-700' : 'text-slate-400'}`;
          badge.textContent = isNextRouletteTarget ? '🎯 다음 배정 자리' : '룰렛 대기';
          deskEl.appendChild(badge);
          deskEl.title = '오른쪽 룰렛을 돌려 이 자리에 앉을 친구를 배정하세요!';
          deskEl.addEventListener('click', () => {
            const curState = AppStore.getState();
            if (curState.rouletteSpinning || curState.rouletteAutoColumnTarget !== null) return;
            const idx = curState.rouletteTargetCoords.findIndex(tc => tc[0] === c && tc[1] === r);
            if (idx > 0) {
              const [pickedCoord] = curState.rouletteTargetCoords.splice(idx, 1);
              curState.rouletteTargetCoords.unshift(pickedCoord);
              renderClassroom(false);
              if (typeof _handlers.onRouletteTargetPicked === 'function') {
                _handlers.onRouletteTargetPicked();
              }
              showToast('이 자리가 다음 룰렛 배정 순서로 지정되었습니다.', 'info');
            }
          });
        } else if (isMasked) {
          const coverDiv = document.createElement('div');
          coverDiv.className = 'flex flex-col items-center justify-center gap-0.5 max-w-full px-1';
          coverDiv.innerHTML = `
            <span class="text-xs font-extrabold text-amber-300 truncate max-w-full">🔒 클릭하여 공개</span>
            <span class="text-[10px] text-indigo-200 truncate max-w-full">누구 자리일까요?</span>
          `;
          deskEl.appendChild(coverDiv);
          deskEl.title = '클릭하면 이 자리의 학생 이름이 공개됩니다!';
          deskEl.addEventListener('click', () => {
            if (typeof _handlers.onRevealSeat === 'function') {
              _handlers.onRevealSeat(student.id);
            }
            renderClassroom(false);
            if (typeof _handlers.onAnimateDesk === 'function') {
              _handlers.onAnimateDesk(student.id);
            }
            showToast(`🎉 ${student.name} 학생의 자리가 공개되었습니다!`, 'success');
          });
        } else {
          const sideBar = document.createElement('div');
          if (state.rules.useGenderDistinction !== false) {
            sideBar.className = `absolute left-0 top-2.5 bottom-2.5 w-1 rounded-r ${
              student.gender === '여' ? 'bg-rose-400' : 'bg-sky-400'
            }`;
          } else {
            sideBar.className = 'absolute left-0 top-2.5 bottom-2.5 w-1 rounded-r bg-indigo-400';
          }
          deskEl.appendChild(sideBar);

          const topBar = document.createElement('div');
          topBar.className = 'absolute top-1 left-2 right-1.5 flex items-center justify-between pointer-events-none';

          const numSpan = document.createElement('span');
          numSpan.className = state.largeViewEnabled ? 'seat-num-large font-semibold text-slate-400' : 'text-[10px] font-semibold text-slate-400';
          numSpan.textContent = formatStudentNumLabel(student, num);
          topBar.appendChild(numSpan);

          const lockBtn = document.createElement('button');
          lockBtn.type = 'button';
          if (locked) {
            lockBtn.className = 'pointer-events-auto opacity-100 text-amber-600 hover:text-amber-700 p-0.5';
            lockBtn.title = '자리 고정 해제';
            lockBtn.innerHTML = `<svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd"/></svg>`;
          } else {
            lockBtn.className = 'pointer-events-auto opacity-0 group-hover:opacity-100 focus:opacity-100 transition p-0.5 rounded hover:bg-slate-200/70 text-slate-400';
            lockBtn.title = '랜덤 배정 시 이 자리 고정';
            lockBtn.innerHTML = `<svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 11V7a4 4 0 118 0m-4 8v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2z"/></svg>`;
          }
          lockBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (typeof _handlers.onToggleLock === 'function') {
              _handlers.onToggleLock(student.id);
            }
            if (AppStore.getState().inSecretRoom) checkSecretRoomLayoutMismatch(true);
            renderClassroom(false);
          });
          topBar.appendChild(lockBtn);
          deskEl.appendChild(topBar);

          const nameDiv = document.createElement('div');
          const nameLenCls = getSeatNameLenClass(student.name);
          const baseNameCls = state.largeViewEnabled
            ? 'seat-name-large font-extrabold text-slate-900 truncate max-w-full px-1.5 mt-2'
            : 'seat-name-fluid font-bold text-slate-900 truncate max-w-full px-1.5 mt-2';
          nameDiv.className = nameLenCls ? `${baseNameCls} ${nameLenCls}` : baseNameCls;
          nameDiv.setAttribute('data-student-name-id', student.id);
          nameDiv.textContent = student.name || '·';
          deskEl.appendChild(nameDiv);

          deskEl.addEventListener('click', () => {
            if (typeof _handlers.onStudentPick === 'function') {
              _handlers.onStudentPick(student.id);
            }
          });
        }

      } else {
        if (isDeskMode) {
          const canDropHere = state.selectedStudentId !== null;
          deskEl.className = `relative ${state.largeViewEnabled ? 'seat-box-large' : 'seat-box-responsive'} border-[1.5px] border-dashed ${borderOverlap} ${
            canDropHere
              ? 'border-indigo-300 bg-indigo-50/40 hover:bg-indigo-100/70 hover:border-indigo-500 text-indigo-600'
              : 'border-slate-300 bg-slate-50/60 hover:border-slate-400 text-slate-400'
          } flex items-center justify-center font-bold text-lg cursor-pointer transition`;
          deskEl.textContent = '＋';
          deskEl.title = state.selectedStudentId !== null
            ? '클릭하여 선택한 책상을 이 위치로 이동'
            : '먼저 옮길 학생의 책상을 클릭해 선택하세요';
          deskEl.addEventListener('click', () => {
            if (typeof _handlers.onEmptySlotClick === 'function') {
              _handlers.onEmptySlotClick(c, r);
            }
          });
        } else {
          deskEl.className = `${state.largeViewEnabled ? 'seat-box-large' : 'seat-box-responsive'} ${borderOverlap} border border-transparent pointer-events-none`;
        }
      }

      colStack.appendChild(deskEl);
    });

    columnsContainer.appendChild(colStack);
  });

  gridBodyWrap.appendChild(columnsContainer);

  // 반대편 두 변의 책상 사이 통로 벌리기(초록 ＋) · 빈 통로 좁히기(빨강 −) 및 호버 가이드선 동기 렌더링
  if (isDeskMode && state.students.length > 0) {
    const colOcc = {};
    const rowOcc = {};
    state.students.forEach(s => {
      const p = activeMap[s.id];
      if (!Array.isArray(p)) return;
      colOcc[p[0]] = (colOcc[p[0]] || 0) + 1;
      rowOcc[p[1]] = (rowOcc[p[1]] || 0) + 1;
    });

    const canInsertCol = (bounds.c1 - bounds.c0 + 1) < MAX_COLS && !(bounds.c1 >= MAX_COLS - 1 && bounds.c0 <= 0);
    const canInsertRow = (bounds.r1 - bounds.r0 + 1) < MAX_ROWS && !(bounds.r1 >= MAX_ROWS - 1 && bounds.r0 <= 0);
    const rowTrackCls = state.largeViewEnabled ? 'aisle-row-track-large' : 'aisle-row-track-responsive';

    const colGuideGrid = document.createElement('div');
    colGuideGrid.className = `absolute inset-0 pointer-events-none z-20 grid ${colGridGapCls}`;
    colGuideGrid.style.gridTemplateColumns = `repeat(${numCols}, minmax(0, 1fr))`;

    const rowGuideStack = document.createElement('div');
    rowGuideStack.className = 'absolute inset-0 pointer-events-none z-20 flex flex-col';

    const colControlsLayer = document.createElement('div');
    colControlsLayer.className = `${isStudentView ? 'aisle-col-bar-top' : 'aisle-col-bar-bottom'} grid ${colGridGapCls}`;
    colControlsLayer.style.gridTemplateColumns = `repeat(${numCols}, minmax(0, 1fr))`;

    const rowControlsLayer = document.createElement('div');
    rowControlsLayer.className = `${isStudentView ? 'aisle-row-bar-left' : 'aisle-row-bar-right'} flex flex-col`;

    const colGuideCells = [];
    const rowGuideCells = [];
    const clearAllGuides = () => {
      colGuideCells.forEach(cell => { cell.innerHTML = ''; });
      rowGuideCells.forEach(cell => { cell.innerHTML = ''; });
    };

    colOrder.forEach((c, idx) => {
      const guideCell = document.createElement('div');
      guideCell.className = 'relative h-full';
      colGuideGrid.appendChild(guideCell);
      colGuideCells.push(guideCell);

      const ctrlCell = document.createElement('div');
      ctrlCell.className = 'relative h-full';

      const isInternalEmptyCol = (colOcc[c] || 0) === 0 && c > bounds.c0 && c < bounds.c1;
      if (isInternalEmptyCol) {
        const minusBtn = document.createElement('button');
        minusBtn.type = 'button';
        minusBtn.className = 'aisle-btn aisle-btn-minus aisle-pos-col-center';
        minusBtn.setAttribute('data-aisle-action', 'remove-col');
        minusBtn.setAttribute('data-aisle-col', String(c));
        minusBtn.setAttribute('aria-label', '빈 세로 통로 좁히기');
        minusBtn.title = '학생이 없는 빈 세로 통로 좁히기';
        minusBtn.textContent = '−';
        minusBtn.addEventListener('mouseenter', () => {
          clearAllGuides();
          const band = document.createElement('div');
          band.className = 'aisle-guide-band-v';
          guideCell.appendChild(band);
        });
        minusBtn.addEventListener('mouseleave', clearAllGuides);
        minusBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          if (typeof _handlers.onRemoveEmptyColAisle === 'function') {
            _handlers.onRemoveEmptyColAisle(c);
          }
        });
        ctrlCell.appendChild(minusBtn);
      }

      if (canInsertCol && idx < colOrder.length - 1) {
        const nextC = colOrder[idx + 1];
        const bothOccupied = (colOcc[c] || 0) > 0 && (colOcc[nextC] || 0) > 0;
        if (bothOccupied) {
          const splitCol = Math.max(c, nextC);
          const plusBtn = document.createElement('button');
          plusBtn.type = 'button';
          plusBtn.className = 'aisle-btn aisle-btn-plus aisle-pos-col-gap';
          plusBtn.setAttribute('data-aisle-action', 'insert-col');
          plusBtn.setAttribute('data-aisle-col', String(splitCol));
          plusBtn.setAttribute('aria-label', '세로 통로 벌리기');
          plusBtn.title = '이 두 열 사이를 벌려 세로 통로 만들기';
          plusBtn.textContent = '＋';
          plusBtn.addEventListener('mouseenter', () => {
            clearAllGuides();
            const line = document.createElement('div');
            line.className = 'aisle-guide-line-v';
            guideCell.appendChild(line);
          });
          plusBtn.addEventListener('mouseleave', clearAllGuides);
          plusBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (typeof _handlers.onInsertColAisle === 'function') {
              _handlers.onInsertColAisle(splitCol);
            }
          });
          ctrlCell.appendChild(plusBtn);
        }
      }

      colControlsLayer.appendChild(ctrlCell);
    });

    rowOrder.forEach((r, idx) => {
      const overlapCls = idx > 0 ? '-mt-[1.5px]' : '';
      const guideCell = document.createElement('div');
      guideCell.className = `relative w-full ${rowTrackCls} ${overlapCls}`;
      rowGuideStack.appendChild(guideCell);
      rowGuideCells.push(guideCell);

      const ctrlCell = document.createElement('div');
      ctrlCell.className = `relative w-full ${rowTrackCls} ${overlapCls}`;

      const isInternalEmptyRow = (rowOcc[r] || 0) === 0 && r > bounds.r0 && r < bounds.r1;
      if (isInternalEmptyRow) {
        const minusBtn = document.createElement('button');
        minusBtn.type = 'button';
        minusBtn.className = 'aisle-btn aisle-btn-minus aisle-pos-row-center';
        minusBtn.setAttribute('data-aisle-action', 'remove-row');
        minusBtn.setAttribute('data-aisle-row', String(r));
        minusBtn.setAttribute('aria-label', '빈 가로 통로 좁히기');
        minusBtn.title = '학생이 없는 빈 가로 통로 좁히기';
        minusBtn.textContent = '−';
        minusBtn.addEventListener('mouseenter', () => {
          clearAllGuides();
          const band = document.createElement('div');
          band.className = 'aisle-guide-band-h';
          guideCell.appendChild(band);
        });
        minusBtn.addEventListener('mouseleave', clearAllGuides);
        minusBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          if (typeof _handlers.onRemoveEmptyRowAisle === 'function') {
            _handlers.onRemoveEmptyRowAisle(r);
          }
        });
        ctrlCell.appendChild(minusBtn);
      }

      if (canInsertRow && idx < rowOrder.length - 1) {
        const nextR = rowOrder[idx + 1];
        const bothOccupied = (rowOcc[r] || 0) > 0 && (rowOcc[nextR] || 0) > 0;
        if (bothOccupied) {
          const splitRow = Math.max(r, nextR);
          const plusBtn = document.createElement('button');
          plusBtn.type = 'button';
          plusBtn.className = 'aisle-btn aisle-btn-plus aisle-pos-row-gap';
          plusBtn.setAttribute('data-aisle-action', 'insert-row');
          plusBtn.setAttribute('data-aisle-row', String(splitRow));
          plusBtn.setAttribute('aria-label', '가로 통로 벌리기');
          plusBtn.title = '이 두 줄 사이를 벌려 가로 통로 만들기';
          plusBtn.textContent = '＋';
          plusBtn.addEventListener('mouseenter', () => {
            clearAllGuides();
            const line = document.createElement('div');
            line.className = 'aisle-guide-line-h';
            guideCell.appendChild(line);
          });
          plusBtn.addEventListener('mouseleave', clearAllGuides);
          plusBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (typeof _handlers.onInsertRowAisle === 'function') {
              _handlers.onInsertRowAisle(splitRow);
            }
          });
          ctrlCell.appendChild(plusBtn);
        }
      }

      rowControlsLayer.appendChild(ctrlCell);
    });

    gridBodyWrap.appendChild(colGuideGrid);
    gridBodyWrap.appendChild(rowGuideStack);
    gridBodyWrap.appendChild(colControlsLayer);
    gridBodyWrap.appendChild(rowControlsLayer);
  }

  gridOuterWrapper.appendChild(gridBodyWrap);
  stage.appendChild(gridOuterWrapper);

  if (!isStudentView) {
    stage.appendChild(createPodiumAndMessageElement(false));
  }
}
