// [L4] 사용자 제작 책상 대형(내 책상 대형) 팝오버 뷰 · 인라인 이름 수정 · 배지 동기화 (실행 콜백은 L5에서 주입)
import { MAX_CUSTOM_LAYOUTS } from '../core/constants.js';
import { escapeHtml } from '../core/utils.js';
import { getLayoutMiniGridGeometry, getNextDefaultLayoutName } from '../domain/custom-layouts.js';
import { loadCustomLayouts } from '../infra/storage-io.js';
import { AppStore } from '../state/store.js';

const _handlers = {
  onApplyCustom: null,
  onSaveCustom: null,
  onRenameCustom: null,
  onDeleteCustom: null
};

let _editingLayoutId = null;

export function bindCustomLayoutPopoverHandlers(nextHandlers = {}) {
  if (!nextHandlers || typeof nextHandlers !== 'object') return;
  if (typeof nextHandlers.onApplyCustom === 'function' || nextHandlers.onApplyCustom === null) {
    _handlers.onApplyCustom = nextHandlers.onApplyCustom;
  }
  if (typeof nextHandlers.onSaveCustom === 'function' || nextHandlers.onSaveCustom === null) {
    _handlers.onSaveCustom = nextHandlers.onSaveCustom;
  }
  if (typeof nextHandlers.onRenameCustom === 'function' || nextHandlers.onRenameCustom === null) {
    _handlers.onRenameCustom = nextHandlers.onRenameCustom;
  }
  if (typeof nextHandlers.onDeleteCustom === 'function' || nextHandlers.onDeleteCustom === null) {
    _handlers.onDeleteCustom = nextHandlers.onDeleteCustom;
  }
}

// 저장된 좌표 형상을 28x20 미니 도트 격자 SVG로 변환한다 (교탁 게시용 시점 반전 반영).
function buildMiniLayoutSvgHtml(coords, flipForTeacher) {
  const { cols, rows, cells } = getLayoutMiniGridGeometry(coords);
  const w = 28;
  const h = 20;
  const pad = 2;
  const availW = w - pad * 2;
  const availH = h - pad * 2;
  const stepX = availW / Math.max(1, cols);
  const stepY = availH / Math.max(1, rows);
  const dotW = Math.max(1.7, Math.min(4.2, stepX * 0.72));
  const dotH = Math.max(1.7, Math.min(3.6, stepY * 0.72));
  const rects = cells.map(([c, r]) => {
    const dc = flipForTeacher ? (cols - 1 - c) : c;
    const dr = flipForTeacher ? (rows - 1 - r) : r;
    const x = (pad + dc * stepX + (stepX - dotW) / 2).toFixed(2);
    const y = (pad + dr * stepY + (stepY - dotH) / 2).toFixed(2);
    return `<rect x="${x}" y="${y}" width="${dotW.toFixed(2)}" height="${dotH.toFixed(2)}" rx="0.8" fill="#4f46e5"/>`;
  }).join('');
  return `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" aria-hidden="true">${rects}</svg>`;
}

export function isCustomLayoutEditing() {
  return Boolean(_editingLayoutId && isCustomLayoutPopoverOpen());
}

export function startCustomLayoutRename(layoutId) {
  _editingLayoutId = layoutId ? String(layoutId) : null;
  renderCustomLayoutPopover();
}

export function cancelCustomLayoutRename() {
  if (!_editingLayoutId) return false;
  _editingLayoutId = null;
  if (isCustomLayoutPopoverOpen()) {
    renderCustomLayoutPopover();
  }
  return true;
}

function syncDefaultColsButtonsUI(state) {
  const curDefaultCols = Number(state && state.rules && state.rules.defaultCols) || 6;
  document.querySelectorAll('.default-cols-btn').forEach(btn => {
    const cVal = Number(btn.getAttribute('data-default-cols'));
    if (cVal === curDefaultCols) {
      btn.className = 'default-cols-btn py-1.5 rounded-lg text-xs font-extrabold border transition bg-violet-600 text-white border-violet-600 shadow-sm';
    } else {
      btn.className = 'default-cols-btn py-1.5 rounded-lg text-xs font-bold border transition bg-white text-slate-700 border-slate-200 hover:bg-slate-100';
    }
  });
}

export function syncCustomLayoutBadgeUI() {
  const state = AppStore.getState();
  const layouts = loadCustomLayouts();
  const badge = document.getElementById('customLayoutCountBadge');
  if (badge) {
    if (layouts.length > 0) {
      badge.textContent = String(layouts.length);
      badge.classList.remove('hidden');
    } else {
      badge.textContent = '0';
      badge.classList.add('hidden');
    }
  }
  syncDefaultColsButtonsUI(state);
  const pop = document.getElementById('customLayoutPopover');
  if (pop && !pop.classList.contains('hidden')) {
    renderCustomLayoutPopover();
  }
}

export function renderCustomLayoutPopover() {
  const state = AppStore.getState();
  const layouts = loadCustomLayouts();
  const defaultGapDot = document.getElementById('customLayoutDefaultGapDot');
  const countText = document.getElementById('customLayoutCountText');
  const listEl = document.getElementById('customLayoutList');
  const nameInput = document.getElementById('customLayoutNameInput');
  const saveBtn = document.getElementById('customLayoutSaveBtn');
  const limitHint = document.getElementById('customLayoutLimitHint');

  if (_editingLayoutId && !layouts.some(item => item.id === _editingLayoutId)) {
    _editingLayoutId = null;
  }

  syncDefaultColsButtonsUI(state);
  if (defaultGapDot) {
    if (state.hasDeleteGapNotice && state.students.length > 0) {
      defaultGapDot.classList.remove('hidden');
    } else {
      defaultGapDot.classList.add('hidden');
    }
  }
  if (countText) {
    countText.textContent = `${layouts.length}/${MAX_CUSTOM_LAYOUTS}`;
  }

  const atLimit = layouts.length >= MAX_CUSTOM_LAYOUTS;
  if (nameInput) {
    nameInput.disabled = atLimit;
    const nextDefault = getNextDefaultLayoutName(layouts);
    nameInput.placeholder = atLimit ? `최대 ${MAX_CUSTOM_LAYOUTS}개 저장됨` : `예: 4인 모둠 (${nextDefault})`;
  }
  if (saveBtn) {
    saveBtn.disabled = atLimit || state.students.length === 0;
  }
  if (limitHint) {
    if (atLimit) {
      limitHint.classList.remove('hidden');
    } else {
      limitHint.classList.add('hidden');
    }
  }

  if (!listEl) return;
  listEl.innerHTML = '';

  if (layouts.length === 0) {
    listEl.innerHTML = `
      <div class="px-4 py-5 text-center text-xs text-slate-400">
        아직 저장된 책상 대형이 없습니다.<br/>
        <span class="text-[11px]">책상을 원하는 모양으로 옮긴 뒤 아래에서 저장하세요.</span>
      </div>
    `;
    return;
  }

  const flipForTeacher = state.viewOrientation === 'teacher';
  let editInputToFocus = null;

  layouts.forEach((layout) => {
    const row = document.createElement('div');

    if (_editingLayoutId === layout.id) {
      row.className = 'flex items-center gap-1.5 px-3 py-2 bg-indigo-50/80';
      row.addEventListener('click', (e) => e.stopPropagation());

      const thumb = document.createElement('span');
      thumb.className = 'w-8 h-6 rounded-md bg-white border border-indigo-200 flex items-center justify-center shrink-0';
      thumb.innerHTML = buildMiniLayoutSvgHtml(layout.coords, flipForTeacher);

      const editInput = document.createElement('input');
      editInput.type = 'text';
      editInput.maxLength = 24;
      editInput.value = layout.name;
      editInput.setAttribute('aria-label', `${layout.name} 새 이름 입력`);
      editInput.className = 'flex-1 min-w-0 px-2 py-1 rounded-lg text-xs text-slate-800 bg-white border border-indigo-300 focus:outline-none focus:ring-2 focus:ring-indigo-500';
      editInput.addEventListener('click', (e) => e.stopPropagation());

      const commitRename = () => {
        if (typeof _handlers.onRenameCustom === 'function') {
          const res = _handlers.onRenameCustom(layout.id, editInput.value);
          if (res && res.ok) {
            _editingLayoutId = null;
            renderCustomLayoutPopover();
          } else {
            editInput.focus();
          }
        }
      };

      editInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          if (e.isComposing || e.keyCode === 229) return;
          e.preventDefault();
          e.stopPropagation();
          commitRename();
        } else if (e.key === 'Escape') {
          e.preventDefault();
          e.stopPropagation();
          cancelCustomLayoutRename();
        }
      });

      const okBtn = document.createElement('button');
      okBtn.type = 'button';
      okBtn.className = 'px-2 py-1 rounded-lg text-[11px] font-bold bg-indigo-600 text-white hover:bg-indigo-700 transition whitespace-nowrap shrink-0';
      okBtn.textContent = '확인';
      okBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        commitRename();
      });

      const cancelBtn = document.createElement('button');
      cancelBtn.type = 'button';
      cancelBtn.className = 'px-2 py-1 rounded-lg text-[11px] font-semibold bg-slate-100 text-slate-600 hover:bg-slate-200 transition whitespace-nowrap shrink-0';
      cancelBtn.textContent = '취소';
      cancelBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        cancelCustomLayoutRename();
      });

      row.appendChild(thumb);
      row.appendChild(editInput);
      row.appendChild(okBtn);
      row.appendChild(cancelBtn);
      listEl.appendChild(row);
      editInputToFocus = editInput;
      return;
    }

    row.className = 'flex items-center justify-between gap-1 px-3 py-2 hover:bg-indigo-50/80 transition group';

    const applyBtn = document.createElement('button');
    applyBtn.type = 'button';
    applyBtn.className = 'flex-1 min-w-0 flex items-center gap-2.5 text-left';
    applyBtn.title = `클릭하여 '${layout.name}' 대형(${layout.coords.length}석) 적용`;
    applyBtn.innerHTML = `
      <span class="w-8 h-6 rounded-md bg-slate-50 border border-slate-200 flex items-center justify-center shrink-0">
        ${buildMiniLayoutSvgHtml(layout.coords, flipForTeacher)}
      </span>
      <span class="min-w-0 flex-1">
        <span class="block text-xs font-bold text-slate-800 group-hover:text-indigo-700 truncate">${escapeHtml(layout.name)}</span>
        <span class="block text-[10px] text-slate-400">${layout.coords.length}석 · 클릭하여 적용</span>
      </span>
    `;
    applyBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (typeof _handlers.onApplyCustom === 'function') {
        _handlers.onApplyCustom(layout);
      }
    });

    const actionsWrap = document.createElement('div');
    actionsWrap.className = 'flex items-center gap-0.5 shrink-0';

    const renameBtn = document.createElement('button');
    renameBtn.type = 'button';
    renameBtn.className = 'w-7 h-7 rounded-lg flex items-center justify-center text-slate-400 hover:text-indigo-700 hover:bg-indigo-100 transition shrink-0 text-xs font-bold';
    renameBtn.setAttribute('aria-label', `${layout.name} 이름 수정`);
    renameBtn.title = '이름 수정';
    renameBtn.textContent = '✎';
    renameBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      startCustomLayoutRename(layout.id);
    });

    const delBtn = document.createElement('button');
    delBtn.type = 'button';
    delBtn.className = 'w-7 h-7 rounded-lg flex items-center justify-center text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition shrink-0 text-xs font-bold';
    delBtn.setAttribute('aria-label', `${layout.name} 대형 삭제`);
    delBtn.title = '이 대형 삭제';
    delBtn.textContent = '✕';
    delBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (typeof _handlers.onDeleteCustom === 'function') {
        _handlers.onDeleteCustom(layout.id);
      }
    });

    actionsWrap.appendChild(renameBtn);
    actionsWrap.appendChild(delBtn);
    row.appendChild(applyBtn);
    row.appendChild(actionsWrap);
    listEl.appendChild(row);
  });

  if (editInputToFocus) {
    editInputToFocus.focus();
    editInputToFocus.select();
  }
}

export function isCustomLayoutPopoverOpen() {
  const pop = document.getElementById('customLayoutPopover');
  return Boolean(pop && !pop.classList.contains('hidden'));
}

export function toggleCustomLayoutPopover() {
  const pop = document.getElementById('customLayoutPopover');
  const chev = document.getElementById('customLayoutChevron');
  const btn = document.getElementById('customLayoutToggleBtn');
  if (!pop) return;
  const isHidden = pop.classList.contains('hidden');
  if (isHidden) {
    _editingLayoutId = null;
    renderCustomLayoutPopover();
    pop.classList.remove('hidden');
    if (chev) chev.classList.add('rotate-180');
    if (btn) btn.setAttribute('aria-expanded', 'true');
  } else {
    closeCustomLayoutPopover();
  }
}

export function closeCustomLayoutPopover() {
  _editingLayoutId = null;
  const pop = document.getElementById('customLayoutPopover');
  const chev = document.getElementById('customLayoutChevron');
  const btn = document.getElementById('customLayoutToggleBtn');
  if (pop) pop.classList.add('hidden');
  if (chev) chev.classList.remove('rotate-180');
  if (btn) btn.setAttribute('aria-expanded', 'false');
}

export function submitCustomLayoutSaveFromPopover() {
  const nameInput = document.getElementById('customLayoutNameInput');
  const rawName = nameInput ? nameInput.value : '';
  if (typeof _handlers.onSaveCustom === 'function') {
    const res = _handlers.onSaveCustom(rawName);
    if (res && res.ok && nameInput) {
      nameInput.value = '';
    }
  }
}
