// [L5] 다단계 실행 취소(Undo) 복원 트랜잭션 코디네이터
import { ensureAllStudentsHaveValidCoords, resolveLockedSafePositions } from '../domain/grid.js';
import {
  doesSecretLayoutMatchCurrent,
  isNormalSeatLocked,
  isSeatLocked
} from '../domain/seat-queries.js';
import { stopSequentialReveal } from '../features/reveal-controller.js';
import { stopRouletteColumnAuto, syncRouletteWithCurrentLocks } from '../features/roulette-controller.js';
import { AppStore } from '../state/store.js';
import { checkSecretRoomLayoutMismatch, updateSecretPresetIndicator } from '../ui/secret-indicators.js';
import { showToast } from '../ui/toast.js';
import { closeStatusHistoryPopover, updateUndoButtonState } from '../views/history-popover.js';
import { syncCustomLayoutBadgeUI } from '../views/custom-layout-popover.js';

// STAGE 1: 선택한 시점~최신 사이의 열 수(prevDefaultCols) · 명단 백업(rosterBackup) 복원 및 반대쪽 미러 스택 대칭 정리
function restoreRosterAndMirrorStacks(state, stack, targetIdx, preUndo) {
  let earliestPrevDefaultCols = null;
  for (let k = targetIdx; k < stack.length; k++) {
    if (stack[k] && stack[k].prevDefaultCols) {
      earliestPrevDefaultCols = stack[k].prevDefaultCols;
      break;
    }
  }

  let earliestRosterBackup = null;
  let earliestRosterBackupIdx = -1;
  for (let k = targetIdx; k < stack.length; k++) {
    if (stack[k] && stack[k].rosterBackup) {
      earliestRosterBackup = stack[k].rosterBackup;
      earliestRosterBackupIdx = k;
      break;
    }
  }

  if (earliestRosterBackup) {
    state.students = JSON.parse(JSON.stringify(earliestRosterBackup.students || []));
    const restoredIdSet = new Set(state.students.map(s => String(s.id)));
    const backupNormalLockSet = new Set((earliestRosterBackup.lockedIds || []).map(String));
    const backupSecretLockSet = new Set((earliestRosterBackup.secretLockedIds || []).map(String));

    // 기존 학생은 현재 잠금 상태를 유지하고, 삭제되었다가 복원된 학생은 삭제 직전 잠금 상태를 복원한다(설계 원칙 ⑥).
    const mergedNormalLocks = new Set(preUndo.normalLocks.map(String).filter(id => restoredIdSet.has(id)));
    const mergedSecretLocks = new Set(preUndo.secretLocks.map(String).filter(id => restoredIdSet.has(id)));
    state.students.forEach(s => {
      const sid = String(s.id);
      if (!preUndo.studentIdSet.has(sid)) {
        if (backupNormalLockSet.has(sid)) mergedNormalLocks.add(sid);
        if (backupSecretLockSet.has(sid)) mergedSecretLocks.add(sid);
      }
    });
    state.lockedIds = [...mergedNormalLocks];
    state.secretLockedIds = [...mergedSecretLocks];
    state.hiddenSeatIds = [...(earliestRosterBackup.hiddenSeatIds || [])].filter(id => restoredIdSet.has(String(id)));
    state.pendingSecretNotices = [...(earliestRosterBackup.pendingSecretNotices || [])];
    if (earliestRosterBackup.hasDeleteGapNotice !== undefined) {
      state.hasDeleteGapNotice = Boolean(earliestRosterBackup.hasDeleteGapNotice);
    }
    if (earliestRosterBackup.rules) {
      state.rules = JSON.parse(JSON.stringify(earliestRosterBackup.rules));
    }
    if (earliestRosterBackup.secretPos) {
      state.secretPos = JSON.parse(JSON.stringify(earliestRosterBackup.secretPos));
    } else {
      state.secretPos = null;
      state.secretLockedIds = [];
      state.undoStackSecret = [];
    }

    // 비밀의 방에서 삭제/추가되어 양쪽 스택에 미러링된 스냅샷이었다면 반대쪽 스택의 대응 스냅샷도 양방향으로 제거한다(BUG-05).
    const otherStack = state.inSecretRoom ? state.undoStackNormal : state.undoStackSecret;
    if (Array.isArray(otherStack) && otherStack.length > 0) {
      const restoredPairIds = new Set();
      for (let k = targetIdx; k < stack.length; k++) {
        if (stack[k] && stack[k]._rosterMirrorPairId) {
          restoredPairIds.add(stack[k]._rosterMirrorPairId);
        }
      }
      if (restoredPairIds.size > 0) {
        let earliestOtherIdx = -1;
        for (let oi = 0; oi < otherStack.length; oi++) {
          if (otherStack[oi] && restoredPairIds.has(otherStack[oi]._rosterMirrorPairId)) {
            earliestOtherIdx = oi;
            break;
          }
        }
        if (earliestOtherIdx !== -1) {
          otherStack.length = earliestOtherIdx;
        }
      } else if (otherStack[otherStack.length - 1]._mirroredRosterOp) {
        otherStack.pop();
      }
    }
  }

  if (earliestPrevDefaultCols !== null && state.rules) {
    state.rules.defaultCols = earliestPrevDefaultCols;
  }

  return { earliestPrevDefaultCols, earliestRosterBackup, earliestRosterBackupIdx };
}

// STAGE 2: [기본 대형 정렬]·[현재 일반 자리 불러오기]·[고정석 동기화] 백업 고정석 목록 복원(BUG-04 방어)
function restoreLocksFromBackups(state, stack, targetIdx, earliestRosterBackupIdx) {
  let earliestLocksBackup = null;
  let earliestLocksBackupIdx = -1;
  const overwrittenLockSet = new Set();
  for (let k = targetIdx; k < stack.length; k++) {
    if (stack[k] && stack[k].locks && !earliestLocksBackup) {
      earliestLocksBackup = stack[k].locks;
      earliestLocksBackupIdx = k;
    }
    if (stack[k] && Array.isArray(stack[k].overwrittenLockIds)) {
      stack[k].overwrittenLockIds.forEach(id => overwrittenLockSet.add(String(id)));
    }
  }

  const curValidStudentIdsAfterRestore = new Set(state.students.map(s => String(s.id)));
  if (earliestLocksBackup && (earliestRosterBackupIdx === -1 || earliestLocksBackupIdx <= earliestRosterBackupIdx)) {
    if (state.inSecretRoom) {
      state.secretLockedIds = (earliestLocksBackup.secretLockedIds || []).filter(id => curValidStudentIdsAfterRestore.has(String(id)));
    } else {
      state.lockedIds = (earliestLocksBackup.lockedIds || []).filter(id => curValidStudentIdsAfterRestore.has(String(id)));
    }
  } else {
    state.lockedIds = (state.lockedIds || []).filter(id => curValidStudentIdsAfterRestore.has(String(id)));
    state.secretLockedIds = (state.secretLockedIds || []).filter(id => curValidStudentIdsAfterRestore.has(String(id)));
  }

  return overwrittenLockSet;
}

// STAGE 3: 잠금 학생 보호 좌표 치환(L1 resolveLockedSafePositions) + 비밀/일반방 정합성 · 룰렛/가리기 상태 복원
function applyRestoredPositionsAndSession(state, targetSnapshot, preUndo, earliestRosterBackup, overwrittenLockSet) {
  const fallbackRosterPos = earliestRosterBackup
    ? (state.inSecretRoom ? (earliestRosterBackup.secretPos || earliestRosterBackup.pos || {}) : (earliestRosterBackup.pos || {}))
    : {};
  const baseSnapPos = { ...fallbackRosterPos, ...(targetSnapshot.pos || {}) };

  const preUndoNormalLockSet = new Set(preUndo.normalLocks.map(String));
  const preUndoSecretLockSet = new Set(preUndo.secretLocks.map(String));
  const wasLockedBeforeUndoNormal = (id) => !overwrittenLockSet.has(String(id)) && preUndoNormalLockSet.has(String(id)) && isNormalSeatLocked(state, id);
  const wasLockedBeforeUndoSecret = (id) => !overwrittenLockSet.has(String(id)) && preUndoSecretLockSet.has(String(id)) && isSeatLocked(state, id);
  const defaultCols = Number(state.rules && state.rules.defaultCols) || 6;

  if (state.inSecretRoom) {
    state.secretPos = resolveLockedSafePositions(state.students, baseSnapPos, preUndo.secretPos, wasLockedBeforeUndoSecret);
    ensureAllStudentsHaveValidCoords(state.students, state.secretPos, defaultCols);
    const snapHadDeletedStudents = Object.keys(baseSnapPos).some(id => !preUndo.studentIdSet.has(String(id)));
    if (earliestRosterBackup && earliestRosterBackup.pos) {
      const mergedNormalPos = {};
      state.students.forEach(s => {
        const sid = String(s.id);
        if (preUndo.studentIdSet.has(sid) && Array.isArray(preUndo.normalPos[sid])) {
          mergedNormalPos[sid] = [...preUndo.normalPos[sid]];
        } else if (Array.isArray(earliestRosterBackup.pos[sid])) {
          mergedNormalPos[sid] = [...earliestRosterBackup.pos[sid]];
        }
      });
      state.pos = resolveLockedSafePositions(state.students, mergedNormalPos, preUndo.normalPos, wasLockedBeforeUndoNormal);
      ensureAllStudentsHaveValidCoords(state.students, state.pos, defaultCols);
    } else if (preUndo.secretMatchedBeforeUndo && snapHadDeletedStudents) {
      const validNormalCoordSet = new Set(
        state.students.map(s => state.pos[s.id]).filter(Boolean).map(p => `${p[0]},${p[1]}`)
      );
      const usedSecretCoords = new Set();
      const orphanStudentIds = [];
      state.students.forEach(s => {
        const sp = state.secretPos[s.id];
        const key = sp ? `${sp[0]},${sp[1]}` : '';
        if (sp && validNormalCoordSet.has(key) && !usedSecretCoords.has(key)) {
          usedSecretCoords.add(key);
        } else {
          orphanStudentIds.push(String(s.id));
        }
      });
      if (orphanStudentIds.length > 0) {
        const missingNormalCoords = state.students
          .map(s => state.pos[s.id])
          .filter(Boolean)
          .filter(p => !usedSecretCoords.has(`${p[0]},${p[1]}`));
        orphanStudentIds.forEach((sid, idx) => {
          if (missingNormalCoords[idx]) {
            state.secretPos[sid] = [...missingNormalCoords[idx]];
          }
        });
      }
    }
    checkSecretRoomLayoutMismatch(false);
    return;
  }

  state.pos = resolveLockedSafePositions(state.students, baseSnapPos, preUndo.normalPos, wasLockedBeforeUndoNormal);
  ensureAllStudentsHaveValidCoords(state.students, state.pos, defaultCols);
  const validRestoredIdSet = new Set(state.students.map(s => String(s.id)));
  if (Array.isArray(targetSnapshot.hiddenSeatIds)) {
    state.hiddenSeatIds = targetSnapshot.hiddenSeatIds.map(String).filter(id => validRestoredIdSet.has(id));
  } else if (!earliestRosterBackup) {
    state.hiddenSeatIds = [];
  }
  stopRouletteColumnAuto();
  state.rouletteActiveSession = Boolean(targetSnapshot.rouletteActiveSession && state.rouletteOpen);
  if (state.rouletteActiveSession) {
    const snapRemainingIds = new Set((targetSnapshot.rouletteRemainingStudents || []).map(s => String(s.id)));
    const inferredDrawn = Array.isArray(targetSnapshot.rouletteDrawnIds)
      ? targetSnapshot.rouletteDrawnIds.map(String)
      : state.students.map(s => String(s.id)).filter(id => !snapRemainingIds.has(id) && !isNormalSeatLocked(state, id));
    state.rouletteDrawnIds = inferredDrawn.filter(id => validRestoredIdSet.has(String(id)) && !isNormalSeatLocked(state, id));
    state.rouletteRemainingStudents = (targetSnapshot.rouletteRemainingStudents || []).filter(s => !isNormalSeatLocked(state, s.id));
    syncRouletteWithCurrentLocks();
  } else if (state.rouletteOpen) {
    state.rouletteDrawnIds = [];
    state.rouletteRemainingStudents = [];
    syncRouletteWithCurrentLocks();
  } else {
    state.rouletteRemainingStudents = [];
    state.rouletteTargetCoords = [];
    state.rouletteAssignedMap = {};
    state.rouletteDrawnIds = [];
  }
}

// STAGE 4: Undo 복원 후 UI·룰렛 안내·스토리지 커밋·팝오버 닫기 마무리
function finalizeUndoRestore(state, targetSnapshot, hasRuleChange, hasRosterBackup) {
  if (!hasRosterBackup) {
    state.pendingSecretNotices = [];
  }
  if (targetSnapshot.hasDeleteGapNotice !== undefined) {
    state.hasDeleteGapNotice = Boolean(targetSnapshot.hasDeleteGapNotice && state.students.length > 0);
  }
  state.selectedStudentId = null;
  updateUndoButtonState();
  updateSecretPresetIndicator();
  syncCustomLayoutBadgeUI();
  if (state.rouletteOpen) {
    const subEl = document.getElementById('rouletteResultSub');
    const mainEl = document.getElementById('rouletteResultMain');
    if (subEl && mainEl) {
      subEl.textContent = '이전 상태로 되돌렸습니다.';
      mainEl.textContent = `남은 인원 ${(state.rouletteRemainingStudents || []).length}명`;
    }
  }
  AppStore.commitChange({
    roster: true,
    classroom: true,
    animate: true,
    print: true,
    rules: hasRuleChange,
    dirty: true,
    save: true
  });
  closeStatusHistoryPopover();
  showToast(`'${targetSnapshot.actionLabel}' 이전 상태로 되돌렸습니다.`, 'info');
}

export function restoreHistoryAtIndex(targetIdx) {
  const state = AppStore.getState();
  const stack = state.inSecretRoom ? state.undoStackSecret : state.undoStackNormal;
  if (!stack || targetIdx < 0 || targetIdx >= stack.length) return;

  stopSequentialReveal();
  state.rouletteSessionToken = (state.rouletteSessionToken || 0) + 1;
  state.rouletteSpinning = false;

  const targetSnapshot = stack[targetIdx];
  const preUndo = {
    studentIdSet: new Set(state.students.map(s => String(s.id))),
    normalPos: JSON.parse(JSON.stringify(state.pos || {})),
    secretPos: state.secretPos ? JSON.parse(JSON.stringify(state.secretPos)) : null,
    normalLocks: [...state.lockedIds],
    secretLocks: [...state.secretLockedIds],
    secretMatchedBeforeUndo: state.inSecretRoom && doesSecretLayoutMatchCurrent(state)
  };

  const stage1 = restoreRosterAndMirrorStacks(state, stack, targetIdx, preUndo);
  const overwrittenLockSet = restoreLocksFromBackups(state, stack, targetIdx, stage1.earliestRosterBackupIdx);
  stack.length = targetIdx;

  applyRestoredPositionsAndSession(state, targetSnapshot, preUndo, stage1.earliestRosterBackup, overwrittenLockSet);
  finalizeUndoRestore(
    state,
    targetSnapshot,
    Boolean(stage1.earliestRosterBackup || stage1.earliestPrevDefaultCols !== null),
    Boolean(stage1.earliestRosterBackup)
  );
}
