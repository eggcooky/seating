// [L5] 다중학급(1~7 슬롯) 전환 · 메타 동기화 · 다중학급 묶음 복원 코디네이터
import { MULTI_CLASS_SLOT_COUNT } from '../core/constants.js';
import { encodeObfuscatedPayload } from '../domain/codec.js';
import { createEmptyClassState, createInitialState, isUnsupportedFutureSchemaPayload, validateBundleSlotPayload } from '../domain/schema.js';
import { stopSequentialReveal } from '../features/reveal-controller.js';
import { initRouletteSession, stopRouletteColumnAuto } from '../features/roulette-controller.js';
import {
  clearAllProtectedFutureSlotKeys,
  getActiveClassSlot,
  loadFromStorage,
  loadMultiClassMeta,
  normalizeSlotIndex,
  readSlotRawText,
  saveCustomLayouts,
  saveMultiClassMeta,
  saveToStorage,
  setActiveClassSlot,
  writeSlotRawText
} from '../infra/storage-io.js';
import { clearUndoHistory } from '../state/history-store.js';
import { AppStore } from '../state/store.js';
import { markDirty } from '../ui/dirty-indicator.js';
import { updateSecretPresetIndicator } from '../ui/secret-indicators.js';
import { showToast } from '../ui/toast.js';
import { syncCustomLayoutBadgeUI } from '../views/custom-layout-popover.js';
import { toggleSecretRoom } from './mode-coordinator.js';
import { discardRulesModalSession } from './rules-coordinator.js';

let _metaCache = null;

function ensureMeta() {
  if (!_metaCache) {
    _metaCache = loadMultiClassMeta();
  }
  return _metaCache;
}

// 좌측 사이드바의 다중학급 체크박스와 다중학급 드롭다운 UI를 현재 메타 상태와 동기화한다.
function syncMultiClassUI() {
  const meta = ensureMeta();
  const state = AppStore.getState();
  const toggleEl = document.getElementById('multiClassModeToggle');
  const toggleWrap = document.getElementById('multiClassToggleWrapper');
  const barEl = document.getElementById('multiClassControlBar');
  const selectEl = document.getElementById('multiClassSlotSelect');

  if (toggleEl) {
    toggleEl.checked = Boolean(meta.enabled);
  }
  if (toggleWrap) {
    if (state.inSecretRoom) {
      toggleWrap.classList.add('hidden');
      toggleWrap.classList.remove('flex');
    } else {
      toggleWrap.classList.remove('hidden');
      toggleWrap.classList.add('flex');
    }
  }
  if (barEl) {
    if (meta.enabled && !state.inSecretRoom) {
      barEl.classList.remove('hidden');
      barEl.classList.add('flex');
    } else {
      barEl.classList.add('hidden');
      barEl.classList.remove('flex');
    }
  }
  if (selectEl) {
    const active = getActiveClassSlot();
    for (let i = 0; i < MULTI_CLASS_SLOT_COUNT; i++) {
      const opt = selectEl.options[i];
      const titleText = meta.titles[i] || `학급 ${i + 1}`;
      if (opt) {
        opt.value = String(i + 1);
        opt.textContent = `${i + 1}. ${titleText}`;
      }
    }
    selectEl.value = String(active);
  }
}

// 상단 학급명 입력칸 수정 시 현재 슬롯의 드롭다운 표시명과 메타 키를 즉시 일치시킨다.
export function syncCurrentSlotTitle(newTitle) {
  const meta = ensureMeta();
  const slot = getActiveClassSlot();
  const clean = String(newTitle || '').trim().slice(0, 40) || `학급 ${slot}`;
  if (meta.titles[slot - 1] !== clean) {
    meta.titles[slot - 1] = clean;
    saveMultiClassMeta(meta);
  }
  syncMultiClassUI();
}

// 앱 시작 시 저장된 메타 키를 불러와 활성 슬롯을 복원하고 데이터를 로드한다.
export function initMultiClassOnBoot() {
  _metaCache = loadMultiClassMeta();
  const startSlot = _metaCache.enabled ? normalizeSlotIndex(_metaCache.activeSlot) : 1;
  setActiveClassSlot(startSlot);
  const fallbackTitle = _metaCache.titles[startSlot - 1] || (startSlot === 1 ? '우리 반 자리 배치표' : `학급 ${startSlot}`);
  const loaded = loadFromStorage(fallbackTitle);
  const bootBlockedFuture = Boolean(AppStore.getState()._futureSchemaBlocked);
  if (!loaded && startSlot > 1) {
    const emptyState = createEmptyClassState(fallbackTitle);
    AppStore.applyLoadedData(emptyState, fallbackTitle, true);
  }
  if (!bootBlockedFuture) {
    const curTitle = String(AppStore.getState().classTitle || fallbackTitle).trim().slice(0, 40) || fallbackTitle;
    _metaCache.titles[startSlot - 1] = curTitle;
  }
  _metaCache.activeSlot = startSlot;
  saveMultiClassMeta(_metaCache);
  syncMultiClassUI();
  return loaded || startSlot > 1;
}

// 다중학급 모드 체크박스 ON/OFF 전환 (OFF 시 2~7번 데이터는 삭제하지 않고 숨김만 유지한다).
export function toggleMultiClassMode(forceEnabled) {
  const meta = ensureMeta();
  const nextEnabled = typeof forceEnabled === 'boolean' ? forceEnabled : !meta.enabled;
  meta.enabled = nextEnabled;
  const curTitle = String(AppStore.getState().classTitle || '').trim().slice(0, 40);
  const activeSlot = getActiveClassSlot();
  if (curTitle) meta.titles[activeSlot - 1] = curTitle;
  saveMultiClassMeta(meta);
  syncMultiClassUI();

  if (nextEnabled) {
    showToast(`다중학급 모드가 활성화되었습니다. 좌측 드롭다운에서 ${MULTI_CLASS_SLOT_COUNT}개 학급을 전환할 수 있습니다.`, 'info');
  } else {
    showToast('다중학급 선택창을 숨겼습니다. (저장된 다른 학급 데이터는 유지됩니다)', 'info');
  }
}

// 6단계 안전 전환 파이프라인으로 학급 슬롯(1~7)을 전환한다.
export function switchClassSlot(targetSlot, options = {}) {
  const nextSlot = normalizeSlotIndex(targetSlot);
  const prevSlot = getActiveClassSlot();
  if (nextSlot === prevSlot && !options.forceReload) {
    syncMultiClassUI();
    return false;
  }

  const state = AppStore.getState();
  if (state.rouletteSpinning) {
    showToast('룰렛 추첨이 진행 중입니다. 추첨이 끝난 뒤 학급을 전환해 주세요.', 'warn');
    syncMultiClassUI();
    return false;
  }

  const meta = ensureMeta();

  // STEP 1 & 2: 대기 커밋 플러시 후 현재 슬롯을 난독화 저장
  AppStore.flushPendingCommit();
  const prevTitle = String(AppStore.getState().classTitle || '').trim().slice(0, 40) || `학급 ${prevSlot}`;
  meta.titles[prevSlot - 1] = prevTitle;
  if (!options.skipSavePrev) {
    saveToStorage(false);
  }

  // STEP 3: 세션 완전 초기화 (비밀의 방·순차 공개·룰렛·Undo·규칙 모달 백업)
  AppStore.clearPendingCommitTimer();
  stopSequentialReveal(false);
  stopRouletteColumnAuto();
  if (AppStore.getState().inSecretRoom) {
    toggleSecretRoom(false, true);
  }
  AppStore.resetTransientSession();
  clearUndoHistory();
  discardRulesModalSession();

  // STEP 4: 대상 슬롯 로드 (미사용 2~7번 슬롯은 0명 빈 학급으로 시작)
  setActiveClassSlot(nextSlot);
  const fallbackTitle = meta.titles[nextSlot - 1] || (nextSlot === 1 ? '우리 반 자리 배치표' : `학급 ${nextSlot}`);
  const loaded = loadFromStorage(fallbackTitle);
  const postLoadState = AppStore.getState();
  const loadHadFutureSchema = Boolean(postLoadState._futureSchemaBlocked);
  const loadHadCorrupted = Boolean(postLoadState._corruptedStorageRecovered);
  const loadCorruptedBackedUp = Boolean(postLoadState._corruptedBackupSaved);
  if (!loaded) {
    if (nextSlot === 1) {
      AppStore.applyLoadedData(createInitialState(), fallbackTitle, true);
    } else {
      AppStore.applyLoadedData(createEmptyClassState(fallbackTitle), fallbackTitle, true);
    }
  }

  // STEP 5: 메타 키 갱신 (상위 스키마 보호 슬롯은 기존 메타 학급명을 유지)
  const curState = AppStore.getState();
  const resolvedTitle = loadHadFutureSchema
    ? (meta.titles[nextSlot - 1] || fallbackTitle)
    : (String(curState.classTitle || fallbackTitle).trim().slice(0, 40) || fallbackTitle);
  meta.activeSlot = nextSlot;
  if (!loadHadFutureSchema) {
    meta.titles[nextSlot - 1] = resolvedTitle;
  }
  saveMultiClassMeta(meta);

  // STEP 6: 전체 뷰 · 제목 · 드롭다운 일괄 동기화
  const titleInput = document.getElementById('classTitleInput');
  if (titleInput) titleInput.value = curState.classTitle;
  if (curState.rouletteOpen) {
    initRouletteSession(false);
  }
  updateSecretPresetIndicator();
  markDirty(false);
  AppStore.syncViews({ roster: true, classroom: true, animate: false, print: true, rules: true });
  const savedTimeEl = document.getElementById('savedTimeText');
  if (savedTimeEl) {
    if (loadHadFutureSchema) {
      savedTimeEl.textContent = '상위 버전 데이터 보호 중 (자동저장 보류)';
    } else {
      savedTimeEl.textContent = curState.lastSavedAt ? `자동저장 (${curState.lastSavedAt})` : '새 학급 (자동저장 대기)';
    }
  }
  syncMultiClassUI();

  if (!options.silent) {
    if (loadHadFutureSchema) {
      showToast(`${nextSlot}번 슬롯은 상위 버전에서 저장된 데이터입니다. 원본을 유지했으니 최신 버전 프로그램을 실행해 주세요.`, 'warn');
    } else if (loadHadCorrupted) {
      showToast(
        loadCorruptedBackedUp
          ? `${nextSlot}번 슬롯의 저장 데이터가 손상되어 백업 키에 보관하고 기본 상태로 시작했습니다.`
          : `${nextSlot}번 슬롯의 저장 데이터가 손상되었으나 저장 공간이 부족해 원본을 유지한 채 기본 상태로 시작했습니다.`,
        'warn'
      );
    } else {
      const countInfo = curState.students.length === 0 ? ' (빈 학급 · 명단을 입력하거나 엑셀에서 붙여넣으세요)' : '';
      showToast(`${nextSlot}번 슬롯 '${resolvedTitle}'(으)로 전환했습니다.${countInfo}`, 'info');
    }
  }
  return true;
}

// 다중학급 묶음 백업의 유효성·상위 스키마 여부·복원 시 비워질 기존 슬롯 목록을 비파괴적으로 사전 검사한다.
export function inspectMultiClassBundleData(bundle, readSlotFn = readSlotRawText) {
  const emptyResult = { ok: false, validatedSlots: new Map(), clearedExistingSlots: [], existingStoredCount: 0, hasFutureSchema: false };
  if (!bundle || bundle._multiClassBundle !== true || !bundle.slots || typeof bundle.slots !== 'object' || Array.isArray(bundle.slots)) {
    return emptyResult;
  }

  // [H-01] 기존 1~7번 슬롯을 수정하기 전에 모든 슬롯의 스키마 버전·좌표 맵·유효 슬롯 1개 이상 여부를 선검증한다.
  const validatedSlots = new Map();
  let hasFutureSchema = false;
  for (let slot = 1; slot <= MULTI_CLASS_SLOT_COUNT; slot++) {
    const rawSlot = bundle.slots[String(slot)];
    if (rawSlot === null || rawSlot === undefined) continue;
    if (isUnsupportedFutureSchemaPayload(rawSlot)) {
      hasFutureSchema = true;
      return { ...emptyResult, hasFutureSchema: true };
    }
    const migrated = validateBundleSlotPayload(rawSlot);
    if (!migrated) {
      return emptyResult;
    }
    validatedSlots.set(slot, migrated);
  }
  if (validatedSlots.size === 0) {
    return emptyResult;
  }

  const clearedExistingSlots = [];
  let existingStoredCount = 0;
  for (let slot = 1; slot <= MULTI_CLASS_SLOT_COUNT; slot++) {
    const raw = readSlotFn(slot);
    if (raw && String(raw).trim()) {
      existingStoredCount++;
      if (!validatedSlots.has(slot)) {
        clearedExistingSlots.push(slot);
      }
    }
  }
  return { ok: true, validatedSlots, clearedExistingSlots, existingStoredCount, hasFutureSchema };
}

// 다중학급 전체 묶음 백업 JSON을 1~7번 슬롯에 복원하고 활성 슬롯을 즉시 반영한다.
export function applyMultiClassBundleData(bundle) {
  const inspected = inspectMultiClassBundleData(bundle);
  if (!inspected.ok) {
    return false;
  }
  const { validatedSlots } = inspected;

  AppStore.flushPendingCommit();
  AppStore.clearPendingCommitTimer();
  stopSequentialReveal(false);
  stopRouletteColumnAuto();
  if (AppStore.getState().inSecretRoom) {
    toggleSecretRoom(false, true);
  }
  AppStore.resetTransientSession();
  clearUndoHistory();
  discardRulesModalSession();
  if (!AppStore.isRunningSelfDiagnostics()) {
    clearAllProtectedFutureSlotKeys();
  }

  const meta = ensureMeta();
  let restoredCount = 0;
  let allPersisted = true;

  for (let slot = 1; slot <= MULTI_CLASS_SLOT_COUNT; slot++) {
    const slotData = validatedSlots.get(slot);
    const fallbackTitle = (Array.isArray(bundle.titles) && typeof bundle.titles[slot - 1] === 'string' && bundle.titles[slot - 1].trim())
      ? bundle.titles[slot - 1].trim().slice(0, 40)
      : `학급 ${slot}`;
    if (slotData) {
      const encoded = encodeObfuscatedPayload(slotData);
      if (!writeSlotRawText(slot, encoded)) allPersisted = false;
      const t = (typeof slotData.classTitle === 'string' && slotData.classTitle.trim())
        ? slotData.classTitle.trim().slice(0, 40)
        : fallbackTitle;
      meta.titles[slot - 1] = t;
      restoredCount++;
    } else {
      writeSlotRawText(slot, null);
      meta.titles[slot - 1] = fallbackTitle;
    }
  }

  const targetSlot = normalizeSlotIndex(bundle.activeSlot || 1);
  meta.enabled = bundle.multiClassEnabled !== undefined ? Boolean(bundle.multiClassEnabled) : (restoredCount > 1);
  meta.activeSlot = targetSlot;
  if (!saveMultiClassMeta(meta)) allPersisted = false;

  if (Array.isArray(bundle.customLayouts)) {
    const customSaveRes = saveCustomLayouts(bundle.customLayouts);
    if (!customSaveRes.ok) allPersisted = false;
  }
  syncCustomLayoutBadgeUI();

  switchClassSlot(targetSlot, { forceReload: true, skipSavePrev: true, silent: true });
  if (allPersisted) {
    showToast(`다중학급 전체 백업(${restoredCount}개 학급)을 복원했습니다.`, 'success');
  } else {
    showToast(`다중학급 전체 백업(${restoredCount}개 학급)을 불러왔으나 브라우저 저장 공간 부족으로 임시 세션으로만 유지됩니다.`, 'warn');
  }
  return true;
}

// 다른 탭에서 메타 키가 바뀌었을 때 현재 탭의 드롭다운 제목 목록만 조용히 동기화한다.
export function refreshMultiClassMetaFromStorage() {
  _metaCache = loadMultiClassMeta();
  syncMultiClassUI();
}
