// [L5 Binder] 사이드바 · 제목 · 다중학급 · 시점 · 배치 · 되돌리기 · 크게 보기 이벤트 바인더
import { toggleLargeViewMode } from '../../features/reveal-controller.js';
import { addNewStudent, sortRosterListByNumber, toggleRosterNumEditMode } from '../../features/roster-actions.js';
import {
  applyCustomLayoutById,
  applyDefaultGridAlignment,
  deleteCustomLayoutById,
  renameCustomLayoutById,
  saveCurrentCustomLayout
} from '../../features/seat-actions.js';
import { arrangeByStudentNumber, handleShuffleButtonClick } from '../../features/seating-actions.js';
import { AppStore } from '../../state/store.js';
import { isRouletteBlockingEdit } from '../../ui/guards.js';
import { showToast } from '../../ui/toast.js';
import {
  bindCustomLayoutPopoverHandlers,
  closeCustomLayoutPopover,
  submitCustomLayoutSaveFromPopover,
  syncCustomLayoutBadgeUI,
  toggleCustomLayoutPopover
} from '../../views/custom-layout-popover.js';
import { closeStatusHistoryPopover, toggleStatusHistoryPopover } from '../../views/history-popover.js';
import { toggleLeftSidebar } from '../../views/toolbar-ui.js';
import { restoreHistoryAtIndex } from '../history-coordinator.js';
import {
  switchClassSlot,
  syncCurrentSlotTitle,
  toggleMultiClassMode
} from '../multiclass-coordinator.js';

export function bindClassroomControlEvents(ctx) {
  // 좌측 사이드바 접기 및 펼치기 버튼
  document.getElementById('collapseSidebarBtn').addEventListener('click', () => {
    toggleLeftSidebar(true);
  });
  document.getElementById('expandSidebarBtn').addEventListener('click', () => {
    toggleLeftSidebar(false);
  });

  // 학급 제목 입력 (연속 타이핑 중 인쇄 뷰 및 스토리지 기록 디바운싱)
  const titleInput = ctx && ctx.titleInput ? ctx.titleInput : document.getElementById('classTitleInput');
  titleInput.value = AppStore.getState().classTitle;
  titleInput.addEventListener('input', (e) => {
    AppStore.getState().classTitle = e.target.value;
    syncCurrentSlotTitle(e.target.value);
    AppStore.scheduleDebouncedCommit(200);
  });

  // 다중학급 토글 및 7슬롯 드롭다운
  const multiClassToggle = document.getElementById('multiClassModeToggle');
  if (multiClassToggle) {
    multiClassToggle.addEventListener('change', (e) => toggleMultiClassMode(Boolean(e.target.checked)));
  }
  const multiClassSelect = document.getElementById('multiClassSlotSelect');
  if (multiClassSelect) {
    multiClassSelect.addEventListener('change', (e) => switchClassSlot(Number(e.target.value)));
  }

  // 기본 대형 정렬 · 내 책상 대형 적용 및 고정석 처리 확인 모달
  const alignLockConfirmModalEl = document.getElementById('alignLockConfirmModal');
  let pendingAlignAction = null;
  const closeAlignLockConfirmModal = () => {
    pendingAlignAction = null;
    if (alignLockConfirmModalEl) {
      alignLockConfirmModalEl.classList.add('hidden');
      alignLockConfirmModalEl.classList.remove('flex');
    }
  };
  const executeLayoutAction = (action, locksBefore = null) => {
    if (action && action.type === 'custom' && action.layoutId) {
      applyCustomLayoutById(action.layoutId, true, locksBefore);
    } else {
      const state = AppStore.getState();
      const prevCols = Number(state.rules && state.rules.defaultCols) || 6;
      const nextCols = action && action.targetCols
        ? Math.min(8, Math.max(5, Number(action.targetCols) || 6))
        : prevCols;
      if (state.rules) state.rules.defaultCols = nextCols;
      applyDefaultGridAlignment(true, locksBefore, prevCols !== nextCols ? prevCols : null);
      syncCustomLayoutBadgeUI();
    }
  };
  const requestLayoutApplyWithLockCheck = (action) => {
    const state = AppStore.getState();
    if (isRouletteBlockingEdit()) return;
    if (state.students.length === 0) {
      if (action && action.type === 'default' && action.targetCols && state.rules) {
        const nextCols = Math.min(8, Math.max(5, Number(action.targetCols) || 6));
        if (state.rules.defaultCols !== nextCols) {
          state.rules.defaultCols = nextCols;
          AppStore.commitChange({ rules: true, dirty: true, save: true });
        }
        syncCustomLayoutBadgeUI();
        showToast(`기본 책상 대형을 ${nextCols}열로 미리 설정했습니다.`, 'info');
      }
      return;
    }
    const activeLocks = state.inSecretRoom ? state.secretLockedIds : state.lockedIds;
    if (Array.isArray(activeLocks) && activeLocks.length > 0 && alignLockConfirmModalEl) {
      pendingAlignAction = action;
      const descEl = document.getElementById('alignLockConfirmDesc');
      if (descEl) {
        if (action && action.type === 'custom') {
          descEl.textContent = `현재 자물쇠(🔒)로 고정된 학생이 ${activeLocks.length}명 있습니다. '${action.layoutName}' 대형 적용 시 고정된 학생의 자리를 어떻게 처리할까요?`;
        } else {
          const colsSuffix = action && action.targetCols ? `(${action.targetCols}열)` : '';
          descEl.textContent = `현재 자물쇠(🔒)로 고정된 학생이 ${activeLocks.length}명 있습니다. 기본 대형 정렬${colsSuffix} 시 고정된 학생의 자리를 어떻게 처리할까요?`;
        }
      }
      alignLockConfirmModalEl.classList.remove('hidden');
      alignLockConfirmModalEl.classList.add('flex');
      return;
    }
    executeLayoutAction(action, null);
  };
  if (ctx && ctx.modalClosers) {
    ctx.modalClosers.alignLockConfirmModal = closeAlignLockConfirmModal;
  }
  document.getElementById('alignCancelModalBtn').addEventListener('click', closeAlignLockConfirmModal);
  alignLockConfirmModalEl.addEventListener('click', (e) => {
    if (e.target === alignLockConfirmModalEl) closeAlignLockConfirmModal();
  });
  document.getElementById('alignKeepLocksBtn').addEventListener('click', () => {
    const action = pendingAlignAction || { type: 'default' };
    closeAlignLockConfirmModal();
    executeLayoutAction(action, null);
  });
  document.getElementById('alignUnlockAllBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    const action = pendingAlignAction || { type: 'default' };
    closeAlignLockConfirmModal();
    const locksBefore = { lockedIds: [...state.lockedIds], secretLockedIds: [...state.secretLockedIds] };
    if (state.inSecretRoom) {
      state.secretLockedIds = [];
    } else {
      state.lockedIds = [];
    }
    executeLayoutAction(action, locksBefore);
  });

  // 기본 대형 열 수 선택 버튼 (5열~8열, 책상 대형 팝오버 상단)
  document.querySelectorAll('.default-cols-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const targetCols = Math.min(8, Math.max(5, Number(btn.getAttribute('data-default-cols')) || 6));
      closeCustomLayoutPopover();
      requestLayoutApplyWithLockCheck({ type: 'default', targetCols });
    });
  });

  // 내 책상 대형(저장 · 적용 · 삭제) 팝오버 이벤트 바인딩
  bindCustomLayoutPopoverHandlers({
    onApplyCustom: (layout) => {
      closeCustomLayoutPopover();
      if (!layout || !layout.id) return;
      requestLayoutApplyWithLockCheck({ type: 'custom', layoutId: layout.id, layoutName: layout.name });
    },
    onSaveCustom: (rawName) => {
      const res = saveCurrentCustomLayout(rawName, true);
      syncCustomLayoutBadgeUI();
      return res;
    },
    onRenameCustom: (layoutId, rawNewName) => {
      const res = renameCustomLayoutById(layoutId, rawNewName, true);
      syncCustomLayoutBadgeUI();
      return res;
    },
    onDeleteCustom: (layoutId) => {
      const res = deleteCustomLayoutById(layoutId, true);
      syncCustomLayoutBadgeUI();
      return res;
    }
  });
  const customLayoutToggleBtn = document.getElementById('customLayoutToggleBtn');
  if (customLayoutToggleBtn) {
    customLayoutToggleBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      closeStatusHistoryPopover();
      toggleCustomLayoutPopover();
    });
  }
  const customLayoutSaveBtn = document.getElementById('customLayoutSaveBtn');
  if (customLayoutSaveBtn) {
    customLayoutSaveBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      submitCustomLayoutSaveFromPopover();
    });
  }
  const customLayoutNameInput = document.getElementById('customLayoutNameInput');
  if (customLayoutNameInput) {
    customLayoutNameInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        if (e.isComposing || e.keyCode === 229) return;
        e.preventDefault();
        submitCustomLayoutSaveFromPopover();
      }
    });
  }

  // 되돌리기 버튼 및 상태 표시줄 히스토리 팝업
  document.getElementById('undoSeatBtn').addEventListener('click', () => {
    const state = AppStore.getState();
    const stack = state.inSecretRoom ? state.undoStackSecret : state.undoStackNormal;
    if (!stack || stack.length === 0) return;
    restoreHistoryAtIndex(stack.length - 1);
  });
  document.getElementById('modeStatusPill').addEventListener('click', (e) => {
    e.stopPropagation();
    closeCustomLayoutPopover();
    toggleStatusHistoryPopover();
  });
  document.addEventListener('click', (e) => {
    const wrapper = document.getElementById('statusHistoryWrapper');
    if (wrapper && !wrapper.contains(e.target)) {
      closeStatusHistoryPopover();
    }
    const layoutWrap = document.getElementById('customLayoutWrapper');
    if (layoutWrap && !layoutWrap.contains(e.target)) {
      closeCustomLayoutPopover();
    }
  });

  // 학생 추가, 반·번호 직접 편집 토글 및 명렬표 번호순 정리, 게시 시점 전환, 성별 색상, 랜덤·번호순 배치, 크게 보기
  document.getElementById('addStudentBtn').addEventListener('click', addNewStudent);
  const toggleRosterNumEditBtn = document.getElementById('toggleRosterNumEditBtn');
  if (toggleRosterNumEditBtn) {
    toggleRosterNumEditBtn.addEventListener('click', () => toggleRosterNumEditMode());
  }
  const sortRosterByNumBtn = document.getElementById('sortRosterByNumBtn');
  if (sortRosterByNumBtn) {
    sortRosterByNumBtn.addEventListener('click', sortRosterListByNumber);
  }
  const doneRosterNumEditBtn = document.getElementById('doneRosterNumEditBtn');
  if (doneRosterNumEditBtn) {
    doneRosterNumEditBtn.addEventListener('click', () => toggleRosterNumEditMode(false));
  }
  document.getElementById('viewStudentBtn').addEventListener('click', () => {
    AppStore.getState().viewOrientation = 'student';
    AppStore.commitChange({ classroom: true, animate: true, print: true, dirty: true, save: true });
  });
  document.getElementById('viewTeacherBtn').addEventListener('click', () => {
    AppStore.getState().viewOrientation = 'teacher';
    AppStore.commitChange({ classroom: true, animate: true, print: true, dirty: true, save: true });
  });

  const genderToggle = document.getElementById('showGenderColorToggle');
  genderToggle.checked = AppStore.getState().showGenderColor;
  genderToggle.addEventListener('change', (e) => {
    AppStore.getState().showGenderColor = e.target.checked;
    AppStore.commitChange({ classroom: true, animate: false, dirty: true, save: true });
  });

  document.getElementById('randomShuffleBtn').addEventListener('click', (e) => {
    handleShuffleButtonClick(e);
  });
  document.getElementById('numberOrderBtn').addEventListener('click', arrangeByStudentNumber);
  document.getElementById('toggleLargeViewBtn').addEventListener('click', () => {
    toggleLargeViewMode();
  });
}
