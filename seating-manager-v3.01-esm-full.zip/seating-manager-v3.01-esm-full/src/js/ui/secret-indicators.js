// [L3] 비밀의 방 정합성 경고 배너 · 고정석 동기화 인디케이터 · 비밀 알림 모달
import { getLockedSeatConflicts, hasValidSecretPreset, isNormalSeatLocked } from '../domain/seat-queries.js';
import { AppStore } from '../state/store.js';
import { showToast } from './toast.js';

export function checkSecretRoomLayoutMismatch(showWarningToast = false) {
  const state = AppStore.getState();
  const warnBox = document.getElementById('secretLayoutMismatchWarning');
  const lockWarnBox = document.getElementById('secretLockedSeatWarning');
  const lockWarnText = document.getElementById('secretLockedSeatWarningText');
  if (!warnBox) return;

  if (!state.inSecretRoom || !hasValidSecretPreset(state)) {
    warnBox.classList.add('hidden');
    if (lockWarnBox) lockWarnBox.classList.add('hidden');
    return;
  }

  // 일반 화면과 비밀의 방의 책상 좌표 일치 여부를 확인한다.
  const normalCoords = state.students.map(s => state.pos[s.id]).filter(Boolean).map(p => `${p[0]},${p[1]}`).sort();
  const secretCoords = state.students.map(s => state.secretPos[s.id]).filter(Boolean).map(p => `${p[0]},${p[1]}`).sort();
  let gridMatches = normalCoords.length === secretCoords.length;
  if (gridMatches) {
    for (let i = 0; i < normalCoords.length; i++) {
      if (normalCoords[i] !== secretCoords[i]) {
        gridMatches = false;
        break;
      }
    }
  }

  if (!gridMatches) {
    warnBox.classList.remove('hidden');
    if (showWarningToast) {
      showToast('⚠️ 일반 배치와 비밀의 방 배치의 책상 배열이 달라 적용이 안 됩니다!', 'warn');
    }
  } else {
    warnBox.classList.add('hidden');
  }

  // 일반 화면의 고정석 위치와 비밀의 방 좌석 위치 간 충돌 여부를 확인한다.
  if (lockWarnBox && lockWarnText) {
    const lockedConflicts = getLockedSeatConflicts(state);
    const normalLockedStudents = state.students.filter(s => isNormalSeatLocked(state, s.id));
    if (lockedConflicts.length > 0) {
      lockWarnBox.classList.remove('hidden');
      lockWarnText.textContent = `🔒 일반 화면에서 잠금(고정)된 학생(${lockedConflicts.join(', ')})의 위치가 비밀의 방과 달라 비밀의 방 배치가 적용되지 않습니다! 일반 화면에서 잠금을 해제하거나 [현재 일반 자리 불러오기]를 눌러주세요.`;
      if (showWarningToast) {
        showToast(`🔒 일반 화면의 고정 자리(${lockedConflicts.join(', ')})와 위치가 달라 비밀 배치가 적용되지 않습니다!`, 'warn');
      }
    } else if (normalLockedStudents.length > 0) {
      lockWarnBox.classList.remove('hidden');
      const lockedNames = normalLockedStudents.map(s => s.name).join(', ');
      lockWarnText.textContent = `🔒 일반 화면에 잠금(고정)된 학생(${lockedNames})이 있습니다. 비밀의 방에서 해당 학생을 다른 자리로 옮기면 비밀 배치가 적용되지 않습니다.`;
    } else {
      lockWarnBox.classList.add('hidden');
    }
  }
}

export function updateSecretPresetIndicator() {
  const state = AppStore.getState();
  checkSecretRoomLayoutMismatch(false);
  const syncBtn = document.getElementById('syncNormalLocksToSecretBtn');
  if (syncBtn) {
    const normalLocks = Array.isArray(state.lockedIds) ? state.lockedIds.map(String) : [];
    const hasNormalLocks = normalLocks.length > 0;
    if (state.inSecretRoom && hasNormalLocks) {
      syncBtn.classList.remove('hidden');
      const secretLockSet = new Set((state.secretLockedIds || []).map(String));
      const alreadyIdentical = hasValidSecretPreset(state) && normalLocks.every(lid => {
        const np = state.pos[lid];
        const sp = state.secretPos[lid];
        return Array.isArray(np) && Array.isArray(sp) && np[0] === sp[0] && np[1] === sp[1] && secretLockSet.has(lid);
      });
      syncBtn.disabled = alreadyIdentical;
      if (alreadyIdentical) {
        syncBtn.className = 'w-full mt-1.5 py-1.5 px-2.5 rounded-lg bg-slate-800/80 text-[11px] font-bold text-slate-400 border border-slate-700 opacity-50 cursor-not-allowed transition flex items-center justify-center gap-1.5';
        syncBtn.innerHTML = '<span>🔒 일반방 고정석과 동일함</span>';
      } else {
        syncBtn.className = 'w-full mt-1.5 py-1.5 px-2.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-[11px] font-bold text-amber-300 border border-amber-500/40 transition flex items-center justify-center gap-1.5';
        syncBtn.innerHTML = '<span>🔒 일반방 고정석 동기화</span>';
      }
    } else {
      syncBtn.classList.add('hidden');
    }
  }
  const gapDot = document.getElementById('alignGapAlertDot');
  const showGap = Boolean(state.hasDeleteGapNotice && state.students.length > 0);
  if (gapDot) {
    if (showGap) {
      gapDot.classList.remove('hidden');
    } else {
      gapDot.classList.add('hidden');
    }
  }
  const innerGapDot = document.getElementById('customLayoutDefaultGapDot');
  if (innerGapDot) {
    if (showGap) {
      innerGapDot.classList.remove('hidden');
    } else {
      innerGapDot.classList.add('hidden');
    }
  }
}

// 비밀의 방 전용 알림 모달에 안내 문구를 표시한다.
export function showSecretNoticePopup(messages) {
  const modal = document.getElementById('secretNoticeModal');
  const list = document.getElementById('secretNoticeList');
  if (!modal || !list || !Array.isArray(messages) || messages.length === 0) return;
  list.innerHTML = '';
  messages.forEach(msg => {
    const p = document.createElement('p');
    p.textContent = '• ' + msg;
    list.appendChild(p);
  });
  modal.classList.remove('hidden');
  modal.classList.add('flex');
}
