// [L3] 로컬 저장소(localStorage) · 7+1 슬롯 라우팅 · 파일 저장/다운로드 어댑터
import {
  CURRENT_SCHEMA_VERSION,
  CUSTOM_LAYOUTS_STORAGE_KEY,
  DIAG_SANDBOX_STORAGE_KEY,
  HELP_GUIDE_SEEN_KEY,
  LEGACY_STORAGE_KEYS,
  MULTI_CLASS_META_KEY,
  MULTI_CLASS_SLOT_COUNT,
  SECRET_HELP_GUIDE_SEEN_KEY,
  STORAGE_KEY
} from '../core/constants.js';
import { sanitizeFileName } from '../core/utils.js';
import {
  encodeMultiClassBundle,
  encodeObfuscatedPayload,
  isSimpleObfuscatedText,
  parseSeatFileText
} from '../domain/codec.js';
import { sanitizeCustomLayoutsList } from '../domain/custom-layouts.js';
import { isUnsupportedFutureSchemaPayload, validateBundleSlotPayload } from '../domain/schema.js';
import { AppStore } from '../state/store.js';
import { markDirty } from '../ui/dirty-indicator.js';
import { updateSecretPresetIndicator } from '../ui/secret-indicators.js';
import { showToast } from '../ui/toast.js';

let _activeClassSlot = 1;
let _diagStorageSandboxActive = false;
const _protectedFutureSlotKeys = new Set();

export function setDiagStorageSandboxActive(active) {
  _diagStorageSandboxActive = Boolean(active);
}

export function isDiagStorageSandboxActive() {
  return _diagStorageSandboxActive;
}

export function isStorageKeyProtectedFutureSchema(key = getActiveStorageKey()) {
  return _protectedFutureSlotKeys.has(String(key || ''));
}

export function clearProtectedFutureSlotKey(key = getActiveStorageKey()) {
  _protectedFutureSlotKeys.delete(String(key || ''));
}

export function clearAllProtectedFutureSlotKeys() {
  _protectedFutureSlotKeys.clear();
}

function logStorageWarning(message, err) {
  if (_diagStorageSandboxActive || AppStore.isRunningSelfDiagnostics()) return;
  if (typeof console !== 'undefined' && typeof console.warn === 'function') {
    if (err !== undefined) console.warn(message, err);
    else console.warn(message);
  }
}
const _memoryStorageFallback = Object.create(null);

function safeStorageGet(key) {
  if (Object.prototype.hasOwnProperty.call(_memoryStorageFallback, key)) {
    return _memoryStorageFallback[key];
  }
  try {
    return localStorage.getItem(key);
  } catch (e) {
    return null;
  }
}

function safeStorageSet(key, val) {
  try {
    localStorage.setItem(key, val);
    delete _memoryStorageFallback[key];
    return true;
  } catch (e) {
    _memoryStorageFallback[key] = String(val);
    return false;
  }
}

function safeStorageRemove(key) {
  delete _memoryStorageFallback[key];
  try {
    localStorage.removeItem(key);
  } catch (e) {}
}

export function normalizeSlotIndex(slot) {
  const n = Math.round(Number(slot));
  if (!Number.isFinite(n) || n < 1 || n > MULTI_CLASS_SLOT_COUNT) return 1;
  return n;
}

export function getActiveClassSlot() {
  return _activeClassSlot;
}

export function setActiveClassSlot(slot) {
  _activeClassSlot = normalizeSlotIndex(slot);
  return _activeClassSlot;
}

export function getSlotStorageKey(slot) {
  const s = normalizeSlotIndex(slot);
  return s === 1 ? STORAGE_KEY : `${STORAGE_KEY}_slot_${s}`;
}

// 자가진단 실행 중에는 자가진단 전용 샌드박스 키로 자동 라우팅해 사용자 1~7번 학급 쓰기를 원천 차단한다.
export function getActiveStorageKey() {
  if (_diagStorageSandboxActive || AppStore.isRunningSelfDiagnostics()) {
    return DIAG_SANDBOX_STORAGE_KEY;
  }
  return getSlotStorageKey(_activeClassSlot);
}

// 자가진단 종료 시 자가진단 전용 샌드박스 키와 파생 손상 백업·사용자 대형 테스트 키를 함께 삭제한다.
export function cleanupDiagSandboxStorage() {
  _protectedFutureSlotKeys.delete(DIAG_SANDBOX_STORAGE_KEY);
  safeStorageRemove(DIAG_SANDBOX_STORAGE_KEY);
  safeStorageRemove(`${DIAG_SANDBOX_STORAGE_KEY}_corrupted_backup`);
  safeStorageRemove(`${DIAG_SANDBOX_STORAGE_KEY}_custom_layouts`);
}

function getActiveCustomLayoutsKey() {
  if (_diagStorageSandboxActive || AppStore.isRunningSelfDiagnostics()) {
    return `${DIAG_SANDBOX_STORAGE_KEY}_custom_layouts`;
  }
  return CUSTOM_LAYOUTS_STORAGE_KEY;
}

// 저장된 사용자 제작 책상 대형 목록(1~7반 공용)을 읽어 검증 후 반환한다.
export function loadCustomLayouts() {
  try {
    const raw = safeStorageGet(getActiveCustomLayoutsKey());
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return sanitizeCustomLayoutsList(parsed);
  } catch (e) {
    return [];
  }
}

// 사용자 제작 책상 대형 목록을 검증 후 저장한다 (자가진단 실행 중에는 샌드박스 키로 격리).
export function saveCustomLayouts(rawList) {
  const clean = sanitizeCustomLayoutsList(rawList);
  try {
    const ok = safeStorageSet(getActiveCustomLayoutsKey(), JSON.stringify(clean));
    return { ok, layouts: clean };
  } catch (e) {
    return { ok: false, layouts: clean };
  }
}

// 첫 실행 도움말 안내 열람 여부 조회 (file:// 보안 정책·프라이빗 모드 안전 폴백)
export function hasSeenHelpGuide() {
  return safeStorageGet(HELP_GUIDE_SEEN_KEY) === '1';
}

// 첫 실행 도움말 재표시 방지 플래그 저장 (자가진단 실행 중에는 쓰기 차단)
export function markHelpGuideSeen() {
  if (_diagStorageSandboxActive || AppStore.isRunningSelfDiagnostics()) return false;
  return safeStorageSet(HELP_GUIDE_SEEN_KEY, '1');
}

// 비밀의 방 전용 도움말 열람 여부 조회
export function hasSeenSecretHelpGuide() {
  return safeStorageGet(SECRET_HELP_GUIDE_SEEN_KEY) === '1';
}

// 비밀의 방 전용 도움말 재표시 방지 플래그 저장 (자가진단 실행 중에는 쓰기 차단)
export function markSecretHelpGuideSeen() {
  if (_diagStorageSandboxActive || AppStore.isRunningSelfDiagnostics()) return false;
  return safeStorageSet(SECRET_HELP_GUIDE_SEEN_KEY, '1');
}

function getDefaultMultiClassMeta() {
  return {
    enabled: false,
    activeSlot: 1,
    titles: Array.from({ length: MULTI_CLASS_SLOT_COUNT }, (_, idx) => `학급 ${idx + 1}`)
  };
}

export function loadMultiClassMeta() {
  const fallback = getDefaultMultiClassMeta();
  try {
    const raw = safeStorageGet(MULTI_CLASS_META_KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return fallback;
    const titles = Array.from({ length: MULTI_CLASS_SLOT_COUNT }, (_, idx) => {
      const candidate = Array.isArray(parsed.titles) ? parsed.titles[idx] : '';
      const clean = typeof candidate === 'string' ? candidate.trim().slice(0, 40) : '';
      return clean || `학급 ${idx + 1}`;
    });
    return {
      enabled: Boolean(parsed.enabled),
      activeSlot: normalizeSlotIndex(parsed.activeSlot),
      titles
    };
  } catch (e) {
    return fallback;
  }
}

export function saveMultiClassMeta(meta) {
  if (_diagStorageSandboxActive || AppStore.isRunningSelfDiagnostics()) return false;
  const base = getDefaultMultiClassMeta();
  const safeMeta = {
    enabled: Boolean(meta && meta.enabled),
    activeSlot: normalizeSlotIndex(meta && meta.activeSlot),
    titles: Array.from({ length: MULTI_CLASS_SLOT_COUNT }, (_, idx) => {
      const candidate = meta && Array.isArray(meta.titles) ? meta.titles[idx] : '';
      const clean = typeof candidate === 'string' ? candidate.trim().slice(0, 40) : '';
      return clean || base.titles[idx];
    })
  };
  try {
    return safeStorageSet(MULTI_CLASS_META_KEY, JSON.stringify(safeMeta));
  } catch (e) {
    return false;
  }
}

export function readSlotRawText(slot) {
  try {
    return safeStorageGet(getSlotStorageKey(slot));
  } catch (e) {
    return null;
  }
}

export function writeSlotRawText(slot, rawText) {
  if (_diagStorageSandboxActive || AppStore.isRunningSelfDiagnostics()) return false;
  try {
    if (rawText === null || rawText === undefined) {
      safeStorageRemove(getSlotStorageKey(slot));
      return true;
    }
    return safeStorageSet(getSlotStorageKey(slot), String(rawText));
  } catch (e) {
    return false;
  }
}

export function getObfuscatedPayload() {
  const state = AppStore.getState();
  return encodeObfuscatedPayload(AppStore.getPersistedState(state));
}

export function saveToStorage(showNotification = false) {
  const state = AppStore.getState();
  const targetKey = getActiveStorageKey();
  if (_protectedFutureSlotKeys.has(targetKey)) {
    const savedTimeEl = document.getElementById('savedTimeText');
    if (savedTimeEl) {
      savedTimeEl.textContent = '상위 버전 데이터 보호 중 (자동저장 보류)';
    }
    if (showNotification) {
      showToast('상위 버전에서 저장된 데이터를 보호하기 위해 자동저장을 보류했습니다. 최신 버전 프로그램을 실행해 주세요.', 'warn');
    }
    return false;
  }
  const now = new Date();
  const timeStr = now.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  state.lastSavedAt = timeStr;
  const payloadStr = getObfuscatedPayload();
  const savedOk = safeStorageSet(targetKey, payloadStr);
  const savedTimeEl = document.getElementById('savedTimeText');
  if (savedTimeEl) {
    savedTimeEl.textContent = savedOk ? `자동저장 (${timeStr})` : '임시 세션 (파일 저장 권장)';
  }
  updateSecretPresetIndicator();
  if (showNotification && savedOk) {
    showToast('현재 상태가 브라우저에 저장되었습니다.', 'success');
  }
  return savedOk;
}

// 1~7번 전체 학급 데이터를 기존 난독화 포맷으로 묶어 직렬화한다.
// 복원 측과 동일한 validateBundleSlotPayload()로 사전 검증해 복원 불가능한 손상·미래버전 슬롯의 유입을 차단하고 제외 목록을 함께 반환한다.
export function buildMultiClassBundlePayload(readSlotFn = readSlotRawText) {
  const state = AppStore.getState();
  const meta = loadMultiClassMeta();
  const activeSlot = getActiveClassSlot();
  const slots = {};
  const skippedSlots = [];
  const futureSkippedSlots = [];
  for (let slot = 1; slot <= MULTI_CLASS_SLOT_COUNT; slot++) {
    if (slot === activeSlot) {
      slots[String(slot)] = AppStore.getPersistedState(state);
      meta.titles[slot - 1] = String(state.classTitle || `학급 ${slot}`).trim().slice(0, 40) || `학급 ${slot}`;
    } else {
      const raw = readSlotFn(slot);
      if (raw && String(raw).trim()) {
        try {
          const parsed = parseSeatFileText(raw);
          if (isUnsupportedFutureSchemaPayload(parsed)) {
            skippedSlots.push(slot);
            futureSkippedSlots.push(slot);
            logStorageWarning(`[storage-io] ${slot}번 학급 슬롯은 상위 스키마 버전이어서 다중학급 백업에서 제외되었습니다.`);
            continue;
          }
          const validSlot = validateBundleSlotPayload(parsed);
          if (validSlot) {
            slots[String(slot)] = validSlot;
            if (typeof validSlot.classTitle === 'string' && validSlot.classTitle.trim()) {
              meta.titles[slot - 1] = validSlot.classTitle.trim().slice(0, 40);
            }
          } else {
            skippedSlots.push(slot);
            logStorageWarning(`[storage-io] ${slot}번 학급 슬롯의 스키마가 유효하지 않아 다중학급 백업에서 제외되었습니다.`);
          }
        } catch (err) {
          skippedSlots.push(slot);
          logStorageWarning(`[storage-io] ${slot}번 학급 슬롯 파싱 실패로 다중학급 백업에서 제외되었습니다:`, err);
        }
      }
    }
  }
  const payload = encodeMultiClassBundle({
    _multiClassBundle: true,
    schemaVersion: CURRENT_SCHEMA_VERSION,
    exportedAt: new Date().toISOString(),
    multiClassEnabled: Boolean(meta.enabled),
    activeSlot,
    titles: meta.titles,
    slots,
    customLayouts: loadCustomLayouts()
  });
  return { payload, skippedSlots, futureSkippedSlots };
}

export async function saveWithFileExplorer() {
  const state = AppStore.getState();
  AppStore.flushPendingCommit();
  saveToStorage(false);
  const meta = loadMultiClassMeta();
  const suggestedName = meta.enabled
    ? `${sanitizeFileName(state.classTitle || '학급자리배치')}_전체백업.json`
    : `${sanitizeFileName(state.classTitle || '우리반_자리배치표')}.json`;

  if (typeof window.showSaveFilePicker === 'function') {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName,
        types: [{
          description: '자리 배치 백업 JSON 파일 (전체 학급)',
          accept: { 'application/json': ['.json'] }
        }]
      });
      const { payload: dataStr, skippedSlots } = buildMultiClassBundlePayload();
      const writable = await handle.createWritable();
      await writable.write(dataStr);
      await writable.close();
      markDirty(false);
      const saveText = document.getElementById('saveStateBtnText');
      if (saveText) {
        saveText.textContent = '✓ 저장 완료';
        setTimeout(() => {
          const latestState = AppStore.getState();
          if (saveText) saveText.textContent = latestState.isDirty ? '저장하기 ●' : '저장하기';
        }, 1500);
      }
      if (skippedSlots.length > 0) {
        showToast(`백업 파일이 저장되었으나 손상·미호환 ${skippedSlots.join('·')}번 학급 슬롯은 제외되었습니다.`, 'warn');
      } else {
        showToast('지정한 폴더 위치에 전체 학급 백업 파일이 성공적으로 저장되었습니다!', 'success');
      }
      return;
    } catch (err) {
      if (err && err.name === 'AbortError') {
        showToast('파일 저장이 취소되었습니다.', 'info');
        return;
      }
    }
  }

  const modal = document.getElementById('saveFileModal');
  const input = document.getElementById('saveFileNameInput');
  if (modal && input) {
    input.value = suggestedName;
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    input.focus();
    input.select();
  }
}

export function triggerBrowserDownload(fileName) {
  const cleanName = sanitizeFileName((fileName || '우리반_자리배치표.json').replace(/\.json$/i, '')) + '.json';
  const { payload: dataStr, skippedSlots } = buildMultiClassBundlePayload();
  const blob = new Blob([dataStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = cleanName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  markDirty(false);
  if (skippedSlots.length > 0) {
    showToast(`'${cleanName}' 파일이 저장되었으나 손상·미호환 ${skippedSlots.join('·')}번 학급 슬롯은 제외되었습니다.`, 'warn');
  } else {
    showToast(`'${cleanName}' 파일(전체 학급 백업)이 저장되었습니다.`, 'success');
  }
  return { ok: true, skippedSlots };
}

export function loadFromStorage(fallbackTitle = '우리 반 자리 배치표') {
  const state = AppStore.getState();
  state._corruptedStorageRecovered = false;
  state._corruptedBackupSaved = false;
  state._futureSchemaBlocked = false;

  const activeKey = getActiveStorageKey();
  let raw = null;
  let legacyKeyUsed = null;
  raw = safeStorageGet(activeKey);
  if (!raw && activeKey === STORAGE_KEY) {
    for (const lk of LEGACY_STORAGE_KEYS) {
      const lraw = safeStorageGet(lk);
      if (lraw) { raw = lraw; legacyKeyUsed = lk; break; }
    }
  }
  if (!raw) {
    _protectedFutureSlotKeys.delete(activeKey);
    return false;
  }

  const needsReObfuscate = !isSimpleObfuscatedText(raw);
  let parsed = null;
  let parseThrew = false;
  try {
    parsed = parseSeatFileText(raw);
  } catch (err) {
    parseThrew = true;
    logStorageWarning('[storage-io] 저장소 데이터 디코딩/파싱 실패:', err);
  }

  // 상위 버전(schemaVersion > CURRENT_SCHEMA_VERSION)에서 저장된 정상 데이터는 손상 처리·삭제하지 않고 원본을 보호한다.
  if (!parseThrew && isUnsupportedFutureSchemaPayload(parsed)) {
    _protectedFutureSlotKeys.add(activeKey);
    state._futureSchemaBlocked = true;
    showToast('상위 버전에서 저장된 데이터입니다. 데이터 보호를 위해 원본을 유지했으니 최신 버전 프로그램을 실행해 주세요.', 'warn');
    return false;
  }

  let appliedOk = false;
  if (!parseThrew && parsed !== null) {
    try {
      appliedOk = AppStore.applyLoadedData(parsed, fallbackTitle, true);
    } catch (err) {
      logStorageWarning('[storage-io] 저장소 데이터 스키마 적용 중 예외 발생:', err);
      appliedOk = false;
    }
  }

  if (appliedOk) {
    _protectedFutureSlotKeys.delete(activeKey);
    const curState = AppStore.getState();
    curState.lastSavedAt = (typeof parsed.lastSavedAt === 'string' && parsed.lastSavedAt.trim()) ? parsed.lastSavedAt.trim().slice(0, 40) : null;
    // 평문 데이터나 이전 키 데이터는 현재 형식으로 다시 저장하고, 실제 저장이 성공한 경우에만 구버전 키를 정리한다.
    if (needsReObfuscate || legacyKeyUsed) {
      try {
        const migratedSaved = safeStorageSet(activeKey, getObfuscatedPayload());
        if (migratedSaved && legacyKeyUsed) {
          safeStorageRemove(legacyKeyUsed);
        }
      } catch (reencErr) {
        logStorageWarning('[storage-io] 구버전 데이터 재직렬화 중 오류:', reencErr);
      }
    }
    return true;
  }

  _protectedFutureSlotKeys.delete(activeKey);
  if (String(raw).trim()) {
    const backupKey = `${activeKey}_corrupted_backup`;
    const backedUp = safeStorageSet(backupKey, String(raw));
    if (backedUp) {
      safeStorageRemove(activeKey);
      if (legacyKeyUsed) safeStorageRemove(legacyKeyUsed);
      state._corruptedStorageRecovered = true;
      state._corruptedBackupSaved = true;
      showToast('저장된 데이터가 손상되어 백업 키에 보관하고 기본 상태로 시작했습니다.', 'warn');
    } else {
      // 브라우저 저장 공간 부족으로 백업 키 기록에 실패하면 원본 키를 삭제하지 않아 영구 유실을 방지한다.
      delete _memoryStorageFallback[backupKey];
      state._corruptedStorageRecovered = true;
      state._corruptedBackupSaved = false;
      showToast('저장된 데이터가 손상되었으나 브라우저 저장 공간이 부족해 원본을 유지한 채 기본 상태로 시작했습니다.', 'warn');
    }
  }
  return false;
}
