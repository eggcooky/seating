// [L3] 오프라인 Web Audio API 효과음 합성기
import { AppStore } from '../state/store.js';
import { isDiagStorageSandboxActive } from './storage-io.js';

let _sharedAudioCtx = null;

export function playSoundEffect(type = 'reveal') {
  const state = AppStore.getState();
  if (AppStore.isRunningSelfDiagnostics() || isDiagStorageSandboxActive() || state.soundEnabled === false) return;
  if (typeof window === 'undefined') return;
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  if (!AudioCtx) return;

  try {
    if (!_sharedAudioCtx || _sharedAudioCtx.state === 'closed') {
      _sharedAudioCtx = new AudioCtx();
    }
    const ctx = _sharedAudioCtx;

    const synthesize = () => {
      try {
        const now = ctx.currentTime;
        const playNote = (freq, startOffset, duration, wave = 'sine', peakGain = 0.16) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = wave;
          osc.frequency.setValueAtTime(freq, now + startOffset);
          gain.gain.setValueAtTime(0.001, now + startOffset);
          gain.gain.linearRampToValueAtTime(peakGain, now + startOffset + 0.012);
          gain.gain.exponentialRampToValueAtTime(0.0001, now + startOffset + duration);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + startOffset);
          osc.stop(now + startOffset + duration + 0.01);
        };

        if (type === 'toggle') {
          playNote(523.25, 0, 0.09, 'sine', 0.15);
          playNote(659.25, 0.07, 0.14, 'sine', 0.17);
        } else if (type === 'select') {
          // 마우스로 첫 번째 책상(학생)을 클릭해 선택할 때의 가벼운 팝 소리
          playNote(659.25, 0, 0.075, 'sine', 0.14);
        } else if (type === 'swap') {
          // 마우스로 두 자리를 맞바꾸거나 빈칸으로 책상을 이동했을 때의 경쾌한 2음 스왑 소리
          playNote(523.25, 0, 0.085, 'triangle', 0.16);
          playNote(783.99, 0.065, 0.15, 'sine', 0.18);
        } else if (type === 'lock') {
          // 자물쇠로 자리를 고정할 때의 단단한 상향 클락음
          playNote(440.0, 0, 0.07, 'triangle', 0.15);
          playNote(659.25, 0.055, 0.12, 'triangle', 0.17);
        } else if (type === 'unlock') {
          // 자물쇠 고정을 해제하거나 선택을 취소할 때의 부드러운 하향음
          playNote(659.25, 0, 0.07, 'sine', 0.14);
          playNote(440.0, 0.055, 0.12, 'sine', 0.14);
        } else if (type === 'tick') {
          // 룰렛 원판 칸 경계를 지날 때의 짧은 클릭음
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(760, now);
          osc.frequency.exponentialRampToValueAtTime(280, now + 0.028);
          gain.gain.setValueAtTime(0.13, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.03);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now);
          osc.stop(now + 0.032);
        } else if (type === 'reveal') {
          // 가려진 좌석 하나가 열릴 때의 맑은 벨 소리
          playNote(587.33, 0, 0.11, 'sine', 0.16);
          playNote(880.0, 0.055, 0.18, 'triangle', 0.17);
        } else if (type === 'shuffle') {
          // 랜덤 자리 바꾸기 완료 시 경쾌한 상승 아르페지오
          playNote(523.25, 0, 0.10, 'triangle', 0.17);
          playNote(659.25, 0.06, 0.10, 'triangle', 0.17);
          playNote(783.99, 0.12, 0.12, 'triangle', 0.18);
          playNote(1046.50, 0.18, 0.25, 'sine', 0.20);
        } else if (type === 'win' || type === 'revealAll') {
          // 룰렛 당첨 확정 또는 전체 공개 완료 시 축하 팡파르
          playNote(523.25, 0, 0.11, 'triangle', 0.17);
          playNote(659.25, 0.08, 0.11, 'triangle', 0.17);
          playNote(783.99, 0.16, 0.12, 'triangle', 0.18);
          playNote(1046.50, 0.24, 0.34, 'sine', 0.20);
          playNote(783.99, 0.24, 0.34, 'triangle', 0.12);
        }
      } catch (innerErr) {}
    };

    if (ctx.state === 'suspended') {
      if (type === 'tick') {
        ctx.resume().catch(() => {});
        return;
      }
      ctx.resume().then(synthesize).catch(() => {});
    } else {
      synthesize();
    }
  } catch (e) {}
}
